// SPDX-License-Identifier: Apache-2.0
// Generated from validated build inputs. Do not edit.
#ifndef VORTEX_AI_P05_BUILD_CONFIG_H
#define VORTEX_AI_P05_BUILD_CONFIG_H
#include <array>
#include <cstdint>
namespace vortex_ai_python::build {
struct Artifact {
  const char* role;
  const char* path;
  const char* sha256;
  std::uint64_t size;
};
inline constexpr char bundle_sha256[] = "504852a59f0654e94a2eef5a15fd8d141f70d59fc278590aada3ff24e29e2fd1";
inline constexpr char source_sha256[] = "c4d476be1ab3dd73fbbe9b3027aac78db4a4890e536efea57319aecffcd6b19a";
inline constexpr char backend[] = "simx";
inline constexpr char format[] = "fp16";
inline constexpr char qualification_id[] = "bdf65307dae6237099fbe96341e01762bf4f8818b191d8fbee590aeb0a816a78";
inline constexpr char source_revision[] = "e1420fd550f716df33a2556057b7086a03032cbe";
inline constexpr std::array<Artifact, 6> artifacts{{
  {"backend", "lib/libvortex-simx.so", "b0985391810b9b2ea56748ff539e2807cf2b4a0523255849d3794d7434a33690", 97512ULL},
  {"module", "kernel.vxbin", "7258e2f1f9a46b187915c42c833bd7b51ed52dea568f83a1e766df44e0329fc4", 6192ULL},
  {"ramulator", "lib/libramulator.so", "10bcf59a01fecb757c6e54f1f490ee9d12f97ff127685907b3d11a8902bf9286", 5560480ULL},
  {"ramulator_extension", "lib/libramulator-vortex.so", "bffe1f935b7de7cf926b6a997137e8e4eef43a3ecd72fa33f6bf95feffa19d0f", 691624ULL},
  {"runtime", "lib/libvortex.so", "5998918e904b7d93d4d159515fb5830ab8d221c6d959a797b52c7d168e2e8ffe", 320392ULL},
  {"simulator", "lib/libsimx.so", "28c09331081d2bdaa95467f946fca759249d4715870c531d6259c52c05f8f475", 2455968ULL},
}};
}  // namespace vortex_ai_python::build
#endif
