// SPDX-License-Identifier: Apache-2.0
// Generated from validated build inputs. Do not edit.
#ifndef VORTEX_AI_P05_BUILD_CONFIG_H
#define VORTEX_AI_P05_BUILD_CONFIG_H
#include <array>
#include <cstdint>
namespace vortex_ai_python::build {
struct Artifact {
  const char* role;
  const char* path;
  const char* sha256;
  std::uint64_t size;
};
inline constexpr char bundle_sha256[] = "27b7f19ce9dfd239c7ff9a68e67e6a9fb0fe950076c25a694544be5b539eeb58";
inline constexpr char source_sha256[] = "c4d476be1ab3dd73fbbe9b3027aac78db4a4890e536efea57319aecffcd6b19a";
inline constexpr char backend[] = "simx";
inline constexpr char format[] = "bf16";
inline constexpr char qualification_id[] = "c5fd995f8fa7f941d44714e282f1bbc5897c4d62a4989cb2563608ff7e437262";
inline constexpr char source_revision[] = "e1420fd550f716df33a2556057b7086a03032cbe";
inline constexpr std::array<Artifact, 6> artifacts{{
  {"backend", "lib/libvortex-simx.so", "b0985391810b9b2ea56748ff539e2807cf2b4a0523255849d3794d7434a33690", 97512ULL},
  {"module", "kernel.vxbin", "1f63549c59b346c09f0f647f43f92f79ead20e426bec145e51de89443ca37b14", 6192ULL},
  {"ramulator", "lib/libramulator.so", "10bcf59a01fecb757c6e54f1f490ee9d12f97ff127685907b3d11a8902bf9286", 5560480ULL},
  {"ramulator_extension", "lib/libramulator-vortex.so", "bffe1f935b7de7cf926b6a997137e8e4eef43a3ecd72fa33f6bf95feffa19d0f", 691624ULL},
  {"runtime", "lib/libvortex.so", "5998918e904b7d93d4d159515fb5830ab8d221c6d959a797b52c7d168e2e8ffe", 320392ULL},
  {"simulator", "lib/libsimx.so", "28c09331081d2bdaa95467f946fca759249d4715870c531d6259c52c05f8f475", 2455968ULL},
}};
}  // namespace vortex_ai_python::build
#endif
