#!/usr/bin/env python3
"""Scratch-only paired CP harness mutation proof; explicit execution required."""

import argparse
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORK = HERE.parent.parent
REPO = WORK / "AI-GPU"
BASE = "7e4ac5851f1f71d292ed1802c3f92456d96faf8d"
BEFORE = "61658f38ee911ee85a8d0c7a70ba3cb5396b48f0ffeec664a0e8ea1b1734a8a9"
AFTER = "96ec63165a5064d2a5a10a9c4e0a385d36080899ab393caad281b9765cc64282"
SOURCE = Path("hw/unittest/cp_llc_port/main.cpp")
BUILD = WORK / "build-local-qualification-2/units"
MODEL = BUILD / "hw/unittest/cp_llc_port/obj_dir"
NATIVE = WORK / "local-qualification-run-2"
TOOL_ROOT = Path("$BASELINE_WORKSPACE")
CXX = TOOL_ROOT / "host-gcc11/usr/bin/g++"
VERILATOR = TOOL_ROOT / "tools-v3.0.2/verilator"
GIB, MIB = 1024 ** 3, 1024 ** 2
BUDGET = {"build_workers": 1, "min_free_bytes": 15 * GIB,
          "max_rss_bytes": GIB, "max_log_bytes": MIB,
          "compile_timeout_seconds": 60, "link_timeout_seconds": 30,
          "run_timeout_seconds": 10, "total_timeout_seconds": 600,
          "max_snapshot_bytes": 32 * MIB}

READ_BRANCH = """        } else {
            auto it = mem.find(r.addr);
            rsps.push_back({it != mem.end() ? it->second : 0, r.tag});
        }
"""
DROP_ALL = """        } else {
            std::fprintf(stderr, "MUTATION drop-all-read addr=0x%08x\\n", r.addr);
        }
"""
DROP_LATER = """        } else {
            if (r.addr == DATA_LINE + 32 * 7 + 5) {
                std::fprintf(stderr, "MUTATION drop-later-read addr=0x%08x\\n", r.addr);
            } else {
                auto it = mem.find(r.addr);
                rsps.push_back({it != mem.end() ? it->second : 0, r.tag});
            }
        }
"""
WRITE_LINE = "            mem[r.addr] = r.data;\n"
CORRUPT = """            mem[r.addr] = r.data;
            if (r.addr == DATA_LINE && r.data == 0x20000000) {
                mem[r.addr] ^= 1u;
                std::fprintf(stderr, "MUTATION corrupt-first-burst addr=0x%08x\\n", r.addr);
            }
"""
EXPECTATIONS = {
    "normal": {"old": [0, "PASSED", 0], "new": [0, "PASSED", 0]},
    "drop-all": {"old": [0, "PASSED", 5],
                 "new": [1, "exactly two DMA read responses must complete", 2]},
    "drop-later": {"old": [0, "PASSED", 1],
                   "new": [1, "DMA read completions missing", 1]},
    "corrupt-first": {"old": [0, "PASSED", 1],
                      "new": [1, "burst write value mismatch", 1]},
}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(MIB), b""):
            h.update(block)
    return h.hexdigest()


def record(path):
    path = Path(path)
    return {"path": str(path), "resolved_path": str(path.resolve(strict=True)),
            "sha256": sha(path), "size_bytes": path.stat().st_size}


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def mutate(text, mutation):
    if mutation == "normal":
        return text
    needle, replacement = {
        "drop-all": (READ_BRANCH, DROP_ALL),
        "drop-later": (READ_BRANCH, DROP_LATER),
        "corrupt-first": (WRITE_LINE, CORRUPT),
    }[mutation]
    require(text.count(needle) == 1, "mutation anchor is not unique: " + mutation)
    result = text.replace(needle, replacement)
    require(result.count("++writes_applied;") == 1, "write count altered")
    require(result.count("rsps.push_back({0, r.tag});") == 1, "flush acknowledgement altered")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", required=True)
    parser.add_argument("--proposed", action="store_true", required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{40}", args.revision) is not None, "full committed revision required")
    output = args.output.resolve()
    require(output.parent == HERE and output.name.startswith("b08d-run"), "output must be a fresh b08d-run directory")
    require(not output.exists(), "refusing to overwrite an existing proof")
    require(shutil.disk_usage(HERE).free >= 15 * GIB + 64 * MIB, "disk reserve unavailable")
    mem = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
    require(int(mem["MemAvailable"].split()[0]) * 1024 >= GIB, "available memory below one GiB")
    output.mkdir()
    for name in ("logs", "sources", "model", "support", "build", "tmp"):
        (output / name).mkdir()
    started = time.monotonic()
    report = {"scope": "paired C++ harness mutation proof against one unchanged native RTL model",
              "outcome": "not_run", "base_revision": BASE, "repository_revision": args.revision,
              "strengthened_source_committed": False, "strengthened_source_sha256": AFTER,
              "concurrent_work": {"native_qualification": "in_progress", "build_workers": 2,
                                  "authorization": "parent explicitly authorized isolated C++ matrix during native run"},
              "budget": BUDGET, "expectations": EXPECTATIONS, "commands": [],
              "cases": [], "snapshots": [], "limitations": [
                  "Reuses an existing generated RTL archive; does not re-elaborate RTL.",
                  "First-word read data and cache-model burst values only; no all-word or backpressure claim.",
                  "Expected negative exits are mutation evidence, not normal qualification passes.",
                  "Final read equality proves total completion accounting, not independent values for later reads."]}
    write_json(output / "expectations.json", EXPECTATIONS)
    write_json(output / "report.json", report)
    snapshot_bytes = 0

    def save():
        report["duration_seconds"] = round(time.monotonic() - started, 6)
        write_json(output / "report.json", report)

    def snapshot(source, dest):
        nonlocal snapshot_bytes
        source = Path(source)
        info = record(source)
        snapshot_bytes += info["size_bytes"]
        require(snapshot_bytes <= BUDGET["max_snapshot_bytes"], "snapshot budget exceeded")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
        require(sha(dest) == info["sha256"], "snapshot copy mismatch")
        require(not source.samefile(dest), "snapshot unexpectedly shares an inode")
        report["snapshots"].append({"source": info, "copy": str(dest.relative_to(output)), "distinct_inode": True})
        return dest

    runner_copy = snapshot(HERE / "b08d-baseline-process.py", output / "support/baseline_process.py")
    spec = importlib.util.spec_from_file_location("b08d_baseline_process", runner_copy)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    report["monitor_limitations"] = list(runner.LIMITATIONS)
    env = os.environ.copy()
    for key in ("CFLAGS", "CXXFLAGS", "LDFLAGS", "GCC_EXEC_PREFIX", "COMPILER_PATH", "CPATH", "CPLUS_INCLUDE_PATH", "LIBRARY_PATH", "LD_LIBRARY_PATH"):
        env.pop(key, None)
    env.update(PATH=str(CXX.parent) + ":/usr/bin:/bin", LC_ALL="C", LANG="C",
               TMPDIR=str(output / "tmp"), CCACHE_DISABLE="1", MAKEFLAGS="-j1", THREADS="1")
    report["command_environment"] = {k: env[k] for k in ("PATH", "LC_ALL", "LANG", "TMPDIR", "CCACHE_DISABLE", "MAKEFLAGS", "THREADS")}

    def command(name, argv, cwd, timeout, expected_exit=0):
        remaining = BUDGET["total_timeout_seconds"] - (time.monotonic() - started)
        require(remaining > 0, "overall time budget exhausted")
        memory = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
        require(int(memory["MemAvailable"].split()[0]) * 1024 >= GIB, "available memory below one GiB")
        log = output / "logs" / (name + ".log")
        result = runner.run_bounded([str(x) for x in argv], cwd, env, log,
                                    timeout_seconds=min(timeout, remaining), min_free_bytes=15 * GIB,
                                    max_rss_bytes=GIB, max_log_bytes=MIB,
                                    resource_paths=(output,), poll_seconds=0.05)
        item = {"name": name, "argv": [str(x) for x in argv], "cwd": str(cwd),
                "expected_exit": expected_exit, "log": str(log.relative_to(output)), **result}
        item["expected_exit_observed"] = (result["process_started"] and result["cleanup_complete"]
            and result["exit_code"] == expected_exit
            and result["reason"] == ("nonzero_exit" if expected_exit else None))
        report["commands"].append(item)
        save()
        require(item["expected_exit_observed"], "unexpected command result: " + name)
        return log.read_text()

    try:
        report["script"] = record(__file__)
        revision = command("git-revision", ["git", "rev-parse", "HEAD"], REPO, 10).strip()
        require(revision == args.revision, "repository revision changed")
        status = command("git-status", ["git", "status", "--porcelain", "--untracked-files=no"], REPO, 10)
        require(not status.strip(), "tracked repository is dirty")
        unchanged = command("git-model-inputs-unchanged", ["git", "diff", "--exit-code", BASE, args.revision, "--",
            "hw/rtl", "hw/dpi", "hw/unittest/cp_llc_port/VX_cp_llc_port_top.sv", "hw/unittest/common/vl_simulator.h",
            "hw/unittest/verilator.vlt.in", "VX_config.toml", "VX_types.toml", "configure", "ci/gen_config.py", "profiles"], REPO, 10)
        require(not unchanged.strip(), "RTL or configuration differs from the frozen model source")
        require(sha(REPO / SOURCE) == BEFORE, "frozen repository harness changed")
        report["repository_harness_before"] = record(REPO / SOURCE)
        original = (HERE / "b08d-original.cpp").read_text()
        strengthened = (HERE / "b08d-strengthened.cpp").read_text()
        require(sha(HERE / "b08d-original.cpp") == BEFORE, "original harness identity mismatch")
        require(sha(HERE / "b08d-strengthened.cpp") == AFTER, "review snapshot identity mismatch")
        native_bytes = (NATIVE / "report.json").read_bytes()
        native_report = json.loads(native_bytes)
        (output / "support/native-report-observed.json").write_bytes(native_bytes)
        report["native_packet"] = {"path": str(NATIVE / "report.json"), "sha256_at_observation": hashlib.sha256(native_bytes).hexdigest(),
                                  "size_bytes_at_observation": len(native_bytes), "may_change_during_concurrent_run": True}
        report["native_packet_outcome"] = native_report["outcome"]
        report["resources_before"] = {"free_disk_bytes": shutil.disk_usage(output).free,
                                      "available_memory_bytes": int(mem["MemAvailable"].split()[0]) * 1024}
        active_cp_before = {str(x.relative_to(MODEL.parent)): sha(x) for x in sorted(MODEL.parent.rglob("*")) if x.is_file()}
        report["active_cp_artifacts_before"] = active_cp_before
        report["tools"] = [record(x) for x in (
            CXX, CXX.parent.parent / "lib/gcc/x86_64-linux-gnu/11/cc1plus",
            CXX.parent.parent / "lib/gcc/x86_64-linux-gnu/11/collect2",
            Path("/usr/bin/as"), Path("/usr/bin/ld"), Path(sys.executable),
            VERILATOR / "bin/verilator", VERILATOR / "bin/verilator_bin")]
        command("compiler-version", [CXX, "--version"], output / "build", 10)
        for name in ("libstdc++.so", "libgcc_s.so"):
            located = command("compiler-path-" + name.replace("+", "p"), [CXX, "-print-file-name=" + name], output / "build", 10).strip()
            require(Path(located).is_file(), "compiler library unresolved")
            report["tools"].append(record(located))

        for file in sorted(MODEL.iterdir()):
            if file.is_file() and (file.name.startswith("VVX_cp_llc_port_top") or file.name in ("verilated.o", "verilated_threads.o")):
                snapshot(file, output / "model" / file.name)
        snapshot(REPO / "hw/unittest/common/vl_simulator.h", output / "support/common/vl_simulator.h")
        for directory in (REPO / "sw/common", BUILD / "sw", BUILD / "hw"):
            target = output / "support" / ("sw-common" if directory == REPO / "sw/common" else "generated-" + directory.name)
            target.mkdir(parents=True, exist_ok=True)
            for file in sorted(directory.glob("*.h")) + sorted(directory.glob("*.vh")):
                snapshot(file, target / file.name)
        snapshot(BUILD / "config.mk", output / "support/config.mk")
        snapshot(NATIVE / "logs/cp-llc-port-build.log", output / "support/native-build.log")
        for path in ("hw/unittest/cp_llc_port/VX_cp_llc_port_top.sv", "hw/rtl/mem/VX_cp_llc_port.sv"):
            require(sha(REPO / path) == sha(NATIVE / "artifacts/source" / path), "RTL differs from native packet")
            snapshot(REPO / path, output / "support/source" / path)
        verilated_inputs = re.findall(r'^S .* "([^\"]+)"$', (MODEL / "VVX_cp_llc_port_top__verFiles.dat").read_text(), re.M)
        report["model_inputs"] = [record(Path(x) if Path(x).is_absolute() else MODEL.parent / x) for x in verilated_inputs]
        header_inputs = re.findall(r" /[^\s\\]+", (MODEL / "main.d").read_text())
        report["compile_header_inputs"] = [record(x.strip()) for x in header_inputs if x.strip().endswith(".h")]
        model_records = {x.name: sha(x) for x in (output / "model").iterdir()}
        report["identical_model_sha256"] = model_records
        original_model_records = {x.name: sha(x) for x in MODEL.iterdir() if x.name in model_records}
        require(model_records == original_model_records, "copied model differs from source model")

        lines = (output / "support/native-build.log").read_text().splitlines()
        commands = [shlex.split(line) for line in lines if line.startswith("g++ ") and " -o main.o " in line]
        require(len(commands) == 1, "cannot identify the exact existing harness compile command")
        template = commands[0]
        require(template[-1] == str(REPO / SOURCE), "unexpected original harness path")
        include_map = {"-I.": "-I" + str(output / "model"),
            "-I" + str(REPO / "hw/unittest/cp_llc_port"): "-I" + str(output / "sources"),
            "-I" + str(REPO / "hw/unittest/common"): "-I" + str(output / "support/common"),
            "-I" + str(REPO / "sw/common"): "-I" + str(output / "support/sw-common"),
            "-I" + str(BUILD / "sw"): "-I" + str(output / "support/generated-sw"),
            "-I" + str(BUILD / "hw"): "-I" + str(output / "support/generated-hw")}
        flags = [include_map.get(x, x) for x in template[1:]]
        flags = flags[:flags.index("-c")]
        report["compile_flags"] = flags
        save()

        for mutation, outcomes in EXPECTATIONS.items():
            for harness, base_text in (("old", original), ("new", strengthened)):
                name = harness + "-" + mutation
                text = mutate(base_text, mutation)
                source = output / "sources" / (name + ".cpp")
                source.write_text(text)
                (output / "sources" / (name + ".patch")).write_text("".join(difflib.unified_diff(base_text.splitlines(True), text.splitlines(True), fromfile=harness + ".cpp", tofile=name + ".cpp")))
                obj, binary = output / "build" / (name + ".o"), output / "build" / name
                command(name + "-compile", [CXX, *flags, "-c", "-o", obj, source], output / "build", 60)
                command(name + "-link", [CXX, obj, output / "model/verilated.o", output / "model/verilated_threads.o",
                        output / "model/VVX_cp_llc_port_top__ALL.a", "-MMD", "-pthread", "-lpthread", "-latomic", "-o", binary], output / "build", 30)
                exit_code, marker, mutation_hits = outcomes[harness]
                log = command(name + "-run", [binary], output / "build", 10, exit_code)
                observed_hits = log.count("MUTATION ")
                okay = marker in log and observed_hits == mutation_hits and (("PASSED" in log) == (exit_code == 0))
                case = {"name": name, "source": record(source), "binary": record(binary),
                        "expected_exit": exit_code, "expected_marker": marker,
                        "expected_mutation_hits": mutation_hits, "observed_mutation_hits": observed_hits,
                        "expectation_met": okay}
                report["cases"].append(case)
                save()
                require(okay, "unexpected mutation observation: " + name)
        final_log = command("new-normal-final-run", [output / "build/new-normal"], output / "build", 10)
        require("PASSED" in final_log and "MUTATION " not in final_log, "final strengthened baseline failed")
        report["final_normal_rerun_passed"] = True
        require(model_records == {x.name: sha(x) for x in (output / "model").iterdir()}, "copied model changed")
        require(original_model_records == {x.name: sha(x) for x in MODEL.iterdir() if x.name in original_model_records}, "original model changed")
        active_cp_after = {str(x.relative_to(MODEL.parent)): sha(x) for x in sorted(MODEL.parent.rglob("*")) if x.is_file()}
        report["active_cp_artifacts_after"] = active_cp_after
        require(active_cp_after == active_cp_before, "active CP artifacts changed during proof")
        require(sha(REPO / SOURCE) == BEFORE, "repository source changed during proof")
        require(command("git-revision-after", ["git", "rev-parse", "HEAD"], REPO, 10).strip() == args.revision, "repository revision changed during proof")
        require(not command("git-status-after", ["git", "status", "--porcelain", "--untracked-files=no"], REPO, 10).strip(), "repository became dirty during proof")
        for entry in report["tools"] + report["model_inputs"] + report["compile_header_inputs"]:
            require(sha(entry["path"]) == entry["sha256"], "input changed during proof: " + entry["path"])
        report["unchanged_inputs_verified"] = True
        report["outcome"] = "pass"
    except Exception as error:
        report["outcome"] = "fail"
        report["error"] = str(error)
    finally:
        report["resources_after"] = {"free_disk_bytes": shutil.disk_usage(output).free}
        save()
        manifest = [record(x) for x in sorted(output.rglob("*")) if x.is_file() and x.name != "manifest.json"]
        write_json(output / "manifest.json", manifest)
    print(json.dumps({"outcome": report["outcome"], "output": str(output),
                      "cases": len(report["cases"]), "error": report.get("error")}), flush=True)
    return 0 if report["outcome"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
