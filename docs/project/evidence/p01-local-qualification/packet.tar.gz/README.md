# Local evidence publication (final)

This is a one-time, unsigned publication of retained records. It executes no test
or workload and is not a production gate. All phase/vendor qualification flags
remain false. Supplemental local execution does not establish vendor runtime,
platform, hw_emu, physical FPGA, cache-coherence or silicon qualification.

## Native attempts and the separate affected-unit follow-up

| Native attempt | Recorded outcome | Actual source revision |
|---|---|---|
| failed953 | fail | `9532327e6006e0b6b09bae761745bc0d36a79b1e` |
| retry7e4 | pass | `7e4ac5851f1f71d292ed1802c3f92456d96faf8d` |

The audited native export is preserved under `native-attempts/`, including its
own manifest, source identities, all logs/snapshots, failed/not-run outcomes and
matched full-suite sidecars. Its original verifier can check that subdirectory.

The separate two-unit follow-up records **pass** at revision `143c69fe284bc2a1628721cf8a4237ac82d2547d`, tree `e8bfd26fccec91bfbcf50242d197217c64d7078e`. It selects only `cp-llc-port` and `mm-axi-arb`; launcher exit **0**. Its source sidecar explicitly records `full_suite_executed: false`. Earlier full-suite results retain their original source identities.

## Nonqualification extras

`extras/diagnostic-stencil-n8/` is the completed 8-cubed, block-size-2 diagnostic,
with observed exit 0. It does not qualify the frozen 64-cubed case.
Its executable, kernel and runtime library identities remain in the record;
those binary bytes are not shipped.

`extras/cp-mutations/setup-failure/` preserves the failed inventory attempt:
five metadata commands completed, but no harness was compiled or simulated.
Its report, logs, expectations, exact failed runner and diagnosis are retained.

`extras/cp-mutations/proof/` is the later isolated paired C++ mutation proof.
Its report, command logs, source variants/diffs, executed runner and independent
verification are retained. The proof used one unchanged copied RTL model and a
proposed, uncommitted harness. These expected negative exits are mutation
evidence; they are not normal qualification passes or a fresh full native suite.

| Mutation case | Expected exit | Observed exit | Raw command outcome |
|---|---:|---:|---|
| old-normal | 0 | 0 | pass |
| new-normal | 0 | 0 | pass |
| old-drop-all | 0 | 0 | pass |
| new-drop-all | 1 | 1 | fail |
| old-drop-later | 0 | 0 | pass |
| new-drop-later | 1 | 1 | fail |
| old-corrupt-first | 0 | 0 | pass |
| new-corrupt-first | 1 | 1 | fail |

The final normal strengthened rerun passed. First-word checks and total read
completion accounting do not establish all-word data checks, independent later
read values, unique per-request identity or response-backpressure coverage.
The retained CP raw-packet manifests preserve all binary, object, static model
and unselected support identities. `manifest.json` explicitly lists omitted
members and states that their bytes were not reread by this publication helper.

`extras/preservation/` retains the completed source-preservation audit.
`extras/ci-guardrail/` retains one targeted host tooling test and its exact log.
Neither extra is a fresh full suite or additional native qualification run.

## Provenance, notes and verification

`index.json` separates these evidence scopes. `identities/` retains the dated
prepared-object audit and exact original Git commit bytes. Prepared objects do
not prove that a branch was published; only a separately retained later ref
observation can establish that. This packet includes 60 finalized agent notes.
The final mode requires all 60 ledger entries complete and each note's raw hash
matched before inclusion. Historical note statements retain their time context.

Root `manifest.json` inventories every distributed member except itself. Each
evidence row maps its exact raw path/hash/size to its public path/hash/size.
Embedded report hashes, expected/observed exits and byte counts continue to
identify raw evidence. Verify distributed bytes with public identities. Literal
path tokenization is documented in the redaction rules; tokens are inert display
labels. `$AGENT_TREE` denotes the logical agent task namespace, preserving each
unique task-name suffix; it is not a home or temporary filesystem root. Other
tokens separately identify filesystem prefixes and generic root labels in prose.

Use the original `export_final_packets.py verify DESTINATION` helper to check
distributed bytes; add `--raw-workspace RAW_WORKSPACE` to reproduce the exact
transformation. Verification does not authenticate original execution. The
manifest is unsigned; the printed bundle digest covers its bytes too.
Archive members are sorted, regular files only, mode 0644, with zero timestamps,
ownership and gzip timestamp, and no gzip filename. Directory and tar forms
contain identical bytes. Existing destinations and raw files are never replaced.
