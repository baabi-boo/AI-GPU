# Completed local qualification text packets

Each attempt directory retains its exact recorded outcome and source identity.
The root manifest distinguishes raw evidence from published, possibly redacted bytes.
Every retained report, log and text snapshot is included; no binary model is copied.

Verify with `python3 -B export_local_packets.py verify DESTINATION`. To also check
the raw-to-public relationship, add `--raw-workspace RAW_WORKSPACE`. Public-only
verification checks shipped bytes and their mapping, not original execution.
The manifest inventories every shipped file except itself and is unsigned.
The printed bundle digest includes the manifest and all member names and bytes.

Directory and optional gzip/tar forms contain identical member bytes. Archive
members have sorted paths, zero timestamps/ownership and mode 0644; the gzip
header has no filename and timestamp zero. No wall-clock export time or output
destination appears in generated content. Byte ceilings apply before writing.
