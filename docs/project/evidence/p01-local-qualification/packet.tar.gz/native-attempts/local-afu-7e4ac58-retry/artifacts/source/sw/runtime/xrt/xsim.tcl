#
# Copyright 2021 Xilinx, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

if {[info exists ::env(VORTEX_XRT_WAVEFORM)] && $::env(VORTEX_XRT_WAVEFORM) eq "1"} {
    log_wave -r *
}

#open_vcd xsim_dump.vcd
#log_vcd /*
#run all
#close_vcd
