# Local AFU attempt: failed953

Recorded native outcome: **fail**. Source revision
`9532327e6006e0b6b09bae761745bc0d36a79b1e`, tree `aeedbf4d7a042e86ec8d1326370a87dd73587494`.
Recorded interval: 2026-11-16T03:06:28+00:00 to 2026-11-16T03:08:50+00:00.
Outer launcher exit: **1**. Separate tooling-suite
outcome: **fail**, process exit
**1**. Individual command exits remain in the report.

| Selected case | Recorded outcome |
|---|---|
| demo | pass |
| reopen-cold | pass |
| reopen-warm | pass |
| axi-store-order | fail |
| cp-llc-port | not_run |
| mm-axi-arb | not_run |
| gemm-fp16 | not_run |
| gemm-bf16 | not_run |

`report.redacted.json` is derived from the complete raw report. Its original
`log_sha256`, snapshot hashes, sizes, outcomes and execution flags are preserved.
Those embedded hashes identify **raw bytes**. Root `manifest.json` records both
raw and public SHA-256/byte counts for each of the 121 retained evidence
files. Verify distributed bytes against **public** identities. Unchanged files
have equal raw and public identities. Reports and logs remain readable; source
snapshots are inert evidence and must not be run as an exported build tree.

Every raw packet file is retained, including every command log and text snapshot.
The matched suite JSON/log, native launcher, stdout/stderr, plan and command
sidecars are also retained. The plan's `pass` outcome describes preflight only.
The stdout report is a separately labeled, already partly redacted launcher copy;
the canonical raw-report relationship is the manifest's `report.redacted.json` row.

The aggregate execution flags can be true when only some cases verified; they
do not turn failed or not-run cases into passes. This is supplemental local
XRT-shim/model evidence. It does not establish vendor runtime, platform,
`hw_emu`, physical FPGA, cache-coherence or silicon qualification. The original
`qualifies_P01_A03` and `phase_complete` fields remain authoritative and false.
Binary executables, kernel images and simulator models referenced by identities
were never part of this text export and are not copied from the build tree.

`redaction-rules.json` lists inert display tokens, exact original-prefix hashes,
and replacement counts. Original prefixes remain in the private input mapping
and raw records. Replacement is literal UTF-8 bytes, longest prefix first;
nonmatching bytes and line endings are unchanged. The metadata is unsigned.
Public verification does not authenticate original execution. With the raw
workspace, the exporter can re-read all bytes and reproduce this transformation.
