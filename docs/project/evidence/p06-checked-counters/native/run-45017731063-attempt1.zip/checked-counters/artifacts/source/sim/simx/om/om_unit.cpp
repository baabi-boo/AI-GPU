// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "om_unit.h"
#include "core.h"
#include "constants.h"
#include "debug.h"
#include "types.h"

using namespace vortex;

// One beat per word in the aperture record: bit0 = colour, bit1 = depth. Only a
// record carrying both is expanded, so the count is always 2.
uint32_t OmUopGen::uop_count(const Instr& instr) {
  auto args = std::get<IntrOmArgs>(instr.get_args());
  uint32_t mask = args.export_mask & 0x3;
  assert(mask == 0x3);
  return ((mask >> 0) & 1) + ((mask >> 1) & 1);
}

Instr::Ptr OmUopGen::get(const Instr& macro_instr, uint32_t uop_index) {
  uint64_t parent_uuid = macro_instr.get_uuid();
  uint32_t total = uop_count(macro_instr);
  uint64_t uop_uuid = make_uop_uuid(parent_uuid, uop_index);

  auto args = std::get<IntrOmArgs>(macro_instr.get_args());

  auto uop_instr = std::allocate_shared<Instr>(pool_, uop_uuid, FUType::SFU);
  uop_instr->set_parent_uuid(parent_uuid);
  uop_instr->set_op_type(OmType::EXPORT);
  for (uint32_t i = 0; i < 3; ++i) {
    auto src = macro_instr.get_src_reg(i);
    uop_instr->set_src_reg(i, src.idx, src.type);
  }
  // Only the last beat completes the record, so only it carries the mask and
  // submits the fragment; the earlier beat is a bus transfer that retires but
  // has no OM side effect. A mask of 0 marks that staging beat.
  IntrOmArgs uopArgs{};
  uopArgs.export_mask = (uop_index + 1 == total) ? (args.export_mask & 0x3) : 0;
  uop_instr->set_args(uopArgs);
  // No other warp of the issue slot issues between the two beats of a record.
  uop_instr->set_fu_lock(uop_index == 0);
  uop_instr->set_fu_unlock(uop_index + 1 == total);
  return uop_instr;
}

// vx_om_export. Each lane carries its own aperture address plus colour/depth, so
// one packet covers the whole warp -- no sub-pixel loop and no window read.
//
// The address is passed through UNDECODED: turning it back into (x, y, face)
// needs the OM's aperture DCRs, which are cluster state. In hardware that decode
// lives at the OM ingress; here it is OmCore's job, for exactly the same reason.
instr_trace_t* OmUnit::process_export(instr_trace_t* trace, uint32_t export_mask) {
  if (req_out_.full()) {
    return nullptr;
  }

  OmReq req;
  req.uuid = trace->uuid;
  req.tag  = uint32_t(trace->uuid);
  req.from_aperture = true;
  req.export_mask   = export_mask;

  uint64_t mask_bits = 0;
  for (uint32_t t = 0; t < VX_CFG_NUM_THREADS; ++t) {
    if (!trace->tmask.test(t)) continue;
    req.addr[t]  = trace->src_data[0].at(t).u;   // aperture address
    req.color[t] = trace->src_data[1].at(t).u;
    req.depth[t] = trace->src_data[2].at(t).u;
    mask_bits |= (uint64_t(1) << t);
  }
  req.tmask_bits = mask_bits;

  req_out_.send(req);
  DT(3, "om-unit export: core=" << core_->id() << ", wid=" << trace->wid);
  return trace;
}
