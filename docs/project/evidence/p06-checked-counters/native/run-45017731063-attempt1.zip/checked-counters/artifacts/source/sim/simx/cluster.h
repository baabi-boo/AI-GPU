// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include "types.h"
#include "cache.h"
#ifdef VX_CFG_EXT_DXA_ENABLE
#include "dxa_core.h"
#endif
#ifdef VX_CFG_EXT_TEX_ENABLE
#include "tex_core.h"
#endif
#ifdef VX_CFG_EXT_OM_ENABLE
#include "om_core.h"
#endif
#ifdef VX_CFG_EXT_RASTER_ENABLE
#include "raster_core.h"
#endif
#ifdef VX_CFG_EXT_RTU_ENABLE
#include "rtu_core.h"
#endif
#ifdef VX_CFG_VM_ENABLE
#include "mem/tlb_l2.h"
#include "mem/ptw.h"
#endif

namespace vortex {

class ProcessorImpl;

class Socket;

class Cluster : public SimObject<Cluster> {
public:
  struct PerfStats {
    Cache::PerfStats l2cache;
#ifdef VX_CFG_EXT_DXA_ENABLE
    DxaCore::PerfStats dxa;
#endif
#ifdef VX_CFG_EXT_TEX_ENABLE
    TexCore::PerfStats tex;
    Cache::PerfStats   tcache;
#endif
#ifdef VX_CFG_EXT_RASTER_ENABLE
    RasterCore::PerfStats raster;
    Cache::PerfStats      rcache;
#endif
#ifdef VX_CFG_EXT_OM_ENABLE
    OmCore::PerfStats om;
    Cache::PerfStats  ocache;
#endif
#ifdef VX_CFG_EXT_RTU_ENABLE
    RtuCore::PerfStats rtu;
    Cache::PerfStats   rtcache;
#endif
#ifdef VX_CFG_VM_ENABLE
    L2Tlb::PerfStats l2tlb;
#endif
  };

  std::vector<SimChannel<MemReq>> mem_req_out;
  std::vector<SimChannel<MemRsp>> mem_rsp_in;

  // Global-barrier event links: every core's arrive end fans into
  // gbar_arrive_in; resume links fan back out, one per cluster core.
  SimEventLink<GbarArrive> gbar_arrive_in;
  std::vector<SimEventLink<GbarResume>> gbar_resume_out;

  // With more than one cluster the barrier spans clusters: arrivals go up to
  // the device-level GbarUnit and its resume comes back down here.
  SimEventLink<GbarArrive> gbar_fwd_out;
  SimEventLink<GbarResume> gbar_fwd_resume_in;

  Cluster(const SimContext& ctx,
          const char* name,
          uint32_t cluster_id,
          ProcessorImpl* processor);

  ~Cluster();

  uint32_t id() const { return cluster_id_; }

  ProcessorImpl* processor() const { return processor_; }

  bool running() const;

  int get_exitcode() const;

  PerfStats perf_stats() const;

  int dcr_write(uint32_t addr, uint32_t value);

#ifdef VX_CFG_VM_ENABLE
  // Host-side VM control: device SATP fan-out to the cores' L1 MMUs.
  void set_mmu_satp(uint64_t value);
  // The cluster L2 TLB's walker link, exported for the processor to bind
  // to the device-level walker (through the PtwMux).
  SimChannel<TlbReq>& ptw_req_out();
  SimChannel<TlbRsp>& ptw_rsp_in();
  // The walker's PTE-fetch client slot on this cluster's L2, valid only
  // under PTW_ON_L2 (the L2 is the LLC).
  SimChannel<MemReq>& ptw_mem_req_in();
  SimChannel<MemRsp>& ptw_mem_rsp_out();
#endif

  int dcr_read(uint32_t addr, uint32_t tag, uint32_t* value);

  class Core* get_core(uint32_t idx) const;

  // Cache flush walk. ProcessorImpl ticks in level order (L1 in parallel
  // → L2 → L3) to avoid downstream evictions racing the next-level walk.
  // L1 fanout: dcache + icache + socket-local {tcache, rtcache} (forwarded
  // to the sockets) + cluster-local {rcache, ocache}.
  void dcache_flush_begin(bool l1_only);
  bool dcache_flush_done() const;
  void icache_flush_begin();
  bool icache_flush_done() const;
#ifdef VX_CFG_EXT_TEX_ENABLE
  void tcache_flush_begin();
  bool tcache_flush_done() const;
#endif
#ifdef VX_CFG_EXT_RASTER_ENABLE
  void rcache_flush_begin();
  bool rcache_flush_done() const;
#endif
#ifdef VX_CFG_EXT_OM_ENABLE
  void ocache_flush_begin();
  bool ocache_flush_done() const;
#endif
#ifdef VX_CFG_EXT_RTU_ENABLE
  void rtcache_flush_begin();
  bool rtcache_flush_done() const;
#endif
  void l2_flush_begin(bool l1_only);
  // The L2, when it is the shared last-level cache, keeps its lines into the
  // next launch.
  void l2_keep_lines();
  // The command processor DMA's client slot on this cluster's L2, valid only
  // under CP_ON_L2 (the L2 is the LLC).
  SimChannel<MemReq>& cp_mem_req_in();
  SimChannel<MemRsp>& cp_mem_rsp_out();
  bool l2_flush_done() const;

#ifdef VX_CFG_EXT_RASTER_ENABLE
  // Cluster-shared raster engine (armed by the KMU's delegated draw launch;
  // the per-core SFU wave-pull launches covered-quad waves autonomously).
  RasterCore::Ptr& raster_core();
#endif

protected:
  void on_reset();

private:
  void on_gbar_arrive(const GbarArrive& msg);
  void on_gbar_fwd_resume(const GbarResume& msg);

  uint32_t       cluster_id_;
  ProcessorImpl* processor_;

  class Impl;
  Impl* impl_;

  friend class SimObject<Cluster>;
};

} // namespace vortex
