// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <stdint.h>
#include <type_traits>
#include <algorithm>
#include <cassert>
#include <array>

namespace vortex {
namespace tensor {

struct fp32 {
  using dtype = float;
  static constexpr uint32_t id = 0;
  static constexpr uint32_t bits = 32;
  static constexpr const char* name = "fp32";
};

struct fp16 {
  using dtype = uint16_t;
  static constexpr uint32_t id = 2;
  static constexpr uint32_t bits = 16;
  static constexpr const char* name = "fp16";
};

struct bf16 {
  using dtype = uint16_t;
  static constexpr uint32_t id = 3;
  static constexpr uint32_t bits = 16;
  static constexpr const char* name = "bf16";
};

struct fp8 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 4;
  static constexpr uint32_t bits = 8;
  static constexpr const char* name = "fp8";
};

struct bf8 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 5;
  static constexpr uint32_t bits = 8;
  static constexpr const char* name = "bf8";
};

struct tf32 {
  using dtype = uint32_t;
  static constexpr uint32_t id = 1;
  static constexpr uint32_t bits = 32;
  static constexpr const char* name = "tf32";
};

struct mxfp8 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 8;
  static constexpr uint32_t bits = 8;
  static constexpr uint32_t scale_bits = 8;
  static constexpr uint32_t ele_block = 32;
  static constexpr const char* name = "mxfp8";
};

struct mxbf8 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 9;
  static constexpr uint32_t bits = 8;
  static constexpr uint32_t scale_bits = 8;
  static constexpr uint32_t ele_block = 32;
  static constexpr const char* name = "mxbf8";
};

struct mxfp4 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 10;
  static constexpr uint32_t bits = 4;
  static constexpr uint32_t scale_bits = 8;
  static constexpr uint32_t ele_block = 32;
  static constexpr const char* name = "mxfp4";
};

struct nvfp4 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 11;
  static constexpr uint32_t bits = 4;
  static constexpr uint32_t scale_bits = 8;
  static constexpr uint32_t ele_block = 16;
  static constexpr const char* name = "nvfp4";
};

struct int32 {
  using dtype = int32_t;
  static constexpr uint32_t id = 16;
  static constexpr uint32_t bits = 32;
  static constexpr const char* name = "i32";
};

struct int8 {
  using dtype = int8_t;
  static constexpr uint32_t id = 17;
  static constexpr uint32_t bits = 8;
  static constexpr const char* name = "i8";
};

struct uint8 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 18;
  static constexpr uint32_t bits = 8;
  static constexpr const char* name = "u8";
};

struct int4 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 19;
  static constexpr uint32_t bits = 4;
  static constexpr const char* name = "i4";
};

struct uint4 {
  using dtype = uint8_t;
  static constexpr uint32_t id = 20;
  static constexpr uint32_t bits = 4;
  static constexpr const char* name = "u4";
};

inline const char* fmt_string(uint32_t fmt) {
  switch (fmt) {
  case fp32::id:   return fp32::name;
  case fp16::id:   return fp16::name;
  case bf16::id:   return bf16::name;
  case fp8::id:    return fp8::name;
  case bf8::id:    return bf8::name;
  case tf32::id:   return tf32::name;
  case mxfp8::id:  return mxfp8::name;
  case mxbf8::id:  return mxbf8::name;
  case mxfp4::id:  return mxfp4::name;
  case nvfp4::id:  return nvfp4::name;
  case int32::id:  return int32::name;
  case int8::id:   return int8::name;
  case uint8::id:  return uint8::name;
  case int4::id:   return int4::name;
  case uint4::id:  return uint4::name;
  default:         return "";
  }
}

// WGMMA shared-memory matrix descriptor (32-bit): the slab's byte offset from
// the local memory base in [17:0], and its row stride in 4-byte words in
// [31:18], 0 selecting the block-major layout.
constexpr uint32_t smem_desc_offset_bits = 18;
constexpr uint32_t smem_desc_stride_lg   = 2;

inline constexpr uint32_t smem_desc_pack(uint32_t offset, uint32_t stride) {
  return ((stride >> smem_desc_stride_lg) << smem_desc_offset_bits) | offset;
}

inline constexpr uint32_t smem_desc_offset(uint32_t desc) {
  return desc & ((1u << smem_desc_offset_bits) - 1);
}

inline constexpr uint32_t smem_desc_stride(uint32_t desc) {
  return (desc >> smem_desc_offset_bits) << smem_desc_stride_lg;
}

// The TCU accumulates and returns fp32 (int32 for integer inputs); it has no
// other output format.
inline constexpr bool tcu_output_valid(uint32_t it, uint32_t ot) {
  return (it >= int32::id) ? (ot == int32::id) : (ot == fp32::id);
}

inline constexpr bool mx_scale_format(uint32_t fmt) {
  switch (fmt) {
  case mxfp8::id:
  case mxbf8::id:
  case mxfp4::id:
  case nvfp4::id:
    return true;
  default:
    return false;
  }
}

inline constexpr uint32_t mx_scale_block_size(uint32_t fmt) {
  switch (fmt) {
  case mxfp8::id:
  case mxbf8::id:
  case mxfp4::id:
    return 32;
  case nvfp4::id:
    return 16;
  default:
    return 1;
  }
}

inline constexpr bool sparse_format_supported(uint32_t fmt) {
  switch (fmt) {
  case tf32::id:
  case fp16::id:
  case bf16::id:
  case fp8::id:
  case bf8::id:
  case int8::id:
  case uint8::id:
  case mxfp8::id:
  case mxbf8::id:
  case int4::id:
  case uint4::id:
  case mxfp4::id:
  case nvfp4::id:
    return true;
  default:
    return false;
  }
}

inline constexpr uint32_t sparse_meta_num_cols(uint32_t fmt, uint32_t nt) {
  switch (fmt) {
  case tf32::id:
    return (nt + 15) / 16;
  case fp16::id:
  case bf16::id:
    return (nt + 7) / 8;
  case fp8::id:
  case bf8::id:
  case int8::id:
  case uint8::id:
  case mxfp8::id:
  case mxbf8::id:
    return (nt + 3) / 4;
  case int4::id:
  case uint4::id:
  case mxfp4::id:
  case nvfp4::id:
    return (nt + 1) / 2;
  default:
    return 0;
  }
}

inline constexpr uint32_t sparse_meta_total_store_uops(uint32_t fmt, uint32_t stores_per_col, uint32_t nt, uint32_t cols_per_load) {
  uint32_t num_cols = sparse_meta_num_cols(fmt, nt);
  return ((num_cols + cols_per_load - 1) / cols_per_load) * stores_per_col;
}

template <uint32_t NT,      // number of threads per warp
          typename It = fp32, // input type (A,B)
          typename Ot = fp32, // output type (C,D)
          uint32_t NR = 8,  // registers per fragment
          uint32_t DK = 0,  // K dimension of the tile (0 for auto, inferred from NT and NR)
          uint32_t DP = 0,  // Dot-Product Length (0 for auto, inferred from NT)
          uint32_t XB = 4   // vector element type size in bytes
          >
struct wmma_config_t {
private:
  static constexpr uint32_t clog2(uint32_t x) {
    return (x < 2) ? 0 : (1 + clog2(x / 2));
  }
  static constexpr uint32_t tile_cap = NT * NR;
  static constexpr uint32_t lg_tile_cap = clog2(tile_cap);
  static constexpr uint32_t tile_en = lg_tile_cap / 2;
  static constexpr uint32_t tile_em = lg_tile_cap - tile_en;

  static constexpr uint32_t block_cap = NT;
  static constexpr uint32_t lg_block_cap = clog2(block_cap);
  static constexpr uint32_t block_en = lg_block_cap / 2;
  static constexpr uint32_t block_em = lg_block_cap - block_en;

public:

  static constexpr uint32_t i_ratio = XB / sizeof(typename It::dtype);
  static constexpr uint32_t o_ratio = XB / sizeof(typename Ot::dtype);
  static_assert(i_ratio * sizeof(typename It::dtype) == XB, "XB must be multiple of sizeof(It)");
  static_assert(o_ratio * sizeof(typename Ot::dtype) == XB, "XB must be multiple of sizeof(Ot)");

  static constexpr uint32_t xtileM = 1u << tile_em;
  static constexpr uint32_t xtileN = 1u << tile_en;
  static constexpr uint32_t xtileK = (DK != 0) ? DK : (tile_cap / ((xtileM > xtileN) ? xtileM : xtileN));

  static constexpr uint32_t tcM = 1u << block_em;
  static constexpr uint32_t tcN = 1u << block_en;
  static constexpr uint32_t tcK = (DP != 0) ? DP : (block_cap / ((tcM > tcN) ? tcM : tcN));

  static constexpr uint32_t m_steps = xtileM / tcM;  // number of M steps per register
  static constexpr uint32_t n_steps = xtileN / tcN;  // number of N steps per register
  static constexpr uint32_t k_steps = xtileK / tcK;  // number of K steps per register

  static constexpr uint32_t a_block_size = tcM * tcK;                 // size of A micro-tile
  static constexpr uint32_t a_sub_blocks = block_cap / a_block_size;  // number of A micro-tiles per register
  static constexpr uint32_t a_sub_steps  = m_steps / a_sub_blocks;    // number of A sub-steps per register

  static constexpr uint32_t b_block_size = tcK * tcN;                   // size of B micro-tile (dense)
  static constexpr uint32_t b_sub_blocks = block_cap / b_block_size;  // number of B micro-tiles per register
  static constexpr uint32_t b_sub_steps  = n_steps / b_sub_blocks;    // number of B sub-steps per register

  // Symmetric sparse flag (NT=4, NT=16: block_em == block_en). It selects the
  // WMMA_SP layout only, so a WGMMA build keeps it: WGMMA_SP has its own.
  static constexpr bool sym_sparse = (block_em == block_en);

  // Symmetric: column-pair layout (block_cap lanes per block)
  // Asymmetric: standard interleaved layout (tcK × tcN × 2 = block_cap lanes per block)
  static constexpr uint32_t b_block_size_sp = sym_sparse ? block_cap : (tcK * tcN) * 2;
  static constexpr uint32_t b_sub_blocks_sp = block_cap / b_block_size_sp;
  static constexpr uint32_t b_sub_steps_sp  = n_steps / b_sub_blocks_sp;

  static constexpr uint32_t NRA = (xtileM * xtileK) / NT; // Number of A registers
  static constexpr uint32_t NRB = (xtileN * xtileK) / NT; // Number of B registers
  static constexpr uint32_t NRC = (xtileM * xtileN) / NT; // Number of C registers

  static_assert((m_steps / a_sub_blocks) != 0, "tcK is too small for tile A");
  static_assert((n_steps / b_sub_blocks) != 0, "tcK is too small for tile B");

  static_assert(DK != 0 || (xtileM * xtileK <= tile_cap), "xtileM * xtileK <= tile_cap");
  static_assert(DK != 0 || (xtileN * xtileK <= tile_cap), "xtileN * xtileK <= tile_cap");
  static_assert((xtileM * xtileN <= tile_cap), "xtileM * xtileN <= tile_cap");

  static_assert((tcM * tcK <= block_cap), "tcM * tcK <= block_cap");
  static_assert((tcN * tcK <= block_cap), "tcN * tcK <= block_cap");
  static_assert((tcM * tcN <= block_cap), "tcM * tcN <= block_cap");

  static_assert((xtileM % tcM) == 0, "M,m divisibility");
  static_assert((xtileN % tcN) == 0, "N,n divisibility");
  static_assert((xtileK % tcK) == 0, "K,k divisibility");

  static constexpr uint32_t tileM = xtileM;
  static constexpr uint32_t tileN = xtileN;
  static constexpr uint32_t tileK = xtileK * i_ratio; // Adjusted for input type size

  // Metadata constants for 2:4 structured sparsity
  static constexpr uint32_t itype_bits = It::bits;
  static constexpr uint32_t rtl_i_ratio = 32 / itype_bits;
  static constexpr uint32_t meta_block_width = NT * 2 * rtl_i_ratio; // bits
  static constexpr uint32_t meta_cols = (meta_block_width + 31) / 32;
  static constexpr uint32_t per_warp_depth = m_steps * (k_steps / 2);
  static constexpr uint32_t meta_cols_per_load = (NT >= per_warp_depth) ? (NT / per_warp_depth) : 1;
  static constexpr uint32_t stores_per_col = (per_warp_depth + NT - 1) / NT;
  static constexpr uint32_t banks_per_store = (NT < per_warp_depth) ? NT : per_warp_depth;
  static constexpr uint32_t num_meta_loads = (per_warp_depth * meta_cols + NT - 1) / NT;
  static constexpr uint32_t meta_stride = num_meta_loads * NT;  // words per K-tile metadata
};

// Host-side WGMMA geometry (mirrors wgmma_context in vx_tensor.h)
//
// All geometry derived from NT and NRC alone (NRA=4 fixed):
//   tcM = 2^ceil(log2(NT)/2),  tcN = tcK = 2^floor(log2(NT)/2)
//   xtileM = 2*tcM,  xtileN = NRC*NT/xtileM,  xtileK = 2*tcK
//   m_steps = 2; k_steps is 2 normally, or 1 with a doubled-K WGMMA FEDP.
template <uint32_t NT, typename It, typename Ot, uint32_t NRC_ = 8>
struct wgmma_config_t {
private:
  static constexpr uint32_t clog2(uint32_t x) {
    return (x < 2) ? 0 : (1 + clog2(x / 2));
  }
  static constexpr uint32_t XB = 4;
  static constexpr uint32_t lg_NT = clog2(NT);
public:
  static constexpr uint32_t NRA = 4;
  static constexpr uint32_t i_ratio = XB / sizeof(typename It::dtype);
  static constexpr uint32_t tcM = 1u << ((lg_NT + 1) / 2);
  static constexpr uint32_t tcN = 1u << (lg_NT / 2);
  static constexpr uint32_t tcK = tcN;
  static constexpr uint32_t fedpK =
#ifdef VX_CFG_TCU_FEDP2K
      2 * tcK;
#else
      tcK;
#endif
  static constexpr uint32_t xtileM = 2 * tcM;
  static constexpr uint32_t xtileN = (NRC_ * NT) / xtileM;
  static constexpr uint32_t xtileK = 2 * tcK;
  static constexpr uint32_t tileK = xtileK * i_ratio;
  static constexpr uint32_t m_steps = 2;
  static constexpr uint32_t k_steps = xtileK / fedpK;
  static constexpr uint32_t b_blk_k = fedpK * i_ratio; // K elements per dense B block
  static constexpr uint32_t NRC = NRC_;
};

} // namespace tensor
} // namespace vortex
