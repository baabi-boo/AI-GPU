// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "fpu_unit.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <string.h>
#include <assert.h>
#include <util.h>
#include <rvfloats.h>
#include <nan_box.h>
#include "debug.h"
#include "core.h"
#include "csr_unit.h"
#include "constants.h"

using namespace vortex;

namespace {
inline uint64_t nan_box(uint32_t value) {
  return nanbox::box32(value);
}
inline int64_t check_boxing(int64_t a) {
  return nanbox::box32(nanbox::unbox32(a, 0x7fc00000));
}
inline uint64_t nan_box16(uint16_t value) {
  return nanbox::box16(value);
}
inline uint16_t check_boxing16(uint64_t a) {
  return nanbox::unbox16(a, 0x7e00);
}
}

FpuUnit::FpuUnit(const SimContext& ctx, const char* name, Core* core)
	// One output slot per tag: an operation holds its slot from acceptance
	// until its result is taken off the response port, however deep the
	// pipelines are.
	: FuncUnit<VX_CFG_NUM_FPU_BLOCKS>(ctx, name, core, VX_CFG_FPU_QUEUE_SIZE)
	, ReleaseOut(this, VX_CFG_ISSUE_WIDTH)
{
	if (!kGather) {
		// No buffer between the dispatch queue and the unit: the input holds
		// only the queue's head.
		for (auto& input : Inputs) {
			input = SimChannel<instr_trace_t*>(this, 1);
		}
	}
}

uint32_t FpuUnit::latency_of(const instr_trace_t* trace) const {
	auto fpu_type = std::get<FpuType>(trace->op_type);
	switch (fpu_type) {
	case FpuType::FCMP:
	case FpuType::FSGNJ:
	case FpuType::FCLASS:
	case FpuType::FMVXW:
	case FpuType::FMVWX:
	case FpuType::FMINMAX:
		return VX_CFG_FNCP_LATENCY;
	case FpuType::FADD:
	case FpuType::FSUB:
	case FpuType::FMUL:
	case FpuType::FMADD:
	case FpuType::FMSUB:
	case FpuType::FNMADD:
	case FpuType::FNMSUB:
		return VX_CFG_FMA_LATENCY;
	case FpuType::FDIV:
		return VX_CFG_FDIV_LATENCY;
	case FpuType::FSQRT:
		return VX_CFG_FSQRT_LATENCY;
	case FpuType::F2I:
	case FpuType::I2F:
	case FpuType::F2F:
		// A 64-bit build splits the 64-bit negate from the leading-zero count.
		return VX_CFG_FCVT_LATENCY + ((VX_CFG_XLEN == 64) ? 1 : 0);
	default:
		std::abort();
	}
}

namespace {
constexpr uint32_t pe_batches(uint32_t pe_ratio) {
  constexpr uint32_t kLanes = VX_CFG_NUM_FPU_LANES;
  return kLanes / std::max<uint32_t>(kLanes / pe_ratio, 1);
}
// A 64-bit FMA on fewer processing elements than the 32-bit one has its own
// pipeline and response arbiter input.
constexpr bool kFma64Split = (VX_CFG_FLEN >= 64)
                          && (pe_batches(VX_CFG_FMA64_PE_RATIO) != pe_batches(VX_CFG_FMA_PE_RATIO));
constexpr uint32_t kRspInputs = kFma64Split ? 5 : 4;
}

uint32_t FpuUnit::pipe_of(const instr_trace_t* trace) const {
  switch (std::get<FpuType>(trace->op_type)) {
  case FpuType::FADD:
  case FpuType::FSUB:
  case FpuType::FMUL:
  case FpuType::FMADD:
  case FpuType::FMSUB:
  case FpuType::FNMADD:
  case FpuType::FNMSUB: {
    const auto& fpu_args = std::get<IntrFpuArgs>(trace->instr_ptr->get_args());
    return (kFma64Split && fpu_args.is_f64) ? kPipeFma64 : kPipeFma;
  }
  case FpuType::FDIV:
    return kPipeDiv;
  case FpuType::FSQRT:
    return kPipeSqrt;
  case FpuType::F2I:
  case FpuType::I2F:
  case FpuType::F2F:
    return kPipeCvt;
  case FpuType::FCMP:
  case FpuType::FSGNJ:
  case FpuType::FCLASS:
  case FpuType::FMVXW:
  case FpuType::FMVWX:
  case FpuType::FMINMAX:
    return kPipeNcp;
  default:
    std::abort();
  }
}

uint32_t FpuUnit::batches_of(const instr_trace_t* trace) const {
  auto fpu_type = std::get<FpuType>(trace->op_type);
  switch (fpu_type) {
  case FpuType::FCMP:
  case FpuType::FSGNJ:
  case FpuType::FCLASS:
  case FpuType::FMVXW:
  case FpuType::FMVWX:
  case FpuType::FMINMAX:
    return pe_batches(VX_CFG_FNCP_PE_RATIO);
  case FpuType::FADD:
  case FpuType::FSUB:
  case FpuType::FMUL:
  case FpuType::FMADD:
  case FpuType::FMSUB:
  case FpuType::FNMADD:
  case FpuType::FNMSUB: {
    auto fpuArgs = std::get<IntrFpuArgs>(trace->instr_ptr->get_args());
    return fpuArgs.is_f64 ? pe_batches(VX_CFG_FMA64_PE_RATIO) : pe_batches(VX_CFG_FMA_PE_RATIO);
  }
  case FpuType::FDIV:
    return pe_batches(VX_CFG_FDIV_PE_RATIO);
  case FpuType::FSQRT:
    return pe_batches(VX_CFG_FSQRT_PE_RATIO);
  case FpuType::F2I:
  case FpuType::I2F:
  case FpuType::F2F:
    return pe_batches(VX_CFG_FCVT_PE_RATIO);
  default:
    std::abort();
  }
}

void FpuUnit::execute(instr_trace_t* trace) {
	auto& emu = core_->csr_unit();           // CSR/FCSR helpers
	// Use trace->tmask captured at issue, not the live warp.tmask; divergent
	// control flow may change the warp's tmask before this trace executes.
	auto& tmask = trace->tmask;
	auto& instr = *trace->instr_ptr;
	auto instrArgs = instr.get_args();
	auto fpuArgs = std::get<IntrFpuArgs>(instrArgs);
	auto fpu_type = std::get<FpuType>(trace->op_type);
	uint32_t wid = trace->wid;
	uint32_t num_threads = VX_CFG_NUM_THREADS;
	auto& rs1_data = trace->src_data[0];
	auto& rs2_data = trace->src_data[1];
	auto& rs3_data = trace->src_data[2];

	uint32_t thread_start = 0;
	for (; thread_start < num_threads; ++thread_start) {
		if (tmask.test(thread_start)) break;
	}

	trace->dst_data.assign(num_threads, reg_data_t{});
	auto& rd_data = trace->dst_data;

	switch (fpu_type) {
	case FpuType::FADD: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fadd_d(rs1_data[t].u64, rs2_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fadd_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FSUB: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fsub_d(rs1_data[t].u64, rs2_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fsub_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FMUL: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fmul_d(rs1_data[t].u64, rs2_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fmul_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FDIV: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fdiv_d(rs1_data[t].u64, rs2_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fdiv_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FSQRT: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fsqrt_d(rs1_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fsqrt_s(check_boxing(rs1_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FSGNJ: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				switch (fpuArgs.frm) {
				case 0: rd_data[t].u64 = rv_fsgnj_d(rs1_data[t].u64, rs2_data[t].u64); break;
				case 1: rd_data[t].u64 = rv_fsgnjn_d(rs1_data[t].u64, rs2_data[t].u64); break;
				case 2: rd_data[t].u64 = rv_fsgnjx_d(rs1_data[t].u64, rs2_data[t].u64); break;
				}
			} else {
				switch (fpuArgs.frm) {
				case 0: rd_data[t].u64 = nan_box(rv_fsgnj_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64))); break;
				case 1: rd_data[t].u64 = nan_box(rv_fsgnjn_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64))); break;
				case 2: rd_data[t].u64 = nan_box(rv_fsgnjx_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64))); break;
				}
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FMINMAX: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				if (fpuArgs.frm) rd_data[t].u64 = rv_fmax_d(rs1_data[t].u64, rs2_data[t].u64, &fflags);
				else             rd_data[t].u64 = rv_fmin_d(rs1_data[t].u64, rs2_data[t].u64, &fflags);
			} else {
				if (fpuArgs.frm) rd_data[t].u64 = nan_box(rv_fmax_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), &fflags));
				else             rd_data[t].u64 = nan_box(rv_fmin_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FCMP: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				switch (fpuArgs.frm) {
				case 0: rd_data[t].i = rv_fle_d(rs1_data[t].u64, rs2_data[t].u64, &fflags); break;
				case 1: rd_data[t].i = rv_flt_d(rs1_data[t].u64, rs2_data[t].u64, &fflags); break;
				case 2: rd_data[t].i = rv_feq_d(rs1_data[t].u64, rs2_data[t].u64, &fflags); break;
				}
			} else {
				switch (fpuArgs.frm) {
				case 0: rd_data[t].i = rv_fle_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), &fflags); break;
				case 1: rd_data[t].i = rv_flt_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), &fflags); break;
				case 2: rd_data[t].i = rv_feq_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), &fflags); break;
				}
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::F2I: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				switch (fpuArgs.cvt) {
				case 0: rd_data[t].i = sext((uint64_t)rv_ftoi_d(rs1_data[t].u64, frm, &fflags), 32); break;
				case 1: rd_data[t].i = sext((uint64_t)rv_ftou_d(rs1_data[t].u64, frm, &fflags), 32); break;
				case 2: rd_data[t].i = rv_ftol_d(rs1_data[t].u64, frm, &fflags); break;
				case 3: rd_data[t].i = rv_ftolu_d(rs1_data[t].u64, frm, &fflags); break;
				}
			} else {
				switch (fpuArgs.cvt) {
				case 0: rd_data[t].i = sext((uint64_t)rv_ftoi_s(check_boxing(rs1_data[t].u64), frm, &fflags), 32); break;
				case 1: rd_data[t].i = sext((uint64_t)rv_ftou_s(check_boxing(rs1_data[t].u64), frm, &fflags), 32); break;
				case 2: rd_data[t].i = rv_ftol_s(check_boxing(rs1_data[t].u64), frm, &fflags); break;
				case 3: rd_data[t].i = rv_ftolu_s(check_boxing(rs1_data[t].u64), frm, &fflags); break;
				}
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::I2F: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				switch (fpuArgs.cvt) {
				case 0: rd_data[t].u64 = rv_itof_d(rs1_data[t].i, frm, &fflags); break;
				case 1: rd_data[t].u64 = rv_utof_d(rs1_data[t].i, frm, &fflags); break;
				case 2: rd_data[t].u64 = rv_ltof_d(rs1_data[t].i, frm, &fflags); break;
				case 3: rd_data[t].u64 = rv_lutof_d(rs1_data[t].i, frm, &fflags); break;
				}
			} else {
				switch (fpuArgs.cvt) {
				case 0: rd_data[t].u64 = nan_box(rv_itof_s(rs1_data[t].i, frm, &fflags)); break;
				case 1: rd_data[t].u64 = nan_box(rv_utof_s(rs1_data[t].i, frm, &fflags)); break;
				case 2: rd_data[t].u64 = nan_box(rv_ltof_s(rs1_data[t].i, frm, &fflags)); break;
				case 3: rd_data[t].u64 = nan_box(rv_lutof_s(rs1_data[t].i, frm, &fflags)); break;
				}
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::F2F: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f16) {
				if (fpuArgs.cvt == 1) {
					rd_data[t].u64 = nan_box16(rv_dtoh(rs1_data[t].u64, frm, &fflags));
				} else {
					rd_data[t].u64 = nan_box16(rv_ftoh_s(check_boxing(rs1_data[t].u64), frm, &fflags));
				}
			} else if (fpuArgs.cvt == 2) {
				auto h = check_boxing16(rs1_data[t].u64);
				if (fpuArgs.is_f64) {
					rd_data[t].u64 = rv_htod(h, frm, &fflags);
				} else {
					rd_data[t].u64 = nan_box(rv_htof_s(h, frm, &fflags));
				}
			} else if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_ftod(check_boxing(rs1_data[t].u64), frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_dtof(rs1_data[t].u64, frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FCLASS: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].i = rv_fclss_d(rs1_data[t].u64);
			} else {
				rd_data[t].i = rv_fclss_s(check_boxing(rs1_data[t].u64));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FMVXW: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t fflags = 0;
			if (fpuArgs.is_f16) {
				rd_data[t].i = sext((uint64_t)uint16_t(rs1_data[t].u64), 16);
			} else if (fpuArgs.is_f64) {
				rd_data[t].u64 = rs1_data[t].u64;
			} else {
				uint32_t result = (uint32_t)rs1_data[t].u64;
				rd_data[t].i = sext((uint64_t)result, 32);
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FMVWX: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t fflags = 0;
			if (fpuArgs.is_f16) {
				rd_data[t].u64 = nan_box16(uint16_t(rs1_data[t].i));
			} else if (fpuArgs.is_f64) {
				rd_data[t].u64 = rs1_data[t].i;
			} else {
				rd_data[t].u64 = nan_box((uint32_t)rs1_data[t].i);
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FMADD: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fmadd_d(rs1_data[t].u64, rs2_data[t].u64, rs3_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fmadd_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), check_boxing(rs3_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FMSUB: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fmsub_d(rs1_data[t].u64, rs2_data[t].u64, rs3_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fmsub_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), check_boxing(rs3_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FNMADD: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fnmadd_d(rs1_data[t].u64, rs2_data[t].u64, rs3_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fnmadd_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), check_boxing(rs3_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	case FpuType::FNMSUB: {
		for (uint32_t t = thread_start; t < num_threads; ++t) {
			if (!tmask.test(t)) continue;
			uint32_t frm = emu.get_fpu_rm(fpuArgs.frm, wid, t);
			uint32_t fflags = 0;
			if (fpuArgs.is_f64) {
				rd_data[t].u64 = rv_fnmsub_d(rs1_data[t].u64, rs2_data[t].u64, rs3_data[t].u64, frm, &fflags);
			} else {
				rd_data[t].u64 = nan_box(rv_fnmsub_s(check_boxing(rs1_data[t].u64), check_boxing(rs2_data[t].u64), check_boxing(rs3_data[t].u64), frm, &fflags));
			}
			emu.update_fcrs(fflags, wid, t);
		}
	} break;
	default:
		std::abort();
	}
	DT(3, this->name() << " execute: op=" << fpu_type << ", " << *trace);
}

void FpuUnit::on_reset() {
  batch_idx_.fill(0);
  for (auto& pipes : results_) {
    for (auto& pipe : pipes) {
      pipe.clear();
    }
  }
  num_results_.fill(0);
  // the arbiter's reset seed gives its first input the first grant
  rsp_grant_.fill(kRspInputs - 1);
}

void FpuUnit::respond(uint32_t b) {
  auto& pipes = results_.at(b);
  uint64_t now = SimPlatform::instance().cycles();
  auto ready = [&](uint32_t p) {
    return !pipes.at(p).empty() && pipes.at(p).front().ready <= now;
  };
  for (uint32_t i = 1; i <= kRspInputs; ++i) {
    uint32_t input = (rsp_grant_.at(b) + i) % kRspInputs;
    uint32_t p = input;
    if (input == kPipeDiv && !ready(kPipeDiv)) {
      p = kPipeSqrt;
    }
    if (!ready(p)) {
      continue;
    }
    // the arbiter's output register
    if (Outputs.at(b).try_send(pipes.at(p).front().trace, 1)) {
      pipes.at(p).pop_front();
      --num_results_.at(b);
      rsp_grant_.at(b) = input;
    }
    return;
  }
}

void FpuUnit::on_tick() {
  bool idle = true;
  for (uint32_t b = 0; b < VX_CFG_NUM_FPU_BLOCKS; ++b) {
    this->respond(b);
    auto& input = Inputs.at(b);
    if (!input.empty()) {
      auto& output = Outputs.at(b);
      // A full response port (every tag in use) stalls admission even though
      // the arithmetic pipelines are deeper.
      if (!output.full() && output.size() + num_results_.at(b) < output.capacity()) {
        auto trace = input.peek();
        // The operation holds the block's input, whatever its class, until its
        // last batch of lanes enters the pipeline.
        if (batch_idx_.at(b) + 1 < this->batches_of(trace)) {
          ++batch_idx_.at(b);
          idle = false;
          continue;
        }
        batch_idx_.at(b) = 0;
        this->execute(trace);
        // The result passes its class's zero-latency skid register to the
        // response arbiter, and keeps its tag until the lane gather, or
        // without one the commit arbiter, takes it.
        uint64_t ready = SimPlatform::instance().cycles() + this->latency_of(trace);
        results_.at(b).at(this->pipe_of(trace)).push_back({ready, trace});
        ++num_results_.at(b);
        input.pop();
        if (!kGather && trace->eop) {
          ReleaseOut.send(trace, 0);
        }
      }
    }
    idle &= (input.size() == 0) && (num_results_.at(b) == 0);
  }
  // sleep until a new trace is reserved toward an input.
  if (idle) {
    this->tick_sleep();
  }
}
