// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <memory>
#include "types.h"
#include <mempool.h>
#include "instr_trace.h"
#include "VX_config.h"
#ifdef VX_CFG_VM_ENABLE
#include "mem/tlb_types.h"
#endif

namespace vortex {

class Socket;
class ProcessorImpl;
class Scheduler;
class Scoreboard;
class CsrUnit;
class TcuUnit;
class SfuUnit;
class LocalMem;
class LocalMemSwitch;
class MemCoalescer;

class Core : public SimObject<Core> {
public:
  struct PerfStats {
    PerfCounter cycles = 0;
    PerfCounter instrs = 0;
    PerfCounter sched_idle = 0;
    PerfCounter active_warps = 0;
    PerfCounter stalled_warps = 0;
    PerfCounter issued_warps = 0;
    PerfCounter issued_threads = 0;
    PerfCounter fetch_stalls = 0;
    PerfCounter ibuf_stalls = 0;
    PerfCounter scrb_stalls = 0;
    PerfCounter opds_stalls = 0;
    PerfCounter alu_stalls = 0;
    PerfCounter fpu_stalls = 0;
    PerfCounter lsu_stalls = 0;
    PerfCounter sfu_stalls = 0;
  #ifdef VX_CFG_EXT_TCU_ENABLE
    PerfCounter tcu_stalls = 0;
  #endif
    PerfCounter branches   = 0;
    PerfCounter divergence = 0;
    PerfCounter alu_instrs = 0;
    PerfCounter fpu_instrs = 0;
    PerfCounter lsu_instrs = 0;
    PerfCounter sfu_instrs = 0;
  #ifdef VX_CFG_EXT_TCU_ENABLE
    PerfCounter tcu_instrs = 0;
  #endif
    PerfCounter ifetches = 0;
    PerfCounter loads = 0;
    PerfCounter stores = 0;
    PerfCounter ifetch_latency = 0;
    PerfCounter load_latency = 0;
  };

  std::vector<SimChannel<MemReq>> icache_req_out;
  std::vector<SimChannel<MemRsp>> icache_rsp_in;

  std::vector<SimChannel<MemReq>> dcache_req_out;
  std::vector<SimChannel<MemRsp>> dcache_rsp_in;

  // Warp releases from resolved branches (ALU) and warp-control ops (SFU).
  // A warp has at most one release in flight, so NUM_WARPS bounds each.
  SimChannel<uint32_t> branch_ctl_in;
  SimChannel<WarpCtl>  warp_ctl_in;
  SimChannel<uint32_t> bar_unlock_in;

  // Global-barrier event links, wired core <-> cluster at elaboration.
  SimEventLink<GbarArrive> gbar_arrive_out;
  SimEventLink<GbarResume> gbar_resume_in;

#ifdef VX_CFG_EXT_RASTER_ENABLE
  // Fragment-work-distributor event links, wired core <-> raster core.
  SimEventLink<FwdArm>  fwd_arm_in;
  SimEventLink<FwdDone> fwd_done_out;
#endif

  Core(const SimContext& ctx,
       const char* name,
       uint32_t core_id,
       Socket* socket
  );

  ~Core();

  bool running() const;

  void resume(uint32_t wid);

  bool has_pending_instrs(uint32_t wid) const;
  bool lsu_drained() const;

  void barrier_arrive(uint32_t bar_id, uint32_t count, uint32_t wid, bool is_sync_bar);

  void barrier_wait(uint32_t bar_id, uint32_t phase, uint32_t wid);

  void global_barrier_resume(uint32_t bar_id);

  void barrier_event_attach(uint32_t bar_id, uint32_t count = 1);

  void barrier_event_release(uint32_t bar_id);

  bool wspawn(uint32_t num_warps, Word nextPC);

  bool setTmask(uint32_t wid, const ThreadMask& tmask);

  uint32_t id() const {
    return core_id_;
  }

  Socket* socket() const {
    return socket_;
  }

  const std::shared_ptr<LocalMem>& local_mem() const;

  const std::shared_ptr<MemCoalescer>& mem_coalescer(uint32_t idx) const;

#ifdef VX_CFG_VM_ENABLE
  struct MmuPerfStats {
    uint64_t tlb_reads = 0;
    uint64_t tlb_hits = 0;
    uint64_t tlb_misses = 0;
    uint64_t tlb_evictions = 0;
  };

  // Combined icache + dcache MMU counters (one bank per core).
  MmuPerfStats mmu_perf_stats() const;

  // Miss/fill channel access for cluster-level TLB binding:
  // which 0 = dcache-side, 1 = icache-side.
  SimChannel<TlbReq>& tlb_miss_out(uint32_t which);
  SimChannel<TlbRsp>& tlb_fill_in(uint32_t which);

  // Device-idle TLB invalidation (host-driven flush broadcast).
#endif

  // Used by LsuUnit to drive the per-block load/store switch.
  const std::shared_ptr<LocalMemSwitch>& lmem_switch(uint32_t idx) const;

  ProcessorImpl* processor() const;

  Scheduler&  scheduler();
  Scoreboard& scoreboard();
  CsrUnit&    csr_unit();
  uint32_t    mpm_class() const;

  // DTM debug-only accessors (sim/simx/dtm/debug_module.cpp).
  Word dtm_get_pc(uint32_t wid) const;
  void dtm_set_pc(uint32_t wid, Word pc);
  Word dtm_get_ireg(uint32_t wid, uint32_t reg);
  void dtm_set_ireg(uint32_t wid, uint32_t reg, Word val);

  int dcr_write(uint32_t addr, uint32_t value);

  int dcr_read(uint32_t addr, uint32_t tag, uint32_t* value);

#ifdef VX_CFG_VM_ENABLE
  // Device satp — invoked from Cluster::set_mmu_satp on the MMU DCR write.
  // Fans out to both per-core MMUs (dcache + icache). Translation itself
  // happens asynchronously inside the Mmu SimObject; LSU/fetch emit VAs.
  void set_satp(uint64_t satp);
#endif


#ifdef VX_CFG_EXT_TCU_ENABLE
  std::shared_ptr<TcuUnit>& tcu_unit();
#endif

  std::shared_ptr<SfuUnit> sfu_unit();

  PoolAllocator<instr_trace_t, 64>& trace_pool();

  const PerfStats& perf_stats() const;
  PerfStats& perf_stats();

  int get_exitcode() const;

protected:
  void on_reset();
  void on_tick();

private:
  void on_gbar_resume(const GbarResume& msg);
#ifdef VX_CFG_EXT_RASTER_ENABLE
  void on_fwd_arm(const FwdArm& msg);
#endif

  uint32_t core_id_;
  Socket*  socket_;

  class Impl;
  Impl* impl_;

  friend class SimObject<Core>;
};

} // namespace vortex
