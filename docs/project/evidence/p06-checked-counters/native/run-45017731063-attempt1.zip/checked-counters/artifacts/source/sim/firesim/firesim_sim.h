// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <stdint.h>
#include <string>
#include <vector>

namespace vortex {

// Drives a Vortex target compiled by Golden Gate, either as a metasimulation
// or on an FPGA. The two differ only in which platform layer the simulator was
// linked against, so this interface is identical for both.
//
// The simulator owns its own run loop and expects to be entered from main(),
// so it runs on a private thread and these calls are requests handed to it.
// Every call blocks until the simulator has serviced it, which keeps the target
// deterministic: nothing advances except when this interface asks it to.
class firesim_sim {
public:

  firesim_sim();
  virtual ~firesim_sim();

  // Starts the simulator thread and holds the target in reset until it is
  // ready to accept requests. `plusargs` go to the platform layer as given:
  // the image (+binary_file=...) and whatever else the platform needs to find
  // its card; a metasimulation takes none.
  int init(const std::vector<std::string>& plusargs);

  int mem_write(uint64_t addr, uint64_t size, const void* value);

  int mem_read(uint64_t addr, uint64_t size, void* value);

  int dcr_write(uint32_t addr, uint32_t value);

  // The response arrives on a later cycle than the request, so this advances
  // the target until the target asserts it or the bounded wait expires.
  int dcr_read(uint32_t addr, uint32_t tag, uint32_t* value);

  // Raises `start` for one target cycle. The kernel runs until `busy` drops.
  int start();

  // Advances the target and reports whether it is still executing. The target
  // only moves while this is being called, so a caller that stops polling
  // stops the simulation rather than leaving it running.
  int is_busy(bool* busy);

  // Polls until the target goes idle. `timeout_ms` bounds wall-clock time, not
  // target cycles; -1 waits indefinitely.
  int ready_wait(int64_t timeout_ms);

private:

  // Reports requested cycles against target cycles actually elapsed, then the
  // core's own counters. The two together separate a design that is idle from a
  // simulation that has stopped advancing it -- from outside, both look like a
  // quiet bus.
  void report_progress(const char *why);

  // Dumps Vortex's own performance counters, which say where inside the core a
  // stall is. Needs RTL built with PERF_ENABLE; see the definition.
  void report_core_counters();

  class Impl;
  Impl* impl_;

  // Target cycles the next is_busy() poll advances. Small while idle so a
  // launch cannot be missed, growing once the target is known to be running.
  uint32_t step_batch_;

  // Target cycles spent continuously busy, and whether this stall has already
  // been reported. Both reset when the target goes idle.
  uint64_t busy_cycles_;
  bool stall_reported_;

  // A launch waits for `busy` to rise and then to fall, and nothing bounds
  // either wait. These track the launch in flight so a target that never
  // starts is reported instead of polled forever in silence.
  bool awaiting_busy_;
  uint64_t idle_cycles_;

  // Set when the launch watchdog (VORTEX_FIRESIM_TIMEOUT_S) or a stop signal
  // gives up on a launch. The launch is then completed -- busy once, then idle
  // -- so the application finishes through its own teardown rather than being
  // killed mid-run.
  int abort_phase_;
  double launch_started_s_;

  // Set once the run is being stopped -- by a signal or by the watchdog -- and
  // never cleared: from then on nothing more is sent to the target.
  bool stopped_;
  bool stopped();

  // True while a report reads counters, which must reach the target even as
  // the run stops.
  bool reporting_;
  static void install_stop_handlers();
};

}
