// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include "types.h"
#include <mempool.h>
#include <array>
#include "instr_trace.h"
#include "instr.h"
#include "func_unit.h"
#include "tcu_tbuf.h"

// The TCU metadata SRAM is present when any metadata-consuming mode (MX or
// sparse) is enabled. Internal derived macro — not a VX_CFG_* knob; mirrors
// the hardware derivation.
#if defined(VX_CFG_TCU_MX_ENABLE) || defined(VX_CFG_TCU_SPARSE_ENABLE)
#define TCU_META_ENABLE
#endif

// TCU_LD memory ports: one per TCU block, through the LSU block that serves
// the same warps, when the LSU has one block per TCU block; otherwise all
// TCU blocks share LSU block 0, as in the RTL (VX_tcu_unit).
#ifndef TCU_AGU_PORTS
#define TCU_AGU_PORTS (uint32_t((VX_CFG_NUM_LSU_BLOCKS == VX_CFG_NUM_TCU_BLOCKS) ? VX_CFG_NUM_TCU_BLOCKS : 1))
#endif

namespace vortex {

class Core;

///////////////////////////////////////////////////////////////////////////////

// Micro-op generator for TCU instructions (WMMA/WGMMA).
// Owned by each per-warp Sequencer.
class TcuUopGen {
public:
  TcuUopGen(PoolAllocator<Instr, 64>& pool) : pool_(pool) {}

  // Returns total micro-op count for a macro instruction (>1 means macro-op).
  static uint32_t uop_count(const Instr& instr);

  // Generate micro-op Instr at uop_index for the given macro instruction.
  Instr::Ptr get(const Instr& macro_instr, uint32_t uop_index);

private:
  PoolAllocator<Instr, 64>& pool_;
};

///////////////////////////////////////////////////////////////////////////////

class TcuUnit : public FuncUnit<VX_CFG_NUM_TCU_BLOCKS> {
public:
  using Ptr = std::shared_ptr<TcuUnit>;

  static op_string_t op_string(TcuType tcu_type, IntrTcuArgs args);

	struct PerfStats {
		PerfCounter latency = 0;
		PerfCounter tbuf_stalls = 0;      // cycles a WGMMA uop waits on its A stripe or the B row, summed over buffers
		PerfCounter tbuf_cache_hits = 0;  // cycles the resident B row serves the representative block
		PerfCounter lmem_reads = 0;       // bank-row reads issued by the A and B buffers

		PerfStats& operator+=(const PerfStats& rhs) {
			this->latency          += rhs.latency;
			this->tbuf_stalls      += rhs.tbuf_stalls;
			this->tbuf_cache_hits  += rhs.tbuf_cache_hits;
			this->lmem_reads       += rhs.lmem_reads;
			return *this;
		}
	};

  TcuUnit(const SimContext &ctx, const char* name, Core* core);
  virtual ~TcuUnit();

#ifdef TCU_META_ENABLE
  // Metadata AGU ports (TCU_AGU_PORTS): TCU_LD issues load requests through
  // the LSU client ports; response fragments return here and accumulate into
  // the metadata SRAM.
  std::vector<SimChannel<LsuReq>> agu_req_out;
  std::vector<SimChannel<LsuRsp>> agu_rsp_in;
#endif

	void wmma(uint32_t wid,
	          uint32_t fmt_s,
	          uint32_t fmt_d,
	          uint32_t step_m,
	          uint32_t step_n,
	          uint32_t step_k,
	          const std::vector<reg_data_t>& rs1_data,
	          const std::vector<reg_data_t>& rs2_data,
	          const std::vector<reg_data_t>& rs3_data,
	          std::vector<reg_data_t>& rd_data,
	          bool is_sparse);

	void wgmma(uint32_t wid,
	           uint32_t fmt_s,
	           uint32_t fmt_d,
	           uint32_t step_m,
	           uint32_t step_n,
	           uint32_t step_k,
	           uint32_t a_desc,
	           uint32_t b_desc,
	           const std::vector<reg_data_t>& rs1_data,
	           const std::vector<reg_data_t>& rs2_data,
	           const std::vector<reg_data_t>& rs3_data,
	           std::vector<reg_data_t>& rd_data,
	           bool is_sparse,
	           uint32_t cd_nregs,
	           uint32_t is_a_smem,
	           uint32_t is_setup_uop);

	// Tile-buffer subsystem (owns abuf×Q + bbuf + LMEM arb); `Core` creates it
	// and binds its LMEM ports.
	void set_tbuf(TcuTbuf::Ptr tbuf);
	const TcuTbuf::Ptr& tbuf() const;

	const PerfStats& perf_stats() const;

protected:
  void on_reset() override;
  void on_tick() override;

private:
	class Impl;
	Impl* impl_;

	TcuTbuf::Ptr tbuf_;
};

} // namespace vortex
