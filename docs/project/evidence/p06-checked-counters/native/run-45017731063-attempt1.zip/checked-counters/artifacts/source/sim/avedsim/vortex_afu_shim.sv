// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "vortex_afu.vh"

module vortex_afu_shim #(
    parameter C_S_AXI_CTRL_ADDR_WIDTH = 16,  // covers legacy + CP regfile range

    parameter C_S_AXI_CTRL_DATA_WIDTH = 32,
    parameter C_M_AXI_MEM_ID_WIDTH    = `PLATFORM_MEMORY_ID_WIDTH,
    parameter C_M_AXI_MEM_DATA_WIDTH  = (`VX_CFG_PLATFORM_MEMORY_DATA_SIZE * 8),
    parameter C_M_AXI_MEM_ADDR_WIDTH  = 64,
    parameter C_M_AXI_MEM_NUM_BANKS   = `AFU_MEM_PORTS
) (
    // System signals
    input wire                                  ap_clk,
    input wire                                  ap_rst_n,

    // AXI4 master interface
    `MP_REPEAT (`AFU_MEM_PORTS, GEN_AXI_MEM, MP_COMMA),

    // AXI4 host-memory master interface (CP command ring + host side of DMA)
    `GEN_AXI_HOST,

    // AXI4-Lite slave interface
    input  wire                                 s_axi_ctrl_awvalid,
    output wire                                 s_axi_ctrl_awready,
    input  wire [C_S_AXI_CTRL_ADDR_WIDTH-1:0]   s_axi_ctrl_awaddr,
    input  wire                                 s_axi_ctrl_wvalid,
    output wire                                 s_axi_ctrl_wready,
    input  wire [C_S_AXI_CTRL_DATA_WIDTH-1:0]   s_axi_ctrl_wdata,
    input  wire [C_S_AXI_CTRL_DATA_WIDTH/8-1:0] s_axi_ctrl_wstrb,
    input  wire                                 s_axi_ctrl_arvalid,
    output wire                                 s_axi_ctrl_arready,
    input  wire [C_S_AXI_CTRL_ADDR_WIDTH-1:0]   s_axi_ctrl_araddr,
    output wire                                 s_axi_ctrl_rvalid,
    input  wire                                 s_axi_ctrl_rready,
    output wire [C_S_AXI_CTRL_DATA_WIDTH-1:0]   s_axi_ctrl_rdata,
    output wire [1:0]                           s_axi_ctrl_rresp,
    output wire                                 s_axi_ctrl_bvalid,
    input  wire                                 s_axi_ctrl_bready,
    output wire [1:0]                           s_axi_ctrl_bresp,
`IGNORE_WARNINGS_BEGIN
    output wire                                 interrupt
`IGNORE_WARNINGS_END
);
    vortex_afu #(
        .C_S_AXI_CONTROL_ADDR_WIDTH (C_S_AXI_CTRL_ADDR_WIDTH),
        .C_S_AXI_CONTROL_DATA_WIDTH (C_S_AXI_CTRL_DATA_WIDTH),
        .C_M_AXI_MEM_ID_WIDTH    (C_M_AXI_MEM_ID_WIDTH),
        .C_M_AXI_MEM_DATA_WIDTH  (C_M_AXI_MEM_DATA_WIDTH),
        .C_M_AXI_MEM_ADDR_WIDTH  (C_M_AXI_MEM_ADDR_WIDTH),
        .C_M_AXI_MEM_NUM_BANKS   (C_M_AXI_MEM_NUM_BANKS)
    ) afu (
        .ap_clk   (ap_clk),
        .ap_rst_n (ap_rst_n),

        `MP_REPEAT (`AFU_MEM_PORTS, AXI_MEM_ARGS, MP_COMMA),

        `AXI_HOST_ARGS,

        .s_axi_control_awvalid (s_axi_ctrl_awvalid),
        .s_axi_control_awready (s_axi_ctrl_awready),
        .s_axi_control_awaddr  (s_axi_ctrl_awaddr),
        .s_axi_control_wvalid  (s_axi_ctrl_wvalid),
        .s_axi_control_wready  (s_axi_ctrl_wready),
        .s_axi_control_wdata   (s_axi_ctrl_wdata),
        .s_axi_control_wstrb   (s_axi_ctrl_wstrb),
        .s_axi_control_arvalid (s_axi_ctrl_arvalid),
        .s_axi_control_arready (s_axi_ctrl_arready),
        .s_axi_control_araddr  (s_axi_ctrl_araddr),
        .s_axi_control_rvalid  (s_axi_ctrl_rvalid),
        .s_axi_control_rready  (s_axi_ctrl_rready),
        .s_axi_control_rdata   (s_axi_ctrl_rdata),
        .s_axi_control_rresp   (s_axi_ctrl_rresp),
        .s_axi_control_bvalid  (s_axi_ctrl_bvalid),
        .s_axi_control_bready  (s_axi_ctrl_bready),
        .s_axi_control_bresp   (s_axi_ctrl_bresp),

        .interrupt          (interrupt)
    );

endmodule
