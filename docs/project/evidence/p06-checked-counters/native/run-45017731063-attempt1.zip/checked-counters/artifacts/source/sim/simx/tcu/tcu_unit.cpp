
// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <VX_types.h>
#include "tcu_unit.h"
#include "tensor_cfg.h"
#include "fragment_layout.h"
#include <rvfloats.h>
#include <fedp.h>
#include "core.h"
#include "scheduler.h"
#include "local_mem.h"
#include "processor_impl.h"
#include "mem/memory.h"
#include "stack_interleave.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <type_traits>

using namespace vortex;

namespace vt = vortex::tensor;
using cfg    = vt::wmma_config_t<VX_CFG_NUM_THREADS>;
using wg_cfg = vt::wgmma_config_t<VX_CFG_NUM_THREADS, vt::fp32, vt::fp32>;
static constexpr uint32_t kFedpWords = wg_cfg::fedpK;
#ifdef VX_CFG_TCU_FEDP2K
static constexpr bool kFedp2K = true;
#else
static constexpr bool kFedp2K = false;
#endif

// Dot-product pipeline depth of the configured tensor-PE type.
static constexpr uint32_t kFedpLatency = VX_CFG_TCU_LATENCY;
// End-to-end MMA uop cost: dispatch plus the dot-product pipeline (an
// unblocked result bypasses the landing queue).
static constexpr uint32_t kMmaLatency = 1 + kFedpLatency;
// The FEDP array holds tcM x tcN / kPeRatio dot products: a compute uop
// occupies it for kPeRatio cycles, one output slice per cycle.
static constexpr uint32_t kPeRatio = VX_CFG_TCU_PE_RATIO;
static_assert(kPeRatio != 0 && (kPeRatio & (kPeRatio - 1)) == 0
           && ((cfg::tcM * cfg::tcN) % kPeRatio) == 0,
              "VX_CFG_TCU_PE_RATIO must be a power of two that divides tcM x tcN");
#ifdef VX_CFG_TCU_WGMMA_ENABLE
static_assert(VX_CFG_LMEM_ENABLED, "TCU_WGMMA_ENABLE requires LMEM_ENABLE");
static_assert(VX_CFG_LMEM_LOG_SIZE <= vt::smem_desc_offset_bits,
              "LMEM exceeds the smem descriptor offset field");
#endif

static constexpr uint64_t kLineMask = ~uint64_t(VX_CFG_MEM_BLOCK_SIZE - 1);

// WGMMA tile-buffer geometry in 32-bit words.
static constexpr uint32_t kLmemBanks     = VX_CFG_LMEM_NUM_BANKS;
static constexpr uint32_t kBankRowWords  = kLmemBanks * (VX_CFG_XLEN / 32);
static constexpr uint32_t kBBlockWords   = kFedpWords * cfg::tcN;
static constexpr uint32_t kBBlockWordsSp = cfg::tcK * cfg::tcN * 2;
// One bank row holds kBSubBlocks consecutive dense B blocks.
static constexpr uint32_t kBSubBlocks =
    (VX_CFG_NUM_THREADS > kBBlockWords) ? (VX_CFG_NUM_THREADS / kBBlockWords) : 1;
// A sparse B block spanning two 32-bit bank rows takes two reads.
static constexpr bool kBSparseTwoFetch =
    (kBBlockWordsSp == 2 * kLmemBanks) && (VX_CFG_XLEN == 32);
// A block-major A stripe is m_steps blocks, each padded to whole bank rows.
static constexpr uint32_t a_stripe_reads(uint32_t block_words) {
  return (wg_cfg::m_steps * ((block_words + kLmemBanks - 1) / kLmemBanks) * kLmemBanks
          + kBankRowWords - 1) / kBankRowWords;
}
static constexpr uint32_t kAStripeReads   = a_stripe_reads(cfg::tcM * kFedpWords);
static constexpr uint32_t kAStripeReadsSp = a_stripe_reads(cfg::tcM * cfg::tcK);

inline uint64_t nan_box(uint32_t value) {
  return value | 0xffffffff00000000;
}

static inline uint8_t unpack_u8(uint32_t word, uint32_t idx) {
  return (word >> (idx * 8)) & 0xffu;
}

// FMA<It, Ot>: one multiply-add step into an Ot-typed accumulator (bit-packed
// in uint32): fp32 for float inputs, int32 for integer inputs.
template <typename It, typename Ot>
struct FMA {
  using itype = typename It::dtype;
  using otype = typename Ot::dtype;
  static uint32_t eval(itype a, itype b, uint32_t c) {
    otype fa = static_cast<otype>(a);
    otype fb = static_cast<otype>(b);
    otype fc = bit_cast<otype>(c);
    return bit_cast<uint32_t>(fa * fb + fc);
  }
};

// -- fp16 inputs --
template <> struct FMA<vt::fp16, vt::fp32> {
  static uint32_t eval(uint16_t a, uint16_t b, uint32_t c) {
    auto fa = rv_htof_s(a, 0, nullptr);
    auto fb = rv_htof_s(b, 0, nullptr);
    return rv_fadd_s(rv_fmul_s(fa, fb, 0, nullptr), c, 0, nullptr);
  }
};
// -- bf16 inputs --
template <> struct FMA<vt::bf16, vt::fp32> {
  static uint32_t eval(uint16_t a, uint16_t b, uint32_t c) {
    auto fa = rv_btof_s(a, 0, nullptr);
    auto fb = rv_btof_s(b, 0, nullptr);
    return rv_fadd_s(rv_fmul_s(fa, fb, 0, nullptr), c, 0, nullptr);
  }
};
// -- fp8 inputs --
template <> struct FMA<vt::fp8, vt::fp32> {
  static uint32_t eval(uint8_t a, uint8_t b, uint32_t c) {
    auto fa = rv_e4m3tof_s(a, 0, nullptr);
    auto fb = rv_e4m3tof_s(b, 0, nullptr);
    return rv_fadd_s(rv_fmul_s(fa, fb, 0, nullptr), c, 0, nullptr);
  }
};
// -- bf8 inputs --
template <> struct FMA<vt::bf8, vt::fp32> {
  static uint32_t eval(uint8_t a, uint8_t b, uint32_t c) {
    auto fa = rv_e5m2tof_s(a, 0, nullptr);
    auto fb = rv_e5m2tof_s(b, 0, nullptr);
    return rv_fadd_s(rv_fmul_s(fa, fb, 0, nullptr), c, 0, nullptr);
  }
};
// -- tf32 inputs --
template <> struct FMA<vt::tf32, vt::fp32> {
  static uint32_t eval(uint32_t a, uint32_t b, uint32_t c) {
    auto fa = rv_tf32tof_s(a, 0, nullptr);
    auto fb = rv_tf32tof_s(b, 0, nullptr);
    return rv_fadd_s(rv_fmul_s(fa, fb, 0, nullptr), c, 0, nullptr);
  }
};
// Float source formats the native TFR datapath reduces (exponent, mantissa bits).
template <typename It> struct TfrFormat { static constexpr bool valid = false; };
template <> struct TfrFormat<vt::fp16> { static constexpr bool valid = true; static constexpr int eb = 5, sb = 10; };
template <> struct TfrFormat<vt::bf16> { static constexpr bool valid = true; static constexpr int eb = 8, sb = 7; };
template <> struct TfrFormat<vt::fp8>  { static constexpr bool valid = true; static constexpr int eb = 4, sb = 3; };
template <> struct TfrFormat<vt::bf8>  { static constexpr bool valid = true; static constexpr int eb = 5, sb = 2; };
template <> struct TfrFormat<vt::tf32> { static constexpr bool valid = true; static constexpr int eb = 8, sb = 10; };

// Generic FEDP, keyed on the output format.
//   * fp32 Ot on the native TFR datapath: its fixed-point reduction —
//     products aligned to the largest exponent in a 25-bit window, summed as
//     integers, rounded once (the TfrFedp model the RTL is checked against).
//   * fp32 Ot otherwise: accumulate Σ(a_k*b_k) in fp32 per register,
//     the register sums in order, c_val last (the DPI datapath's order).
//   * int32 Ot (integer inputs): exact integer accumulation.
template <typename It, typename Ot>
struct FEDP {
  using itype = typename It::dtype;
  static uint32_t eval(const reg_data_t *a_row, const reg_data_t *b_col, uint32_t c_val) {
    return eval_n(a_row, b_col, c_val, cfg::tcK);
  }

  static uint32_t eval_n(const reg_data_t *a_row, const reg_data_t *b_col, uint32_t c_val, uint32_t k_words) {
    constexpr uint32_t i_ratio = sizeof(uint32_t) / sizeof(itype);
    static_assert(i_ratio * sizeof(itype) == sizeof(uint32_t), "FEDP: tcK * i_ratio must be <= 32");
#ifdef VX_CFG_TCU_TYPE_TFR
    if constexpr (std::is_same_v<Ot, vt::fp32> && TfrFormat<It>::valid) {
      std::vector<uint32_t> a(k_words), b(k_words);
      for (uint32_t z = 0; z < k_words; ++z) {
        a[z] = a_row[z].u32;
        b[z] = b_col[z].u32;
      }
      TfrFedp fedp(TfrFormat<It>::eb, TfrFormat<It>::sb);
      float c;
      std::memcpy(&c, &c_val, sizeof(c));
      float d = fedp(a.data(), b.data(), c, k_words);
      uint32_t d_bits;
      std::memcpy(&d_bits, &d, sizeof(d_bits));
      return d_bits;
    } else
#endif
    if constexpr (std::is_same_v<Ot, vt::fp32>) {
      uint32_t acc = 0;
      for (uint32_t z = 0; z < k_words; ++z) {
        auto a = reinterpret_cast<const itype *>(&a_row[z].u32);
        auto b = reinterpret_cast<const itype *>(&b_col[z].u32);
        uint32_t prod = 0;
        for (uint32_t i = 0; i < i_ratio; ++i) {
          prod = FMA<It, vt::fp32>::eval(a[i], b[i], prod);
        }
        acc = rv_fadd_s(prod, acc, 0, nullptr);
      }
      return rv_fadd_s(c_val, acc, 0, nullptr);
    } else {
      static_assert(std::is_same_v<Ot, vt::int32>, "TCU output type must be fp32 (int32 for integer inputs)");
      uint32_t acc = c_val;
      for (uint32_t z = 0; z < k_words; ++z) {
        auto a = reinterpret_cast<const itype *>(&a_row[z].u32);
        auto b = reinterpret_cast<const itype *>(&b_col[z].u32);
        for (uint32_t i = 0; i < i_ratio; ++i) {
          acc = FMA<It, Ot>::eval(a[i], b[i], acc);
        }
      }
      return acc;
    }
  }
};

template <>
struct FEDP<vt::int4, vt::int32>{
  static uint32_t eval(const reg_data_t *a_row, const reg_data_t *b_col, uint32_t c_val) {
    return eval_n(a_row, b_col, c_val, cfg::tcK);
  }

  static uint32_t eval_n(const reg_data_t *a_row, const reg_data_t *b_col, uint32_t c_val, uint32_t k_words) {
    auto acc = bit_cast<int32_t>(c_val);
    for (uint32_t z = 0; z < k_words; ++z) {
      auto a = a_row[z].u32;
      auto b = b_col[z].u32;
      for (uint32_t i = 0; i < 8; ++i) { // 8 * 4 bits = 32 bits
        int32_t a_val = (a >> (i * 4)) & 0xF;
        int32_t b_val = (b >> (i * 4)) & 0xF;
        if (a_val & 0x8) {
          a_val |= 0xFFFFFFF0;
        }
        if (b_val & 0x8) {
          b_val |= 0xFFFFFFF0;
        }
        acc += a_val * b_val;
      }
    }
    return bit_cast<uint32_t>(acc);
  }
};

template <>
struct FEDP<vt::uint4, vt::int32>{
  static uint32_t eval(const reg_data_t *a_row, const reg_data_t *b_col, uint32_t c_val) {
    return eval_n(a_row, b_col, c_val, cfg::tcK);
  }

  static uint32_t eval_n(const reg_data_t *a_row, const reg_data_t *b_col, uint32_t c_val, uint32_t k_words) {
    auto acc = bit_cast<int32_t>(c_val);
    for (uint32_t z = 0; z < k_words; ++z) {
      auto a = a_row[z].u32;
      auto b = b_col[z].u32;
      for (uint32_t i = 0; i < 8; ++i) { // 8 * 4 bits = 32 bits
        int32_t a_val = (a >> (i * 4)) & 0xF;
        int32_t b_val = (b >> (i * 4)) & 0xF;
        acc += a_val * b_val;
      }
    }
    return bit_cast<uint32_t>(acc);
  }
};

using PFN_FEDP_N = uint32_t (*)(const reg_data_t*, const reg_data_t*, uint32_t, uint32_t);

static PFN_FEDP_N select_FEDP_N(uint32_t IT, uint32_t OT) {
  switch (OT) {
  case vt::fp32::id:
    switch (IT) {
    case vt::fp16::id:
      return FEDP<vt::fp16, vt::fp32>::eval_n;
    case vt::bf16::id:
      return FEDP<vt::bf16, vt::fp32>::eval_n;
    case vt::fp8::id:
      return FEDP<vt::fp8, vt::fp32>::eval_n;
    case vt::bf8::id:
      return FEDP<vt::bf8, vt::fp32>::eval_n;
    case vt::tf32::id:
      return FEDP<vt::tf32, vt::fp32>::eval_n;
    default:
      break;
    }
    break;
  case vt::int32::id:
    switch (IT) {
    case vt::int8::id:
      return FEDP<vt::int8, vt::int32>::eval_n;
    case vt::uint8::id:
      return FEDP<vt::uint8, vt::int32>::eval_n;
    case vt::int4::id:
      return FEDP<vt::int4, vt::int32>::eval_n;
    case vt::uint4::id:
      return FEDP<vt::uint4, vt::int32>::eval_n;
    default:
      break;
    }
    break;
  default:
    break;
  }
  std::cout << "Error: unsupported mma format: " << IT << " -> " << OT << "!" << std::endl;
  std::abort();
}

// Format-agnostic sparse gather: for each bword, iterate over its elem_count packed
// elements, collect those flagged by lo_mask/hi_mask respectively.
static inline uint32_t gather_sparse(uint32_t bword0, uint32_t bword1,
                                     uint32_t lo_mask, uint32_t hi_mask,
                                     uint32_t elem_bits) {
  uint32_t elem_count = 32 / elem_bits;
  uint32_t elem_mask  = (elem_bits < 32) ? ((1u << elem_bits) - 1u) : ~0u;
  assert((uint32_t)(__builtin_popcount(lo_mask) + __builtin_popcount(hi_mask)) == elem_count &&
         "gather_sparse: total selected elements must equal elem_count");
  uint32_t out = 0, k = 0;
  for (uint32_t i = 0; i < elem_count; ++i) {
    if (lo_mask & (1u << i))
      out |= ((bword0 >> (i * elem_bits)) & elem_mask) << (k++ * elem_bits);
  }
  for (uint32_t i = 0; i < elem_count; ++i) {
    if (hi_mask & (1u << i))
      out |= ((bword1 >> (i * elem_bits)) & elem_mask) << (k++ * elem_bits);
  }
  return out;
}

static inline uint32_t meta_num_cols(uint32_t fmt_s) {
  return vt::sparse_meta_num_cols(fmt_s, VX_CFG_NUM_THREADS);
}

static inline uint32_t meta_row_width(uint32_t elem_bits) {
  // Each K-step uses (32/elem_bits) meta bits per half (lo and hi), 2 halves per row.
  return cfg::tcK * 2 * (32 / elem_bits);
}

class TcuUnit::Impl {
public:

  struct lmem_desc_t {
    uint64_t base = 0;
    uint32_t ldm = 0;
    bool col_major = false;
  };

  Impl(TcuUnit* simobject, Core* core)
    : simobject_(simobject)
    , core_(core)
    , sparse_meta_(VX_CFG_NUM_WARPS, std::vector<uint32_t>(kMetaBanks * kMaxMetaCols, 0))
  #ifdef VX_CFG_TCU_MX_ENABLE
    , mx_meta_a_(VX_CFG_NUM_WARPS, std::vector<uint32_t>(VX_CFG_NUM_THREADS, 0))
    , mx_meta_b_(VX_CFG_NUM_WARPS, std::vector<uint32_t>(VX_CFG_NUM_THREADS, 0))
  #endif
    , perf_stats_()
  {
    exec_done_.fill(false);
    slices_.fill(0);
    in_wgmma_.fill(false);
    wgmma_desc_.fill({0, 0});
  }

  ~Impl() {}

  void reset() {
    // perf_stats_ survives: the MPM counters run from device reset.
    for (auto& sparse_meta : sparse_meta_) {
      std::fill(sparse_meta.begin(), sparse_meta.end(), 0);
    }
  #ifdef VX_CFG_TCU_MX_ENABLE
    for (auto& mx_meta : mx_meta_a_) {
      std::fill(mx_meta.begin(), mx_meta.end(), 0);
    }
    for (auto& mx_meta : mx_meta_b_) {
      std::fill(mx_meta.begin(), mx_meta.end(), 0);
    }
  #endif
    exec_done_.fill(false);
    slices_.fill(0);
    for (auto& due : result_due_) {
      due.clear();
    }
    in_wgmma_.fill(false);
    lmem_desc_.clear();
    wgmma_desc_.fill({0, 0});
    cta_owner_a_.fill(-1);
  #ifdef VX_CFG_TCU_WGMMA_ENABLE
    abuf_.fill(abuf_slot_t{});
    bbuf_ = bbuf_slot_t{};
  #endif
    cur_block_ = 0;
  #ifdef TCU_META_ENABLE
    agu_.fill(agu_state_t{});
    agu_issue_rr_ = 0;
  #endif
  }

#ifdef TCU_META_ENABLE
  // Each TCU block's AGU tracks one metadata load and writes each returned
  // lane straight into the block's metadata SRAM.
  static constexpr uint32_t kAguBeats =
      (VX_CFG_NUM_THREADS + VX_CFG_NUM_LSU_LANES - 1) / VX_CFG_NUM_LSU_LANES;

  struct agu_state_t {
    bool busy = false;
    bool complete = false;
    instr_trace_t* trace = nullptr;
    uint32_t wid = 0;
    uint32_t selector = 0;
    uint32_t next_beat = 0;
    uint32_t rsp_count = 0;
    std::array<uint64_t, VX_CFG_NUM_THREADS> addrs{};
  };
  std::array<agu_state_t, VX_CFG_NUM_TCU_BLOCKS> agu_;
  uint32_t agu_issue_rr_ = 0;

  void agu_start(uint32_t block, uint32_t wid, uint32_t selector,
                 uint64_t base_addr, instr_trace_t* trace) {
    assert((base_addr & 3) == 0 && "metadata base must be word-aligned");
    auto& agu = agu_.at(block);
    agu = agu_state_t{};
    agu.busy     = true;
    agu.trace    = trace;
    agu.wid      = wid;
    agu.selector = selector;
    for (uint32_t t = 0; t < VX_CFG_NUM_THREADS; ++t) {
      agu.addrs.at(t) = base_addr + uint64_t(t) * 4;
      // Metadata is read as a linear warp-wide tile, which an interleaved
      // per-thread stack cannot provide.
      if (StackInterleave::contains(agu.addrs.at(t))) {
        std::cout << "Error: TCU metadata inside the thread stack window: addr=0x"
                  << std::hex << agu.addrs.at(t) << std::dec << std::endl;
        std::abort();
      }
    }
  }

  LsuReq agu_make_req(uint32_t block, agu_state_t& agu) {
    LsuReq req(VX_CFG_NUM_LSU_LANES);
    req.op   = MemOp::LD;
    req.tag  = block * kAguBeats + agu.next_beat;
    req.wid  = agu.wid;
    req.cid  = agu.trace->cid;
    req.uuid = agu.trace->uuid;
    for (uint32_t i = 0; i < VX_CFG_NUM_LSU_LANES; ++i) {
      uint32_t idx = agu.next_beat * VX_CFG_NUM_LSU_LANES + i;
      if (idx >= VX_CFG_NUM_THREADS) {
        break;
      }
      req.mask.set(i);
      req.addrs.at(i) = agu.addrs.at(idx);
      req.tids.at(i)  = idx % VX_CFG_NUM_THREADS;
    }
    ++agu.next_beat;
    return req;
  }

  void agu_receive(const LsuRsp& rsp) {
    uint32_t block = (uint32_t)rsp.tag / kAguBeats;
    uint32_t beat = (uint32_t)rsp.tag % kAguBeats;
    auto& agu = agu_.at(block);
    for (uint32_t lane = 0; lane < rsp.mask.size(); ++lane) {
      if (!rsp.mask.test(lane)) {
        continue;
      }
      uint32_t idx = beat * VX_CFG_NUM_LSU_LANES + lane;
      assert(idx < VX_CFG_NUM_THREADS && rsp.data.at(lane));
      uint32_t off = agu.addrs.at(idx) & (VX_CFG_MEM_BLOCK_SIZE - 1);
      uint32_t word = 0;
      std::memcpy(&word, rsp.data.at(lane)->data() + off, 4);
      this->agu_write(agu, idx, word);
      ++agu.rsp_count;
    }
    if (agu.busy && !agu.complete && agu.rsp_count == VX_CFG_NUM_THREADS) {
      agu.complete = true;
    }
  }

  void agu_step() {
    if (TCU_AGU_PORTS == 1) {
      // every block shares one port: round-robin one request per cycle
      if (!simobject_->agu_req_out.at(0).full()) {
        for (uint32_t offset = 0; offset < VX_CFG_NUM_TCU_BLOCKS; ++offset) {
          uint32_t block = (agu_issue_rr_ + offset) % VX_CFG_NUM_TCU_BLOCKS;
          auto& agu = agu_.at(block);
          if (!agu.busy || agu.next_beat >= kAguBeats) {
            continue;
          }
          simobject_->agu_req_out.at(0).send(this->agu_make_req(block, agu));
          agu_issue_rr_ = (block + 1) % VX_CFG_NUM_TCU_BLOCKS;
          break;
        }
      }
    } else {
      // each block issues on its own port
      for (uint32_t block = 0; block < VX_CFG_NUM_TCU_BLOCKS; ++block) {
        auto& agu = agu_.at(block);
        if (!agu.busy || agu.next_beat >= kAguBeats
         || simobject_->agu_req_out.at(block).full()) {
          continue;
        }
        simobject_->agu_req_out.at(block).send(this->agu_make_req(block, agu));
      }
    }

    for (uint32_t p = 0; p < TCU_AGU_PORTS; ++p) {
      auto& rsp_in = simobject_->agu_rsp_in.at(p);
      if (rsp_in.empty()) {
        continue;
      }
      this->agu_receive(rsp_in.peek());
      rsp_in.pop();
    }
  }

  // A TCU_LD retires once its words are deposited into the metadata SRAM;
  // the AGU takes the next load the cycle after.
  void agu_retire(uint64_t now) {
    for (uint32_t b = 0; b < VX_CFG_NUM_TCU_BLOCKS; ++b) {
      auto& agu = agu_.at(b);
      if (!agu.complete)
        continue;
      // The result is offered in the cycle its last fragment lands, as the
      // AGU's done flag; the lane gather adds the one register to commit.
      if (simobject_->Outputs.at(b).try_send(agu.trace, 0)) {
        result_due_.at(b).push_back(now);
        DT(3, simobject_->name() << " execute: op=" << TcuType::TCU_LD << ", " << *agu.trace);
        agu = agu_state_t{};
      }
    }
  }

  // Write lane T's fetched word into the selected metadata SRAM.
  void agu_write(const agu_state_t& agu, uint32_t T, uint32_t word) {
    uint32_t wid = agu.wid;
  #ifdef VX_CFG_TCU_MX_ENABLE
    if (agu.selector & 0x10) {
      auto& dst = (agu.selector & 1) ? mx_meta_b_.at(wid) : mx_meta_a_.at(wid);
      dst.at(T) = word;
      return;
    }
  #endif
  #ifdef VX_CFG_TCU_SPARSE_ENABLE
    uint32_t slot_idx = agu.selector & 0xf;
    // Map lane T to its (bank, col) metadata cell using the host pack layout:
    //   flat_store = slot*cols_per_load + T/BPS
    //   col  = flat_store / stores_per_col
    //   bank = (flat_store % stores_per_col)*BPS + T%BPS
    // Covers NT < kMetaBanks (stores_per_col > 1) as well as NT >= kMetaBanks.
    constexpr uint32_t PWD = kMetaBanks;
    constexpr uint32_t BPS = cfg::banks_per_store;
    constexpr uint32_t SPC = cfg::stores_per_col;
    constexpr uint32_t CPL = cfg::meta_cols_per_load;
    uint32_t store_in_load   = T / BPS;
    uint32_t thread_in_store = T % BPS;
    uint32_t flat_store      = slot_idx * CPL + store_in_load;
    uint32_t col             = flat_store / SPC;
    uint32_t store_in_col    = flat_store % SPC;
    uint32_t bank            = store_in_col * BPS + thread_in_store;
    if (bank >= PWD || col >= kMaxMetaCols) {
      return;
    }
    sparse_meta_.at(wid).at(bank * kMaxMetaCols + col) = word;
    // Trace: META_SRAM write (CSV: wid,bank,col,addr,value).
    if (const char* p = std::getenv("VORTEX_TCU_TRACE")) {
      if (p[0] == '1') {
        fprintf(stderr, "META_TRC,%u,%u,%u,0x%lx,0x%08x\n",
                wid, bank, col, (unsigned long)agu.addrs.at(T), word);
      }
    }
  #else
    __unused(T, word);
  #endif
  }
#endif // TCU_META_ENABLE

  void tick() {
  #ifdef TCU_META_ENABLE
    this->agu_step();
  #endif
  #ifdef VX_CFG_TCU_WGMMA_ENABLE
    uint32_t wgmma_ready = this->tbuf_step();
    uint32_t setup_fired = 0;
  #endif

    uint64_t now = SimPlatform::instance().cycles();
    for (uint32_t b = 0; b < VX_CFG_NUM_TCU_BLOCKS; ++b) {
      // A result completing while an earlier one still waits for the commit
      // side holds admission for the cycle. Results already visible but not
      // taken are the output occupancy beyond those still in flight.
      auto& due = result_due_.at(b);
      due.erase(std::remove_if(due.begin(), due.end(), [now](uint64_t t) { return t < now; }), due.end());
      bool completing = std::any_of(due.begin(), due.end(), [now](uint64_t t) { return t == now; });
      bool backed_up = simobject_->Outputs.at(b).size() > due.size();
      auto& input = simobject_->Inputs.at(b);
      if (input.empty())
        continue;
      auto trace = input.peek();
      auto tcu_type = std::get<TcuType>(trace->op_type);
      auto tpuArgs = std::get<IntrTcuArgs>(trace->instr_ptr->get_args());

    #ifdef TCU_META_ENABLE
      // A TCU_LD leaves the input for the AGU once the AGU is free, so the ops
      // behind it run while its metadata is in flight; it retires from the AGU.
      if (tcu_type == TcuType::TCU_LD) {
        if (!agu_.at(b).busy) {
          // rs1 is a full-width address (.u64); use u64 to avoid truncation on XLEN=64.
          auto& rs1_data = trace->src_data[0];
          uint64_t base_addr = rs1_data.empty() ? 0 : rs1_data.at(0).u64;
          this->agu_start(b, trace->wid, tpuArgs.fmt_d, base_addr, trace);
          input.pop();
        }
        continue;
      }
    #endif

      if (completing && backed_up) {
        continue;
      }

    #ifdef VX_CFG_TCU_WGMMA_ENABLE
      // A WGMMA compute uop fires once its tile-buffer operands are ready.
      if (tcu_is_wgmma(tcu_type) && !tpuArgs.is_setup_uop
       && !exec_done_.at(b) && !((wgmma_ready >> b) & 1u)) {
        continue;
      }
    #endif

      // Execute once per trace; results persist across backpressure retries
      // via exec_done_[b].
      if (!exec_done_.at(b)) {
        uint32_t wid = trace->wid;
        uint32_t num_threads = VX_CFG_NUM_THREADS;
        auto& rs1_data = trace->src_data[0];
        auto& rs2_data = trace->src_data[1];
        auto& rs3_data = trace->src_data[2];
        trace->dst_data.assign(num_threads, reg_data_t{});
        auto& rd_data = trace->dst_data;

        if (!vt::tcu_output_valid(tpuArgs.fmt_s, tpuArgs.fmt_d)) {
          std::cerr << "*** TCU output format " << tpuArgs.fmt_d << " for input format " << tpuArgs.fmt_s
                    << " is not supported: the TCU returns fp32 (int32 for integer inputs)" << std::endl;
          std::abort();
        }

        switch (tcu_type) {
        case TcuType::WMMA:
        case TcuType::WMMA_SP:
          this->wmma(wid, tpuArgs.fmt_s, tpuArgs.fmt_d,
                     tpuArgs.step_m, tpuArgs.step_n, tpuArgs.step_k,
                     rs1_data, rs2_data, rs3_data, rd_data,
                     tcu_is_sparse(tcu_type));
          break;
      #ifdef VX_CFG_TCU_WGMMA_ENABLE
        case TcuType::WGMMA:
        case TcuType::WGMMA_SP: {
          uint32_t a_desc = rs1_data.empty() ? 0 : rs1_data.at(0).u32;
          uint32_t b_desc = rs2_data.empty() ? 0 : rs2_data.at(0).u32;
          cur_block_ = b;
          int32_t this_cta = (int32_t)core_->scheduler().warp(wid).cta_csrs.cta_id;
          // CTA lockstep invariant: no block may execute a WGMMA uop for a
          // different cta_id while another block is mid-WGMMA.
          if (!tpuArgs.is_setup_uop) {
            for (uint32_t k = 0; k < VX_CFG_NUM_TCU_BLOCKS; ++k) {
              if (k == b) continue;
              if (in_wgmma_.at(k) && cta_owner_a_.at(k) != this_cta) {
                std::cerr << "*** TCU CTA lockstep violation: block " << b
                          << " executing WGMMA cta_id=" << this_cta
                          << " while block " << k << " holds cta_id="
                          << cta_owner_a_.at(k) << std::endl;
                std::abort();
              }
            }
          }
          this->wgmma(wid, tpuArgs.fmt_s, tpuArgs.fmt_d,
                      tpuArgs.step_m, tpuArgs.step_n, tpuArgs.step_k,
                      a_desc, b_desc, rs1_data, rs2_data, rs3_data, rd_data,
                      tcu_is_sparse(tcu_type),
                      tpuArgs.cd_nregs, tpuArgs.is_a_smem, tpuArgs.is_setup_uop);
          if (tpuArgs.is_setup_uop) {
            setup_fired |= (1u << b);
          } else {
            // The block owns its CTA from its first compute uop to its last.
            if (tpuArgs.is_first_uop) {
              in_wgmma_.at(b) = true;
              cta_owner_a_.at(b) = this_cta;
            }
            if (tpuArgs.is_last_uop) {
              in_wgmma_.at(b) = false;
              cta_owner_a_.at(b) = -1;
            }
          }
        } break;
      #endif
        default:
          std::abort();
        }
        exec_done_.at(b) = true;
      }

      // A compute uop holds its input while its leading output slices go
      // through the FEDP array, under the admission conditions of its fire,
      // and leaves with the last one.
      if (kPeRatio > 1 && !tpuArgs.is_setup_uop && slices_.at(b) + 1 < kPeRatio) {
      #ifdef VX_CFG_TCU_WGMMA_ENABLE
        bool tbuf_ready = !tcu_is_wgmma(tcu_type) || ((wgmma_ready >> b) & 1u);
      #else
        bool tbuf_ready = true;
      #endif
        if (tbuf_ready && !simobject_->Outputs.at(b).full()) {
          ++slices_.at(b);
        }
        continue;
      }

      if (simobject_->Outputs.at(b).try_send(trace, kMmaLatency)) {
        due.push_back(now + kMmaLatency);
        exec_done_.at(b) = false;
        slices_.at(b) = 0;
        DT(3, simobject_->name() << " execute: op=" << tcu_type << ", " << *trace);
        input.pop();
      }
    }

  #ifdef TCU_META_ENABLE
    this->agu_retire(now);
  #endif

  #ifdef VX_CFG_TCU_WGMMA_ENABLE
    // A setup uop drops its block's A stripe and the shared B row at the end
    // of the cycle; uops firing alongside it still read the old contents.
    if (setup_fired != 0) {
      auto& tbuf = simobject_->tbuf();
      for (uint32_t b = 0; b < VX_CFG_NUM_TCU_BLOCKS; ++b) {
        if ((setup_fired >> b) & 1u) {
          abuf_.at(b) = abuf_slot_t{};
          tbuf->invalidate_a(b);
        }
      }
      bbuf_ = bbuf_slot_t{};
      tbuf->invalidate_b();
    }
  #endif
  }

#ifdef VX_CFG_TCU_WGMMA_ENABLE
  // A block's A buffer: one k-stripe.
  struct abuf_slot_t {
    bool     valid = false;
    bool     fetching = false;
    bool     first_refetched = false;
    uint32_t step_k = 0;
  };

  // The shared B buffer and its refill key.
  struct bbuf_slot_t {
    bool     valid = false;
    bool     fetching = false;
    bool     first_refetched = false;
    bool     kmajor = false;
    bool     sparse = false;
    uint64_t row = 0;       // block-major: LMEM address of the bank row
    int32_t  cta = -1;      // K-major: the (cta, step_k, step_n) block
    uint32_t step_k = 0;
    uint32_t step_n = 0;

    bool same_row(const bbuf_slot_t& key) const {
      if (kmajor != key.kmajor || sparse != key.sparse) {
        return false;
      }
      if (kmajor) {
        return cta == key.cta && step_k == key.step_k && step_n == key.step_n;
      }
      return row == key.row;
    }
  };

  // One block's WGMMA compute uop as the tile buffers see it.
  struct tbuf_req_t {
    bool     valid = false;
    uint32_t wid = 0;
    int32_t  cta = -1;
    bool     is_first_uop = false;
    bool     is_sparse = false;
    bool     a_is_smem = false;
    uint32_t step_m = 0;
    uint32_t step_n = 0;
    uint32_t step_k = 0;
    uint32_t cd_nregs = 0;
    uint32_t fmt_s = 0;
    uint32_t desc_b = 0;

    // The A buffer forces a refetch on a WGMMA's first compute uop.
    bool first_compute() const {
      return step_m == 0 && step_n == 0 && step_k == 0;
    }
  };

  // Evaluate the A/B tile buffers for the uops at the head of each block
  // and return the blocks whose WGMMA compute uop may fire.
  //
  // The B buffer holds one bank row and refills when the key of the lowest
  // block with a uop changes; a block whose (desc_b, step_k, step_n) differs
  // from that block's waits. Each A buffer holds its block's k-stripe.
  // Refills start from the buffer state at the beginning of the cycle, and a
  // refill that completes this cycle serves from the next.
  uint32_t tbuf_step() {
    auto& tbuf = simobject_->tbuf();

    std::array<tbuf_req_t, VX_CFG_NUM_TCU_BLOCKS> reqs;
    int32_t rep = -1;
    for (uint32_t b = 0; b < VX_CFG_NUM_TCU_BLOCKS; ++b) {
      auto& input = simobject_->Inputs.at(b);
      // A uop requests its tiles for as long as it holds the block's input,
      // through its last output slice and any wait for the result side.
      if (input.empty()) {
        continue;
      }
      auto trace = input.peek();
      auto tcu_type = std::get<TcuType>(trace->op_type);
      if (!tcu_is_wgmma(tcu_type)) {
        continue;
      }
      auto tpuArgs = std::get<IntrTcuArgs>(trace->instr_ptr->get_args());
      if (tpuArgs.is_setup_uop) {
        continue;
      }
      uint32_t wid = trace->wid;
      int32_t cta = (int32_t)core_->scheduler().warp(wid).cta_csrs.cta_id;
      // CTA lockstep: wait while another block is mid-WGMMA for another CTA.
      bool cta_conflict = false;
      for (uint32_t k = 0; k < VX_CFG_NUM_TCU_BLOCKS; ++k) {
        if (k != b && in_wgmma_.at(k) && cta_owner_a_.at(k) != cta) {
          cta_conflict = true;
          break;
        }
      }
      if (cta_conflict) {
        continue;
      }

      bool is_sparse = (tcu_type == TcuType::WGMMA_SP);
      bool needs_setup = kFedp2K && !tpuArgs.is_a_smem && !is_sparse;
      if (tpuArgs.is_first_uop && !needs_setup) {
        // The first compute uop carries the live descriptors.
        if (tpuArgs.is_a_smem) {
          wgmma_desc_[wid][0] = trace->src_data.at(0).at(0).u32;
        }
        wgmma_desc_[wid][1] = trace->src_data.at(1).at(0).u32;
        this->decode_descs(wid, tpuArgs.fmt_s, tpuArgs.is_a_smem);
      }

      auto& req = reqs.at(b);
      req.valid        = true;
      req.wid          = wid;
      req.cta          = cta;
      req.is_first_uop = tpuArgs.is_first_uop;
      req.is_sparse    = is_sparse;
      req.a_is_smem    = tpuArgs.is_a_smem;
      req.step_m       = tpuArgs.step_m;
      req.step_n       = tpuArgs.step_n;
      req.step_k       = tpuArgs.step_k;
      req.cd_nregs     = tpuArgs.cd_nregs;
      req.fmt_s        = tpuArgs.fmt_s;
      req.desc_b       = wgmma_desc_[wid][1];
      if (rep < 0) {
        rep = b;
      }
    }

    // Shared B buffer, keyed by the lowest block with a uop.
    bool bbuf_ready = true;
    if (rep >= 0) {
      auto& r = reqs.at(rep);
      bbuf_slot_t key = this->bbuf_key(r);
      bool resident = bbuf_.valid && bbuf_.same_row(key)
                   && (!key.kmajor || !r.is_first_uop || bbuf_.first_refetched);
      if (resident) {
        ++perf_stats_.tbuf_cache_hits;
      } else {
        bbuf_ready = false;
        ++perf_stats_.tbuf_stalls;
        if (!bbuf_.fetching) {
          bool first_refetched = bbuf_.first_refetched;
          bbuf_ = key;
          bbuf_.fetching = true;
          bbuf_.first_refetched = first_refetched;
          DT(3, simobject_->name() << " bbuf: alloc desc_b=0x" << std::hex << r.desc_b
                << std::dec << ", sparse=" << r.is_sparse << ", step_k=" << r.step_k
                << ", step_n=" << r.step_n << ", row=0x" << std::hex << key.row
                << std::dec << ", wid=" << r.wid);
          tbuf->fill_b(this->b_refill(r));
        }
      }
    }

    // Per-block A buffers.
    std::array<bool, VX_CFG_NUM_TCU_BLOCKS> abuf_ready;
    for (uint32_t b = 0; b < VX_CFG_NUM_TCU_BLOCKS; ++b) {
      auto& r = reqs.at(b);
      auto& slot = abuf_.at(b);
      abuf_ready.at(b) = true;
      if (!r.valid || !r.a_is_smem) {
        continue;
      }
      bool resident = slot.valid && slot.step_k == r.step_k
                   && (!r.first_compute() || slot.first_refetched);
      if (resident) {
        continue;
      }
      abuf_ready.at(b) = false;
      ++perf_stats_.tbuf_stalls;
      if (!slot.fetching) {
        slot.valid    = false;
        slot.fetching = true;
        slot.step_k   = r.step_k;
        tbuf->fill_a(b, this->a_refill(r));
      }
    }

    uint32_t ready_mask = 0;
    for (uint32_t b = 0; b < VX_CFG_NUM_TCU_BLOCKS; ++b) {
      auto& r = reqs.at(b);
      if (!r.valid) {
        continue;
      }
      auto& p = reqs.at(rep);
      bool key_match = (vt::smem_desc_offset(r.desc_b) == vt::smem_desc_offset(p.desc_b))
                    && r.step_k == p.step_k
                    && r.step_n == p.step_n
                    && r.cd_nregs == p.cd_nregs;
      if (abuf_ready.at(b) && bbuf_ready && key_match) {
        ready_mask |= (1u << b);
      }
    }

    // Buffer state for the next cycle.
    if (bbuf_.fetching && !tbuf->filling_b()) {
      bbuf_.fetching = false;
      bbuf_.valid = true;
      if (rep >= 0 && reqs.at(rep).is_first_uop) {
        bbuf_.first_refetched = true;
      }
    } else if (rep >= 0 && bbuf_ready && !reqs.at(rep).is_first_uop) {
      bbuf_.first_refetched = false;
    }
    for (uint32_t b = 0; b < VX_CFG_NUM_TCU_BLOCKS; ++b) {
      auto& r = reqs.at(b);
      auto& slot = abuf_.at(b);
      if (slot.fetching && !tbuf->filling_a(b)) {
        slot.fetching = false;
        slot.valid = true;
        if (r.valid && r.first_compute()) {
          slot.first_refetched = true;
        }
      } else if (r.valid && abuf_ready.at(b) && !r.first_compute()) {
        slot.first_refetched = false;
      }
    }

    return ready_mask;
  }

  // Decode a warp's WGMMA descriptors into LMEM base and row stride.
  void decode_descs(uint32_t wid, uint32_t fmt_s, bool is_a_smem) {
    uint32_t e_bits = elem_bits(fmt_s);
    uint32_t a_desc = wgmma_desc_[wid][0];
    uint32_t b_desc = wgmma_desc_[wid][1];
    if (is_a_smem) {
      lmem_desc_[wid][0] = {uint64_t(VX_MEM_LMEM_BASE_ADDR) + vt::smem_desc_offset(a_desc), vt::smem_desc_stride(a_desc) * 8 / e_bits, false};
    }
    lmem_desc_[wid][1] = {uint64_t(VX_MEM_LMEM_BASE_ADDR) + vt::smem_desc_offset(b_desc), vt::smem_desc_stride(b_desc) * 8 / e_bits, false};
  }

  static uint32_t xtile_n_of(uint32_t cd_nregs) {
    // NRC: cd_nregs 0/1/2 → 8/16/32; xtileN = NRC * NT / xtileM.
    uint32_t nrc = (cd_nregs == 0) ? 8 : (cd_nregs == 1) ? 16 : 32;
    return (nrc * VX_CFG_NUM_THREADS) / wg_cfg::xtileM;
  }

  // Refill key of the B row serving `req`. Block-major B is keyed by the
  // bank row holding the (step_k, step_n) block; K-major B by the block.
  bbuf_slot_t bbuf_key(const tbuf_req_t& req) {
    const auto& sd_b = lmem_desc_[req.wid][1];
    bbuf_slot_t key;
    key.kmajor = (sd_b.ldm != 0);
    key.sparse = req.is_sparse;
    if (key.kmajor) {
      key.cta    = req.cta;
      key.step_k = req.step_k;
      key.step_n = req.step_n;
    } else {
      uint32_t n_steps = xtile_n_of(req.cd_nregs) / cfg::tcN;
      uint32_t blk = req.step_k * n_steps + req.step_n;
      uint32_t blk_bytes = req.is_sparse ? (kBBlockWordsSp * 4) : (kBBlockWords * 4);
      uint32_t blks_per_row = req.is_sparse ? 1 : kBSubBlocks;
      key.row = sd_b.base + uint64_t(blk / blks_per_row) * blks_per_row * blk_bytes;
    }
    return key;
  }

  // LMEM reads that refill the B buffer for `req`: one bank row for a
  // block-major row (two when a sparse block spans two rows) and one per
  // N-row of the block in K-major layout.
  std::vector<TcuTbuf::LmemRead> b_refill(const tbuf_req_t& req) {
    const auto& sd_b = lmem_desc_[req.wid][1];
    uint32_t e_bits  = elem_bits(req.fmt_s);
    uint32_t ratio   = 32 / e_bits;
    uint32_t xtile_n = xtile_n_of(req.cd_nregs);
    uint32_t n_steps = xtile_n / cfg::tcN;
    uint32_t k_words = req.is_sparse ? cfg::tcK : kFedpWords;
    bool kmajor = (sd_b.ldm != 0);

    // (step_k, step_n) blocks this refill brings in.
    uint32_t blk = req.step_k * n_steps + req.step_n;
    uint32_t blks = (kmajor || req.is_sparse) ? 1 : kBSubBlocks;
    uint32_t first_blk = blk - (blk % blks);

    std::vector<uint64_t> lines;
    for (uint32_t bi = first_blk; bi < first_blk + blks; ++bi) {
      uint32_t step_k = bi / n_steps;
      uint32_t step_n = bi % n_steps;
      for (uint32_t j = 0; j < cfg::tcN; ++j) {
        uint32_t col = step_n * cfg::tcN + j;
        for (uint32_t z = 0; z < k_words; ++z) {
          uint32_t k_elem = (step_k * k_words + z) * ratio * (req.is_sparse ? 2 : 1);
          uint32_t k_elems = req.is_sparse ? (2 * ratio) : ratio;
          for (uint32_t e = 0; e < k_elems; ++e) {
            uint64_t off = elem_offset(sd_b, k_elem + e, col, e_bits, xtile_n,
                                       true, req.is_sparse, false);
            lines.push_back((sd_b.base + off * e_bits / 8) & kLineMask);
          }
        }
      }
    }

    uint32_t num_reads = kmajor ? cfg::tcN
                       : (req.is_sparse && kBSparseTwoFetch) ? 2 : 1;
    return split_reads(std::move(lines), num_reads);
  }

  // LMEM reads that refill a block's A buffer with the k-stripe of `req`:
  // one per bank row of a block-major stripe, one per row in row-major.
  std::vector<TcuTbuf::LmemRead> a_refill(const tbuf_req_t& req) {
    const auto& sd_a = lmem_desc_[req.wid][0];
    uint32_t e_bits  = elem_bits(req.fmt_s);
    uint32_t ratio   = 32 / e_bits;
    uint32_t xtile_n = xtile_n_of(req.cd_nregs);
    uint32_t k_words = req.is_sparse ? cfg::tcK : kFedpWords;

    std::vector<uint64_t> lines;
    for (uint32_t row = 0; row < wg_cfg::m_steps * cfg::tcM; ++row) {
      for (uint32_t z = 0; z < k_words; ++z) {
        uint32_t k_elem = (req.step_k * k_words + z) * ratio;
        for (uint32_t e = 0; e < ratio; ++e) {
          uint64_t off = elem_offset(sd_a, row, k_elem + e, e_bits, xtile_n,
                                     false, false, req.is_sparse);
          lines.push_back((sd_a.base + off * e_bits / 8) & kLineMask);
        }
      }
    }

    uint32_t num_reads = (sd_a.ldm != 0) ? (wg_cfg::m_steps * cfg::tcM)
                       : req.is_sparse ? kAStripeReadsSp : kAStripeReads;
    return split_reads(std::move(lines), num_reads);
  }

  // Spread a refill's distinct lines over the hardware's read count.
  static std::vector<TcuTbuf::LmemRead> split_reads(std::vector<uint64_t> lines,
                                                    uint32_t num_reads) {
    std::sort(lines.begin(), lines.end());
    lines.erase(std::unique(lines.begin(), lines.end()), lines.end());
    uint32_t n = lines.size();
    if (n == 0) {
      return {};
    }
    std::vector<TcuTbuf::LmemRead> reads(num_reads);
    for (uint32_t i = 0; i < num_reads; ++i) {
      if (n >= num_reads) {
        reads.at(i).assign(lines.begin() + (uint64_t(i) * n) / num_reads,
                           lines.begin() + (uint64_t(i + 1) * n) / num_reads);
      } else {
        reads.at(i).push_back(lines.at(i % n));
      }
    }
    return reads;
  }
#endif // VX_CFG_TCU_WGMMA_ENABLE


  void wmma(uint32_t wid,
            uint32_t fmt_s,
            uint32_t fmt_d,
            uint32_t step_m,
            uint32_t step_n,
            uint32_t step_k,
            const std::vector<reg_data_t>& rs1_data,
            const std::vector<reg_data_t>& rs2_data,
            const std::vector<reg_data_t>& rs3_data,
            std::vector<reg_data_t>& rd_data,
            bool is_sparse) {
    if (is_sparse) {
      if (!vt::sparse_format_supported(fmt_s)) {
        std::cout << "Error: WMMA_SP unsupported input format: "
                  << vt::fmt_string(fmt_s) << " (id=" << fmt_s
                  << ")." << std::endl;
        std::abort();
      }
      if ((VX_CFG_NUM_THREADS % cfg::b_block_size_sp) != 0) {
        std::cout << "Error: VX_CFG_NUM_THREADS must be divisible by sparse B block size" << std::endl;
        std::abort();
      }
    }

    uint32_t a_off = (step_m % cfg::a_sub_blocks) * cfg::a_block_size;
    uint32_t b_off = is_sparse
                   ? (step_n % cfg::b_sub_blocks_sp) * cfg::b_block_size_sp
                   : (step_n % cfg::b_sub_blocks)    * cfg::b_block_size;

    // WMMA occupies the low half of a widened FEDP and zeros the unused half.
    reg_data_t a_tile[cfg::tcM * kFedpWords] = {};
    for (uint32_t i = 0; i < cfg::tcM; ++i) {
      for (uint32_t z = 0; z < cfg::tcK; ++z) {
        a_tile[i * kFedpWords + z] = rs1_data.at(a_off + i * cfg::tcK + z);
      }
    }

    reg_data_t b_tile[cfg::tcM * cfg::tcN * kFedpWords] = {};
    if (is_sparse) {
      constexpr uint32_t kCompression = 2;
      uint32_t ebits = elem_bits(fmt_s);
      uint32_t meta_bits = 32 / ebits;
      uint32_t bank = step_m * (cfg::k_steps / 2) + step_k;
      auto meta_bit = [&](uint32_t bit_idx) {
        return (sparse_meta_.at(wid).at(bank * kMaxMetaCols + bit_idx / 32) >> (bit_idx % 32)) & 1u;
      };
      for (uint32_t i = 0; i < cfg::tcM; ++i) {
        uint32_t row_base = i * meta_row_width(ebits);
        for (uint32_t j = 0; j < cfg::tcN; ++j) {
          uint32_t j_sp = cfg::sym_sparse ? (j % (cfg::tcN / 2)) : j;
          for (uint32_t z = 0; z < cfg::tcK; ++z) {
            uint32_t b_idx = b_off + j_sp * cfg::tcK * kCompression + z * kCompression;
            uint32_t lo = 0, hi = 0;
            for (uint32_t b = 0; b < meta_bits; ++b) {
              lo |= meta_bit(row_base + meta_bits * z + b) << b;
              hi |= meta_bit(row_base + meta_bits * (cfg::tcK + z) + b) << b;
            }
            b_tile[(i * cfg::tcN + j) * kFedpWords + z].u32 =
                gather_sparse(rs2_data.at(b_idx).u32, rs2_data.at(b_idx + 1).u32, lo, hi, ebits);
          }
        }
      }
    } else {
      for (uint32_t i = 0; i < cfg::tcM; ++i) {
        for (uint32_t j = 0; j < cfg::tcN; ++j) {
          for (uint32_t z = 0; z < cfg::tcK; ++z) {
            b_tile[(i * cfg::tcN + j) * kFedpWords + z] = rs2_data.at(b_off + j * cfg::tcK + z);
          }
        }
      }
    }

    fedp_tile(wid, step_m, step_n, step_k, fmt_s, fmt_d,
              a_tile, b_tile, rs3_data, rd_data,
              is_sparse, kFedpWords, cfg::tcK,
              cfg::k_steps * cfg::tcK);
  }

  void wgmma(uint32_t wid,
             uint32_t fmt_s,
             uint32_t fmt_d,
             uint32_t step_m,
             uint32_t step_n,
             uint32_t step_k,
             uint32_t a_desc,
             uint32_t b_desc,
             const std::vector<reg_data_t>& rs1_data,
             const std::vector<reg_data_t>& rs2_data,
             const std::vector<reg_data_t>& rs3_data,
             std::vector<reg_data_t>& rd_data,
             bool is_sparse,
             uint32_t cd_nregs,
             uint32_t is_a_smem,
             uint32_t is_setup_uop) {
    if (is_sparse && !vt::sparse_format_supported(fmt_s)) {
      std::cout << "Error: WGMMA_SP unsupported input format: "
                << vt::fmt_string(fmt_s) << " (id=" << fmt_s << ")" << std::endl;
      std::abort();
    }

    uint32_t ratio   = elem_ratio(fmt_s);
    uint32_t k_words = is_sparse ? cfg::tcK : kFedpWords;
    uint32_t e_bits = elem_bits(fmt_s);

    // Decode smem descriptors (B always from smem, A optionally).
    if (is_setup_uop) {
      wgmma_desc_[wid][0] = a_desc;
      wgmma_desc_[wid][1] = b_desc;
      if (is_a_smem) {
        lmem_desc_[wid][0] = {uint64_t(VX_MEM_LMEM_BASE_ADDR) + vt::smem_desc_offset(a_desc), vt::smem_desc_stride(a_desc) * 8 / e_bits, false};
      }
      lmem_desc_[wid][1] = {uint64_t(VX_MEM_LMEM_BASE_ADDR) + vt::smem_desc_offset(b_desc), vt::smem_desc_stride(b_desc) * 8 / e_bits, false};
      uint32_t nrc = (cd_nregs == 0) ? 8 : (cd_nregs == 1) ? 16 : 32;
      cur_xtile_n_ = (nrc * VX_CFG_NUM_THREADS) / wg_cfg::xtileM;
      return;
    }

    lmem_desc_t sd_a = lmem_desc_[wid][0];
    lmem_desc_t sd_b = lmem_desc_[wid][1];
    // load_lmem_word distinguishes A from B by descriptor base.
    cur_a_desc_base_ = is_a_smem ? sd_a.base : ~uint64_t(0);
    cur_is_sparse_ = is_sparse;
    // NRC: cd_nregs 0/1/2 → 8/16/32; xtileN = NRC * NT / xtileM.
    {
      uint32_t nrc = (cd_nregs == 0) ? 8 : (cd_nregs == 1) ? 16 : 32;
      cur_xtile_n_ = (nrc * VX_CFG_NUM_THREADS) / wg_cfg::xtileM;
    }

    reg_data_t a_tile[cfg::tcM * kFedpWords] = {};
    for (uint32_t i = 0; i < cfg::tcM; ++i) {
      uint32_t a_row_idx = step_m * cfg::tcM + i;
      for (uint32_t z = 0; z < k_words; ++z) {
        if (is_a_smem) {
          uint32_t k_elem = (step_k * k_words + z) * ratio;
          a_tile[i * k_words + z].u32 =
              load_lmem_word(sd_a, a_row_idx, k_elem, fmt_s, false, false);
        } else {
          if (z < cfg::tcK) {
            a_tile[i * k_words + z] = rs1_data.at(i * cfg::tcK + z);
          } else {
            a_tile[i * k_words + z] = rs2_data.at(i * cfg::tcK + (z - cfg::tcK));
          }
        }
      }
    }

    reg_data_t b_tile[cfg::tcM * cfg::tcN * kFedpWords] = {};
    if (is_sparse) {
      uint32_t ebits       = elem_bits(fmt_s);
      uint32_t rtl_i_ratio = 32 / ebits;
      uint32_t meta_row_w  = k_words * 2 * rtl_i_ratio;
      // Bank encoding {step_m, step_k_half}: m=1 → bank (cfg::k_steps/2).
      uint32_t wg_bank = step_m * (cfg::k_steps / 2) + step_k;
      // Metadata is preloaded into sparse_meta_ via TCU_LD before dispatch.
      auto meta_bit_wg = [&](uint32_t bit_idx) -> uint32_t {
        uint32_t word_idx = wg_bank * kMaxMetaCols + bit_idx / 32;
        uint32_t word_val = sparse_meta_.at(wid).at(word_idx);
        // Trace: META_RD (CSV: wid,step_m,step_k,bank,value).
        if (const char* p = std::getenv("VORTEX_TCU_TRACE")) {
          if (p[0] == '1' && (bit_idx % 32) == 0) {
            fprintf(stderr, "META_RD,%u,%u,%u,%u,0x%08x\n",
                    wid, step_m, step_k, wg_bank, word_val);
          }
        }
        return (word_val >> (bit_idx % 32)) & 1u;
      };
      for (uint32_t i = 0; i < cfg::tcM; ++i) {
        uint32_t row_base = i * meta_row_w;
        for (uint32_t j = 0; j < cfg::tcN; ++j) {
          uint32_t b_col_idx = step_n * cfg::tcN + j;
          for (uint32_t z = 0; z < k_words; ++z) {
            uint32_t lo = 0, hi = 0;
            for (uint32_t b = 0; b < rtl_i_ratio; ++b) {
              lo |= meta_bit_wg(row_base + rtl_i_ratio * z              + b) << b;
              hi |= meta_bit_wg(row_base + rtl_i_ratio * (k_words + z) + b) << b;
            }
            constexpr uint32_t kCompression = 2;
            uint32_t k_elem_b0 = (step_k * k_words + z) * ratio * kCompression;
            uint32_t bword0 = load_lmem_word(sd_b, k_elem_b0,         b_col_idx, fmt_s, true, true);
            uint32_t bword1 = load_lmem_word(sd_b, k_elem_b0 + ratio, b_col_idx, fmt_s, true, true);
            uint32_t gathered = gather_sparse(bword0, bword1, lo, hi, ebits);
            b_tile[(i * cfg::tcN + j) * k_words + z].u32 = gathered;
            // Trace: B-gather (CSV: wid,step_m,step_n,i,lane,bword0,bword1,lo,hi,gathered).
            if (const char* p = std::getenv("VORTEX_TCU_TRACE")) {
              if (p[0] == '1') {
                fprintf(stderr, "GATHER,%u,%u,%u,%u,%u,0x%08x,0x%08x,%u,%u,0x%08x\n",
                        wid, step_m, step_n, i, j*k_words+z,
                        bword0, bword1, lo, hi, gathered);
              }
            }
          }
        }
      }
    } else {
      for (uint32_t i = 0; i < cfg::tcM; ++i) {
        for (uint32_t j = 0; j < cfg::tcN; ++j) {
          uint32_t b_col_idx = step_n * cfg::tcN + j;
          for (uint32_t z = 0; z < k_words; ++z) {
            uint32_t k_elem = (step_k * k_words + z) * ratio;
            b_tile[(i * cfg::tcN + j) * k_words + z].u32 =
                load_lmem_word(sd_b, k_elem, b_col_idx, fmt_s, true, false);
          }
        }
      }
    }

    fedp_tile(wid, step_m, step_n, step_k, fmt_s, fmt_d,
              a_tile, b_tile, rs3_data, rd_data,
              is_sparse, k_words, k_words,
              wg_cfg::k_steps * wg_cfg::fedpK);
    __unused(b_desc);
  }

  const PerfStats& perf_stats() const {
    // lmem_reads: total MemReq traffic from TcuTbuf (abuf + bbuf).
    perf_stats_.lmem_reads = simobject_->tbuf()->reads();
    return perf_stats_;
  }

private:
  uint32_t elem_bits(uint32_t fmt_s) const {
    switch (fmt_s) {
    case vt::fp32::id:
    case vt::tf32::id:
    case vt::int32::id:
      return 32;
    case vt::fp16::id:
    case vt::bf16::id:
      return 16;
    case vt::fp8::id:
    case vt::bf8::id:
    case vt::int8::id:
    case vt::uint8::id:
    case vt::mxfp8::id:
    case vt::mxbf8::id:
      return 8;
    case vt::int4::id:
    case vt::uint4::id:
    case vt::mxfp4::id:
    case vt::nvfp4::id:
      return 4;
    default:
      std::abort();
    }
  }

  uint32_t elem_ratio(uint32_t fmt_s) const {
    return 32 / elem_bits(fmt_s);
  }

  uint32_t mx_tile_scale_blocks(uint32_t fmt_s, uint32_t tile_k_words) const {
    uint32_t logical_tile_k = tile_k_words * elem_ratio(fmt_s);
    uint32_t block_size = vt::mx_scale_block_size(fmt_s);
    return std::max(1u, (logical_tile_k + block_size - 1) / block_size);
  }

  static uint8_t meta_byte(const std::vector<uint32_t>& words, uint32_t index) {
    return (words.at(index / 4) >> (8 * (index & 0x3))) & 0xff;
  }

  uint32_t eval_mx_fedp(uint32_t wid, uint32_t fmt_s, uint32_t fmt_d,
                        uint32_t step_m, uint32_t step_n, uint32_t step_k,
                        uint32_t i, uint32_t j, const reg_data_t* a_row,
                        const reg_data_t* b_col, uint32_t c_val, bool is_sparse,
                        uint32_t fedp_words, uint32_t tile_k_words) const {
#ifndef VX_CFG_TCU_MX_ENABLE
    __unused(wid, fmt_s, fmt_d, step_m, step_n, step_k, i, j, a_row, b_col,
             is_sparse, fedp_words, tile_k_words);
    return c_val;
#else
    uint32_t ratio = elem_ratio(fmt_s);
    uint32_t scale_blocks_k = mx_tile_scale_blocks(fmt_s, tile_k_words);
    uint32_t block_size = vt::mx_scale_block_size(fmt_s);
    auto scale_a = [&](uint32_t elem_k) {
      uint32_t row = step_m * cfg::tcM + i;
      return meta_byte(mx_meta_a_.at(wid), row * scale_blocks_k + elem_k / block_size);
    };
    auto scale_b = [&](uint32_t elem_k) {
      uint32_t col = step_n * cfg::tcN + j;
      return meta_byte(mx_meta_b_.at(wid), col * scale_blocks_k + elem_k / block_size);
    };

    if (fmt_d == vt::fp32::id) {
#ifdef VX_CFG_TCU_TYPE_TFR
      // The native datapath: the TfrFedp model, with each lane's (16 bits of
      // a register) scales taken at its first element.
      {
        int eb = 0, sb = 0;
        bool e4m3_scale = false;
        if (fmt_s == vt::mxfp8::id) {
          eb = 4; sb = 3;
        } else if (fmt_s == vt::mxbf8::id) {
          eb = 5; sb = 2;
        } else if (fmt_s == vt::mxfp4::id) {
          eb = 2; sb = 1;
        } else if (fmt_s == vt::nvfp4::id) {
          eb = 2; sb = 1; e4m3_scale = true;
        } else {
          std::abort();
        }
        uint32_t sparse_ratio = is_sparse ? 2 : 1;
        std::vector<uint32_t> a(fedp_words), b(fedp_words);
        std::vector<uint8_t> sf_a(2 * fedp_words), sf_b(2 * fedp_words);
        for (uint32_t z = 0; z < fedp_words; ++z) {
          a[z] = a_row[z].u32;
          b[z] = b_col[z].u32;
        }
        for (uint32_t lane = 0; lane < 2 * fedp_words; ++lane) {
          uint32_t z = lane / 2;
          uint32_t e = (lane % 2) * (ratio / 2);
          uint32_t elem_k = ((step_k * fedp_words + z) * ratio + e) * sparse_ratio;
          sf_a[lane] = uint8_t(scale_a(elem_k));
          sf_b[lane] = uint8_t(scale_b(elem_k));
        }
        TfrFedp fedp(eb, sb);
        float c;
        std::memcpy(&c, &c_val, sizeof(c));
        float d = fedp(a.data(), b.data(), c, fedp_words, sf_a.data(), sf_b.data(), e4m3_scale);
        uint32_t d_bits;
        std::memcpy(&d_bits, &d, sizeof(d_bits));
        return d_bits;
      }
#endif
      uint32_t acc = c_val;
      for (uint32_t z = 0; z < fedp_words; ++z) {
        for (uint32_t e = 0; e < ratio; ++e) {
          uint32_t sparse_ratio = is_sparse ? 2 : 1;
          uint32_t elem_k = ((step_k * fedp_words + z) * ratio + e) * sparse_ratio;
          uint32_t xa, xb;
          if (fmt_s == vt::mxfp8::id) {
            xa = rv_mxfp8tof_s((a_row[z].u32 >> (8 * e)) & 0xff, scale_a(elem_k), 0, nullptr);
            xb = rv_mxfp8tof_s((b_col[z].u32 >> (8 * e)) & 0xff, scale_b(elem_k), 0, nullptr);
          } else if (fmt_s == vt::mxbf8::id) {
            xa = rv_mxbf8tof_s((a_row[z].u32 >> (8 * e)) & 0xff, scale_a(elem_k), 0, nullptr);
            xb = rv_mxbf8tof_s((b_col[z].u32 >> (8 * e)) & 0xff, scale_b(elem_k), 0, nullptr);
          } else if (fmt_s == vt::mxfp4::id) {
            xa = rv_mxfp4tof_s((a_row[z].u32 >> (4 * e)) & 0xf, scale_a(elem_k), 0, nullptr);
            xb = rv_mxfp4tof_s((b_col[z].u32 >> (4 * e)) & 0xf, scale_b(elem_k), 0, nullptr);
          } else if (fmt_s == vt::nvfp4::id) {
            xa = rv_nvfp4tof_s((a_row[z].u32 >> (4 * e)) & 0xf, scale_a(elem_k), 0, nullptr);
            xb = rv_nvfp4tof_s((b_col[z].u32 >> (4 * e)) & 0xf, scale_b(elem_k), 0, nullptr);
          } else {
            std::abort();
          }
          acc = rv_fadd_s(rv_fmul_s(xa, xb, 0, nullptr), acc, 0, nullptr);
        }
      }
      return acc;
    }

    std::cout << "Error: unsupported MX mma format: " << fmt_s << " -> " << fmt_d << "!" << std::endl;
    std::abort();
#endif
  }

  // Element offset of one operand element from its descriptor base. A is
  // (row=M, col=K) and B is (row=K, col=N); `pack_along_row` selects B.
  static uint64_t elem_offset(const lmem_desc_t& desc, uint32_t row, uint32_t col,
                              uint32_t e_bits, uint32_t xtile_n,
                              bool pack_along_row, bool sparse_b,
                              bool sparse_a_layout) {
    uint32_t ratio = (e_bits >= 32) ? 1 : (32 / e_bits);
    uint64_t elem_off;
    if (desc.ldm == 0) {
      // Block-major SMEM. K dimension is along col for A (pack_along_row
      // false) and along row for B (pack_along_row true).
      uint32_t k_blk_dim = (sparse_a_layout && !pack_along_row)
                         ? (cfg::tcK * ratio)
                         : (kFedpWords * ratio);
      if (pack_along_row && sparse_b) {
        // Sparse B in flat (candidate-pair) layout: block-contiguous
        // K-word-major / N-inner order [kw_in*tcN + n_in].
        uint32_t b_tcK_words = cfg::tcK * 2;
        uint32_t k_word = row / ratio;
        uint32_t elem   = row % ratio;
        uint32_t k_blk  = k_word / b_tcK_words;
        uint32_t kw_in  = k_word % b_tcK_words;
        uint32_t n_blk  = col / cfg::tcN;
        uint32_t n_in   = col % cfg::tcN;
        uint32_t blk_words = cfg::tcN * b_tcK_words;
        uint32_t n_steps   = xtile_n / cfg::tcN;
        uint64_t word_off  = (k_blk * n_steps + n_blk) * blk_words
                           + (kw_in * cfg::tcN + n_in);
        elem_off = word_off * ratio + elem;
      } else if (pack_along_row) {
        // Dense B (block-major): r is K coord, c is N coord; N outer, K inner.
        uint32_t k_blk = row / k_blk_dim;
        uint32_t r_in  = row % k_blk_dim;
        uint32_t n_blk = col / cfg::tcN;
        uint32_t n_in  = col % cfg::tcN;
        uint32_t b_blk_elems = k_blk_dim * cfg::tcN;
        uint32_t n_steps     = xtile_n / cfg::tcN;
        elem_off = (k_blk * n_steps + n_blk) * b_blk_elems
                 + n_in * k_blk_dim + r_in;
      } else {
        // A: r is M coord, c is K coord.
        uint32_t m_blk = row / cfg::tcM;
        uint32_t i_in  = row % cfg::tcM;
        uint32_t k_blk = col / k_blk_dim;
        uint32_t k_in  = col % k_blk_dim;
        uint32_t a_blk_elems = cfg::tcM * k_blk_dim;
        elem_off = (k_blk * wg_cfg::m_steps + m_blk) * a_blk_elems
                 + i_in * k_blk_dim + k_in;
      }
    } else if (desc.col_major) {
      elem_off = uint64_t(col) * desc.ldm + row;
    } else if (pack_along_row) {
      // B: K-major (N-outer K-inner). row=K, col=N;
      // ldm = stride in elements between N rows.
      elem_off = uint64_t(col) * desc.ldm + row;
    } else {
      // A: row-major (M-outer K-inner). row=M, col=K.
      elem_off = uint64_t(row) * desc.ldm + col;
    }
    return elem_off;
  }

  // Gather one 32-bit operand word from a TCU line cache.
  // `read_line` is supplied by the caller and routes to the right per-role
  // buffer inside TcuTbuf (A → read_a, B → read_b). For sub-32-bit formats,
  // packs `ratio = 32 / e_bits` adjacent elements along the K direction
  // (col for A, row for B via pack_along_row).
  template <typename ReadLine>
  uint32_t gather_word(ReadLine read_line, const lmem_desc_t& desc,
                       uint32_t row, uint32_t col,
                       uint32_t fmt_s, bool pack_along_row, bool sparse_b,
                       bool sparse_a_layout) const {
    uint32_t e_bits  = elem_bits(fmt_s);
    uint32_t ratio   = (e_bits >= 32) ? 1 : (32 / e_bits);
    uint32_t result = 0;
    for (uint32_t r = 0; r < ratio; ++r) {
      uint32_t cur_row = pack_along_row ? (row + r) : row;
      uint32_t cur_col = pack_along_row ? col       : (col + r);
      uint64_t elem_off = elem_offset(desc, cur_row, cur_col, e_bits, cur_xtile_n_,
                                      pack_along_row, sparse_b, sparse_a_layout);
      uint64_t byte_addr = desc.base + elem_off * e_bits / 8;
      auto line = read_line(byte_addr);
      if (!line) {
        std::cout << "Error: TCU buffer miss at 0x" << std::hex << byte_addr
                  << std::dec << std::endl;
        std::abort();
      }
      uint32_t off = byte_addr & (VX_CFG_MEM_BLOCK_SIZE - 1);
      if (e_bits == 32) {
        result = (uint32_t((*line)[off    ]))        |
                 (uint32_t((*line)[off + 1]) << 8)   |
                 (uint32_t((*line)[off + 2]) << 16)  |
                 (uint32_t((*line)[off + 3]) << 24);
        return result;
      } else if (e_bits == 16) {
        uint32_t val = uint32_t((*line)[off]) | (uint32_t((*line)[off + 1]) << 8);
        result |= (val & 0xFFFF) << (r * 16);
      } else if (e_bits == 8) {
        result |= uint32_t((*line)[off]) << (r * 8);
      } else if (e_bits == 4) {
        uint32_t val = (uint32_t((*line)[off]) >> (4 * (elem_off & 1))) & 0xf;
        result |= val << (r * 4);
      } else {
        std::abort();
      }
    }
    return result;
  }

  // Routes A reads through the current block's A buffer; B through the shared B buffer.
  // sparse_b selects the flat candidate-pair B layout.
  uint32_t load_lmem_word(const lmem_desc_t& desc, uint32_t row, uint32_t col,
                          uint32_t fmt_s, bool pack_along_row, bool sparse_b) const {
    auto& tbuf = simobject_->tbuf();
    if (desc.base == cur_a_desc_base_) {
      uint32_t b = cur_block_;
      return gather_word([&](uint64_t addr) { return tbuf->read_a(b, addr); },
                         desc, row, col, fmt_s, pack_along_row, false, cur_is_sparse_);
    }
    return gather_word([&](uint64_t addr) { return tbuf->read_b(addr); },
                       desc, row, col, fmt_s, pack_along_row, sparse_b, false);
  }

  static constexpr uint32_t kSparseKSteps = cfg::k_steps / 2;
  static constexpr uint32_t kMetaBanks = cfg::m_steps * kSparseKSteps;
  static constexpr uint32_t kMaxMetaCols = VX_CFG_NUM_THREADS / 2;

  // FEDP tile computation for both WMMA and WGMMA.
  // a_tile: [tcM][k_words] flat array of pre-loaded A operand words.
  // b_tile: [tcM][tcN][k_words] flat array of pre-loaded B operand words
  //         (for dense, each i-slice is identical; for sparse, already gathered).
  void fedp_tile(uint32_t wid,
                 uint32_t step_m, uint32_t step_n, uint32_t step_k,
                 uint32_t fmt_s, uint32_t fmt_d,
                 const reg_data_t* a_tile,
                 const reg_data_t* b_tile,
                 const std::vector<reg_data_t>& rs3_data,
                 std::vector<reg_data_t>& rd_data,
                 bool is_sparse,
                 uint32_t k_words = cfg::tcK,
                 uint32_t fedp_words = cfg::tcK,
                 uint32_t tile_k_words = cfg::k_steps * cfg::tcK) {
    PFN_FEDP_N fedp = vt::mx_scale_format(fmt_s) ? nullptr : select_FEDP_N(fmt_s, fmt_d);

    for (uint32_t i = 0; i < cfg::tcM; ++i) {
      for (uint32_t j = 0; j < cfg::tcN; ++j) {
        auto t = i * cfg::tcN + j;
        auto c_val = rs3_data.at(t).u32;
        auto a_row = &a_tile[i * k_words];
        auto b_col = &b_tile[(i * cfg::tcN + j) * k_words];

        uint32_t d_val = vt::mx_scale_format(fmt_s)
                       ? eval_mx_fedp(wid, fmt_s, fmt_d, step_m, step_n, step_k,
                                      i, j, a_row, b_col, c_val, is_sparse,
                                      fedp_words, tile_k_words)
                       : fedp(a_row, b_col, c_val, k_words);

        rd_data.at(t).u64 = nan_box(d_val);
        DTH(3, simobject_->name() << " FEDP"
            << ": wid=" << wid << ", i=" << i << ", j=" << j
            << ", m=" << step_m << ", n=" << step_n
            << ", k=" << step_k << std::hex
            << ", a0=0x" << a_row[0].u32 << ", b0=0x" << b_col[0].u32
            << ", c=0x" << c_val << ", d=0x" << d_val << std::dec << std::endl);
      }
    }
  }

  TcuUnit*   simobject_;
  Core*         core_;
  std::vector<std::vector<uint32_t>> sparse_meta_;
#ifdef VX_CFG_TCU_MX_ENABLE
  std::vector<std::vector<uint32_t>> mx_meta_a_;
  std::vector<std::vector<uint32_t>> mx_meta_b_;
#endif
  std::unordered_map<uint32_t, lmem_desc_t[2]> lmem_desc_;
  std::array<std::array<uint32_t, 2>, VX_CFG_NUM_WARPS> wgmma_desc_;
  mutable PerfStats perf_stats_;
  // Per-block guard: execute already happened for this trace; reset on pop().
  std::array<bool, VX_CFG_NUM_TCU_BLOCKS> exec_done_;
  // Output slices of the head uop already through the FEDP array.
  std::array<uint32_t, VX_CFG_NUM_TCU_BLOCKS> slices_;
  // Cycles at which each block's results sent so far become visible.
  std::array<std::vector<uint64_t>, VX_CFG_NUM_TCU_BLOCKS> result_due_;
  // True while a block is between its first and last WGMMA uop.
  std::array<bool, VX_CFG_NUM_TCU_BLOCKS> in_wgmma_;
  // Current block index, set before delegating to wgmma().
  uint32_t cur_block_ = 0;
  // A-descriptor base for the current wgmma(); distinguishes A from B in load_lmem_word.
  uint64_t cur_a_desc_base_ = ~uint64_t(0);
  bool cur_is_sparse_ = false;
  // xtileN for the active WGMMA (derived from NRC).
  uint32_t cur_xtile_n_ = 8;
  // CTA each block holds while mid-WGMMA (-1 = none).
  std::array<int32_t, VX_CFG_NUM_TCU_BLOCKS> cta_owner_a_{};
#ifdef VX_CFG_TCU_WGMMA_ENABLE
  std::array<abuf_slot_t, VX_CFG_NUM_TCU_BLOCKS> abuf_;
  bbuf_slot_t bbuf_;
#endif
};

///////////////////////////////////////////////////////////////////////////////

op_string_t TcuUnit::op_string(TcuType tcu_type, IntrTcuArgs args) {
  bool is_sparse = tcu_is_sparse(tcu_type);
  switch (tcu_type) {
  case TcuType::WMMA:
  case TcuType::WMMA_SP:
    return {"WMMA." + std::string(is_sparse ? "SP." : "") + std::string(vt::fmt_string(args.fmt_s)) + "." + std::string(vt::fmt_string(args.fmt_d))
             + "." + std::to_string(args.step_m) + "." + std::to_string(args.step_n)
             + "." + std::to_string(args.step_k), ""};
  case TcuType::WGMMA:
  case TcuType::WGMMA_SP: {
    uint32_t nrc = (args.cd_nregs == 0) ? 8 : (args.cd_nregs == 1) ? 16 : 32;
    std::string src_mode = std::string(args.is_a_smem ? "S" : "R") + "S";
    return {"WGMMA." + std::string(is_sparse ? "SP." : "") + std::string(vt::fmt_string(args.fmt_s)) + "." + std::string(vt::fmt_string(args.fmt_d))
             + "." + std::to_string(nrc) + "." + src_mode
             + "." + std::to_string(args.step_m) + "." + std::to_string(args.step_n), ""};
  }
  case TcuType::TCU_LD:
    return {"TCU_LD." + std::string((args.fmt_d & 0x10) ? "MX." : "SP.")
             + std::string(vt::fmt_string(args.fmt_s)) + ".slot" + std::to_string(args.fmt_d & 0xf), ""};
  default:
    std::abort();
  }
}

///////////////////////////////////////////////////////////////////////////////

uint32_t TcuUopGen::uop_count(const Instr& instr) {
  if (instr.get_fu_type() != FUType::TCU)
    return 1;

  auto tcu_type = std::get<TcuType>(instr.get_op_type());
#ifdef VX_CFG_TCU_WGMMA_ENABLE
  auto args = std::get<IntrTcuArgs>(instr.get_args());
#endif

  if (tcu_is_wmma(tcu_type)) {
    using wmma = vt::wmma_config_t<VX_CFG_NUM_THREADS>;
    bool is_sparse = tcu_is_sparse(tcu_type);
    // Metadata SRAM is filled by a preceding TCU_LD instruction.
    uint32_t k_count = is_sparse ? (wmma::k_steps / 2) : wmma::k_steps;
    uint32_t mma_steps = (wmma::sym_sparse && is_sparse)
                       ? (wmma::m_steps * wmma::n_steps * wmma::k_steps)
                       : (wmma::m_steps * wmma::n_steps * k_count);
    return mma_steps;
  }

#ifdef VX_CFG_TCU_WGMMA_ENABLE
  if (tcu_is_wgmma(tcu_type)) {
    bool is_sparse = tcu_is_sparse(tcu_type);
    bool needs_setup = kFedp2K && !args.is_a_smem && !is_sparse;
    uint32_t nrc = (args.cd_nregs == 0) ? 8 : (args.cd_nregs == 1) ? 16 : 32;
    uint32_t k_count = is_sparse ? std::max(1u, wg_cfg::k_steps / 2) : wg_cfg::k_steps;
    uint32_t mma_uops = k_count * nrc;
    return mma_uops + needs_setup;
  }
#endif

  return 1;
}

///////////////////////////////////////////////////////////////////////////////

Instr::Ptr TcuUopGen::get(const Instr& macro_instr, uint32_t uop_index) {
  auto tcu_type = std::get<TcuType>(macro_instr.get_op_type());
  auto args = std::get<IntrTcuArgs>(macro_instr.get_args());
  uint64_t parent_uuid = macro_instr.get_uuid();
  uint64_t uop_uuid = make_uop_uuid(parent_uuid, uop_index);

  auto uop_instr = std::allocate_shared<Instr>(pool_, uop_uuid, FUType::TCU);
  uop_instr->set_parent_uuid(parent_uuid);
  uop_instr->set_fcsr_use(macro_instr.fcsr_reads(), macro_instr.fcsr_writes());

  if (tcu_is_wmma(tcu_type)) {
    using wmma = vt::wmma_config_t<VX_CFG_NUM_THREADS>;
    constexpr uint32_t rc_base = 0, ra_base = 10;
    constexpr uint32_t rb_base = (wmma::NRB == 4) ? 28 : 24;
    bool is_sparse = tcu_is_sparse(tcu_type);
    uint32_t fmt_s = args.fmt_s;
    uint32_t fmt_d = args.fmt_d;

    {
      // MMA uops.
      uint32_t mma_idx = uop_index;
      uint32_t k_count = is_sparse ? (wmma::k_steps / 2) : wmma::k_steps;

      if (wmma::sym_sparse && is_sparse) {
        // Symmetric-sparse: flatten (m, n, k) into a single counter
        constexpr uint32_t lg_n = (wmma::n_steps > 1) ? log2ceil(wmma::n_steps) : 0;
        constexpr uint32_t lg_k = (wmma::k_steps > 1) ? log2ceil(wmma::k_steps) : 0;
        constexpr uint32_t step_bits = lg_n + lg_k;
        constexpr uint32_t step_mask = step_bits ? ((1u << step_bits) - 1) : 0;

        uint32_t n_sp = step_bits ? (mma_idx & step_mask) : 0;
        uint32_t m_sp = mma_idx >> step_bits;
        // n_sp encodes both actual N step (high bits) and lo/hi half (low lg_k bits).
        // Extract just the N step for accum indexing; n_sp is still used for B register selection.
        uint32_t actual_n = lg_k ? (n_sp >> lg_k) : n_sp;
        uint32_t reg_rs3 = rc_base + (mma_idx >> 1);
        uop_instr->set_op_type(TcuType::WMMA_SP);
        uop_instr->set_args(IntrTcuArgs{0, 0, fmt_s, fmt_d, m_sp, actual_n, 0, 0, 0, 0});
        uop_instr->set_dest_reg(reg_rs3, RegType::Float);
        uop_instr->set_src_reg(0, ra_base + m_sp, RegType::Float);
        uop_instr->set_src_reg(1, rb_base + n_sp, RegType::Float);
        uop_instr->set_src_reg(2, reg_rs3, RegType::Float);
        // Symmetric sparse: no k-loop, always wb=1 and always reads C from RF.
        // Even uops run the low half of each block's columns, odd uops the high half.
        ThreadMask tmask(VX_CFG_NUM_THREADS);
        bool hi_half = (mma_idx & 1);
        for (uint32_t lane = 0; lane < VX_CFG_NUM_THREADS; ++lane) {
          if (((lane % wmma::tcN) >= (wmma::tcN / 2)) == hi_half) {
            tmask.set(lane);
          }
        }
        uop_instr->set_tmask(tmask);
      } else {
        // Standard k-major triple loop (dense or non-sym sparse)
        uint32_t mn = wmma::m_steps * wmma::n_steps;
        uint32_t k = mma_idx / mn;
        uint32_t rem = mma_idx % mn;
        uint32_t m = rem / wmma::n_steps;
        uint32_t n = rem % wmma::n_steps;
        uint32_t reg_rs1, reg_rs2, reg_rs3;
        if (is_sparse) {
          // Sparse non-sym: A=identity, B and C permuted.
          uint32_t a_off = (m / wmma::a_sub_blocks) * k_count + k;
          reg_rs1 = ra_base + a_off;
          reg_rs2 = rb_base + frag::rb_off_sp(n, k);
          reg_rs3 = rc_base + frag::rc_off_sp(m, n);
        } else {
          reg_rs1 = ra_base + frag::ra_off(m, k);
          reg_rs2 = rb_base + frag::rb_off(n, k);
          reg_rs3 = rc_base + frag::rc_off(m, n);
        }
        uop_instr->set_op_type(is_sparse ? TcuType::WMMA_SP : TcuType::WMMA);
        uop_instr->set_args(IntrTcuArgs{0, 0, fmt_s, fmt_d, m, n, k, 0, 0, 0});
        uop_instr->set_dest_reg(reg_rs3, RegType::Float);
        uop_instr->set_src_reg(0, reg_rs1, RegType::Float);
        uop_instr->set_src_reg(1, reg_rs2, RegType::Float);
        uop_instr->set_src_reg(2, reg_rs3, RegType::Float);
      }
    }
  }
#ifdef VX_CFG_TCU_WGMMA_ENABLE
  else if (tcu_is_wgmma(tcu_type)) {
    constexpr uint32_t m_steps = wg_cfg::m_steps;
    constexpr uint32_t k_steps = wg_cfg::k_steps;
    constexpr uint32_t a_reg_k_steps = 2;
    uint32_t fmt_s = args.fmt_s;
    uint32_t fmt_d = args.fmt_d;
    bool is_sparse = tcu_is_sparse(tcu_type);
    bool is_a_smem = args.is_a_smem;
    bool needs_setup = kFedp2K && !is_a_smem && !is_sparse;
    uint32_t cd_nregs = args.cd_nregs;
    uint32_t k_count = is_sparse ? std::max(1u, k_steps / 2) : k_steps;
    uint32_t total = uop_count(macro_instr);
    constexpr uint32_t a0 = 10, a1 = 11;

    {
      uop_instr->set_op_type(is_sparse ? TcuType::WGMMA_SP : TcuType::WGMMA);

      if (needs_setup && uop_index == 0) {
        uop_instr->set_args(IntrTcuArgs{is_a_smem ? 1u : 0u, cd_nregs,
                                       fmt_s, fmt_d, 0, 0, 0, 1, 0, 1});
        uop_instr->set_src_reg(0, a0, RegType::Integer);
        uop_instr->set_src_reg(1, a1, RegType::Integer);
        uop_instr->set_fu_lock(true);
        uop_instr->set_fu_unlock(false);
        return uop_instr;
      }

      // MMA phase
      uint32_t mma_idx = uop_index - needs_setup;
      uint32_t ra_base = is_a_smem ? 10 : 24;

      // Loop order: m (inner) -> n (middle) -> k (outer). K-outer maximizes
      // per-block A-buffer reuse: each A_w[m,k] is consumed across the entire
      // (n,m) inner sweep, and each shared B[k,n] is consumed for m_steps
      // consecutive uops.
      uint32_t compute_total = total - needs_setup;
      uint32_t mn = compute_total / k_count;
      uint32_t k = mma_idx / mn;
      uint32_t rem = mma_idx % mn;
      uint32_t n = rem / m_steps;
      uint32_t m = rem % m_steps;
      uint32_t r = n * m_steps + m;

      bool first = (mma_idx == 0);
      bool last  = (uop_index == (total - 1));
      uop_instr->set_args(IntrTcuArgs{is_a_smem ? 1u : 0u, cd_nregs,
                                     fmt_s, fmt_d, m, n, k, first ? 1u : 0u, last ? 1u : 0u, 0});
      uop_instr->set_dest_reg(r, RegType::Float);
      if (!is_a_smem) {
        uint32_t rs1_off = is_sparse ? m : (m * a_reg_k_steps + k);
        uop_instr->set_src_reg(0, ra_base + rs1_off, RegType::Float);
        if (needs_setup)
          uop_instr->set_src_reg(1, ra_base + rs1_off + 1, RegType::Float);
      } else if (first) {
        uop_instr->set_src_reg(0, a0, RegType::Integer);
      }
      if (first && !needs_setup)
        uop_instr->set_src_reg(1, a1, RegType::Integer);
      uop_instr->set_src_reg(2, r, RegType::Float);
    }
    // fu_lock on first uop, fu_unlock on last uop
    uop_instr->set_fu_lock(uop_index == 0);
    uop_instr->set_fu_unlock(uop_index == (total - 1));
  }
#endif

  return uop_instr;
}

///////////////////////////////////////////////////////////////////////////////

TcuUnit::TcuUnit(const SimContext &ctx, const char* name, Core* core)
	: FuncUnit(ctx, name, core, 1u << log2ceil(VX_CFG_TCU_LATENCY + 1)) // landing-queue depth bounds results awaiting the consumer
#ifdef TCU_META_ENABLE
	, agu_req_out(TCU_AGU_PORTS, this)
	, agu_rsp_in(TCU_AGU_PORTS, this)
#endif
	, impl_(new Impl(this, core))
{}

TcuUnit::~TcuUnit() {
  delete impl_;
}

void TcuUnit::set_tbuf(TcuTbuf::Ptr tbuf) {
  tbuf_ = std::move(tbuf);
}

const TcuTbuf::Ptr& TcuUnit::tbuf() const {
  return tbuf_;
}

void TcuUnit::on_reset() {
  impl_->reset();
}

void TcuUnit::on_tick() {
  impl_->tick();
}

const TcuUnit::PerfStats &TcuUnit::perf_stats() const {
	return impl_->perf_stats();
}

void TcuUnit::wmma(uint32_t wid,
                      uint32_t fmt_s,
                      uint32_t fmt_d,
                      uint32_t step_m,
                      uint32_t step_n,
                      uint32_t step_k,
                      const std::vector<reg_data_t>& rs1_data,
                      const std::vector<reg_data_t>& rs2_data,
                      const std::vector<reg_data_t>& rs3_data,
                      std::vector<reg_data_t>& rd_data,
                      bool is_sparse) {
  impl_->wmma(wid, fmt_s, fmt_d, step_m, step_n, step_k,
              rs1_data, rs2_data, rs3_data,
              rd_data,
              is_sparse);
}

void TcuUnit::wgmma(uint32_t wid,
                    uint32_t fmt_s,
                    uint32_t fmt_d,
                    uint32_t step_m,
                    uint32_t step_n,
                    uint32_t step_k,
                    uint32_t a_desc,
                    uint32_t b_desc,
                    const std::vector<reg_data_t>& rs1_data,
                    const std::vector<reg_data_t>& rs2_data,
                    const std::vector<reg_data_t>& rs3_data,
                    std::vector<reg_data_t>& rd_data,
                    bool is_sparse,
                    uint32_t cd_nregs,
                    uint32_t is_a_smem,
                    uint32_t is_setup_uop) {
  impl_->wgmma(wid, fmt_s, fmt_d, step_m, step_n, step_k, a_desc, b_desc,
               rs1_data, rs2_data, rs3_data, rd_data,
               is_sparse, cd_nregs, is_a_smem, is_setup_uop);
}
