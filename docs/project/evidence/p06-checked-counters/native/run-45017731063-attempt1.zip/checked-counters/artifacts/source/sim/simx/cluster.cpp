// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "cluster.h"
#include <algorithm>
#include "delay_buffer.h"
#include "socket.h"
#include "core.h"
#include "local_mem.h"
#include "constants.h"
#include "types.h"
#include "debug.h"
#ifdef SIMX_CLUSTER_UNIT_MMU
#include "mem/mmu.h"
#endif
#ifdef VX_CFG_EXT_OM_ENABLE
#include "om_core.h"
#include "om_unit.h"
#include "sfu_unit.h"
#endif
#ifdef VX_CFG_EXT_RASTER_ENABLE
#include "raster_core.h"
#include "raster_unit.h"
#include "sfu_unit.h"
#endif

using namespace vortex;

// Output-buffer stages of the socket and cluster gbar arbiters (OUT_BUF 3, one
// cycle each), present when the arbiter has more than one input.
static constexpr uint32_t kSocketArbLag  = (VX_CFG_SOCKET_SIZE > 1) ? 1 : 0;
static constexpr uint32_t kClusterArbLag = (NUM_SOCKETS > 1) ? 1 : 0;

class Cluster::Impl {
public:
  Impl(Cluster* simobject)
    : simobject_(simobject)
    , sockets_(NUM_SOCKETS)
    , gbarriers_(VX_CFG_NUM_BARRIERS)
    , cores_per_socket_(VX_CFG_SOCKET_SIZE)
  {
    const std::string& name = simobject_->name();
    char sname[100];

    uint32_t sockets_per_cluster = sockets_.size();
    uint32_t cluster_id = simobject_->id();

    // create sockets

    for (uint32_t i = 0; i < sockets_per_cluster; ++i) {
      uint32_t socket_id = cluster_id * sockets_per_cluster + i;
      snprintf(sname, 100, "%s-socket%d", name.c_str(), i);
      // A socket's unit MMU is a cluster-TLB client after every core's two.
      uint32_t unit_tlb_client = sockets_per_cluster * VX_CFG_SOCKET_SIZE * 2 + i;
      sockets_.at(i) = Socket::Create(sname, socket_id, simobject_, unit_tlb_client);
    }

    // Global-barrier event links: each core's arrive end fans into the
    // cluster's handler; one resume link fans back out per core.
    for (uint32_t i = 0; i < sockets_per_cluster; ++i) {
      for (uint32_t c = 0; c < cores_per_socket_; ++c) {
        auto* core = sockets_.at(i)->core(c).get();
        core->gbar_arrive_out.bind(&simobject_->gbar_arrive_in);
        simobject_->gbar_resume_out.at(i * cores_per_socket_ + c).bind(&core->gbar_resume_in);
      }
    }

    // Create l2cache

    snprintf(sname, 100, "%s-l2cache", name.c_str());
    // L2 is the LLC iff L2 is enabled and L3 is not.
    {
      // the CP writes into this cache when it is the last level: its state
      // and a transfer's fills carry across the launch reset
      SimPlatform::LaunchKeepScope keep(CP_ON_L2 != 0);
      l2cache_ = Cache::Create(sname, Cache::Config{
        !VX_CFG_L2_ENABLED,
        VX_CFG_L2_SIZE,          // size
        log2ceil(VX_CFG_L2_LINE_SIZE),// L
        log2ceil(VX_CFG_L2_SECTOR_SIZE),// S
        log2ceil(VX_CFG_L1_LINE_SIZE), // W
        VX_CFG_L2_NUM_WAYS,            // ways
        log2ceil(VX_CFG_L2_NUM_BANKS), // B
        VX_CFG_XLEN,                   // address bits
        L2_CACHE_REQS,                 // request size
        VX_CFG_L2_MEM_PORTS,           // memory ports
        VX_CFG_L2_WRITEBACK,           // write-back
        false,                  // write response
        VX_CFG_L2_MSHR_SIZE,           // mshr size
        VX_CFG_L2_LATENCY,             // pipeline latency
        VX_CFG_L2_REPL_POLICY,         // replacement policy
        (VX_CFG_L2_ENABLED != 0) && (VX_CFG_L3_ENABLED == 0), // is_llc
        true,                          // non-cacheable bypass
        (VX_CFG_L2_BANK_HASH != 0) && (VX_CFG_L2_NUM_BANKS > 1), // bank_hash
        L2_SHARED_LLC,                 // shared_llc
        VX_CFG_L2_LAZY_FETCH != 0,     // lazy_fetch
        true,                          // core-response register (behind the bypass layer)
        0,                             // read_merge
        CP_ON_L2 != 0,                 // write_around
        VX_CFG_L2_MRSQ_SIZE != 0,      // memory-response queue
        false,                         // memory-response slice
        false,                         // acquire forward
        false,                         // line merging
        true,                          // core-request skid
      });
    }


    // connect l2cache memory interface
    for (uint32_t i = 0; i < VX_CFG_L2_MEM_PORTS; ++i) {
      l2cache_->mem_req_out.at(i).bind(&simobject_->mem_req_out.at(i));
      simobject_->mem_rsp_in.at(i).bind(&l2cache_->mem_rsp_in.at(i));
    }

    // A socket memory port reaches its L2 port across the link to the L2,
    // VX_CFG_L2_LINK_LATENCY cycles each way.
    auto bind_l2_link = [&](uint32_t port,
                            SimChannel<MemReq>& req_src, SimChannel<MemReq>& req_dst,
                            SimChannel<MemRsp>& rsp_src, SimChannel<MemRsp>& rsp_dst) {
      if constexpr (VX_CFG_L2_LINK_LATENCY != 0) {
        snprintf(sname, 100, "%s-l2link-req%d", name.c_str(), port);
        auto req_link = DelayBuffer<MemReq>::Create(sname, VX_CFG_L2_LINK_LATENCY);
        snprintf(sname, 100, "%s-l2link-rsp%d", name.c_str(), port);
        auto rsp_link = DelayBuffer<MemRsp>::Create(sname, VX_CFG_L2_LINK_LATENCY);
        req_src.bind(&req_link->In);
        req_link->Out.bind(&req_dst);
        rsp_src.bind(&rsp_link->In);
        rsp_link->Out.bind(&rsp_dst);
      } else {
        __unused(port);
        req_src.bind(&req_dst);
        rsp_src.bind(&rsp_dst);
      }
    };

    // ── L2 fan-in: sockets + cluster-resident gfx caches ────────────────
    // Row 0 = sockets (high priority; TEX/RTU/DXA traffic already merged at
    // each socket's L2-facing arb).
    // Row 1 = ocache (if enabled).
    // Row 2 = rcache (if enabled).
    // The priority arbiter lets sockets win over extension traffic on
    // contention, matching the hardware priority ordering.
#if defined(VX_CFG_EXT_OM_ENABLE) || defined(VX_CFG_EXT_RASTER_ENABLE)
    constexpr uint32_t kL2Rows = 1
        + VX_CFG_EXT_OM_ENABLED + VX_CFG_EXT_RASTER_ENABLED;
    snprintf(sname, 100, "%s-l2arb", name.c_str());
    auto l2arb = MemArbiter::Create(sname, ArbiterType::Priority,
                                    kL2Rows * VX_CFG_L2_DEMAND_REQS, VX_CFG_L2_DEMAND_REQS);
    // sockets → row 0
    for (uint32_t i = 0; i < sockets_per_cluster; ++i) {
      for (uint32_t j = 0; j < VX_CFG_L1_MEM_PORTS; ++j) {
        uint32_t port = i * VX_CFG_L1_MEM_PORTS + j;
        bind_l2_link(port, sockets_.at(i)->mem_req_out.at(j), l2arb->ReqIn.at(kL2Rows * port + 0),
                     l2arb->RspOut.at(kL2Rows * port + 0), sockets_.at(i)->mem_rsp_in.at(j));
      }
    }
    // A gfx cache's memory port reaches the L2 arbiter through the cluster
    // unit MMU under VM.
    auto bind_gfx_port = [&](uint32_t arb_idx, uint32_t cmmu_idx,
                             SimChannel<MemReq>& req_src,
                             SimChannel<MemRsp>& rsp_dst) {
    #ifdef SIMX_CLUSTER_UNIT_MMU
      req_src.bind(&gfx_mmu_->ReqIn.at(cmmu_idx));
      gfx_mmu_->RspOut.at(cmmu_idx).bind(&rsp_dst);
      gfx_mmu_->ReqOut.at(cmmu_idx).bind(&l2arb->ReqIn.at(arb_idx));
      l2arb->RspOut.at(arb_idx).bind(&gfx_mmu_->RspIn.at(cmmu_idx));
    #else
      __unused(cmmu_idx);
      req_src.bind(&l2arb->ReqIn.at(arb_idx));
      l2arb->RspOut.at(arb_idx).bind(&rsp_dst);
    #endif
    };
    // L2 arb outputs → l2cache (after all rows are bound).
    for (uint32_t i = 0; i < VX_CFG_L2_DEMAND_REQS; ++i) {
      l2arb->ReqOut.at(i).bind(&l2cache_->core_req_in.at(i));
      l2cache_->core_rsp_out.at(i).bind(&l2arb->RspIn.at(i));
    }
#else
    // No cluster-resident gfx caches: direct sockets → L2.
    for (uint32_t i = 0; i < sockets_per_cluster; ++i) {
      for (uint32_t j = 0; j < VX_CFG_L1_MEM_PORTS; ++j) {
        uint32_t port = i * VX_CFG_L1_MEM_PORTS + j;
        bind_l2_link(port, sockets_.at(i)->mem_req_out.at(j), l2cache_->core_req_in.at(port),
                     l2cache_->core_rsp_out.at(port), sockets_.at(i)->mem_rsp_in.at(j));
      }
    }
#endif // cluster-resident gfx caches

#ifdef VX_CFG_VM_ENABLE
    // Shared cluster L2 TLB. Every core's two L1 TLBs are clients, then each
    // socket's unit MMU; its misses export on the walker link the processor
    // binds at the device.
    uint32_t num_core_tlb_clients = sockets_per_cluster * VX_CFG_SOCKET_SIZE * 2;
  #ifdef SIMX_SOCKET_UNIT_MMU
    uint32_t num_unit_tlb_clients = sockets_per_cluster;
  #else
    uint32_t num_unit_tlb_clients = 0;
  #endif
  #ifdef SIMX_CLUSTER_UNIT_MMU
    uint32_t gfx_tlb_client = num_core_tlb_clients + num_unit_tlb_clients;
    uint32_t num_tlb_clients = gfx_tlb_client + 1;
  #else
    uint32_t num_tlb_clients = num_core_tlb_clients + num_unit_tlb_clients;
  #endif
    snprintf(sname, 100, "%s-l2tlb", name.c_str());
    l2tlb_ = L2Tlb::Create(sname, num_tlb_clients);

    for (uint32_t s = 0; s < sockets_per_cluster; ++s) {
      for (uint32_t c = 0; c < VX_CFG_SOCKET_SIZE; ++c) {
        auto& core = sockets_.at(s)->core(c);
        uint32_t base = (s * VX_CFG_SOCKET_SIZE + c) * 2;
        for (uint32_t k = 0; k < 2; ++k) {
          core->tlb_miss_out(k).bind(&l2tlb_->ReqIn.at(base + k));
          l2tlb_->RspOut.at(base + k).bind(&core->tlb_fill_in(k));
        }
      }
    }
  #ifdef SIMX_SOCKET_UNIT_MMU
    for (uint32_t s = 0; s < sockets_per_cluster; ++s) {
      auto& socket = sockets_.at(s);
      socket->tlb_miss_out().bind(&l2tlb_->ReqIn.at(socket->unit_tlb_client()));
      l2tlb_->RspOut.at(socket->unit_tlb_client()).bind(&socket->tlb_fill_in());
    }
  #endif
  #ifdef SIMX_CLUSTER_UNIT_MMU
    // Cluster unit MMU: between the rcache / ocache memory ports and the L2,
    // so those caches are virtually tagged. Its TLB is the cluster TLB's last
    // client. Like the socket unit MMU, each response leaves through a
    // registered stage and a new miss is held a cycle before it allocates;
    // the ocache writes, so a flush token is ordered behind its parks.
    snprintf(sname, 100, "%s-gfx_mmu", name.c_str());
    gfx_mmu_ = Mmu::Create(sname, CMMU_NUM_REQS, VX_CFG_CTLB_SIZE, gfx_tlb_client,
                           false, true, VX_CFG_EXT_OM_ENABLED != 0, true);
    gfx_mmu_->TlbMissOut.bind(&l2tlb_->ReqIn.at(gfx_tlb_client));
    l2tlb_->RspOut.at(gfx_tlb_client).bind(&gfx_mmu_->TlbFillIn);
  #endif

#endif

#ifdef VX_CFG_EXT_OM_ENABLE
    // ── Cluster-shared OM engine + ocache ───────────────────────────────
    snprintf(sname, 100, "%s-om-core", name.c_str());
    om_core_ = OmCore::Create(sname, simobject_);

    // ocache: write-through TLM Cache, config from VX_config.toml [ocache] section.
    snprintf(sname, 100, "%s-ocache", name.c_str());
    constexpr uint32_t kOcacheLineSize = VX_CFG_MEM_BLOCK_SIZE;
    constexpr uint32_t kOcacheWordSize = 4;
    constexpr uint32_t kOcacheNumReqs  = VX_CFG_OCACHE_NUM_BANKS;
    constexpr uint32_t kOcacheMemPorts = 1;
    auto ocache = Cache::Create(sname, Cache::Config{
      false,                        // bypass
      VX_CFG_OCACHE_SIZE,                  // size
      log2ceil(kOcacheLineSize),    // L
      log2ceil(kOcacheLineSize),    // S (no sectoring)
      log2ceil(kOcacheWordSize),    // W
      VX_CFG_OCACHE_NUM_WAYS,              // ways
      log2ceil(VX_CFG_OCACHE_NUM_BANKS),   // B
      VX_CFG_XLEN,                         // address bits
      kOcacheNumReqs,               // request size
      kOcacheMemPorts,              // memory ports
      false,                        // write-back (write-through)
      true,                         // write response (OM holds its same-pixel
                                    // R-M-W interlock until writes COMMIT)
      VX_CFG_OCACHE_MSHR_SIZE,             // mshr size
      2,                            // pipeline latency
      uint8_t(VX_CFG_L2_REPL_POLICY),      // replacement policy
      false,                        // is_llc (OCACHE is auxiliary, not LLC)
    });
    ocache_ = ocache;

    // om_core ↔ ocache (per-port).
    for (uint32_t i = 0; i < kOcacheNumReqs; ++i) {
      om_core_->ocache_req_out.at(i).bind(&ocache->core_req_in.at(i));
      ocache->core_rsp_out.at(i).bind(&om_core_->ocache_rsp_in.at(i));
    }

    // ocache memory side → l2arb.
    constexpr uint32_t kOmRow = 1;
    for (uint32_t i = 0; i < kOcacheMemPorts; ++i) {
      bind_gfx_port(kL2Rows * i + kOmRow, CMMU_OCACHE_IDX, ocache->mem_req_out.at(i), ocache->mem_rsp_in.at(i));
    }

    // Per-core SFU.om_req_out (OmUnit decodes onto it) → OmCore::om_req_in[cid],
    // crossing into the cluster domain through a registered stage owned by the
    // sending core's partition. OM has no return value — no rsp channel back
    // to SfuUnit.
    for (uint32_t s = 0; s < sockets_per_cluster; ++s) {
      for (uint32_t c = 0; c < cores_per_socket_; ++c) {
        uint32_t cid = s * cores_per_socket_ + c;
        auto* core = sockets_.at(s)->core(c).get();
        snprintf(sname, 100, "%s-om-slice%d", name.c_str(), cid);
        RegSlice<OmReq>::Ptr slice;
        {
          SimPlatform::DomainScope core_scope(core);
          slice = RegSlice<OmReq>::Create(sname, 1);
        }
        core->sfu_unit()->om_req_out.bind(&slice->In);
        slice->Out.bind(&om_core_->om_req_in.at(cid));
      }
    }
#endif

#ifdef VX_CFG_EXT_RASTER_ENABLE
    // ── Cluster-shared RASTER engine + rcache ───────────────────────────
    snprintf(sname, 100, "%s-raster-core", name.c_str());
    raster_core_ = RasterCore::Create(sname, simobject_);

    // rcache: read-only TLM Cache, config from VX_config.toml [rcache] section.
    snprintf(sname, 100, "%s-rcache", name.c_str());
    constexpr uint32_t kRcacheLineSize = VX_CFG_MEM_BLOCK_SIZE;
    constexpr uint32_t kRcacheWordSize = 4;
    constexpr uint32_t kRcacheNumReqs  = VX_CFG_RCACHE_NUM_BANKS;
    constexpr uint32_t kRcacheMemPorts = 1;
    auto rcache = Cache::Create(sname, Cache::Config{
      false,                        // bypass
      VX_CFG_RCACHE_SIZE,                  // size
      log2ceil(kRcacheLineSize),    // L
      log2ceil(kRcacheLineSize),    // S (no sectoring)
      log2ceil(kRcacheWordSize),    // W
      VX_CFG_RCACHE_NUM_WAYS,              // ways
      log2ceil(VX_CFG_RCACHE_NUM_BANKS),   // B
      VX_CFG_XLEN,                         // address bits
      kRcacheNumReqs,               // request size
      kRcacheMemPorts,              // memory ports
      false,                        // write-back (read-only)
      false,                        // write response
      VX_CFG_RCACHE_MSHR_SIZE,             // mshr size
      2,                            // pipeline latency
      uint8_t(VX_CFG_L2_REPL_POLICY),      // replacement policy
      false,                        // is_llc (RCACHE is auxiliary, not LLC)
    });
    rcache_ = rcache;

    // raster_core ↔ rcache (per-port).
    for (uint32_t i = 0; i < kRcacheNumReqs; ++i) {
      raster_core_->rcache_req_out.at(i).bind(&rcache->core_req_in.at(i));
      rcache->core_rsp_out.at(i).bind(&raster_core_->rcache_rsp_in.at(i));
    }

    // rcache memory side → l2arb.
    constexpr uint32_t kRasterRow = 1 + VX_CFG_EXT_OM_ENABLED;
    for (uint32_t i = 0; i < kRcacheMemPorts; ++i) {
      bind_gfx_port(kL2Rows * i + kRasterRow, CMMU_RCACHE_IDX, rcache->mem_req_out.at(i), rcache->mem_rsp_in.at(i));
    }

    // Cluster-level RasterBus arbiter: NUM_CORES_PER_CLUSTER inputs (one per
    // SfuUnit) → 1 lane (kNumRasterLanes=1).
    snprintf(sname, 100, "%s-raster-bus", name.c_str());
    uint32_t cores_per_cluster_r = sockets_per_cluster * cores_per_socket_;
    auto raster_bus = RasterBusArbiter::Create(sname, ArbiterType::RoundRobin,
                                               cores_per_cluster_r, 1);
    raster_bus_arb_ = raster_bus;
    // Both bus directions cross the core <-> cluster boundary through
    // registered stages owned by their sending side: requests core-side,
    // responses cluster-side.
    for (uint32_t s = 0; s < sockets_per_cluster; ++s) {
      for (uint32_t c = 0; c < cores_per_socket_; ++c) {
        uint32_t cid = s * cores_per_socket_ + c;
        auto* core = sockets_.at(s)->core(c).get();
        auto sfu = core->sfu_unit();
        snprintf(sname, 100, "%s-raster-req-slice%d", name.c_str(), cid);
        RegSlice<RasterReq>::Ptr req_slice;
        {
          SimPlatform::DomainScope core_scope(core);
          req_slice = RegSlice<RasterReq>::Create(sname, 1);
        }
        sfu->raster_req_out.bind(&req_slice->In);
        req_slice->Out.bind(&raster_bus->ReqIn.at(cid));
        snprintf(sname, 100, "%s-raster-rsp-slice%d", name.c_str(), cid);
        auto rsp_slice = RegSlice<RasterRsp>::Create(sname, 1);
        raster_bus->RspOut.at(cid).bind(&rsp_slice->In);
        rsp_slice->Out.bind(&sfu->raster_rsp_in);
        raster_core_->fwd_arm_out.at(cid).bind(&core->fwd_arm_in);
        core->fwd_done_out.bind(&raster_core_->fwd_done_in);
      }
    }
    raster_bus->ReqOut.at(0).bind(&raster_core_->raster_req_in.at(0));
    raster_core_->raster_rsp_out.at(0).bind(&raster_bus->RspIn.at(0));
#endif

  }

  void reset() {
    for (auto& gbar : gbarriers_) {
      gbar.reset();
    }
    gbar_fwd_next_ = 0;
    // Sockets are SimObjects; reset by SimPlatform.
  }

  bool running() const {
    for (auto& socket : sockets_) {
      if (socket->running())
        return true;
    }
  #ifdef VX_CFG_VM_ENABLE
    // A parked fill holds no channel packet while it waits, so completion
    // must ask the TLB directly. (The device walker is the processor's.)
    if (l2tlb_->busy()) {
      return true;
    }
  #endif
  #ifdef SIMX_CLUSTER_UNIT_MMU
    if (!gfx_mmu_->empty()) {
      return true;
    }
  #endif
    return false;
  }

  int get_exitcode() const {
    int exitcode = 0;
    for (auto& socket : sockets_) {
      exitcode |= socket->get_exitcode();
    }
    return exitcode;
  }

  void global_barrier_arrive(uint32_t bar_id, uint32_t count, uint32_t core_id) {
    auto bar_index = bar_id % gbarriers_.size();
    auto& gbar = gbarriers_.at(bar_index);

    uint32_t cores_per_cluster = sockets_.size() * cores_per_socket_;
    uint32_t local_core_id = core_id % cores_per_cluster;

    // set core arrival bit
    gbar.mask.set(local_core_id);

    DT(4, "*** Global barrier arrive: cluster #" << simobject_->id() << ", core #" << core_id << " at barrier #" << bar_id << ", arrived=" << gbar.mask.count());

    // Up to the device unit: the socket arbiter's output buffer, then the
    // cluster arbiter (one arrival per cycle) and its output buffer. A
    // single-core device has no global-barrier path.
    uint32_t lag = 0;
    if constexpr (VX_CFG_NUM_CLUSTERS * VX_CFG_NUM_CORES > 1) {
      uint64_t now = SimPlatform::instance().cycles();
      uint64_t out = std::max(now + kSocketArbLag, gbar_fwd_next_);
      gbar_fwd_next_ = out + 1;
      lag = out + kClusterArbLag - now;
    }
    if constexpr (VX_CFG_NUM_CLUSTERS > 1) {
      // the device arbiter's output buffer
      simobject_->gbar_fwd_out.send({bar_id, count, core_id}, lag + 1);
    } else if (gbar.mask.count() == (size_t)count) {
      // With one cluster the device arbiter is a wire. The unit registers its
      // release, which then crosses the cluster's and the socket's response
      // forks.
      this->global_barrier_resume(bar_id, lag + 1 + kClusterArbLag + kSocketArbLag);
    }
  }

  // The device unit's release crosses the cluster's and the socket's response
  // forks on its way down.
  void global_barrier_fwd_resume(uint32_t bar_id) {
    this->global_barrier_resume(bar_id, 1 + kClusterArbLag + kSocketArbLag);
  }

  // Resume the cores of this cluster that arrived, then clear the barrier.
  void global_barrier_resume(uint32_t bar_id, uint32_t delay) {
    auto& gbar = gbarriers_.at(bar_id % gbarriers_.size());
    for (uint32_t s = 0; s < sockets_.size(); ++s) {
      for (uint32_t c = 0; c < cores_per_socket_; ++c) {
        uint32_t i = s * cores_per_socket_ + c;
        if (gbar.mask.test(i)) {
          simobject_->gbar_resume_out.at(i).send({bar_id}, delay);
        }
      }
    }
    gbar.mask.reset();
  }

  Cluster::PerfStats perf_stats() const {
    Cluster::PerfStats perf_stats;
    perf_stats.l2cache = l2cache_->perf_stats();
#ifdef VX_CFG_EXT_RASTER_ENABLE
    perf_stats.raster = raster_core_->perf_stats();
    perf_stats.rcache = rcache_->perf_stats();
#endif
#ifdef VX_CFG_EXT_OM_ENABLE
    perf_stats.om     = om_core_->perf_stats();
    perf_stats.ocache = ocache_->perf_stats();
#endif
#if defined(VX_CFG_EXT_DXA_ENABLE) || defined(VX_CFG_EXT_TEX_ENABLE) || defined(VX_CFG_EXT_RTU_ENABLE)
    // Socket-resident units (TEX/RTU/DXA) aggregate across sockets.
    for (auto& socket : sockets_) {
      auto socket_perf = socket->perf_stats();
#ifdef VX_CFG_EXT_DXA_ENABLE
      perf_stats.dxa += socket_perf.dxa;
#endif
#ifdef VX_CFG_EXT_TEX_ENABLE
      perf_stats.tex    += socket_perf.tex;
      perf_stats.tcache += socket_perf.tcache;
#endif
#ifdef VX_CFG_EXT_RTU_ENABLE
      perf_stats.rtu     += socket_perf.rtu;
      perf_stats.rtcache += socket_perf.rtcache;
#endif
    }
#endif
#ifdef VX_CFG_VM_ENABLE
    perf_stats.l2tlb = l2tlb_->perf_stats();
#endif
    return perf_stats;
  }

#ifdef VX_CFG_VM_ENABLE
  void set_mmu_satp(uint64_t value) {
    // Single DCR source of truth: fan the device-programmed satp to every
    // core's L1 MMUs. Mirrors the RTL, where the L1 TLBs source satp from
    // the DCR broadcast (not the per-core CSR); the device walker receives
    // its copy from the processor directly.
    for (auto& socket : sockets_) {
      for (uint32_t c = 0; c < cores_per_socket_; ++c) {
        socket->core(c)->set_satp(value);
      }
    #ifdef SIMX_SOCKET_UNIT_MMU
      socket->set_satp(value);
    #endif
    }
  #ifdef SIMX_CLUSTER_UNIT_MMU
    // The rcache and ocache are virtually tagged: a satp commit flushes the
    // cluster unit TLB and invalidates them. The ocache writes through, and a
    // commit falls between launches, so it holds no write to drain first.
    gfx_mmu_->set_satp(value);
  #ifdef VX_CFG_EXT_RASTER_ENABLE
    rcache_->invalidate();
  #endif
  #ifdef VX_CFG_EXT_OM_ENABLE
    ocache_->invalidate();
  #endif
  #endif
  }

  SimChannel<TlbReq>& ptw_req_out() {
    return l2tlb_->PtwReqOut;
  }

  SimChannel<TlbRsp>& ptw_rsp_in() {
    return l2tlb_->PtwRspIn;
  }

  SimChannel<MemReq>& ptw_mem_req_in() {
    return l2cache_->core_req_in.at(VX_CFG_L2_PTW_IDX);
  }

  SimChannel<MemRsp>& ptw_mem_rsp_out() {
    return l2cache_->core_rsp_out.at(VX_CFG_L2_PTW_IDX);
  }
#endif

  int dcr_write(uint32_t addr, uint32_t value) {
#ifdef VX_CFG_EXT_OM_ENABLE
    if (addr >= VX_DCR_OM_STATE_BEGIN && addr < VX_DCR_OM_STATE_END) {
#ifdef VX_CFG_EXT_RASTER_ENABLE
      // The depth buffer is shared with the raster early-Z stage; let it snoop
      // the depth config (zbuf addr/pitch, func, early-Z gate).
      raster_core_->om_dcr_snoop(addr, value);
#endif
      return om_core_->dcr_write(addr, value);
    }
#endif
#ifdef VX_CFG_EXT_RASTER_ENABLE
    // RASTER_FRAG_* (fragment-shader dispatch descriptor): capture the
    // entry/param halves and latch the assembled 64-bit values into RasterCore
    // (descriptor only — the frame is armed by the delegated launch's
    // frame_kick, not by these writes). Do NOT forward these to dcr_write —
    // that path calls reset_load_state(), which is undesirable for a
    // descriptor that only names the FS to launch.
    if (addr == VX_DCR_RASTER_FRAG_ENTRY_LO) {
      frag_entry_ = (frag_entry_ & ~uint64_t(0xffffffff)) | value;
      return 0;
    }
    if (addr == VX_DCR_RASTER_FRAG_ENTRY_HI) {
      frag_entry_ = (frag_entry_ & uint64_t(0xffffffff)) | (uint64_t(value) << 32);
      return 0;
    }
    if (addr == VX_DCR_RASTER_FRAG_PARAM_LO) {
      frag_param_ = (frag_param_ & ~uint64_t(0xffffffff)) | value;
      return 0;
    }
    if (addr == VX_DCR_RASTER_FRAG_PARAM_HI) {
      frag_param_ = (frag_param_ & uint64_t(0xffffffff)) | (uint64_t(value) << 32);
      raster_core_->set_frag_descriptor(frag_entry_, frag_param_);
      return 0;
    }
    if (addr >= VX_DCR_RASTER_STATE_BEGIN && addr < VX_DCR_RASTER_STATE_END) {
      return raster_core_->dcr_write(addr, value);
    }
#endif
    for (auto& socket : sockets_) {
      int ret = socket->dcr_write(addr, value);
      if (ret != 0)
        return ret;
    }
    return 0;
  }

  int dcr_read(uint32_t addr, uint32_t tag, uint32_t* value) {
    for (auto& socket : sockets_) {
      int ret = socket->dcr_read(addr, tag, value);
      if (ret != 0)
        return ret;
    }
    return 0;
  }

  void dcache_flush_begin(bool l1_only) {
    for (auto& socket : sockets_) {
      socket->dcache_flush_begin(l1_only);
    }
  }

  bool dcache_flush_done() const {
    for (auto& socket : sockets_) {
      if (!socket->dcache_flush_done()) return false;
    }
    return true;
  }

  void icache_flush_begin() {
    for (auto& socket : sockets_) {
      socket->icache_flush_begin();
    }
  }

  bool icache_flush_done() const {
    for (auto& socket : sockets_) {
      if (!socket->icache_flush_done()) return false;
    }
    return true;
  }

#ifdef VX_CFG_EXT_TEX_ENABLE
  void tcache_flush_begin() {
    for (auto& socket : sockets_) {
      socket->tcache_flush_begin();
    }
  }
  bool tcache_flush_done() const {
    for (auto& socket : sockets_) {
      if (!socket->tcache_flush_done()) return false;
    }
    return true;
  }
#endif

#ifdef VX_CFG_EXT_RASTER_ENABLE
  void rcache_flush_begin() { rcache_->flush_begin(); }
  bool rcache_flush_done() const { return rcache_->flush_done(); }
#endif

#ifdef VX_CFG_EXT_OM_ENABLE
  void ocache_flush_begin() { ocache_->flush_begin(); }
  bool ocache_flush_done() const { return ocache_->flush_done(); }
#endif

#ifdef VX_CFG_EXT_RTU_ENABLE
  void rtcache_flush_begin() {
    for (auto& socket : sockets_) {
      socket->rtcache_flush_begin();
    }
  }
  bool rtcache_flush_done() const {
    for (auto& socket : sockets_) {
      if (!socket->rtcache_flush_done()) return false;
    }
    return true;
  }
#endif

  void l2_flush_begin(bool l1_only) {
    l2cache_->flush_begin(l1_only);
  }

  void l2_keep_lines() {
    l2cache_->keep_lines();
  }

  SimChannel<MemReq>& cp_mem_req_in() {
    return l2cache_->core_req_in.at(L2_CP_IDX);
  }

  SimChannel<MemRsp>& cp_mem_rsp_out() {
    return l2cache_->core_rsp_out.at(L2_CP_IDX);
  }

  bool l2_flush_done() const {
    return l2cache_->flush_done();
  }

  Core* get_core(uint32_t idx) const {
    uint32_t sockets_per_cluster = sockets_.size();
    if (idx >= sockets_per_cluster * cores_per_socket_) return nullptr;
    uint32_t s = idx / cores_per_socket_;
    uint32_t c = idx % cores_per_socket_;
    return sockets_.at(s)->core(c).get();
  }

#ifdef VX_CFG_EXT_RASTER_ENABLE
  RasterCore::Ptr& raster_core() { return raster_core_; }
#endif

private:
  Cluster*                    simobject_;
  std::vector<Socket::Ptr>    sockets_;
  std::vector<core_barrier_t> gbarriers_;
  uint64_t gbar_fwd_next_ = 0;  // next free cycle at the cluster's gbar arbiter
  Cache::Ptr                  l2cache_;
  uint32_t                    cores_per_socket_;
#ifdef VX_CFG_VM_ENABLE
  L2Tlb::Ptr                  l2tlb_;
#ifdef SIMX_CLUSTER_UNIT_MMU
  Mmu::Ptr                    gfx_mmu_;
#endif
#endif
#ifdef VX_CFG_EXT_OM_ENABLE
  OmCore::Ptr                 om_core_;
  Cache::Ptr                  ocache_;
#endif
#ifdef VX_CFG_EXT_RASTER_ENABLE
  RasterCore::Ptr             raster_core_;
  Cache::Ptr                  rcache_;
  RasterBusArbiter::Ptr       raster_bus_arb_;
  // RASTER_FRAG_* descriptor halves, assembled across the 4 DCR writes.
  uint64_t                    frag_entry_ = 0;
  uint64_t                    frag_param_ = 0;
#endif
};

///////////////////////////////////////////////////////////////////////////////

Cluster::Cluster(const SimContext& ctx,
                 const char* name,
                 uint32_t cluster_id,
                 ProcessorImpl* processor)
  : SimObject(ctx, name)
  , mem_req_out(VX_CFG_L2_MEM_PORTS, this)
  , mem_rsp_in(VX_CFG_L2_MEM_PORTS, this)
  , gbar_arrive_in(this)
  , gbar_resume_out(NUM_SOCKETS * VX_CFG_SOCKET_SIZE, this)
  , gbar_fwd_out(this)
  , gbar_fwd_resume_in(this)
  , cluster_id_(cluster_id)
  , processor_(processor)
  , impl_(new Impl(this))
{
  gbar_arrive_in.bind(this, &Cluster::on_gbar_arrive);
  gbar_fwd_resume_in.bind(this, &Cluster::on_gbar_fwd_resume);
}

Cluster::~Cluster() {
  delete impl_;
}

void Cluster::on_reset() {
  impl_->reset();
}

bool Cluster::running() const {
  return impl_->running();
}

int Cluster::get_exitcode() const {
  return impl_->get_exitcode();
}

void Cluster::on_gbar_arrive(const GbarArrive& msg) {
  impl_->global_barrier_arrive(msg.bar_id, msg.count, msg.core_id);
}

void Cluster::on_gbar_fwd_resume(const GbarResume& msg) {
  impl_->global_barrier_fwd_resume(msg.bar_id);
}

Cluster::PerfStats Cluster::perf_stats() const {
  return impl_->perf_stats();
}

#ifdef VX_CFG_VM_ENABLE
void Cluster::set_mmu_satp(uint64_t value) {
  impl_->set_mmu_satp(value);
}

SimChannel<TlbReq>& Cluster::ptw_req_out() {
  return impl_->ptw_req_out();
}

SimChannel<TlbRsp>& Cluster::ptw_rsp_in() {
  return impl_->ptw_rsp_in();
}

SimChannel<MemReq>& Cluster::ptw_mem_req_in() {
  return impl_->ptw_mem_req_in();
}

SimChannel<MemRsp>& Cluster::ptw_mem_rsp_out() {
  return impl_->ptw_mem_rsp_out();
}
#endif

int Cluster::dcr_write(uint32_t addr, uint32_t value) {
  return impl_->dcr_write(addr, value);
}

int Cluster::dcr_read(uint32_t addr, uint32_t tag, uint32_t* value) {
  return impl_->dcr_read(addr, tag, value);
}

Core* Cluster::get_core(uint32_t idx) const {
  return impl_->get_core(idx);
}

void Cluster::dcache_flush_begin(bool l1_only) {
  impl_->dcache_flush_begin(l1_only);
}

bool Cluster::dcache_flush_done() const {
  return impl_->dcache_flush_done();
}

void Cluster::icache_flush_begin() {
  impl_->icache_flush_begin();
}

bool Cluster::icache_flush_done() const {
  return impl_->icache_flush_done();
}

#ifdef VX_CFG_EXT_TEX_ENABLE
void Cluster::tcache_flush_begin() { impl_->tcache_flush_begin(); }
bool Cluster::tcache_flush_done() const { return impl_->tcache_flush_done(); }
#endif

#ifdef VX_CFG_EXT_RASTER_ENABLE
void Cluster::rcache_flush_begin() { impl_->rcache_flush_begin(); }
bool Cluster::rcache_flush_done() const { return impl_->rcache_flush_done(); }
#endif

#ifdef VX_CFG_EXT_OM_ENABLE
void Cluster::ocache_flush_begin() { impl_->ocache_flush_begin(); }
bool Cluster::ocache_flush_done() const { return impl_->ocache_flush_done(); }
#endif

#ifdef VX_CFG_EXT_RTU_ENABLE
void Cluster::rtcache_flush_begin() { impl_->rtcache_flush_begin(); }
bool Cluster::rtcache_flush_done() const { return impl_->rtcache_flush_done(); }
#endif

void Cluster::l2_flush_begin(bool l1_only) {
  impl_->l2_flush_begin(l1_only);
}

void Cluster::l2_keep_lines() {
  impl_->l2_keep_lines();
}

SimChannel<MemReq>& Cluster::cp_mem_req_in() {
  return impl_->cp_mem_req_in();
}

SimChannel<MemRsp>& Cluster::cp_mem_rsp_out() {
  return impl_->cp_mem_rsp_out();
}

bool Cluster::l2_flush_done() const {
  return impl_->l2_flush_done();
}

#ifdef VX_CFG_EXT_RASTER_ENABLE
RasterCore::Ptr& Cluster::raster_core() {
  return impl_->raster_core();
}
#endif

