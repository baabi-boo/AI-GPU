// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <cstdint>

#ifdef __cplusplus
extern "C" {
#endif

uint32_t rv_fadd_s(uint32_t a, uint32_t b, uint32_t frm, uint32_t* fflags);
uint32_t rv_fsub_s(uint32_t a, uint32_t b, uint32_t frm, uint32_t* fflags);
uint32_t rv_fmul_s(uint32_t a, uint32_t b, uint32_t frm, uint32_t* fflags);
uint32_t rv_fmadd_s(uint32_t a, uint32_t b, uint32_t c, uint32_t frm, uint32_t* fflags);
uint32_t rv_fmsub_s(uint32_t a, uint32_t b, uint32_t c, uint32_t frm, uint32_t* fflags);
uint32_t rv_fnmadd_s(uint32_t a, uint32_t b, uint32_t c, uint32_t frm, uint32_t* fflags);
uint32_t rv_fnmsub_s(uint32_t a, uint32_t b, uint32_t c, uint32_t frm, uint32_t* fflags);
uint32_t rv_fdiv_s(uint32_t a, uint32_t b, uint32_t frm, uint32_t* fflags);
uint32_t rv_fsqrt_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_frecip7_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_frsqrt7_s(uint32_t a, uint32_t frm, uint32_t* fflags);

uint32_t rv_ftoi_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_ftou_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_itof_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_utof_s(uint32_t a, uint32_t frm, uint32_t* fflags);

uint64_t rv_ftol_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_ftolu_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_ltof_s(uint64_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_lutof_s(uint64_t a, uint32_t frm, uint32_t* fflags);

uint32_t rv_fclss_s(uint32_t a);

uint32_t rv_fsgnj_s(uint32_t a, uint32_t b);
uint32_t rv_fsgnjn_s(uint32_t a, uint32_t b);
uint32_t rv_fsgnjx_s(uint32_t a, uint32_t b);

bool rv_flt_s(uint32_t a, uint32_t b, uint32_t* fflags);
bool rv_fle_s(uint32_t a, uint32_t b, uint32_t* fflags);
bool rv_feq_s(uint32_t a, uint32_t b, uint32_t* fflags);
uint32_t rv_fmin_s(uint32_t a, uint32_t b, uint32_t* fflags);
uint32_t rv_fmax_s(uint32_t a, uint32_t b, uint32_t* fflags);

///////////////////////////////////////////////////////////////////////////////

uint64_t rv_fadd_d(uint64_t a, uint64_t b, uint32_t frm, uint32_t* fflags);
uint64_t rv_fsub_d(uint64_t a, uint64_t b, uint32_t frm, uint32_t* fflags);
uint64_t rv_fmul_d(uint64_t a, uint64_t b, uint32_t frm, uint32_t* fflags);
uint64_t rv_fdiv_d(uint64_t a, uint64_t b, uint32_t frm, uint32_t* fflags);
uint64_t rv_fsqrt_d(uint64_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_frecip7_d(uint64_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_frsqrt7_d(uint64_t a, uint32_t frm, uint32_t* fflags);

uint64_t rv_fmadd_d(uint64_t a, uint64_t b, uint64_t c, uint32_t frm, uint32_t* fflags);
uint64_t rv_fmsub_d(uint64_t a, uint64_t b, uint64_t c, uint32_t frm, uint32_t* fflags);
uint64_t rv_fnmadd_d(uint64_t a, uint64_t b, uint64_t c, uint32_t frm, uint32_t* fflags);
uint64_t rv_fnmsub_d(uint64_t a, uint64_t b, uint64_t c, uint32_t frm, uint32_t* fflags);

uint32_t rv_ftoi_d(uint64_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_ftou_d(uint64_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_ftol_d(uint64_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_ftolu_d(uint64_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_itof_d(uint32_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_utof_d(uint32_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_ltof_d(uint64_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_lutof_d(uint64_t a, uint32_t frm, uint32_t* fflags);

uint32_t rv_fclss_d(uint64_t a);
uint64_t rv_fsgnj_d(uint64_t a, uint64_t b);
uint64_t rv_fsgnjn_d(uint64_t a, uint64_t b);
uint64_t rv_fsgnjx_d(uint64_t a, uint64_t b);

bool rv_flt_d(uint64_t a, uint64_t b, uint32_t* fflags);
bool rv_fle_d(uint64_t a, uint64_t b, uint32_t* fflags);
bool rv_feq_d(uint64_t a, uint64_t b, uint32_t* fflags);
uint64_t rv_fmin_d(uint64_t a, uint64_t b, uint32_t* fflags);
uint64_t rv_fmax_d(uint64_t a, uint64_t b, uint32_t* fflags);

uint32_t rv_dtof(uint64_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_ftod(uint32_t a, uint32_t frm, uint32_t* fflags);

// fp16 <--> fp32 conversions
uint32_t rv_htof_s(uint16_t a, uint32_t frm, uint32_t* fflags);
uint16_t rv_ftoh_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint64_t rv_htod(uint16_t a, uint32_t frm, uint32_t* fflags);
uint16_t rv_dtoh(uint64_t a, uint32_t frm, uint32_t* fflags);

// bf16 <--> fp32 conversions
uint32_t rv_btof_s(uint16_t a, uint32_t frm, uint32_t* fflags);
uint16_t rv_ftob_s(uint32_t a, uint32_t frm, uint32_t* fflags);

// fp8_e4m3 <--> fp32 conversions
uint32_t rv_e4m3tof_s(uint8_t a, uint32_t frm, uint32_t* fflags);
uint8_t rv_ftoe4m3_s(uint32_t a, uint32_t frm, uint32_t* fflags);

// fp8_e5m2 <--> fp32 conversions
uint32_t rv_e5m2tof_s(uint8_t a, uint32_t frm, uint32_t* fflags);
uint8_t rv_ftoe5m2_s(uint32_t a, uint32_t frm, uint32_t* fflags);

// tf32 <--> fp32 conversions
uint32_t rv_tf32tof_s(uint32_t a, uint32_t frm, uint32_t* fflags);
uint32_t rv_ftotf32_s(uint32_t a, uint32_t frm, uint32_t* fflags);

// mxfp8 <--> fp32 conversions
uint32_t rv_mxfp8tof_s(uint8_t a, uint8_t sf, uint32_t frm, uint32_t* fflags);
uint8_t rv_ftomxfp8_s(uint32_t a, uint8_t sf, uint32_t frm, uint32_t* fflags);

// mxbf8 <--> fp32 conversions
uint32_t rv_mxbf8tof_s(uint8_t a, uint8_t sf, uint32_t frm, uint32_t* fflags);
uint8_t rv_ftomxbf8_s(uint32_t a, uint8_t sf, uint32_t frm, uint32_t* fflags);

// mxfp4 <--> fp32 conversions
uint32_t rv_mxfp4tof_s(uint8_t a, uint8_t sf, uint32_t frm, uint32_t* fflags);
uint8_t rv_ftomxfp4_s(uint32_t a, uint8_t sf, uint32_t frm, uint32_t* fflags);

// nvfp4 <--> fp32 conversions
uint32_t rv_nvfp4tof_s(uint8_t a, uint8_t sf, uint32_t frm, uint32_t* fflags);
uint8_t rv_ftonvfp4_s(uint32_t a, uint8_t sf, uint32_t frm, uint32_t* fflags);

// e2m1 <--> fp32 conversions
uint32_t rv_e2m1tof_s(uint8_t a, uint32_t frm, uint32_t* fflags);
uint8_t rv_ftoe2m1_s(uint32_t a, uint32_t frm, uint32_t* fflags);

#ifdef __cplusplus
}
#endif
