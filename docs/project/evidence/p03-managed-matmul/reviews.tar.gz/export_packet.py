import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path('/workspace/scratch/198e8aeab1bd')
DEST = BASE / 'p03-review/package'
DEST.mkdir(exist_ok=True)

def identity(path):
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def pack(name, entries):
    target = DEST / (name + '.tar.gz')
    members = []
    with target.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for member, path in sorted(entries.items()):
                    assert not path.is_symlink(), path
                    assert not member.startswith('/') and '..' not in Path(member).parts, member
                    assert path.suffix not in ('.so', '.a', '.o', '.elf', '.vxbin', '.pyc'), path
                    data = path.read_bytes()
                    info = tarfile.TarInfo(member)
                    info.size = len(data)
                    info.mtime = 0
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(data))
                    members.append({'path': member, 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)})
    return {'path': target.name, **identity(target), 'members': members}

def tree(root):
    return {p.relative_to(root).as_posix(): p for p in root.rglob('*') if p.is_file()}

matrix = json.loads((BASE / 'p03-formal-results/report.json').read_text())
host = json.loads((BASE / 'p03-formal-host/verification.json').read_text())
rv32 = json.loads((BASE / 'p03-rv32/final-evidence/report.json').read_text())
assert matrix['state'] == 'finished' and matrix['outcome'] == 'pass' and matrix['source_stable']
assert (matrix['completed_case_executions'], matrix['completed_launches'], matrix['checked_words']) == (176, 352, 14336)
assert host['outcome'] == 'pass' and host['source_stable']
assert rv32['outcome'] == 'pass' and rv32['revision'] == host['source_revision']
archives = [pack('execution', tree(BASE / 'p03-formal-results'))]
entries = {p.name: p for p in (BASE / 'p03-formal-host').iterdir() if p.is_file()}
entries['run_formal_host.py'] = BASE / 'p03-review/run_formal_host.py'
archives.append(pack('host-tests', entries))
archives.append(pack('rv32-lifecycle', tree(BASE / 'p03-rv32/final-evidence')))
entries = {}
for name in ('p03-preflight-blocked', 'p03-host-interrupted', 'p03-pre-correction-results', 'p03-pre-correction-host'):
    root = BASE / name
    for relative, path in tree(root).items():
        if 'tmp' not in Path(relative).parts:
            entries[name + '/' + relative] = path
for name in ('p03-dev', 'p03-kernel-probe'):
    root = BASE / name
    for path in root.iterdir():
        if path.is_file() and path.suffix in ('.json', '.py', '.log'):
            entries[name + '/' + path.name] = path
    if (root / 'logs').exists():
        for relative, path in tree(root / 'logs').items():
            entries[name + '/logs/' + relative] = path
for name in ('local-dependency-restoration.json', 'pre-correction-interruption.json'):
    entries[name] = BASE / 'p03-review' / name
archives.append(pack('development-history', entries))
index = {'schema_version': 1, 'source_revision': host['source_revision'], 'source_tree': host['source_tree'],
         'archives': archives, 'notes': ['Exact report, log, configuration and source bodies are retained; tar timestamps and ownership are normalized.',
         'Non-sensitive ephemeral workspace paths remain to preserve raw command and binding integrity; no credentials or private account data are intentionally included.',
         'Built GPU binaries, libraries, toolchains and waveforms are identified by hashes rather than included.',
         'Interrupted and blocked runs are historical and do not support acceptance.']}
(DEST / 'archive-index.json').write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
print(json.dumps([{'archive': a['path'], 'size_bytes': a['size_bytes'], 'members': len(a['members'])} for a in archives], indent=2))
