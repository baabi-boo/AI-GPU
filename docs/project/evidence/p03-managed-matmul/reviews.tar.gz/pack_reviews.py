from pathlib import Path
import hashlib
import json

BASE = Path('/workspace/scratch/198e8aeab1bd')
REVIEW = BASE / 'p03-review'
ROOT = BASE / 'AI-GPU'
DEST = ROOT / 'docs/project/evidence/p03-managed-matmul'
space = {}
body = (REVIEW / 'export_packet.py').read_text().split('matrix = json.loads')[0]
exec(compile(body, str(REVIEW / 'export_packet.py'), 'exec'), space)
space['DEST'] = DEST
entries = {name: REVIEW / name for name in (
    'runtime-review.json', 'failure-path-review.json', 'execution-review.json',
    'execution-parser-tests.log', 'delivery-policy-review.json',
    'delivery-policy-review.initial.json', 'export_packet.py', 'pack_reviews.py',
    'closeout-checks.json', 'closeout-governance.log',
    'closeout-governance-tests.log', 'closeout-diff.log')}
for directory in ('base-classifier', 'delivery-policy-checks', 'brace-fix', 'qualification-audit'):
    for path in (REVIEW / directory).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            entries[path.relative_to(REVIEW).as_posix()] = path
archive = space['pack']('reviews', entries)
index = json.loads((DEST / 'archive-index.json').read_text())
index['archives'] = [archive if row['path'] == 'reviews.tar.gz' else row for row in index['archives']]
(DEST / 'archive-index.json').write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
for name in ('acceptance-numerics.json', 'acceptance-lifecycle.json'):
    path = DEST / name
    record = json.loads(path.read_text())
    for artifact in record['artifacts']:
        artifact['sha256'] = hashlib.sha256((ROOT / artifact['path']).read_bytes()).hexdigest()
    path.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'review_members': len(archive['members']), 'review_archive_bytes': archive['size_bytes'],
                  'review_archive_sha256': archive['sha256']}, indent=2))
