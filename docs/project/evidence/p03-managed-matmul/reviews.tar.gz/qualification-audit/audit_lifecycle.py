from __future__ import annotations
import hashlib
import gzip
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

SOURCE = Path('/workspace/scratch/198e8aeab1bd/AI-GPU')
WORK = SOURCE.parent
OUT = WORK / 'p03-review/qualification-audit'
REVISION = '319ad63532cee17ae88fa75757a5ac87ed5c6a77'
checks = []
cache = {}

def require(value, label):
    if not value:
        raise AssertionError(label)
    checks.append(label)

def digest(path):
    path = Path(path)
    stat = path.stat()
    identity = (str(path.resolve()), stat.st_size, stat.st_mtime_ns)
    if identity not in cache:
        h = hashlib.sha256()
        with path.open('rb') as stream:
            for part in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(part)
        cache[identity] = h.hexdigest()
    return cache[identity]

def checked_file(root, row, label):
    path = Path(row['path'])
    path = path if path.is_absolute() else root / path
    require(path.is_file(), label + ': exists')
    if 'resolved_path' in row:
        require(str(path.resolve()) == row['resolved_path'], label + ': resolution')
    require(digest(path) == row['sha256'], label + ': sha256')
    if 'size_bytes' in row:
        require(path.stat().st_size == row['size_bytes'], label + ': size')
    return path

def snapshot(packet, row, label):
    return json.loads(checked_file(packet, row, label).read_text())

def nested_rows(value):
    if isinstance(value, dict):
        if 'path' in value and 'sha256' in value:
            yield value
        else:
            for item in value.values():
                yield from nested_rows(item)
    elif isinstance(value, list):
        for item in value:
            yield from nested_rows(item)

expected_groups = [
    '[OK] overflowing and boundary buffer spans',
    '[OK] rejected wait lists preserve ownership and outputs',
    '[OK] timeout retains pending allocation until completion',
    '[OK] 14 failed-dependency/sticky commands release captures before completion',
    '[OK] failed unmap propagates error and finish restores queue',
    '[OK] host-allocation unwind: 3 failures, 13 successful enqueues',
    '[OK] module setup OOM: BSS, 4 symbol failures, 2 kernel failures; all references and memory restored',
    '[OK] real DMA allocation stage 0 OOM propagates, releases captures, and recovers',
    '[OK] real DMA allocation stage 1 OOM propagates, releases captures, and recovers',
    '[OK] real DMA allocation stage 2 OOM propagates, releases captures, and recovers',
    '[OK] scratch-pool OOM frees 96 uncached slots',
    '[OK] allocation exhaustion and 32 transfer/release cycles restore memory',
]
expected_error = "Error: out of memory (Can't find next address)"

def lifecycle_log(packet, command, label):
    require(command['outcome'] == 'pass' and command['exit_code'] == 0 and command['cleanup_complete'] is True,
            label + ': successful bounded command')
    path = packet / command['log']
    require(digest(path) == command['log_sha256'], label + ': raw log hash')
    require(path.stat().st_size == command['log_size_bytes'], label + ': raw log size')
    lines = path.read_text().splitlines()
    require([line for line in lines if line.startswith('[OK]')] == expected_groups,
            label + ': exact twelve groups')
    require(lines[-1] == 'P03_LIFECYCLE PASSED' and lines.count('P03_LIFECYCLE PASSED') == 1,
            label + ': unique terminal success')
    require([line for line in lines if not line.startswith('[OK]') and line != 'P03_LIFECYCLE PASSED'] == [expected_error],
            label + ': only deliberate device-exhaustion error')
    require(lines.index(expected_error) + 1 == lines.index(expected_groups[-1]), label + ': exhaustion context')
    return {'path': str(path), 'sha256': digest(path), 'size_bytes': path.stat().st_size,
            'groups': len(expected_groups), 'duration_seconds': command['duration_seconds']}

head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
require(head == REVISION, 'current HEAD equals frozen revision')
require(not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True).strip(), 'source currently clean')

packet32 = WORK / 'p03-rv32/final-evidence'
r32 = json.loads((packet32/'report.json').read_text())
require(r32['state'] == 'complete' and r32['outcome'] == 'pass', 'RV32 receipt complete pass')
require(r32['revision'] == REVISION and r32['source_dirty'] is False, 'RV32 revision and clean status')
require(r32['kernel_built'] is False and r32['synthetic_module_executed'] is False, 'RV32 synthetic image never executed')
require(r32['configuration']['xlen'] == 32 and r32['configuration']['profile'] == '' and r32['configuration']['configs'] == ''
        and r32['configuration']['backend'] == 'simx', 'RV32 default configuration')
flags = r32['configuration']['resolved_flags'].split()
require('-DVX_CFG_XLEN=32' in flags and '-DVX_CFG_XLEN_32' in flags and '-DVX_CFG_XLEN_64' not in flags,
        'RV32 compiler XLEN macros')
require('-DVX_CFG_ICACHE_ENABLED=1' in flags and '-DVX_CFG_DCACHE_ENABLED=1' in flags, 'RV32 hardware caches enabled in exact flags')
for role in ('source','artifacts','tools','dependencies'):
    before = snapshot(packet32, r32[role+'_before'], 'RV32 '+role+' before')
    after = snapshot(packet32, r32[role+'_after'], 'RV32 '+role+' after')
    require(before == after, 'RV32 '+role+' before equals after')
    root = Path(r32['build_root']) if role == 'artifacts' else SOURCE
    for row in nested_rows(before):
        checked_file(root,row,'RV32 '+role+' input '+row['path'])
source32 = snapshot(packet32,r32['source_before'],'RV32 source snapshot repeat')
require(source32['checkout']['revision'] == REVISION and source32['checkout']['dirty'] is False
        and source32['checkout']['blockers'] == [], 'RV32 checkout provenance')
files32 = {row['path']:row for row in source32['files']}
for path in ('sw/runtime/common/callbacks.inc','third_party/softfloat/source/RISCV/specialize.h', 'sim/common/cmd_processor.cpp', 'tests/runtime/test_ai_lifecycle.cpp'):
    require(path in files32,'RV32 explicit required source '+path)
deps = snapshot(packet32,r32['compiler_dependencies'],'RV32 compiler dependency audit')
require(deps['repository_inputs'] == 201 and deps['dependency_files'] == 41 and deps['missing_from_source_inventory'] == [],
        'RV32 all recorded compiler dependencies covered')
require(all(files32.get(row['path']) == row for row in deps['inputs']), 'RV32 compiler input hashes agree with source inventory')
for cmd in r32['commands']:
    require(cmd['outcome'] == 'pass' and cmd['exit_code'] == 0 and cmd['cleanup_complete'] is True,
            'RV32 command '+cmd['id']+' passed')
    path = packet32/cmd['log']
    require(digest(path) == cmd['log_sha256'] and path.stat().st_size == cmd['log_size_bytes'], 'RV32 command '+cmd['id']+' log integrity')
    require(cmd['environment']['CCACHE_DISABLE'] == '1', 'RV32 command '+cmd['id']+' compiler cache disabled')
for name in ('host_cxx_frontend','runner','preparation_report'):
    checked_file(packet32,r32[name],'RV32 '+name)
for file in (packet32/'source').rglob('*'):
    if file.is_file():
        relative=file.relative_to(packet32/'source').as_posix()
        require(relative in files32 and digest(file)==files32[relative]['sha256'],'RV32 retained source '+relative)
cmd32 = next(c for c in r32['commands'] if c['id']=='lifecycle-run')
require(cmd32['environment']['VORTEX_DRIVER']=='simx' and cmd32['environment']['LD_LIBRARY_PATH']==r32['build_root']+'/sw/runtime',
        'RV32 explicit runtime binding')
log32 = lifecycle_log(packet32,cmd32,'RV32 lifecycle')

packet64 = WORK / 'p03-formal-results'
r64 = json.loads((packet64/'report.json').read_text())
source64 = snapshot(packet64,r64['source_before'],'RV64 source before')
require(source64['checkout']['revision'] == REVISION and source64['checkout']['dirty'] is False and source64['checkout']['blockers'] == [],
        'RV64 source clean frozen provenance')
require(source64 == source32, 'RV32 and RV64 exact source snapshot agrees')
v64 = next(v for v in r64['variants'] if v['id']=='simx-fp16')
require(v64['outcome']=='pass' and v64['artifacts_before']==v64['artifacts_after'], 'RV64 SimX FP16 variant completed with stable binaries')
build64 = Path(r64['paths']['work'])/'simx-fp16'
for row in v64['artifacts_before']:
    checked_file(build64,row,'RV64 stable artifact '+row['path'])
require(r64['lifecycle']['driver']=='simx' and r64['lifecycle']['outcome']=='pass', 'RV64 actual lifecycle reported pass')
checked_file(build64,r64['lifecycle']['binary'],'RV64 lifecycle executable')
cmd64 = next(c for c in r64['commands'] if c['id']=='lifecycle-run')
require(cmd64['environment']['VORTEX_DRIVER']=='simx' and cmd64['environment']['LD_LIBRARY_PATH']==str(build64/'sw/runtime'),
        'RV64 explicit runtime binding')
log64=lifecycle_log(packet64,cmd64,'RV64 lifecycle')
require(log32['sha256']==log64['sha256'],'RV32 and RV64 identical twelve-group observations')

hostpacket = WORK/'p03-formal-host'
host=json.loads((hostpacket/'verification.json').read_text())
require(host['source_revision']==REVISION and host['source_dirty'] is False, 'host tests frozen revision')
hostlines=(hostpacket/'full-suite.log').read_text().splitlines()
managed=[line for line in hostlines if 'ManagedRuntimeHostTests' in line]
host_pass=host.get('outcome')=='pass' and host.get('source_stable') is True
managed_pass=len(managed)==9 and all(line.endswith(' ... ok') for line in managed)
if managed_pass:
    require(True,'nine host mock lifecycle tests observed passing')
if host_pass:
    require(host['source_before'] == host['source_after'] == source32, 'completed host suite uses identical stable source inventory')
    for cmd in host['commands']:
        require(cmd['outcome'] == 'pass' and cmd['exit_code'] == 0 and cmd['cleanup_complete'] is True, 'completed host command '+cmd['label']+' passed')
        require(digest(hostpacket/cmd['log']) == cmd['log_sha256'], 'completed host command '+cmd['label']+' raw log integrity')
    require(hostlines[-1] == 'OK', 'complete host unittest suite final success')

reviewed = [
    'tests/runtime/test_ai_lifecycle.cpp','tests/runtime/Makefile',
    'ci/project/test_p03_managed_runtime.py','ci/project/fixtures/p03_managed_runtime_test.cpp',
    'sw/runtime/common/device.cpp','sw/runtime/common/queue.cpp','sw/runtime/common/module.cpp',
    'sw/runtime/common/buffer.cpp','sw/runtime/common/vortex2_internal.h',
    'sw/runtime/simx/vortex.cpp','sim/common/cmd_processor.cpp',
]
record={
    'schema_version':1,'reviewer':'/root/qualification_audit/lifecycle_evidence',
    'reviewed_at':datetime.now(timezone.utc).isoformat(timespec='seconds'),
    'source_revision':REVISION,'source_tree':r32['tree'],
    'independence':'Read-only reviewer; authored none of implementation, test harness, runner or enforcement. Did not rerun builds or tests.',
    'scope':'P03-A03 actual SimX lifecycle integration on default RV32 and p02-tfr RV64; host mock wrapper failure/lifetime test coverage inspected separately.',
    'outcome':'pass','blocking_findings':[],
    'recommendation':'Actual lifecycle integration supports P03-A03 at simulated scope. Overall phase acceptance remains with parent after final full-host and numerical packet review.',
    'checks_passed':len(checks),'checks':checks,
    'source_artifacts':[{'path':p,'sha256':digest(SOURCE/p),'size_bytes':(SOURCE/p).stat().st_size} for p in reviewed],
    'runtime_evidence':{'rv32_report':{'path':str(packet32/'report.json'),'sha256':digest(packet32/'report.json')},
        'rv32_commands':len(r32['commands']),'rv32_source_files':len(source32['files']),
        'rv32_compiler_dependency_files':deps['dependency_files'],'rv32_repository_inputs':deps['repository_inputs'],
        'rv32_artifact_count':len(snapshot(packet32,r32['artifacts_before'],'RV32 artifact recount')),
        'rv32_lifecycle':log32,'rv64_lifecycle':log64,'groups':expected_groups,
        'rv64_matrix_still_running_at_review':r64['state']!='finished'},
    'host_mock_evidence':{'verification_report':{'path':str(hostpacket/'verification.json'),'sha256':digest(hostpacket/'verification.json')},'test_count':9,'coverage_inspected':True,'passing_lines_observed':len(managed),
        'all_nine_passing':managed_pass,'full_host_suite_finished_pass':host_pass,
        'test_driver':'C++17 with UBSan; explicitly fake vx runtime/queue/event functions and deterministic sentinel output, not GPU arithmetic evidence'},
    'metadata_clarification':{'field':'RV32 configuration.cache_enabled=false','severity':'F1',
        'observation':'Ambiguous shorthand in RV32 helper. All commands explicitly use CCACHE_DISABLE=1; exact resolved flags have ICACHE_ENABLED=1 and DCACHE_ENABLED=1.',
        'required_publication_scope':'Describe compiler cache as disabled and hardware caches as enabled/default; preserve raw report and include this clarification rather than claim hardware caches disabled.'},
    'limitations':[
        'Synthetic images exercise skipped-launch ownership and module allocation paths; they are never executed by the lifecycle test.',
        'Nine host mock groups exercise wrapper behavior; mocked VX_ERR_DEVICE_LOST is not a physical bus/device-loss observation.',
        'Actual transfer failures are controlled host bad_alloc at backend registration, common registration, and software-CP scratch allocation; they are not electrical transport faults.',
        'The stage2 case fails before copy and verifies seeded destination before replacement write; no general rollback of partially completed DMA is demonstrated.',
        'Device-memory snapshots and intrusive refcounts are checked; process-heap leak freedom is not measured by an allocation profiler or sanitizer.',
        'Finite tests cover declared paths; arbitrary simulator/cache/processor exceptions, backend construction exhaustion, XRT physical transport failure and permanent device hangs are not qualified.',
        'Timeout retains resources; wrapper destruction may drain indefinitely when a backend never completes.',
        'RV32 build is explicitly reused from same task preparation, then reconfigured/rebuilt on frozen source; it is not represented as a from-empty build.',
        'Sampling budgets are not hard OS quotas and measured RSS may miss short-lived peaks.',
        'Full formal numerical matrix and overall host suite are reviewed separately by parent; this receipt does not close P03 by itself.'
    ]}
record['checks_passed'] = len(checks)
ledger = OUT/'lifecycle-checks.json.gz'
ledger.write_bytes(gzip.compress((json.dumps(checks, indent=2)+'\n').encode(), mtime=0))
record.pop('checks')
record['detailed_checks'] = {'path':str(ledger),'sha256':digest(ledger),'size_bytes':ledger.stat().st_size}
record['check_groups'] = ['Exact frozen commit and clean provenance', 'All 950 source inventory files rehashed against retained before/after snapshots', 'RV32 source/artifacts/tools/dependencies stable before and after', 'All 14 RV32 build artifact hashes match live generated files and binaries', 'All eight bounded RV32 commands passed and their raw logs verify', 'All 201 source dependencies from 41 compiler dependency files covered', 'Retained runtime source bodies match source inventory', 'Explicit SimX driver and runtime library binding for both configurations', 'RV64 completed SimX FP16 variant stable artifact identities and lifecycle executable hash', 'Exact12group ordered lifecycle results, expected exhaustion-only error, and unique terminal success on both XLENs', 'Nine wrapper mock tests individually observed passing; completed host suite receipt, source stability and log identities additionally verified']
(OUT/'lifecycle-review.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'outcome':record['outcome'],'checks_passed':len(checks),'rv32_groups':log32['groups'],'rv64_groups':log64['groups'],'host_mock_lines':len(managed),'host_complete_pass':host_pass,'receipt':str(OUT/'lifecycle-review.json')}))
