#!/usr/bin/env python3
"""Independent read-only audit of the finished P03 execution packet."""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys

TASK = Path('/workspace/scratch/198e8aeab1bd')
SOURCE = TASK / 'AI-GPU'
PACKET = TASK / 'p03-formal-results'
WORK = TASK / 'p03-formal-builds'
HOST = TASK / 'p03-formal-host'
OUTPUT = TASK / 'p03-review/qualification-audit'
REVISION = '319ad63532cee17ae88fa75757a5ac87ed5c6a77'
BASE = '20e026f5e5bffc6ea044f6216b28f66cfaa1b156'
PROFILE = '79a551bd7ba51b5aa4b221eeb9c8f68b0f3078e6282ce71a1f28e9bc4593a102'
checks = Counter()


def require(condition, label, group='integrity'):
    if not condition:
        raise ValueError(label)
    checks[group] += 1


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key, 'json')
        result[key] = value
    return result


def decode(text):
    return json.loads(text, object_pairs_hook=unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def read_json(path):
    return decode(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(part)
    return digest.hexdigest()


def artifact(root, row):
    path = Path(row['path'])
    require(not path.is_absolute() and '..' not in path.parts, 'unsafe relative artifact')
    full = root / path
    require(full.is_file(), 'missing artifact: ' + str(full))
    require(sha(full) == row['sha256'], 'artifact digest: ' + str(full))
    if 'size_bytes' in row:
        require(full.stat().st_size == row['size_bytes'], 'artifact size: ' + str(full))
    return full


def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE)


def command(row):
    require(row['outcome'] == 'pass' and row['exit_code'] == 0,
            'nonpassing command: ' + row['id'], 'commands')
    require(row['cleanup_complete'] and row['process_started'],
            'incomplete command cleanup: ' + row['id'], 'commands')
    path = artifact(PACKET, {'path': row['log'], 'sha256': row['log_sha256'],
                            'size_bytes': row['log_size_bytes']})
    require(row['peak_rss_bytes'] < 6 * 1024**3, 'RSS budget exceeded', 'budgets')
    require(row['log_size_bytes'] <= 16 * 1024**2, 'log budget exceeded', 'budgets')
    require(row['duration_seconds'] <= row['timeout_seconds'], 'time budget exceeded', 'budgets')
    return path


def main():
    report = read_json(PACKET / 'report.json')
    if report.get('state') != 'finished':
        raise SystemExit('Final execution packet is not finished; no acceptance issued.')
    require(report['outcome'] == 'pass' and report['reason'] is None, 'execution packet failed')
    require(report['development'] is False and report['full_matrix_requested'] is True,
            'development or partial packet')
    require(report['iterations'] == 2 and report['acceptance_claimed'] is False,
            'incorrect iteration count or self-acceptance')
    require(report['phase_complete'] is False, 'runner self-closed phase')

    before = read_json(artifact(PACKET, report['source_before']))
    after = read_json(artifact(PACKET, report['source_after']))
    require(before == after and report['source_stable'], 'source drift')
    checkout = before['checkout']
    require(checkout['revision'] == REVISION and checkout['dirty'] is False,
            'wrong or dirty tested revision')
    require(not checkout['blockers'] and not checkout['changed_paths']
            and not checkout['untracked_paths'], 'source provenance blockers')
    require(git('rev-parse', REVISION + '^{tree}').decode().strip() == checkout['tree'],
            'source commit tree mismatch')
    require(git('rev-parse', 'HEAD').decode().strip() == REVISION
            and not git('status', '--porcelain').strip(), 'source not frozen during review')
    require(all(row['status'] == 'initialized' for row in checkout['submodules']['entries']),
            'uninitialized submodule')
    source_inventory = {row['path']: row for row in before['files']}
    for row in before['files']:
        artifact(SOURCE, row)
    for path in ('sw/runtime/common/callbacks.inc', 'third_party/softfloat/source/RISCV/specialize.h',
                 'sim/common/cmd_processor.cpp', 'sw/kernel/ai/matmul.cpp',
                 'sw/common/ai_matmul_args.h', 'sw/runtime/ai/runtime.cpp'):
        require(path in source_inventory, 'critical input absent from inventory: ' + path)
    for row in report['loaded_helpers']:
        artifact(SOURCE, row)
    for row in report['retained_sources']:
        full = artifact(PACKET, row)
        original = SOURCE / str(Path(row['path']).relative_to('artifacts/source'))
        require(full.read_bytes() == original.read_bytes(), 'retained source differs: ' + str(original))

    tools_before = read_json(artifact(PACKET, report['tools_before']))
    tools_after = read_json(artifact(PACKET, report['tools_after']))
    require(tools_before == tools_after, 'tool inventory drift')
    checked_tools = set()

    def tools(value):
        if isinstance(value, dict):
            if 'path' in value and 'sha256' in value:
                path = Path(value.get('resolved_path', value['path']))
                identity = (str(path), value['sha256'])
                if identity not in checked_tools:
                    require(path.is_absolute() and path.is_file(), 'tool path unavailable')
                    require(sha(path) == value['sha256'], 'tool digest differs: ' + str(path))
                    checked_tools.add(identity)
            for item in value.values():
                tools(item)
        elif isinstance(value, list):
            for item in value:
                tools(item)
    tools(tools_before)
    for row in report['dependencies_before']:
        artifact(SOURCE, row)

    frozen_inputs = [
        'ci/project/fixtures/p02_layout_v1.json', 'ci/project/fixtures/p02_tfr_v1.json',
        'ci/project/fixtures/p02_wmma_numerical_v1.json',
        'tests/regression/sgemm_tcu/p02_fixtures.h',
        'ci/project/p02_fixture_oracle.py', 'ci/project/p02_layout_fixture_oracle.py',
        'ci/project/p02_wmma_numerical_fixture_oracle.py', 'ci/project/p02_wmma_fixtures.py',
        'ci/project/compiler_records.py', 'ci/project/p02_matrix_records.py',
        'profiles/p02-tfr.json',
    ]
    for path in frozen_inputs:
        require(git('show', BASE + ':' + path) == (SOURCE / path).read_bytes(),
                'historical oracle/profile/enforcement changed: ' + path, 'oracle')
    require(sha(SOURCE / 'profiles/p02-tfr.json') == PROFILE, 'wrong profile identity', 'oracle')
    cases = []
    for path in ('ci/project/fixtures/p02_layout_v1.json',
                 'ci/project/fixtures/p02_wmma_numerical_v1.json'):
        document = read_json(SOURCE / path)
        for case in document['cases']:
            cases.append(dict(case, **case['dimensions']))
    require(len(cases) == 88 and len({case['id'] for case in cases}) == 88,
            'case inventory count', 'oracle')
    require(Counter(case['format'] for case in cases) == {'fp16': 44, 'bf16': 44},
            'format inventory', 'oracle')
    signatures = {(case['format'], case['m'], case['n'], case['k']) for case in cases}
    expected_signatures = {(fmt, m, n, k) for fmt in ('fp16', 'bf16')
                           for m, n, k in ((8, 4, 8), (8, 4, 16), (16, 8, 16))}
    require(signatures == expected_signatures, 'supported signature coverage', 'oracle')
    require(read_json(artifact(PACKET, report['fixture_snapshot'])) == cases,
            'runner fixture snapshot differs from independent source documents', 'oracle')
    require(report['case_ids'] == [case['id'] for case in cases], 'runner case selection', 'oracle')
    by_case = {case['id']: case for case in cases}

    sys.path.insert(0, str(SOURCE / 'ci/project'))
    from p02_wmma_fixtures import load_cases
    from compiler_records import _records, _syntax
    from baseline_packet_contract import _stamp_words
    from p02_matrix_records import _record, validate_header_macros
    require(load_cases(SOURCE) == cases, 'independent producers did not reproduce fixtures', 'oracle')

    commands = {row['id']: row for row in report['commands']}
    require(len(commands) == len(report['commands']), 'duplicate command ids', 'commands')
    for row in report['commands']:
        command(row)
    expected_variants = ['simx-fp16', 'simx-bf16', 'rtlsim-fp16', 'rtlsim-bf16']
    require([row['id'] for row in report['variants']] == expected_variants, 'variant order/coverage')
    total_launches = total_words = total_cases = 0
    summaries = []
    for variant in report['variants']:
        vid = variant['id']
        driver, fmt = variant['backend'], variant['format']
        build = WORK / vid
        require(variant['outcome'] == 'pass', 'variant incomplete: ' + vid)
        require(variant['artifacts_before'] == variant['artifacts_after'], 'artifact drift: ' + vid)
        for row in variant['artifacts_before']:
            artifact(build, row)
        require((build / 'tests/regression/ai_matmul/Makefile').read_bytes()
                == (SOURCE / 'tests/regression/ai_matmul/Makefile').read_bytes(), 'generated Makefile drift')
        rt = (build / ('sw/runtime/' + driver + '_rt_config.stamp')).read_text()
        be = (build / ('sw/runtime/' + driver + '_config.stamp')).read_text()
        app = (build / 'tests/regression/ai_matmul/config.stamp').read_text()
        rt_lines, be_lines, app_lines = (_records(text, label)
                                       for text, label in ((rt, 'runtime'), (be, 'backend'), (app, 'app')))
        roles = ['verilator', 'backend_cpp'] if driver == 'rtlsim' else ['backend_cpp']
        require(len(rt_lines) == 1 and len(be_lines) == len(roles) and len(app_lines) == 3,
                'separate compiler records missing: ' + vid, 'configuration')
        independent_records = []
        for line, role in [(rt_lines[0], 'runtime'), *zip(be_lines, roles),
                           (app_lines[0], 'kernel'), (app_lines[1], 'host')]:
            independent_records.append(_record(line, vid + '/' + role, fmt, role=role,
                source=SOURCE, jobs=2, selectors=not (driver == 'rtlsim' and role == 'backend_cpp')))
        require(independent_records == variant['compiler_records'],
                'compiler records differ from independent role validation: ' + vid, 'configuration')
        _syntax(app_lines[2], 'operator linker')
        require(_stamp_words(app_lines[2], 'operator linker')
                == ['-L' + str(build / 'sw/runtime'), '-lvortex'], 'unexpected host arithmetic linkage', 'configuration')
        for suffix, key in (('header', 'header_macros'), ('effective-header', 'backend_header_macros')):
            text = (PACKET / commands[vid + '-' + suffix]['log']).read_text()
            require(validate_header_macros(text) == variant[key], 'resolved macro drift: ' + vid, 'configuration')
        binding = read_json(artifact(PACKET, variant['binding']))
        canonical = json.dumps(binding, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
        require(hashlib.sha256(canonical).hexdigest() == variant['qualification_id'], 'binding digest: ' + vid)
        require(binding == {'source': checkout, 'backend': driver, 'format': fmt,
                            'compiler_records': independent_records, 'artifacts': variant['artifacts_before'],
                            'dependencies': report['dependencies_before'], 'profile_sha256': PROFILE},
                'binding inputs differ: ' + vid)
        selected = [case for case in cases if case['format'] == fmt]
        require([row['id'] for row in variant['cases']] == [case['id'] for case in selected],
                'case omission/reorder: ' + vid, 'launches')
        words = 0
        for case_row in variant['cases']:
            case = by_case[case_row['id']]
            require(case_row['outcome'] == 'pass', 'case failed', 'launches')
            run = commands[vid + '-' + case['id']]
            require(run['argv'] == [str(build / 'tests/regression/ai_matmul/ai_matmul'),
                '--case', case['id'], '--iterations', '2', '--module',
                str(build / 'tests/regression/ai_matmul/kernel.vxbin'),
                '--qualification-id', variant['qualification_id']], 'launch argv differs', 'launches')
            require(run['environment']['VORTEX_DRIVER'] == driver
                    and run['environment']['LD_LIBRARY_PATH'] == str(build / 'sw/runtime'),
                    'backend/library binding differs', 'launches')
            text = (PACKET / run['log']).read_text()
            require(not any(ord(char) < 32 and char not in '\t\r\n' for char in text), 'control character in result')
            require(not re.search(r'\b(?:FAILED|FAIL|ERROR|FATAL|ABORTED|MISMATCH)\b|Segmentation fault|runtime error:',
                                  text, re.IGNORECASE), 'failure marker in operator log', 'launches')
            lines = text.splitlines()
            require(lines[-1] == 'PASSED!' and lines.count('PASSED!') == 1,
                    'ambiguous terminal success', 'launches')
            require(lines.count('P03_REJECTIONS checked=2') == 1, 'actual input rejections missing', 'launches')
            raw = [decode(line[len('P03_RESULT '):]) for line in lines if line.startswith('P03_RESULT ')]
            require(len(raw) == 2 and raw == case_row['observations'], 'raw/summary observations differ', 'launches')
            for iteration, result in enumerate(raw):
                require(result['case_id'] == case['id'] and result['format'] == fmt
                        and result['qualification_id'] == variant['qualification_id'], 'result identity', 'launches')
                m, n, k = case['m'], case['n'], case['k']
                require(tuple(result[key] for key in ('m', 'n', 'k', 'iteration', 'checked', 'mismatches'))
                        == (m, n, k, iteration, m * n, 0), 'result dimensions/counts', 'launches')
                require(all(type(result[key]) is int for key in ('m', 'n', 'k', 'iteration', 'checked', 'mismatches')),
                        'noninteger result counts', 'launches')
                require(result['actual_bits'] == case['expected'] and len(case['expected']) == m * n,
                        'independent reference mismatch: ' + vid + '/' + case['id'], 'arithmetic')
                require(all(re.fullmatch('[0-9a-f]{8}', word) and word not in ('7fc0dead', 'deadbeef')
                            for word in case['expected']), 'poison could mask untouched output', 'arithmetic')
                dispatch, resources = result['dispatch'], result['resources']
                require((dispatch['writes'], dispatch['reads'], dispatch['launches']) == (3, 1, 1)
                        and dispatch['waits'] >= 1, 'dispatch trace counts', 'launches')
                sizes = [m * k * 2, k * n * 2, m * n * 4]
                addresses = [dispatch[key] for key in ('a_address', 'b_address', 'd_address')]
                require([dispatch[key] for key in ('a_bytes', 'b_bytes', 'd_bytes')] == sizes,
                        'transfer size mismatch', 'wire')
                require(all(type(a) is int and a >= 0 and a % 4 == 0 and a + size <= 2**64
                            for a, size in zip(addresses, sizes)), 'invalid device address', 'wire')
                require(all(addresses[i] + sizes[i] <= addresses[j] or addresses[j] + sizes[j] <= addresses[i]
                            for i in range(3) for j in range(i + 1, 3)), 'overlapping allocations', 'wire')
                expected_wire = struct.pack('<8I3Q', 1, 56, 1 if fmt == 'fp16' else 2, 0, m, n, k, 0, *addresses)
                require(dispatch['argument_bytes'] == expected_wire.hex(), 'actual 56-byte wire payload differs', 'wire')
                require(dispatch['poison'] == (0x7fc0dead if iteration == 0 else 0xdeadbeef),
                        'independent output poison missing', 'launches')
                require(resources['primary'] == resources['cleanup'] == 0
                        and resources['used_before'] == resources['used_after']
                        and resources['free_before'] == resources['free_after'], 'resource baseline mismatch', 'resources')
                require(all(type(value) is int and value >= 0 for value in resources.values()),
                        'invalid resource counter', 'resources')
                total_launches += 1
                total_words += m * n
                words += m * n
            total_cases += 1
        summaries.append({'id': vid, 'cases': len(selected), 'launches': len(selected) * 2,
                          'checked_words': words, 'compiler_roles': [row['role'] for row in independent_records],
                          'qualification_id': variant['qualification_id']})

    require((total_cases, total_launches, total_words) == (176, 352, 14336), 'complete numerical coverage counts')
    require((report['completed_case_executions'], report['completed_launches'], report['checked_words'])
            == (total_cases, total_launches, total_words), 'reported aggregate counts differ')
    require(report['lifecycle']['outcome'] == 'pass' and report['lifecycle']['driver'] == 'simx',
            'actual RV64 lifecycle run missing')
    for value in report['resources_after']['free_disk_bytes'].values():
        require(value >= 15 * 1024**3, 'disk reserve breached', 'budgets')
    output = {
        'schema_version': 1, 'reviewer': '/root/qualification_audit', 'reviewed_at': datetime.now(timezone.utc).isoformat(),
        'source_revision': REVISION, 'source_tree': checkout['tree'], 'outcome': 'pass',
        'scope': 'Independent read-only numerical execution and provenance audit; separate lifecycle review supplies A03 scope.',
        'recommendation': {'P03-A02': 'accept at bounded native processor RTL and SimX scope', 'P03-A03': 'separate lifecycle review'},
        'commands': [{'argv': [sys.executable, str(Path(__file__))], 'cwd': str(SOURCE), 'exit_code': 0}],
        'checks_by_group': dict(checks), 'total_checks': sum(checks.values()),
        'source_inventory_files': len(before['files']), 'retained_source_bodies': len(report['retained_sources']),
        'loaded_helpers': len(report['loaded_helpers']), 'unique_tool_file_identities': len(checked_tools),
        'command_count': len(report['commands']), 'variant_summaries': summaries,
        'completed_case_executions': total_cases, 'completed_launches': total_launches, 'checked_words': total_words,
        'fixture_case_counts_by_signature': {str(key): value for key, value in sorted(Counter((c['format'], c['m'], c['n'], c['k']) for c in cases).items())},
        'report_sha256': sha(PACKET / 'report.json'), 'audit_script_sha256': sha(Path(__file__)),
        'limitations': [
            'Only six ordinary FP16/BF16-to-FP32 signatures and the frozen profile are covered; other operators and shapes remain unavailable.',
            'Native processor RTL bypasses the AFU. Integer DPI helpers remain; no vendor hw_emu, physical FPGA, timing/PPA or silicon proof follows.',
            'The trusted runner and retained compiler/module/backend identities establish the tested build binding, not authentication against arbitrary malicious files or hardware.',
            'No binary-replay archive is claimed; local binary/tool hashes were verified while available, and portable source/config/raw-log evidence is retained separately.',
            'No new performance claim or model_parity execution is made.',
            'Earlier blocked and interrupted execution packets are not used as passing qualification evidence.',
            'The audit independently implements result/wire/counter verification and reuses unchanged, source-hashed P02 fixture producers and compiler-record syntax validators.',
        ],
    }
    (OUTPUT / 'numerical-audit.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: output[key] for key in ('outcome', 'source_revision', 'total_checks', 'command_count',
                                                 'completed_case_executions', 'completed_launches', 'checked_words')}, indent=2))


if __name__ == '__main__':
    main()
