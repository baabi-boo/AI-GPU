import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

source = Path('/workspace/scratch/198e8aeab1bd/AI-GPU')
output = Path('/workspace/scratch/198e8aeab1bd/p03-formal-host')
output.mkdir()
(output / 'tmp').mkdir()
sys.path.insert(0, str(source / 'ci/project'))
from baseline_process import run_bounded
from p03_execute import source_snapshot

def git(*args):
    return subprocess.check_output(['git', *args], cwd=source, text=True).strip()

assert not git('status', '--porcelain'), 'formal tests require clean source'
environment = os.environ.copy()
environment.pop('PYTHONPATH', None)
overrides = {'PYTHONDONTWRITEBYTECODE': '1', 'CCACHE_DISABLE': '1', 'OBJCACHE': '',
             'MAKEFLAGS': '-j2', 'CMAKE_BUILD_PARALLEL_LEVEL': '2', 'THREADS': '2',
             'TMPDIR': str(output / 'tmp'), 'LC_ALL': 'C', 'LANG': 'C'}
environment.update(overrides)
initial = source_snapshot(source)
record = {'schema_version': 1, 'source_revision': git('rev-parse', 'HEAD'),
          'source_tree': git('rev-parse', 'HEAD^{tree}'), 'source_dirty': False,
          'environment_overrides': overrides, 'python': sys.version,
          'budget': {'timeout_seconds': 1800, 'min_free_bytes': 15 * 1024**3,
                     'max_log_bytes': 16 * 1024**2, 'max_rss_bytes': 6 * 1024**3},
          'source_before': initial, 'commands': []}
for label, argv in [('governance', ['python3', 'ci/project/check_project.py']),
                    ('software-boundary', ['bash', 'ci/check_sw_sim_boundary.sh']),
                    ('full-suite', ['python3', '-m', 'unittest', 'discover', '-s', 'ci/project', '-p', 'test_*.py', '-v'])]:
    print('Starting ' + label, flush=True)
    result = run_bounded(argv, source, environment, output / (label + '.log'),
                         timeout_seconds=1800, resource_paths=(output, source))
    record['commands'].append(dict(result, label=label, argv=argv, cwd=str(source), log=label + '.log'))
    (output / 'verification.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'label': label, 'outcome': result['outcome'], 'duration_seconds': result['duration_seconds']}), flush=True)
    if result['outcome'] != 'pass':
        break
record['source_after'] = source_snapshot(source)
record['working_tree_after'] = git('status', '--porcelain')
record['source_stable'] = record['source_before'] == record['source_after'] and not record['working_tree_after']
record['outcome'] = 'pass' if record['source_stable'] and len(record['commands']) == 3 and all(c['outcome'] == 'pass' for c in record['commands']) else 'fail'
(output / 'verification.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Formal result: ' + record['outcome'], flush=True)
sys.exit(0 if record['outcome'] == 'pass' else 1)
