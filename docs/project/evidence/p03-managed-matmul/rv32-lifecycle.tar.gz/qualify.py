#!/usr/bin/env python3
"""Final frozen-source default RV32 lifecycle receipt, reusing this task's build."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import shlex
import shutil
import sys

SOURCE = Path('/workspace/scratch/198e8aeab1bd/AI-GPU')
WORK = Path(__file__).resolve().parent
BUILD = WORK / 'build'
OUTPUT = WORK / 'final-evidence'
TOOLS = Path('/workspace/scratch/5b5ef3281659/ai-gpu-work/tools')
HOST_BIN = Path('/workspace/scratch/5b5ef3281659/ai-gpu-work/host-bin')
sys.path.insert(0, str(SOURCE / 'ci/project'))
import p02_matrix as base
import p03_execute as operator_runner
from baseline_inventory import hash_artifacts
from baseline_process import run_bounded

PATHS = dict(source=SOURCE, tools=TOOLS, work=WORK, output=OUTPUT,
             host_bin=HOST_BIN, verilator=TOOLS / 'verilator')
ENV = base.clean_environment(PATHS, 2)
ENV.pop('HOME', None)
ENV.update(CONFIGS='', PROFILE='')
ARTIFACTS = tuple(base.GENERATED) + (
    'tests/runtime/Makefile', 'sw/runtime/libvortex.so',
    'sw/runtime/libvortex-simx.so', 'sw/runtime/libsimx.so',
    'sw/runtime/simx_rt_config.stamp', 'sw/runtime/simx_config.stamp',
    'tests/runtime/test_ai_lifecycle',
)
RETAINED = (
    'sim/common/cmd_processor.cpp', 'sim/common/cmd_processor.h',
    'sw/runtime/common/device.cpp', 'sw/runtime/common/module.cpp',
    'sw/runtime/common/queue.cpp', 'sw/runtime/common/buffer.cpp',
    'sw/runtime/common/vortex2_internal.h', 'sw/runtime/simx/vortex.cpp',
    'sw/runtime/common/callbacks.inc', 'tests/runtime/test_ai_lifecycle.cpp',
    'tests/runtime/Makefile', 'third_party/softfloat/source/RISCV/specialize.h',
)
report = {}

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def checkpoint():
    base._write_json(OUTPUT / 'report.json', report)

def save(name, value):
    path = OUTPUT / 'snapshots' / (name + '.json')
    base._write_json(path, value)
    return hash_artifacts(OUTPUT, [path.relative_to(OUTPUT).as_posix()])[0]

def command(name, argv, cwd, env=None, timeout=1800):
    row = dict(id=name, argv=[str(x) for x in argv], cwd=str(cwd), environment=env or ENV,
               log='logs/' + name + '.log', timeout_seconds=timeout, outcome='running')
    report['commands'].append(row)
    checkpoint()
    row.update(run_bounded(row['argv'], cwd, row['environment'], OUTPUT / row['log'],
                           timeout_seconds=timeout, **base.BUDGET,
                           resource_paths=(SOURCE, WORK, OUTPUT, TOOLS)))
    checkpoint()
    print(json.dumps({k: row.get(k) for k in (
        'id', 'outcome', 'exit_code', 'reason', 'duration_seconds', 'peak_rss_bytes',
        'log_size_bytes', 'cleanup_complete')}), flush=True)
    require(row['outcome'] == 'pass' and row['exit_code'] == 0 and row['cleanup_complete'],
            'command failed: ' + name)
    return (OUTPUT / row['log']).read_text()

def execute():
    expected_commit = sys.argv[1]
    OUTPUT.mkdir(mode=0o700)
    (OUTPUT / 'logs').mkdir()
    (OUTPUT / 'snapshots').mkdir()
    report.update(schema_version=1, purpose='default-rv32-simx-runtime-lifecycle',
                  started_at=base._now(), state='running', outcome='running', commands=[],
                  source_root=str(SOURCE), build_root=str(BUILD),
                  budget=dict(base.BUDGET, jobs=2), reused_task_preparation_build=True,
                  preparation_report=base._file_identity(WORK / 'evidence/report.json'),
                  kernel_built=False, synthetic_module_executed=False,
                  phase_acceptance_claimed=False, runner=base._file_identity(Path(__file__)),
                  limitations=list(base.PROCESS_LIMITATIONS))
    report['resources_before'] = base._resources(PATHS)
    require(report['resources_before']['available_memory_bytes'] >= base.BUDGET['max_rss_bytes'],
            'less than 6 GiB available RAM')
    require(min(report['resources_before']['free_disk_bytes'].values()) >= base.BUDGET['min_free_bytes'],
            'less than 15 GiB free disk')
    before = operator_runner.source_snapshot(SOURCE)
    base._source_ok(before, False)
    require(before['checkout']['revision'] == expected_commit, 'unexpected source commit')
    report.update(revision=expected_commit, tree=before['checkout']['tree'], source_dirty=False)
    report['source_before'] = save('source-before', before)
    names = {row['path'] for row in before['files']}
    require(set(RETAINED) <= names, 'runtime source inventory is incomplete')
    tools = base.tool_inventory(PATHS, ENV, ['simx'])
    dependencies = hash_artifacts(SOURCE, base.DEPENDENCIES)
    report['tools_before'] = save('tools-before', tools)
    report['dependencies_before'] = save('dependencies-before', dependencies)
    command('cxx-version', [tools['g++']['path'], '--version'], WORK, timeout=30)
    frontend = command('cxx-frontend', [tools['g++']['path'], '-print-prog-name=cc1plus'],
                       WORK, timeout=30).strip()
    report['host_cxx_frontend'] = base._file_identity(frontend)
    command('configure', [SOURCE / 'configure', '--xlen=32', '--profile=',
            '--osversion=ubuntu/focal', '--tooldir=' + str(TOOLS)], BUILD, timeout=120)
    flags = command('resolved-config', [sys.executable, BUILD / 'ci/gen_config.py',
        '--config=' + str(SOURCE / 'VX_config.toml'), '--profile=',
        '--cflags=-DVX_CFG_XLEN=32', '--format=cflags'], BUILD, timeout=30).strip()
    parsed_flags = shlex.split(flags)
    require('-DVX_CFG_XLEN=32' in parsed_flags and '-DVX_CFG_XLEN_32' in parsed_flags
            and '-DVX_CFG_XLEN_64' not in parsed_flags, 'configuration is not default RV32')
    macros = command('host-config-macros', [tools['g++']['path'], '-dM', '-E', '-x', 'c++',
        *parsed_flags, '-include', BUILD / 'sw/VX_config.h', '/dev/null'], BUILD, timeout=30)
    require(re.search(r'^#define VX_CFG_XLEN 32$', macros, re.M), 'compiled XLEN is not 32')
    report['configuration'] = dict(xlen=32, profile='', configs='', resolved_flags=flags,
                                   backend='simx', cache_enabled=False)
    command('runtime-build', ['make', '-j2', '-C', BUILD / 'sw/runtime',
            'stub', 'simx', 'CONFIGS=', 'PROFILE='], BUILD)
    command('lifecycle-build', ['make', '-j2', '-C', BUILD / 'tests/runtime',
            'test_ai_lifecycle', 'CONFIGS=', 'PROFILE='], BUILD, timeout=180)
    observed = set()
    dependency_files = list(BUILD.rglob('*.d'))
    for path in dependency_files:
        for token in path.read_text().replace('\\\n', ' ').split():
            token = token.rstrip(':')
            if token.startswith(str(SOURCE) + '/'):
                observed.add(Path(token).resolve().relative_to(SOURCE).as_posix())
    require(observed <= names, 'compiler dependencies absent from source inventory: ' +
            ', '.join(sorted(observed - names)))
    report['compiler_dependencies'] = save('compiler-dependencies', dict(
        dependency_files=len(dependency_files), repository_inputs=len(observed),
        missing_from_source_inventory=[], inputs=hash_artifacts(SOURCE, sorted(observed))))
    require(operator_runner.source_snapshot(SOURCE) == before, 'source changed during build')
    frozen = hash_artifacts(BUILD, ARTIFACTS)
    report['artifacts_before'] = save('artifacts-before', frozen)
    for name in RETAINED:
        path = OUTPUT / 'source' / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE / name, path)
    for name in tuple(base.GENERATED) + ('tests/runtime/Makefile',):
        path = OUTPUT / 'generated' / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(BUILD / name, path)
    run_env = dict(ENV, VORTEX_DRIVER='simx', LD_LIBRARY_PATH=str(BUILD / 'sw/runtime'))
    output = command('lifecycle-run', [BUILD / 'tests/runtime/test_ai_lifecycle'],
                     BUILD / 'tests/runtime', env=run_env, timeout=180)
    groups = [line for line in output.splitlines() if line.startswith('[OK]')]
    require(len(groups) == 12 and 'P03_LIFECYCLE PASSED' in output, 'incomplete lifecycle result')
    report['lifecycle_groups'] = groups
    after = operator_runner.source_snapshot(SOURCE)
    report['source_after'] = save('source-after', after)
    report['artifacts_after'] = save('artifacts-after', hash_artifacts(BUILD, ARTIFACTS))
    report['tools_after'] = save('tools-after', base.tool_inventory(PATHS, ENV, ['simx']))
    report['dependencies_after'] = save('dependencies-after', hash_artifacts(SOURCE, base.DEPENDENCIES))
    require(after == before, 'source changed during execution')
    for role in ('artifacts', 'tools', 'dependencies'):
        require(report[role + '_before']['sha256'] == report[role + '_after']['sha256'],
                role + ' changed during execution')
    require(report['host_cxx_frontend'] == base._file_identity(frontend), 'native frontend changed')
    require(report['runner'] == base._file_identity(Path(__file__)), 'qualification helper changed')
    report['resources_after'] = base._resources(PATHS)
    report.update(state='complete', outcome='pass', completed_at=base._now())
    checkpoint()
    print(json.dumps({'outcome': 'pass', 'revision': expected_commit,
                      'source_snapshot': report['source_before'], 'lifecycle_groups': groups,
                      'report': str(OUTPUT / 'report.json')}), flush=True)

try:
    execute()
except Exception as error:
    if OUTPUT.is_dir():
        report.update(state='failed', outcome='fail', error=str(error), failed_at=base._now())
        checkpoint()
    raise
