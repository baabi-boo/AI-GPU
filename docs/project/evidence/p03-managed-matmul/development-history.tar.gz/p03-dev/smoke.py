import json
from pathlib import Path
import sys

work = Path(__file__).resolve().parent
source = work.parent / "AI-GPU"
sys.path.insert(0, str(source / "ci/project"))
from baseline_process import run_bounded
from baseline_inventory import hash_artifacts
from p03_execute import artifacts
from p03_execution_records import validate_records, qualification_id, verify_output
from p02_wmma_fixtures import load_cases

build = work / "build"
app = build / "tests/regression/ai_matmul"
tools = Path("/workspace/scratch/5b5ef3281659/ai-gpu-work/tools")
tag = sys.argv[1]
env = {"PATH": "/workspace/scratch/5b5ef3281659/ai-gpu-work/host-bin:/usr/local/bin:/usr/bin:/bin",
       "TMPDIR": str(work / "tmp"), "LANG": "C", "LC_ALL": "C", "CCACHE_DISABLE": "1",
       "OBJCACHE": "", "MAKEFLAGS": "-j2", "THREADS": "2",
       "CONFIGS": "-DITYPE=fp16 -DOTYPE=fp32 -DKUNROLL=1"}

def command(name, argv, cwd, environment=env):
    name = tag + "-" + name
    result = run_bounded([str(x) for x in argv], cwd, environment,
                         work / "logs" / (name + ".log"), timeout_seconds=1800)
    (work / (name + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(name, result["outcome"], result["duration_seconds"], flush=True)
    if result["outcome"] != "pass":
        print((work / "logs" / (name + ".log")).read_text()[-3000:], flush=True)
        raise SystemExit(1)
    return (work / "logs" / (name + ".log")).read_text()

make = ["make", "--no-print-directory", "-j2", "THREADS=2", "VERILATOR_PATH=" + str(tools / "verilator")]
command("configure", [source / "configure", "--xlen=64", "--profile=p02-tfr",
                      "--osversion=ubuntu/focal", "--tooldir=" + str(tools)], build)
command("runtime", make + ["runtime-simx"], app)
command("application", make + ["all"], app)
records = validate_records((build / "sw/runtime/simx_rt_config.stamp").read_text(),
    (build / "sw/runtime/simx_config.stamp").read_text(), (app / "config.stamp").read_text(),
    driver="simx", fmt="fp16", source=source, build=build, jobs=2)
binding = {"scope": "development", "records": records, "artifacts": hash_artifacts(build, artifacts("simx"))}
binding_id = qualification_id(binding)
(work / (tag + "-binding.json")).write_text(json.dumps(binding, indent=2) + "\n")
launch_env = dict(env, VORTEX_DRIVER="simx", LD_LIBRARY_PATH=str(build / "sw/runtime"))
text = command("matmul", [app / "ai_matmul", "--case", "fp16-single-k00", "--iterations", "2",
                         "--module", app / "kernel.vxbin", "--qualification-id", binding_id], app, launch_env)
case = next(row for row in load_cases(source) if row["id"] == "fp16-single-k00")
print("Verified output words:", sum(row["checked"] for row in verify_output(text, case, 2, binding_id)), flush=True)
command("lifecycle-build", make + ["test_ai_lifecycle"], build / "tests/runtime")
command("lifecycle-run", [build / "tests/runtime/test_ai_lifecycle"], build / "tests/runtime", launch_env)
