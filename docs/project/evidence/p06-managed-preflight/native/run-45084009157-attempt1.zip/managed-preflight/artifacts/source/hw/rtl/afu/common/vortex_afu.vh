// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`ifndef VORTEX_AFU_VH
`define VORTEX_AFU_VH

// Synthesis-time base offset added to every m_axi_mem_<i> outgoing AXI byte
// address so that Vortex's compile-time absolute addresses (STARTUP_ADDR,
// STACK_BASE_ADDR, ...) land inside the xrt::bo allocation that XRT placed
// in that bank.
`ifndef PLATFORM_MEMORY_OFFSET
`define PLATFORM_MEMORY_OFFSET 0
`endif

`ifndef PLATFORM_MEMORY_ID_WIDTH
`define PLATFORM_MEMORY_ID_WIDTH 32
`endif

`define GEN_AXI_MEM(i) \
	output wire                                 m_axi_mem_``i``_awvalid, \
	input  wire                                 m_axi_mem_``i``_awready, \
	output wire [C_M_AXI_MEM_ADDR_WIDTH-1:0] 	m_axi_mem_``i``_awaddr, \
	output wire [C_M_AXI_MEM_ID_WIDTH-1:0]   	m_axi_mem_``i``_awid, \
	output wire [7:0]                           m_axi_mem_``i``_awlen, \
	output wire                                 m_axi_mem_``i``_wvalid, \
	input  wire                                 m_axi_mem_``i``_wready, \
	output wire [C_M_AXI_MEM_DATA_WIDTH-1:0]   	m_axi_mem_``i``_wdata, \
	output wire [C_M_AXI_MEM_DATA_WIDTH/8-1:0] 	m_axi_mem_``i``_wstrb, \
	output wire                                 m_axi_mem_``i``_wlast, \
	output wire                                 m_axi_mem_``i``_arvalid, \
	input  wire                                 m_axi_mem_``i``_arready, \
	output wire [C_M_AXI_MEM_ADDR_WIDTH-1:0]   	m_axi_mem_``i``_araddr, \
	output wire [C_M_AXI_MEM_ID_WIDTH-1:0]     	m_axi_mem_``i``_arid, \
	output wire [7:0]                           m_axi_mem_``i``_arlen, \
	input  wire                                 m_axi_mem_``i``_rvalid, \
	output wire                                 m_axi_mem_``i``_rready, \
	input  wire [C_M_AXI_MEM_DATA_WIDTH-1:0] 	m_axi_mem_``i``_rdata, \
	input  wire                                 m_axi_mem_``i``_rlast, \
	input  wire [C_M_AXI_MEM_ID_WIDTH-1:0]   	m_axi_mem_``i``_rid, \
	input  wire [1:0]                           m_axi_mem_``i``_rresp, \
	input  wire                                 m_axi_mem_``i``_bvalid, \
	output wire                                 m_axi_mem_``i``_bready, \
	input  wire [1:0]                           m_axi_mem_``i``_bresp, \
	input  wire [C_M_AXI_MEM_ID_WIDTH-1:0]   	m_axi_mem_``i``_bid

`define AXI_MEM_ARGS(i) \
    .m_axi_mem_``i``_awvalid(m_axi_mem_``i``_awvalid), \
    .m_axi_mem_``i``_awready(m_axi_mem_``i``_awready), \
    .m_axi_mem_``i``_awaddr(m_axi_mem_``i``_awaddr), \
    .m_axi_mem_``i``_awid(m_axi_mem_``i``_awid), \
    .m_axi_mem_``i``_awlen(m_axi_mem_``i``_awlen), \
    .m_axi_mem_``i``_wvalid(m_axi_mem_``i``_wvalid), \
    .m_axi_mem_``i``_wready(m_axi_mem_``i``_wready), \
    .m_axi_mem_``i``_wdata(m_axi_mem_``i``_wdata), \
    .m_axi_mem_``i``_wstrb(m_axi_mem_``i``_wstrb), \
    .m_axi_mem_``i``_wlast(m_axi_mem_``i``_wlast), \
    .m_axi_mem_``i``_arvalid(m_axi_mem_``i``_arvalid), \
    .m_axi_mem_``i``_arready(m_axi_mem_``i``_arready), \
    .m_axi_mem_``i``_araddr(m_axi_mem_``i``_araddr), \
    .m_axi_mem_``i``_arid(m_axi_mem_``i``_arid), \
    .m_axi_mem_``i``_arlen(m_axi_mem_``i``_arlen), \
    .m_axi_mem_``i``_rvalid(m_axi_mem_``i``_rvalid), \
    .m_axi_mem_``i``_rready(m_axi_mem_``i``_rready), \
    .m_axi_mem_``i``_rdata(m_axi_mem_``i``_rdata), \
    .m_axi_mem_``i``_rlast(m_axi_mem_``i``_rlast), \
    .m_axi_mem_``i``_rid(m_axi_mem_``i``_rid), \
    .m_axi_mem_``i``_rresp(m_axi_mem_``i``_rresp), \
    .m_axi_mem_``i``_bvalid(m_axi_mem_``i``_bvalid), \
    .m_axi_mem_``i``_bready(m_axi_mem_``i``_bready), \
    .m_axi_mem_``i``_bresp(m_axi_mem_``i``_bresp), \
    .m_axi_mem_``i``_bid(m_axi_mem_``i``_bid)

// Host-memory AXI4 master port (CP command ring + host side of DMA).
// XRT pins this kernel port to the card descriptor's host tag (hw/syn/xilinx/platforms).
`define GEN_AXI_HOST \
	output wire                                 m_axi_host_awvalid, \
	input  wire                                 m_axi_host_awready, \
	output wire [C_M_AXI_MEM_ADDR_WIDTH-1:0] 	m_axi_host_awaddr, \
	output wire [C_M_AXI_MEM_ID_WIDTH-1:0]   	m_axi_host_awid, \
	output wire [7:0]                           m_axi_host_awlen, \
	output wire                                 m_axi_host_wvalid, \
	input  wire                                 m_axi_host_wready, \
	output wire [C_M_AXI_MEM_DATA_WIDTH-1:0]   	m_axi_host_wdata, \
	output wire [C_M_AXI_MEM_DATA_WIDTH/8-1:0] 	m_axi_host_wstrb, \
	output wire                                 m_axi_host_wlast, \
	output wire                                 m_axi_host_arvalid, \
	input  wire                                 m_axi_host_arready, \
	output wire [C_M_AXI_MEM_ADDR_WIDTH-1:0]   	m_axi_host_araddr, \
	output wire [C_M_AXI_MEM_ID_WIDTH-1:0]     	m_axi_host_arid, \
	output wire [7:0]                           m_axi_host_arlen, \
	input  wire                                 m_axi_host_rvalid, \
	output wire                                 m_axi_host_rready, \
	input  wire [C_M_AXI_MEM_DATA_WIDTH-1:0] 	m_axi_host_rdata, \
	input  wire                                 m_axi_host_rlast, \
	input  wire [C_M_AXI_MEM_ID_WIDTH-1:0]   	m_axi_host_rid, \
	input  wire [1:0]                           m_axi_host_rresp, \
	input  wire                                 m_axi_host_bvalid, \
	output wire                                 m_axi_host_bready, \
	input  wire [1:0]                           m_axi_host_bresp, \
	input  wire [C_M_AXI_MEM_ID_WIDTH-1:0]   	m_axi_host_bid

`define AXI_HOST_ARGS \
    .m_axi_host_awvalid(m_axi_host_awvalid), \
    .m_axi_host_awready(m_axi_host_awready), \
    .m_axi_host_awaddr(m_axi_host_awaddr), \
    .m_axi_host_awid(m_axi_host_awid), \
    .m_axi_host_awlen(m_axi_host_awlen), \
    .m_axi_host_wvalid(m_axi_host_wvalid), \
    .m_axi_host_wready(m_axi_host_wready), \
    .m_axi_host_wdata(m_axi_host_wdata), \
    .m_axi_host_wstrb(m_axi_host_wstrb), \
    .m_axi_host_wlast(m_axi_host_wlast), \
    .m_axi_host_arvalid(m_axi_host_arvalid), \
    .m_axi_host_arready(m_axi_host_arready), \
    .m_axi_host_araddr(m_axi_host_araddr), \
    .m_axi_host_arid(m_axi_host_arid), \
    .m_axi_host_arlen(m_axi_host_arlen), \
    .m_axi_host_rvalid(m_axi_host_rvalid), \
    .m_axi_host_rready(m_axi_host_rready), \
    .m_axi_host_rdata(m_axi_host_rdata), \
    .m_axi_host_rlast(m_axi_host_rlast), \
    .m_axi_host_rid(m_axi_host_rid), \
    .m_axi_host_rresp(m_axi_host_rresp), \
    .m_axi_host_bvalid(m_axi_host_bvalid), \
    .m_axi_host_bready(m_axi_host_bready), \
    .m_axi_host_bresp(m_axi_host_bresp), \
    .m_axi_host_bid(m_axi_host_bid)

`define AXI_MEM_TO_ARRAY(i) \
	assign m_axi_mem_``i``_awvalid = m_axi_mem_awvalid_a[i]; \
	assign m_axi_mem_awready_a[i] = m_axi_mem_``i``_awready; \
	assign m_axi_mem_``i``_awaddr = m_axi_mem_awaddr_a[i]; \
	assign m_axi_mem_``i``_awid = m_axi_mem_awid_a[i]; \
	assign m_axi_mem_``i``_awlen = m_axi_mem_awlen_a[i]; \
	assign m_axi_mem_``i``_wvalid = m_axi_mem_wvalid_a[i]; \
	assign m_axi_mem_wready_a[i] = m_axi_mem_``i``_wready; \
	assign m_axi_mem_``i``_wdata = m_axi_mem_wdata_a[i]; \
	assign m_axi_mem_``i``_wstrb = m_axi_mem_wstrb_a[i]; \
	assign m_axi_mem_``i``_wlast = m_axi_mem_wlast_a[i]; \
	assign m_axi_mem_``i``_arvalid = m_axi_mem_arvalid_a[i]; \
	assign m_axi_mem_arready_a[i] = m_axi_mem_``i``_arready; \
	assign m_axi_mem_``i``_araddr = m_axi_mem_araddr_a[i]; \
	assign m_axi_mem_``i``_arid = m_axi_mem_arid_a[i]; \
	assign m_axi_mem_``i``_arlen = m_axi_mem_arlen_a[i]; \
	assign m_axi_mem_rvalid_a[i] = m_axi_mem_``i``_rvalid; \
	assign m_axi_mem_``i``_rready = m_axi_mem_rready_a[i]; \
	assign m_axi_mem_rdata_a[i] = m_axi_mem_``i``_rdata; \
	assign m_axi_mem_rlast_a[i] = m_axi_mem_``i``_rlast; \
	assign m_axi_mem_rid_a[i] = m_axi_mem_``i``_rid; \
	assign m_axi_mem_rresp_a[i] = m_axi_mem_``i``_rresp; \
	assign m_axi_mem_bvalid_a[i] = m_axi_mem_``i``_bvalid; \
	assign m_axi_mem_``i``_bready = m_axi_mem_bready_a[i]; \
	assign m_axi_mem_bresp_a[i] = m_axi_mem_``i``_bresp; \
	assign m_axi_mem_bid_a[i] = m_axi_mem_``i``_bid

`define AXI_MEM_TO_BUS(i) \
	assign m_axi_mem_``i``_awvalid = m_axi_mem_awvalid_bus[i]; \
	assign m_axi_mem_awready_bus[i] = m_axi_mem_``i``_awready; \
	assign m_axi_mem_``i``_awaddr = m_axi_mem_awaddr_bus[(i)*C_M_AXI_MEM_ADDR_WIDTH +: C_M_AXI_MEM_ADDR_WIDTH]; \
	assign m_axi_mem_``i``_awid = m_axi_mem_awid_bus[(i)*C_M_AXI_MEM_ID_WIDTH +: C_M_AXI_MEM_ID_WIDTH]; \
	assign m_axi_mem_``i``_awlen = m_axi_mem_awlen_bus[(i)*8 +: 8]; \
	assign m_axi_mem_``i``_wvalid = m_axi_mem_wvalid_bus[i]; \
	assign m_axi_mem_wready_bus[i] = m_axi_mem_``i``_wready; \
	assign m_axi_mem_``i``_wdata = m_axi_mem_wdata_bus[(i)*C_M_AXI_MEM_DATA_WIDTH +: C_M_AXI_MEM_DATA_WIDTH]; \
	assign m_axi_mem_``i``_wstrb = m_axi_mem_wstrb_bus[(i)*(C_M_AXI_MEM_DATA_WIDTH/8) +: (C_M_AXI_MEM_DATA_WIDTH/8)]; \
	assign m_axi_mem_``i``_wlast = m_axi_mem_wlast_bus[i]; \
	assign m_axi_mem_``i``_arvalid = m_axi_mem_arvalid_bus[i]; \
	assign m_axi_mem_arready_bus[i] = m_axi_mem_``i``_arready; \
	assign m_axi_mem_``i``_araddr = m_axi_mem_araddr_bus[(i)*C_M_AXI_MEM_ADDR_WIDTH +: C_M_AXI_MEM_ADDR_WIDTH]; \
	assign m_axi_mem_``i``_arid = m_axi_mem_arid_bus[(i)*C_M_AXI_MEM_ID_WIDTH +: C_M_AXI_MEM_ID_WIDTH]; \
	assign m_axi_mem_``i``_arlen = m_axi_mem_arlen_bus[(i)*8 +: 8]; \
	assign m_axi_mem_rvalid_bus[i] = m_axi_mem_``i``_rvalid; \
	assign m_axi_mem_``i``_rready = m_axi_mem_rready_bus[i]; \
	assign m_axi_mem_rdata_bus[(i)*C_M_AXI_MEM_DATA_WIDTH +: C_M_AXI_MEM_DATA_WIDTH] = m_axi_mem_``i``_rdata; \
	assign m_axi_mem_rlast_bus[i] = m_axi_mem_``i``_rlast; \
	assign m_axi_mem_rid_bus[(i)*C_M_AXI_MEM_ID_WIDTH +: C_M_AXI_MEM_ID_WIDTH] = m_axi_mem_``i``_rid; \
	assign m_axi_mem_rresp_bus[(i)*2 +: 2] = m_axi_mem_``i``_rresp; \
	assign m_axi_mem_bvalid_bus[i] = m_axi_mem_``i``_bvalid; \
	assign m_axi_mem_``i``_bready = m_axi_mem_bready_bus[i]; \
	assign m_axi_mem_bresp_bus[(i)*2 +: 2] = m_axi_mem_``i``_bresp; \
	assign m_axi_mem_bid_bus[(i)*C_M_AXI_MEM_ID_WIDTH +: C_M_AXI_MEM_ID_WIDTH] = m_axi_mem_``i``_bid

// AXI memory masters the AFU exposes: one per GPU memory port, rounded up to
// a power of two so that address bits select the port, and at most one per
// platform memory channel. A platform top must spell its ports out, so the
// build resolves this to the literal AFU_MEM_PORTS
// (hw/scripts/afu_mem_ports.sh) and VX_afu_wrap checks that the two agree.
`define AFU_MEM_PORTS_OF(n) `MIN(1 << `CLOG2(n), `VX_CFG_PLATFORM_MEMORY_NUM_BANKS)

// Flat per-field buses connecting a platform top's m_axi_mem_<i> ports to
// VX_afu_wrap, port i in slice i. They are plain Verilog, so the platform
// tops stay Verilog, which the Vitis and AVED kernel packagers require.
`define AXI_MEM_BUSES(n) \
    wire [(n)-1:0]                              m_axi_mem_awvalid_bus; \
    wire [(n)-1:0]                              m_axi_mem_awready_bus; \
    wire [(n)*C_M_AXI_MEM_ADDR_WIDTH-1:0]       m_axi_mem_awaddr_bus; \
    wire [(n)*C_M_AXI_MEM_ID_WIDTH-1:0]         m_axi_mem_awid_bus; \
    wire [(n)*8-1:0]                            m_axi_mem_awlen_bus; \
    wire [(n)-1:0]                              m_axi_mem_wvalid_bus; \
    wire [(n)-1:0]                              m_axi_mem_wready_bus; \
    wire [(n)*C_M_AXI_MEM_DATA_WIDTH-1:0]       m_axi_mem_wdata_bus; \
    wire [(n)*(C_M_AXI_MEM_DATA_WIDTH/8)-1:0]   m_axi_mem_wstrb_bus; \
    wire [(n)-1:0]                              m_axi_mem_wlast_bus; \
    wire [(n)-1:0]                              m_axi_mem_arvalid_bus; \
    wire [(n)-1:0]                              m_axi_mem_arready_bus; \
    wire [(n)*C_M_AXI_MEM_ADDR_WIDTH-1:0]       m_axi_mem_araddr_bus; \
    wire [(n)*C_M_AXI_MEM_ID_WIDTH-1:0]         m_axi_mem_arid_bus; \
    wire [(n)*8-1:0]                            m_axi_mem_arlen_bus; \
    wire [(n)-1:0]                              m_axi_mem_rvalid_bus; \
    wire [(n)-1:0]                              m_axi_mem_rready_bus; \
    wire [(n)*C_M_AXI_MEM_DATA_WIDTH-1:0]       m_axi_mem_rdata_bus; \
    wire [(n)-1:0]                              m_axi_mem_rlast_bus; \
    wire [(n)*C_M_AXI_MEM_ID_WIDTH-1:0]         m_axi_mem_rid_bus; \
    wire [(n)*2-1:0]                            m_axi_mem_rresp_bus; \
    wire [(n)-1:0]                              m_axi_mem_bvalid_bus; \
    wire [(n)-1:0]                              m_axi_mem_bready_bus; \
    wire [(n)*2-1:0]                            m_axi_mem_bresp_bus; \
    wire [(n)*C_M_AXI_MEM_ID_WIDTH-1:0]         m_axi_mem_bid_bus;

`define AXI_MEM_BUS_ARGS \
    .m_axi_mem_awvalid_bus(m_axi_mem_awvalid_bus), \
    .m_axi_mem_awready_bus(m_axi_mem_awready_bus), \
    .m_axi_mem_awaddr_bus(m_axi_mem_awaddr_bus), \
    .m_axi_mem_awid_bus(m_axi_mem_awid_bus), \
    .m_axi_mem_awlen_bus(m_axi_mem_awlen_bus), \
    .m_axi_mem_wvalid_bus(m_axi_mem_wvalid_bus), \
    .m_axi_mem_wready_bus(m_axi_mem_wready_bus), \
    .m_axi_mem_wdata_bus(m_axi_mem_wdata_bus), \
    .m_axi_mem_wstrb_bus(m_axi_mem_wstrb_bus), \
    .m_axi_mem_wlast_bus(m_axi_mem_wlast_bus), \
    .m_axi_mem_arvalid_bus(m_axi_mem_arvalid_bus), \
    .m_axi_mem_arready_bus(m_axi_mem_arready_bus), \
    .m_axi_mem_araddr_bus(m_axi_mem_araddr_bus), \
    .m_axi_mem_arid_bus(m_axi_mem_arid_bus), \
    .m_axi_mem_arlen_bus(m_axi_mem_arlen_bus), \
    .m_axi_mem_rvalid_bus(m_axi_mem_rvalid_bus), \
    .m_axi_mem_rready_bus(m_axi_mem_rready_bus), \
    .m_axi_mem_rdata_bus(m_axi_mem_rdata_bus), \
    .m_axi_mem_rlast_bus(m_axi_mem_rlast_bus), \
    .m_axi_mem_rid_bus(m_axi_mem_rid_bus), \
    .m_axi_mem_rresp_bus(m_axi_mem_rresp_bus), \
    .m_axi_mem_bvalid_bus(m_axi_mem_bvalid_bus), \
    .m_axi_mem_bready_bus(m_axi_mem_bready_bus), \
    .m_axi_mem_bresp_bus(m_axi_mem_bresp_bus), \
    .m_axi_mem_bid_bus(m_axi_mem_bid_bus)

`include "VX_define.vh"

`endif // VORTEX_AFU_VH
