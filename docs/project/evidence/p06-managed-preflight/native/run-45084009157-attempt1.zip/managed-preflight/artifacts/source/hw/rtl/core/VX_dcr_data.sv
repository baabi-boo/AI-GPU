// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

module VX_dcr_data import VX_gpu_pkg::*; #(
    parameter `STRING INSTANCE_ID = ""
) (
    input wire              clk,
    input wire              reset,

    input wire [CORE_ID_WIDTH-1:0] core_id,

    // Inputs
    VX_dcr_bus_if.slave     dcr_bus_if,

    // DCR-triggered CSR read bypass (for MPM perf counter readback)
    VX_dcr_csr_if.master    dcr_csr_if,

    // DCR-triggered cache flush
    VX_dcr_flush_if.master  dcr_flush_if,
    output wire             flush_l1_only
);
    `UNUSED_SPARAM (INSTANCE_ID)

    // MPM perf-counter readback via DCR interface ////////////////////////////

    wire [7:0]  mpm_class      = dcr_bus_if.req_data.data[22 +: 8];
    wire [5:0]  mpm_tag_idx    = dcr_bus_if.req_data.data[16 +: 6];
    wire [15:0] mpm_target_cid = dcr_bus_if.req_data.data[0  +:16];

    wire [`VX_CSR_ADDR_BITS-1:0] mpm_csr_addr = mpm_tag_idx[5]
        ? (`VX_CSR_ADDR_BITS'(`VX_CSR_MPM_BASE_H) + `VX_CSR_ADDR_BITS'(mpm_tag_idx[4:0]))
        : (`VX_CSR_ADDR_BITS'(`VX_CSR_MPM_BASE)   + `VX_CSR_ADDR_BITS'(mpm_tag_idx[4:0]));

    // Latch a read request when it is for this core and addr == MPM_VALUE
    reg                         dcr_csr_pending_r;
    reg [`VX_CSR_ADDR_BITS-1:0] dcr_csr_addr_r;
    reg [7:0]                   dcr_csr_class_r;

    wire is_mpm_read = dcr_bus_if.req_valid
                    && ~dcr_bus_if.req_data.rw
                    && (dcr_bus_if.req_data.addr == `VX_DCR_BASE_MPM_VALUE)
                    && (mpm_target_cid == 16'(core_id))
                    && ~dcr_csr_pending_r;

    always @(posedge clk) begin
        if (reset) begin
            dcr_csr_pending_r <= 1'b0;
            dcr_csr_addr_r    <= '0;
            dcr_csr_class_r   <= '0;
        end else if (is_mpm_read) begin
            dcr_csr_pending_r <= 1'b1;
            dcr_csr_addr_r    <= mpm_csr_addr;
            dcr_csr_class_r   <= mpm_class;
        end else if (dcr_csr_if.ready) begin
            dcr_csr_pending_r <= 1'b0;
        end
    end

    assign dcr_csr_if.valid = dcr_csr_pending_r;
    assign dcr_csr_if.addr  = dcr_csr_addr_r;
    assign dcr_csr_if.mpm_class = dcr_csr_class_r;

    wire dcr_csr_if_fire = dcr_csr_if.valid && dcr_csr_if.ready;

    // Cache flush via DCR interface /////////////////////////////////////////

    // A flush starts on a DCR write to CACHE_FLUSH, which reaches every core,
    // and this core's flush read is answered once its flush has completed. The
    // DCR response bus has no back-pressure, so the command processor starts
    // all cores with one write and then reads them one at a time: the flushes
    // overlap and the responses never collide.
    reg flush_pending_r;  // flush running
    reg flush_complete_r; // flush finished, not yet reported
    reg flush_read_r;     // flush read waiting for completion
    reg flush_l1_only_r;  // the last-level cache keeps its lines

    wire is_flush_req   = dcr_bus_if.req_valid
                       && (dcr_bus_if.req_data.addr == `VX_DCR_BASE_CACHE_FLUSH);
    wire is_flush_write = is_flush_req && dcr_bus_if.req_data.rw;
    wire is_flush_read  = is_flush_req && ~dcr_bus_if.req_data.rw
                       && (mpm_target_cid == 16'(core_id));

    wire flush_done  = flush_pending_r && dcr_flush_if.done;
    wire flush_start = ~flush_pending_r && is_flush_write;
    wire flush_rsp   = flush_read_r && (flush_complete_r || flush_done);

    always @(posedge clk) begin
        if (reset) begin
            flush_pending_r  <= 1'b0;
            flush_complete_r <= 1'b0;
            flush_read_r     <= 1'b0;
            flush_l1_only_r  <= 1'b0;
        end else begin
            flush_pending_r  <= flush_start || (flush_pending_r && ~flush_done);
            // a write opens a new flush, so an older completion cannot answer it
            flush_complete_r <= ~is_flush_write && ~flush_rsp && (flush_complete_r || flush_done);
            flush_read_r     <= ~flush_rsp && (flush_read_r || is_flush_read);
            if (flush_start) begin
                flush_l1_only_r <= (dcr_bus_if.req_data.data & VX_DCR_DATA_WIDTH'(`VX_CACHE_FLUSH_L1_ONLY)) != 0;
            end
        end
    end

    assign dcr_flush_if.req = flush_pending_r;
    assign flush_l1_only    = flush_l1_only_r;

    // Return CSR data or flush-done on DCR response bus
    // Use intermediate registers — Vivado (Synth 8-453) forbids procedural
    // assignment to interface net signals; drive them with continuous assigns.
    reg         rsp_valid_r;
    dcr_rsp_t   rsp_data_r;

    always @(posedge clk) begin
        if (reset) begin
            rsp_valid_r <= 1'b0;
            rsp_data_r  <= '0;
        end else begin
            rsp_valid_r <= dcr_csr_if_fire || flush_rsp;
            if (dcr_csr_if_fire) begin
                rsp_data_r <= dcr_csr_if.value;
            end else if (flush_rsp) begin
                rsp_data_r <= '0;
            end
        end
    end

    assign dcr_bus_if.rsp_valid = rsp_valid_r;
    assign dcr_bus_if.rsp_data  = rsp_data_r;

    // the requester issues one read at a time, so the two answers never meet
    `RUNTIME_ASSERT (~(dcr_csr_if_fire && flush_rsp), ("%t: %s CSR read and flush answered in the same cycle", $time, INSTANCE_ID))
    // a new flush starts only after every core reported the previous one
    `RUNTIME_ASSERT (~(is_flush_write && flush_pending_r), ("%t: %s flush started while one is running", $time, INSTANCE_ID))
    `RUNTIME_ASSERT (~(is_flush_read && ~flush_pending_r && ~flush_complete_r), ("%t: %s flush read with no flush started", $time, INSTANCE_ID))

`ifdef DBG_TRACE_PIPELINE
    always @(posedge clk) begin
        if (dcr_bus_if.req_valid && dcr_bus_if.req_data.rw) begin
            `TRACE(2, ("%t: %s: state=", $time, INSTANCE_ID))
            VX_trace_pkg::trace_base_dcr(1, dcr_bus_if.req_data.addr);
            `TRACE(2, (", rw=%b, data=0x%h\n", dcr_bus_if.req_data.rw, dcr_bus_if.req_data.data))
        end
    end
`endif

endmodule
