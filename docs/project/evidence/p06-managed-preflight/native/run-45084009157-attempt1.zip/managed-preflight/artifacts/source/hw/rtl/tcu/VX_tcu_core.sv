// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

module VX_tcu_core import VX_gpu_pkg::*, VX_tcu_pkg::*; #(
    parameter `STRING INSTANCE_ID = ""
) (
    `SCOPE_IO_DECL

    input wire          clk,
    input wire          reset,

`ifdef VX_CFG_TCU_WGMMA_ENABLE
    input wire [TCU_WG_A_DATA_SIZE-1:0][`VX_CFG_XLEN-1:0] tbuf_rs1_data,
    input wire [TCU_WG_RS2_WIDTH-1:0][`VX_CFG_XLEN-1:0] tbuf_rs2_data,
    input wire          tbuf_ready,
`endif

    // Metadata write port from the block's VX_tcu_agu.
`ifdef TCU_META_ENABLE
    input wire                     ext_meta_wr_en,
    input wire [NW_WIDTH-1:0]      ext_meta_wr_wid,
    input wire [4:0]               ext_meta_wr_idx,
    input wire [TCU_BLOCK_CAP-1:0] ext_meta_wr_mask,
    input wire [TCU_BLOCK_CAP-1:0][31:0] ext_meta_wr_data,
`endif

    // Inputs
    VX_execute_if.slave execute_if,

    // Outputs
    VX_result_if.master result_if
);

`ifdef SCOPE
    `SCOPE_IO_SWITCH (1);
    `SCOPE_IO_UNUSED (0)
`endif
    `UNUSED_SPARAM (INSTANCE_ID);

    // FEDP dot-product width in 32-bit words (doubles under FEDP2K).
    localparam FEDP_K = TCU_WG_FEDP_K;

    // Total FEDP latency of the configured TCU type; each FEDP variant
    // asserts it against its internal stage structure.
    localparam FEDP_LATENCY = `VX_CFG_TCU_LATENCY;

    localparam PIPE_LATENCY = FEDP_LATENCY + 1;
    localparam MDATA_QUEUE_DEPTH = 1 << $clog2(PIPE_LATENCY);

    localparam LG_A_BS    = $clog2(TCU_A_BLOCK_SIZE);
    localparam LG_B_BS    = $clog2(TCU_B_BLOCK_SIZE);
    localparam OFF_W      = $clog2(TCU_BLOCK_CAP);
`ifdef VX_CFG_TCU_WGMMA_ENABLE
    localparam LG_WG_B_BS = $clog2(TCU_WG_B_BLOCK_SIZE);
    localparam WG_B_OFF_W = $clog2(TCU_WG_RS2_WIDTH);
`endif

`ifdef VX_CFG_TCU_SPARSE_ENABLE
    localparam LG_B_BS_SP = $clog2(TCU_B_BLOCK_SIZE_SP);
    wire is_sparse = (execute_if.data.op_type == INST_TCU_WMMA_SP)
              `ifdef VX_CFG_TCU_WGMMA_ENABLE
                 || (execute_if.data.op_type == INST_TCU_WGMMA_SP)
              `endif
                 ;
`endif

`ifdef VX_CFG_TCU_MX_ENABLE
`ifdef VX_CFG_TCU_SPARSE_ENABLE
    wire mx_is_sparse = is_sparse;
`else
    wire mx_is_sparse = 1'b0;
`endif
    localparam FEDP_SF = TCU_MX_MAX_SF;
`else
    localparam FEDP_SF = 1;
    `UNUSED_PARAM (FEDP_SF)
`endif

    // The FEDP array holds TC_M x TC_N / PE_RATIO dot products, PE_M x PE_N.
    // A micro-op occupies it for PE_RATIO cycles, one output slice per cycle:
    // column slices first, so a PE keeps its A row while PE_RATIO <= TC_N.
    localparam PE_RATIO   = `VX_CFG_TCU_PE_RATIO;
    localparam PE_RATIO_N = `MIN(PE_RATIO, TCU_TC_N);
    localparam PE_RATIO_M = PE_RATIO / PE_RATIO_N;
    localparam PE_M       = TCU_TC_M / PE_RATIO_M;
    localparam PE_N       = TCU_TC_N / PE_RATIO_N;
    localparam SLICE_W    = `LOG2UP(PE_RATIO);
    localparam SLICE_M_W  = `LOG2UP(PE_RATIO_M);
    localparam SLICE_N_W  = `LOG2UP(PE_RATIO_N);
    localparam ROW_W      = `LOG2UP(TCU_TC_M);
    localparam COL_W      = `LOG2UP(TCU_TC_N);

    `STATIC_ASSERT (`IS_POW2(PE_RATIO) && `IS_DIVISBLE(TCU_TC_M * TCU_TC_N, PE_RATIO),
        ("invalid parameter: VX_CFG_TCU_PE_RATIO=%0d must be a power of two that divides TC_M x TC_N = %0d", PE_RATIO, TCU_TC_M * TCU_TC_N))

    // the output slice entering the array this cycle
    wire [SLICE_W-1:0] slice_idx;
    wire array_issue;
    `UNUSED_VAR (array_issue)
    wire [SLICE_M_W-1:0] slice_m = SLICE_M_W'(32'(slice_idx) / PE_RATIO_N);
    wire [SLICE_N_W-1:0] slice_n = SLICE_N_W'(32'(slice_idx) % PE_RATIO_N);

    // -----------------------------------------------------------------------
    // WGMMA / WMMA abstraction layer
    // -----------------------------------------------------------------------
    // All WGMMA-vs-WMMA runtime differences are resolved here behind a
    // common interface.  Downstream code uses only these wires and never
    // references tbuf_* or is_wgmma directly.

    wire [TCU_WG_A_DATA_SIZE-1:0][`VX_CFG_XLEN-1:0] rs1_data;
`ifdef VX_CFG_TCU_WGMMA_ENABLE
    wire [TCU_WG_RS2_WIDTH-1:0][`VX_CFG_XLEN-1:0] rs2_data;
`else
    wire [TCU_BLOCK_CAP-1:0][`VX_CFG_XLEN-1:0] rs2_data;
`endif
    wire exe_ready_extra; // additional ready gating (tbuf_ready)
`ifdef VX_CFG_TCU_SPARSE_ENABLE
    wire [TCU_MAX_META_BLOCK_WIDTH-1:0] wmma_sp_meta;
`endif

`ifdef VX_CFG_TCU_WGMMA_ENABLE
    wire is_wgmma = (execute_if.data.op_type == INST_TCU_WGMMA)
              `ifdef VX_CFG_TCU_SPARSE_ENABLE
                 || (execute_if.data.op_type == INST_TCU_WGMMA_SP)
              `endif
                 ;
    wire wg_a_smem = execute_if.data.op_args.tcu.a_from_smem;

    // A/B operand mux: tile buffer (smem) or register file. The
    // RF-side rs2_data is NUM_THREADS lanes wide; the WGMMA bbuf can be
    // wider (TCU_WG_RS2_WIDTH lanes). Pad/truncate to the wgmma width on
    // the false branch so both arms match TCU_WG_RS2_WIDTH * XLEN bits.
    localparam WG_RS1_BITS = TCU_WG_A_DATA_SIZE * `VX_CFG_XLEN;
    localparam WG_RS2_BITS = TCU_WG_RS2_WIDTH * `VX_CFG_XLEN;
    wire [WG_RS1_BITS-1:0] rs1_data_rf = WG_RS1_BITS'(execute_if.data.rs1_data);
    wire [WG_RS2_BITS-1:0] rs2_data_rf = WG_RS2_BITS'(execute_if.data.rs2_data);
    assign rs1_data = (is_wgmma && wg_a_smem) ? tbuf_rs1_data : rs1_data_rf;
    assign rs2_data = is_wgmma ? tbuf_rs2_data : rs2_data_rf;

  `ifdef VX_CFG_TCU_SPARSE_ENABLE
    // Sparse metadata lives in VX_tcu_sp_meta SRAM, preloaded via TCU_LD.
    wire [TCU_MAX_META_BLOCK_WIDTH-1:0] vld_meta_block = wmma_sp_meta;
  `endif

    assign exe_ready_extra = ~is_wgmma || tbuf_ready;
`else
    assign rs1_data = execute_if.data.rs1_data;
    assign rs2_data = execute_if.data.rs2_data;
  `ifdef VX_CFG_TCU_SPARSE_ENABLE
    wire [TCU_MAX_META_BLOCK_WIDTH-1:0] vld_meta_block = wmma_sp_meta;
  `endif
    assign exe_ready_extra = 1'b1;
`endif

    wire [3:0] step_m = execute_if.data.op_args.tcu.step_m;
    wire [3:0] step_n = execute_if.data.op_args.tcu.step_n;
    wire [3:0] step_k = execute_if.data.op_args.tcu.step_k;

    wire [4:0] fmt_s = execute_if.data.op_args.tcu.fmt_s;
    wire [4:0] fmt_d = execute_if.data.op_args.tcu.fmt_d;

    wire execute_fire = execute_if.valid && execute_if.ready;
`ifdef VX_CFG_TCU_WGMMA_ENABLE
    wire is_wgmma_setup = is_wgmma && !execute_if.data.header.wb;
`else
    wire is_wgmma_setup = 1'b0;
`endif
    wire setup_enqueue = execute_fire && is_wgmma_setup;
    wire fedp_enqueue  = execute_fire && !is_wgmma_setup;

    // The accumulator is fp32 (int32 for integer inputs); no other fmt_d exists.
    `RUNTIME_ASSERT (~fedp_enqueue || (fmt_d == (tcu_fmt_is_int(fmt_s) ? TCU_FMT_WIDTH'(TCU_I32_ID) : TCU_FMT_WIDTH'(TCU_FP32_ID))),
        ("%t: *** %s unsupported TCU output format: fmt_s=%0d, fmt_d=%0d (fp32 only)", $time, INSTANCE_ID, fmt_s, fmt_d))

    // -----------------------------------------------------------------------
    // Sparse metadata: VX_tcu_sp_meta (for WMMA_SP) + optional tile-buffer mux
    // -----------------------------------------------------------------------

    tcu_header_t mdata_queue_in;
    always_comb begin
        mdata_queue_in = execute_if.data.header;
    end

    `UNUSED_VAR ({step_m, step_n, step_k, fmt_s, fmt_d, execute_if.data});

`ifdef VX_TCU_LD_TRACE
`ifdef VX_CFG_TCU_SPARSE_ENABLE
    // META_RD trace: logs vld_meta_block at FEDP consume time.
    // Format: META_RD,wid,step_m,step_k,wg_bank,word_lo32
    wire trc_is_sp = (execute_if.data.op_type == INST_OP_BITS'(INST_TCU_WMMA_SP))
        `ifdef VX_CFG_TCU_WGMMA_ENABLE
                  || (execute_if.data.op_type == INST_OP_BITS'(INST_TCU_WGMMA_SP))
        `endif
                  ;
    wire [3:0] trc_wg_bank = ((TCU_K_STEPS > 2) ? (step_m << 1) : step_m) | step_k;
    always @(posedge clk) begin
        if (execute_fire && trc_is_sp) begin
            $write("META_RD,%0d,%0d,%0d,%0d,0x%08h\n",
                execute_if.data.header.wid, step_m, step_k, trc_wg_bank,
                vld_meta_block[31:0]);
        end
    end
`endif
`endif

    // -----------------------------------------------------------------------
    // Pipeline control
    // -----------------------------------------------------------------------
    // The FEDP array free-runs (no freeze enable): admission reserves a slot
    // in the result landing queue, so a completing result always has a place
    // to land and no per-register enable network spans the grid.

    // Landing capacity matches the header FIFO: credits bound the results
    // outstanding, so both queues share one occupancy invariant.
    localparam LANDQ_SIZE = MDATA_QUEUE_DEPTH;

    wire mdata_queue_full;

    wire result_fire = result_if.valid && result_if.ready;

    reg setup_valid_r;
    tcu_header_t setup_header_r;
    tcu_header_t mdata_queue_out;

    wire setup_result_fire = setup_valid_r && result_if.ready;
    // A non-setup result retires whenever the consumer takes one, whether it
    // comes straight off the array (fedp_done) or from the landing queue —
    // the header queue must pop in lockstep with either source.
    wire fedp_result_fire  = result_fire && !setup_valid_r;

    always @(posedge clk) begin
        if (reset) begin
            setup_valid_r <= 1'b0;
        end else begin
            if (setup_result_fire) begin
                setup_valid_r <= 1'b0;
            end
            if (setup_enqueue) begin
                setup_valid_r <= 1'b1;
                setup_header_r <= execute_if.data.header;
            end
        end
    end

    reg [PIPE_LATENCY-1:0] fedp_delay_pipe;
    always @(posedge clk) begin
        if (reset) begin
            fedp_delay_pipe <= '0;
        end else begin
            fedp_delay_pipe <= {fedp_enqueue, fedp_delay_pipe[PIPE_LATENCY-1:1]};
        end
    end

    wire fedp_done = fedp_delay_pipe[0];

    wire landq_credits_full;
    VX_pending_size #(
        .SIZE (LANDQ_SIZE)
    ) landq_credits (
        .clk   (clk),
        .reset (reset),
        .incr  (execute_fire),
        .decr  (result_fire),
        `UNUSED_PIN (empty),
        `UNUSED_PIN (alm_empty),
        .full  (landq_credits_full),
        `UNUSED_PIN (alm_full),
        `UNUSED_PIN (size)
    );

    // Admission stalls while a completed result waits on the consumer: this
    // keeps the landing queue shallow so a chained MMA never sees queueing
    // delay behind other warps' results. The credit bound stays as the hard
    // overflow guarantee for the free-running array.
    // A setup uop needs no FEDP slot but must not overwrite a setup result
    // still waiting on the consumer.
    wire admit_ready = ~mdata_queue_full && ~landq_credits_full
                    && (~fedp_done || result_if.ready)
                    && exe_ready_extra;

    wire setup_ready = ~is_wgmma_setup || ~setup_valid_r || result_if.ready;

    wire mdata_push = fedp_enqueue;

    VX_fifo_queue #(
        .DATAW ($bits(tcu_header_t)),
        .DEPTH (MDATA_QUEUE_DEPTH),
        .OUT_REG (1)
    ) mdata_queue (
        .clk    (clk),
        .reset  (reset),
        .push   (mdata_push),
        .pop    (fedp_result_fire),
        .data_in(mdata_queue_in),
        .data_out(mdata_queue_out),
        `UNUSED_PIN(empty),
        `UNUSED_PIN(alm_empty),
        .full   (mdata_queue_full),
        `UNUSED_PIN(alm_full),
        `UNUSED_PIN(size)
    );

    assign result_if.data.header = setup_valid_r ? setup_header_r : mdata_queue_out;

    // -----------------------------------------------------------------------
    // Operand offset computation
    // -----------------------------------------------------------------------

    wire [OFF_W-1:0] a_off = (OFF_W'(step_m) & OFF_W'(TCU_A_SUB_BLOCKS-1)) << LG_A_BS;
    wire [OFF_W-1:0] b_off_wm;
`ifdef VX_CFG_TCU_SPARSE_ENABLE
    assign b_off_wm = is_sparse
        ? (OFF_W'(step_n) & OFF_W'(TCU_B_SUB_BLOCKS_SP-1)) << LG_B_BS_SP
        : (OFF_W'(step_n) & OFF_W'(TCU_B_SUB_BLOCKS-1)) << LG_B_BS;
`else
    assign b_off_wm = (OFF_W'(step_n) & OFF_W'(TCU_B_SUB_BLOCKS-1)) << LG_B_BS;
`endif
`ifdef VX_CFG_TCU_WGMMA_ENABLE
    wire [WG_B_OFF_W-1:0] b_off_wg =
        (WG_B_OFF_W'(step_n) & WG_B_OFF_W'(TCU_WG_B_SUB_BLOCKS-1)) << LG_WG_B_BS;
`endif

`ifdef VX_CFG_TCU_MX_ENABLE
    wire [TCU_BLOCK_CAP-1:0][31:0] mx_meta_a;
    wire [TCU_BLOCK_CAP-1:0][31:0] mx_meta_b;
`endif

`ifdef TCU_META_ENABLE
    // a TCU block only executes one residue class of warps modulo NUM_TCU_BLOCKS
    VX_tcu_meta #(
        .INSTANCE_ID (INSTANCE_ID),
        .WID_STRIDE  (`VX_CFG_NUM_TCU_BLOCKS)
    ) tcu_meta (
        .clk    (clk),
        .reset  (reset),
        .wr_en  (ext_meta_wr_en),
        .wr_wid (ext_meta_wr_wid),
        .wr_idx (ext_meta_wr_idx),
        .wr_mask(ext_meta_wr_mask),
        .wr_data(ext_meta_wr_data),
        .rd_wid (execute_if.data.header.wid)
    `ifdef VX_CFG_TCU_SPARSE_ENABLE
        , .step_m   (step_m)
        , .step_k   (step_k)
        , .vld_block(wmma_sp_meta)
    `endif
    `ifdef VX_CFG_TCU_MX_ENABLE
        , .meta_a   (mx_meta_a)
        , .meta_b   (mx_meta_b)
    `endif
    );
`endif

`ifdef VX_CFG_TCU_MX_ENABLE

`ifdef VX_CFG_TCU_WGMMA_ENABLE
    localparam MX_MAX_MN = `MAX(`MAX(TCU_TILE_M, TCU_TILE_N), `MAX(TCU_WG_TILE_M, TCU_WG_TILE_N));
`else
    localparam MX_MAX_MN = `MAX(TCU_TILE_M, TCU_TILE_N);
`endif
    localparam MX_IDX_W = $clog2(MX_MAX_MN);
    localparam MX_TILE_K_MAX = `MAX(TCU_TILE_K, TCU_WG_K_STEPS * TCU_WG_FEDP_K);
    localparam MX_K_IDX_W = `LOG2UP(MX_TILE_K_MAX * TCU_MAX_ELT_RATIO);
    localparam MX_SCALE_BLOCKS_MAX = mx_scale_blocks_k_words(TCU_NVFP4_ID, MX_TILE_K_MAX);
    localparam MX_SCALE_IDX_W = $clog2(MX_MAX_MN * MX_SCALE_BLOCKS_MAX);

    function automatic [7:0] mx_scale_at(
        input logic [TCU_BLOCK_CAP-1:0][31:0] meta,
        input logic [4:0] fmt,
        input logic [MX_SCALE_IDX_W-1:0] scale_blocks_k,
        input logic [MX_IDX_W-1:0] mn_idx,
        input logic [MX_K_IDX_W-1:0] k_base_idx
    );
        logic [MX_SCALE_IDX_W-1:0] scale_k;
        logic [MX_SCALE_IDX_W-1:0] scale_idx;
        logic [`LOG2UP(TCU_BLOCK_CAP)-1:0] word_idx;
        logic [1:0] byte_idx;
        begin
            scale_k = MX_SCALE_IDX_W'(k_base_idx / mx_scale_block_size(fmt));
            scale_idx = MX_SCALE_IDX_W'(mn_idx) * scale_blocks_k + scale_k;
            word_idx = `LOG2UP(TCU_BLOCK_CAP)'(scale_idx >> 2);
            byte_idx = scale_idx[1:0];
            mx_scale_at = meta[word_idx][byte_idx * 8 +: 8];
        end
    endfunction

    wire [TCU_TC_M-1:0][FEDP_SF-1:0][7:0] mx_sf_a;
    wire [TCU_TC_N-1:0][FEDP_SF-1:0][7:0] mx_sf_b;
    wire [3:0] mx_elems_per_word = 4'(32 / tcu_fmt_width(fmt_s));
    wire [MX_SCALE_IDX_W-1:0] mx_scale_blocks_k_eff =
    `ifdef VX_CFG_TCU_WGMMA_ENABLE
        is_wgmma ? MX_SCALE_IDX_W'(mx_scale_blocks_k_words(fmt_s, TCU_WG_K_STEPS * TCU_WG_FEDP_K))
                 : MX_SCALE_IDX_W'(mx_scale_blocks_k_words(fmt_s, TCU_TILE_K));
    `else
        MX_SCALE_IDX_W'(mx_scale_blocks_k_words(fmt_s, TCU_TILE_K));
    `endif
    wire [MX_K_IDX_W:0] mx_uop_k_words =
    `ifdef VX_CFG_TCU_WGMMA_ENABLE
        is_wgmma ? (MX_K_IDX_W+1)'(TCU_WG_FEDP_K) : (MX_K_IDX_W+1)'(TCU_TC_K);
    `else
        (MX_K_IDX_W+1)'(TCU_TC_K);
    `endif
    wire [MX_K_IDX_W:0] mx_uop_k_elems = (MX_K_IDX_W+1)'(
        mx_uop_k_words * (MX_K_IDX_W+1)'(mx_elems_per_word)
        * (MX_K_IDX_W+1)'(mx_is_sparse ? 2 : 1));
    wire [MX_K_IDX_W:0] mx_fedp_k_elems = (MX_K_IDX_W+1)'(
        (MX_K_IDX_W+1)'(FEDP_K) * (MX_K_IDX_W+1)'(mx_elems_per_word)
        * (MX_K_IDX_W+1)'(mx_is_sparse ? 2 : 1));
    wire [MX_K_IDX_W-1:0] mx_k_base_idx = MX_K_IDX_W'(step_k * mx_uop_k_elems);

    for (genvar i = 0; i < TCU_TC_M; ++i) begin : g_mx_sf_a_i
        wire [MX_IDX_W-1:0] mx_a_idx = MX_IDX_W'(step_m) * MX_IDX_W'(TCU_TC_M) + MX_IDX_W'(i);
        for (genvar s = 0; s < FEDP_SF; ++s) begin : g_s
            wire [MX_K_IDX_W-1:0] mx_k_idx = mx_k_base_idx + MX_K_IDX_W'((s * mx_fedp_k_elems) / FEDP_SF);
            assign mx_sf_a[i][s] = mx_scale_at(mx_meta_a, fmt_s, mx_scale_blocks_k_eff, mx_a_idx, mx_k_idx);
        end
    end

    for (genvar j = 0; j < TCU_TC_N; ++j) begin : g_mx_sf_b_j
        wire [MX_IDX_W-1:0] mx_b_idx = MX_IDX_W'(step_n) * MX_IDX_W'(TCU_TC_N) + MX_IDX_W'(j);
        for (genvar s = 0; s < FEDP_SF; ++s) begin : g_s
            wire [MX_K_IDX_W-1:0] mx_k_idx = mx_k_base_idx + MX_K_IDX_W'((s * mx_fedp_k_elems) / FEDP_SF);
            assign mx_sf_b[j][s] = mx_scale_at(mx_meta_b, fmt_s, mx_scale_blocks_k_eff, mx_b_idx, mx_k_idx);
        end
    end
`endif

    // -----------------------------------------------------------------------
    // FEDP grid: PE_M × PE_N compute elements
    // -----------------------------------------------------------------------

    wire [TCU_TC_M-1:0][TCU_TC_N-1:0][31:0] d_val;
    wire [PE_M-1:0][PE_N-1:0][31:0] d_pe;

    for (genvar i = 0; i < PE_M; ++i) begin : g_i
        for (genvar j = 0; j < PE_N; ++j) begin : g_j
            // the output element (row_i, col_j) this PE computes this cycle
            wire [ROW_W-1:0] row_i = ROW_W'(i) + ROW_W'(PE_M) * ROW_W'(slice_m);
            wire [COL_W-1:0] col_j = COL_W'(j) + COL_W'(PE_N) * COL_W'(slice_n);
            `UNUSED_VAR ({row_i, col_j})
        `ifdef VX_CFG_TCU_SPARSE_ENABLE
            wire [FEDP_K-1:0][31:0] a_row, b_col, b_col_dense;
            wire [TCU_TC_K-1:0][31:0] b_col_sparse, b_col_1, b_col_2;
        `else
            wire [FEDP_K-1:0][31:0] a_row, b_col;
        `endif
        `ifdef VX_CFG_TCU_MX_ENABLE
            wire [FEDP_SF-1:0][7:0] sf_a = mx_sf_a[row_i];
            wire [FEDP_SF-1:0][7:0] sf_b = mx_sf_b[col_j];
        `endif
            for (genvar k_idx = 0; k_idx < FEDP_K; ++k_idx) begin : g_slice_assign
            `ifdef VX_CFG_TCU_WGMMA_ENABLE
                wire [31:0] wg_b_idx = 32'(col_j) * TCU_WG_FEDP_K + k_idx;
            `endif
                if (k_idx < TCU_TC_K) begin : g_lo
                `ifdef VX_CFG_TCU_WGMMA_ENABLE
                    wire [31:0] a_wgmma_smem = 32'(rs1_data[row_i * TCU_WG_FEDP_K + k_idx]);
                    wire [31:0] a_wgmma_reg  = 32'(execute_if.data.rs1_data[row_i * TCU_TC_K + k_idx]);
                    assign a_row[k_idx] = is_wgmma
                        ? (wg_a_smem ? a_wgmma_smem : a_wgmma_reg)
                        : 32'(execute_if.data.rs1_data[a_off + row_i * TCU_TC_K + k_idx]);
                `else
                    assign a_row[k_idx] = 32'(rs1_data[a_off + row_i * TCU_TC_K + k_idx]);
                `endif
                `ifdef VX_CFG_TCU_SPARSE_ENABLE
                    assign b_col_dense[k_idx] =
                    `ifdef VX_CFG_TCU_WGMMA_ENABLE
                        is_wgmma ? 32'(rs2_data[int'(b_off_wg) + wg_b_idx]) :
                    `endif
                        32'(rs2_data[b_off_wm + col_j * TCU_TC_K + k_idx]);
                `else
                    assign b_col[k_idx] =
                    `ifdef VX_CFG_TCU_WGMMA_ENABLE
                        is_wgmma ? 32'(rs2_data[int'(b_off_wg) + wg_b_idx]) :
                    `endif
                        32'(rs2_data[b_off_wm + col_j * TCU_TC_K + k_idx]);
                `endif
                end else begin : g_hi
                `ifdef VX_CFG_TCU_WGMMA_ENABLE
                    wire [31:0] a_wgmma_smem = 32'(rs1_data[row_i * TCU_WG_FEDP_K + k_idx]);
                    wire [31:0] a_wgmma_reg =
                    `ifdef VX_CFG_TCU_FEDP2K
                        `ifdef VX_CFG_TCU_SPARSE_ENABLE
                            is_sparse ? 32'b0 :
                        `endif
                        32'(execute_if.data.rs2_data[row_i * TCU_TC_K + (k_idx - TCU_TC_K)]);
                    `else
                        32'b0;
                    `endif
                    assign a_row[k_idx] = (is_wgmma
                        `ifdef VX_CFG_TCU_SPARSE_ENABLE
                            && !is_sparse
                        `endif
                        ) ? (wg_a_smem ? a_wgmma_smem : a_wgmma_reg) : 32'b0;
                `else
                    assign a_row[k_idx] = 32'b0;
                `endif
                `ifdef VX_CFG_TCU_SPARSE_ENABLE
                    assign b_col_dense[k_idx] =
                    `ifdef VX_CFG_TCU_WGMMA_ENABLE
                        (is_wgmma && !is_sparse) ? 32'(rs2_data[int'(b_off_wg) + wg_b_idx]) :
                    `endif
                        32'b0;
                `else
                    assign b_col[k_idx] =
                    `ifdef VX_CFG_TCU_WGMMA_ENABLE
                        is_wgmma ? 32'(rs2_data[int'(b_off_wg) + wg_b_idx]) :
                    `endif
                        32'b0;
                `endif
                end
            end

        `ifdef VX_CFG_TCU_SPARSE_ENABLE
            for (genvar k_idx = 0; k_idx < TCU_TC_K; ++k_idx) begin : g_sparse_slice_assign
                wire [COL_W-1:0] col_j_sp = SYM_SPARSE ? (col_j % COL_W'(`MAX(TCU_TC_N / 2, 1))) : col_j;
                // rs2_data sparse-pair layout differs by op:
                //   WGMMA_SP: source is tbuf (shared mem), K-major, all columns →
                //     idx = k_idx*(TC_N*2) + j*2 + lane
                //   WMMA_SP : source is the register file, J-major, folded to
                //     column pairs when SYM_SPARSE →
                //     idx = col_j_sp*(TC_K*2) + k_idx*2 + lane
                // The two layouts are incompatible; separate formulas are required.
            `ifdef VX_CFG_TCU_WGMMA_ENABLE
                wire [31:0] b_col_1_wg = 32'(rs2_data[k_idx * TCU_TC_N * 2 + col_j * 2]);
                wire [31:0] b_col_2_wg = 32'(rs2_data[k_idx * TCU_TC_N * 2 + col_j * 2 + 1]);
                wire [31:0] b_col_1_wm = 32'(rs2_data[b_off_wm + col_j_sp * TCU_TC_K * 2 + k_idx * 2]);
                wire [31:0] b_col_2_wm = 32'(rs2_data[b_off_wm + col_j_sp * TCU_TC_K * 2 + k_idx * 2 + 1]);
                assign b_col_1[k_idx] = is_wgmma ? b_col_1_wg : b_col_1_wm;
                assign b_col_2[k_idx] = is_wgmma ? b_col_2_wg : b_col_2_wm;
            `else
                assign b_col_1[k_idx] = 32'(rs2_data[b_off_wm + col_j_sp * TCU_TC_K * 2 + k_idx * 2]);
                assign b_col_2[k_idx] = 32'(rs2_data[b_off_wm + col_j_sp * TCU_TC_K * 2 + k_idx * 2 + 1]);
            `endif
            end
        `endif

            wire [31:0] c_val = 32'(execute_if.data.rs3_data[row_i * TCU_TC_N + col_j]);

        `ifdef VX_CFG_TCU_SPARSE_ENABLE
            VX_tcu_sp_mux #(
                .INSTANCE_ID (INSTANCE_ID),
                .ROW_IDX     (i),
                .ROW_STRIDE  (PE_M),
                .ROW_SELS    (PE_RATIO_M)
            ) tcu_sp_mux (
                .row_sel   (slice_m),
                .fmt_s     (fmt_s),
                .b_col_in1 (b_col_1),
                .b_col_in2 (b_col_2),
                .vld_mask  (vld_meta_block),
                .b_col_out (b_col_sparse)
            );
            for (genvar k_idx = 0; k_idx < FEDP_K; ++k_idx) begin : g_sparse_b_select
                if (k_idx < TCU_TC_K) begin : g_lo
                    assign b_col[k_idx] = is_sparse ? b_col_sparse[k_idx] : b_col_dense[k_idx];
                end else begin : g_hi
                    assign b_col[k_idx] = is_sparse ? 32'b0 : b_col_dense[k_idx];
                end
            end

        `ifdef VX_TCU_LD_TRACE
            // GATHER trace: GATHER,wid,step_m,step_n,i,k,bword0,bword1,lo,hi,gathered
            // One line per (i, j, k_idx); emitted only for sparse ops.
            always @(posedge clk) begin
                if (array_issue && is_sparse) begin
                    for (int kk = 0; kk < TCU_TC_K; ++kk) begin
                        $write("GATHER,%0d,%0d,%0d,%0d,%0d,0x%08h,0x%08h,?,?,0x%08h\n",
                            execute_if.data.header.wid, step_m, step_n,
                            row_i, int'(col_j)*TCU_TC_K + kk,
                            b_col_1[kk], b_col_2[kk], b_col_sparse[kk]);
                    end
                end
            end
        `endif
        `endif

        // Dual-side sparse lane mask
        `ifdef VX_CFG_TCU_TYPE_TFR
            wire [TCU_MAX_INPUTS-1:0] vld_mask_r;
        `ifdef VX_CFG_TCU_DSM_ENABLE
            wire [TCU_MAX_INPUTS-1:0] vld_mask;
            VX_tcu_dsm #(
                .N (TCU_TC_K)
            ) dual_sparse_mask (
                .clk      (clk),
                .reset    (reset),
                .enable   (1'b1),
                .fmt_s    (fmt_s),
                .a_row    (a_row),
                .b_col    (b_col),
                .vld_mask (vld_mask)
            );
            VX_pipe_register #(
                .DATAW (TCU_MAX_INPUTS)
            ) pipe_vld_mask (
                .clk      (clk),
                .reset    (reset),
                .enable   (1'b1),
                .data_in  (vld_mask),
                .data_out (vld_mask_r)
            );
        `else
            assign vld_mask_r = '1;
        `endif
        `endif

            wire [4:0] fmt_s_r, fmt_d_r;
            wire [FEDP_K-1:0][31:0] a_row_r, b_col_r;
        `ifdef VX_CFG_TCU_MX_ENABLE
            wire [FEDP_SF-1:0][7:0] sf_a_r, sf_b_r;
        `endif
            wire [31:0] c_val_r;

        `ifdef VX_CFG_TCU_MX_ENABLE
            VX_pipe_register #(
                .DATAW (32 + 5 + 5 + FEDP_K * 32 + FEDP_K * 32 + 2 * FEDP_SF * 8)
            ) pipe_fedp (
                .clk      (clk),
                .reset    (reset),
                .enable   (1'b1),
                .data_in  ({c_val,   sf_b,   sf_a,   fmt_s,   fmt_d,   b_col,   a_row}),
                .data_out ({c_val_r, sf_b_r, sf_a_r, fmt_s_r, fmt_d_r, b_col_r, a_row_r})
            );
        `else
            VX_pipe_register #(
                .DATAW (32 + 5 + 5 + FEDP_K * 32 + FEDP_K * 32)
            ) pipe_fedp (
                .clk      (clk),
                .reset    (reset),
                .enable   (1'b1),
                .data_in  ({c_val,   fmt_s,   fmt_d,   b_col,   a_row}),
                .data_out ({c_val_r, fmt_s_r, fmt_d_r, b_col_r, a_row_r})
            );
        `endif

        `ifdef VX_CFG_TCU_TYPE_DPI
            VX_tcu_fedp_dpi #(
                .INSTANCE_ID (INSTANCE_ID),
                .LATENCY (FEDP_LATENCY),
                .N (FEDP_K),
                .SF (FEDP_SF)
            ) fedp (
                .clk   (clk),
                .reset (reset),
                .enable(1'b1),
                .fmt_s (fmt_s_r),
                .fmt_d (fmt_d_r),
                .a_row(a_row_r),
                .b_col(b_col_r),
            `ifdef VX_CFG_TCU_MX_ENABLE
                .sf_a  (sf_a_r),
                .sf_b  (sf_b_r),
            `endif
                .c_val (c_val_r),
                .d_val (d_pe[i][j])
            );
        `elsif VX_CFG_TCU_TYPE_BHF
            VX_tcu_fedp_bhf #(
                .INSTANCE_ID (INSTANCE_ID),
                .LATENCY (FEDP_LATENCY),
                .N (FEDP_K)
            ) fedp (
                .clk   (clk),
                .reset (reset),
                .enable(1'b1),
                .fmt_s (fmt_s_r),
                .fmt_d (fmt_d_r),
                .a_row(a_row_r),
                .b_col(b_col_r),
                .c_val (c_val_r),
                .d_val (d_pe[i][j])
            );
        `elsif VX_CFG_TCU_TYPE_FPNEW
            VX_tcu_fedp_fpnew #(
                .INSTANCE_ID (INSTANCE_ID),
                .LATENCY (FEDP_LATENCY),
                .N (FEDP_K)
            ) fedp (
                .clk   (clk),
                .reset (reset),
                .enable(1'b1),
                .fmt_s (fmt_s_r),
                .fmt_d (fmt_d_r),
                .a_row (a_row_r),
                .b_col (b_col_r),
                .c_val (c_val_r),
                .d_val (d_pe[i][j])
            );
        `elsif VX_CFG_TCU_TYPE_TFR
            VX_tcu_fedp_tfr #(
                .INSTANCE_ID (INSTANCE_ID),
                .LATENCY (FEDP_LATENCY),
                .N (FEDP_K),
                .SF (FEDP_SF),
                .USE_DSP (`VX_CFG_TCU_USE_DSP)
            ) fedp (
                .clk   (clk),
                .reset (reset),
                .enable(1'b1),
                .vld_mask(vld_mask_r),
                .fmt_s (fmt_s_r),
                .fmt_d (fmt_d_r),
                .a_row (a_row_r),
                .b_col (b_col_r),
            `ifdef VX_CFG_TCU_MX_ENABLE
                .sf_a  (sf_a_r),
                .sf_b  (sf_b_r),
            `endif
                .c_val (c_val_r),
                .d_val (d_pe[i][j])
            );
        `elsif VX_CFG_TCU_TYPE_DSP
            VX_tcu_fedp_dsp #(
                .INSTANCE_ID (INSTANCE_ID),
                .LATENCY (FEDP_LATENCY),
                .N (FEDP_K)
            ) fedp (
                .clk   (clk),
                .reset (reset),
                .enable(1'b1),
                .fmt_s (fmt_s_r),
                .fmt_d (fmt_d_r),
                .a_row(a_row_r),
                .b_col(b_col_r),
                .c_val (c_val_r),
                .d_val (d_pe[i][j])
            );
        `else
            VX_tcu_fedp_no_implementation_selected fedp ();
        `endif

        `ifdef DBG_TRACE_TCU
            always @(posedge clk) begin
                if (array_issue) begin
                    `TRACE(3, ("%t: %s FEDP-enq: wid=%0d, cta_id=%0d, i=%0d, j=%0d, m=%0d, n=%0d, a_row=", $time, INSTANCE_ID, execute_if.data.header.wid, execute_if.data.header.cta_id, row_i, col_j, step_m, step_n))
                    `TRACE_ARRAY1D(2, "0x%0h", a_row, FEDP_K)
                    `TRACE(3, (", b_col="));
                    `TRACE_ARRAY1D(2, "0x%0h", b_col, FEDP_K)
                    `TRACE(3, (", c_val=0x%0h (#%0d)\n", c_val, execute_if.data.header.uuid));
                end
                if (result_if.valid && result_if.ready) begin
                    for (int s = 0; s < PE_RATIO; ++s) begin
                        automatic int ri = i + PE_M * (s / PE_RATIO_N);
                        automatic int cj = j + PE_N * (s % PE_RATIO_N);
                        `TRACE(3, ("%t: %s FEDP-deq: wid=%0d, cta_id=%0d, i=%0d, j=%0d, d_val=0x%0h (#%0d)\n", $time, INSTANCE_ID, result_if.data.header.wid, result_if.data.header.cta_id, ri, cj, result_if.data.data[ri * TCU_TC_N + cj][31:0], result_if.data.header.uuid));
                    end
                end
            end
        `endif // DBG_TRACE_TCU
        end
    end

    // -----------------------------------------------------------------------
    // Output slices
    // -----------------------------------------------------------------------

    if (PE_RATIO > 1) begin : g_slices
        // A micro-op holds the execute interface while its slices enter the
        // array and fires with the last one, so its result completes with that
        // slice, PIPE_LATENCY after the fire, as an unsliced micro-op's does.
        // The earlier slices complete first and wait here; the next
        // micro-op's first slice completes a cycle after this one's result
        // retires or lands, so one register per slice suffices.
        reg [SLICE_W-1:0] slice_in_r, slice_out_r;
        reg [PIPE_LATENCY-1:0] slice_delay_pipe;
        reg [PE_RATIO-2:0][PE_M-1:0][PE_N-1:0][31:0] d_slices_r;
        wire slice_last;

        // A compute micro-op is taken with its last output slice. The tile
        // buffer's ready, the deepest input, meets the other terms last, as
        // without slices, so the slice term replaces one there: a full header
        // queue implies full landing credits, which also count a pending setup
        // result, and only a setup micro-op has no writeback.
        `RUNTIME_ASSERT (~mdata_queue_full || landq_credits_full,
            ("%t: %s: header queue full with landing credits left", $time, INSTANCE_ID))
        `RUNTIME_ASSERT (~execute_if.valid || execute_if.data.header.wb || is_wgmma_setup,
            ("%t: %s: a compute micro-op without a writeback", $time, INSTANCE_ID))
        `UNUSED_VAR (admit_ready)
        wire slice_blocked = landq_credits_full || (fedp_done && ~result_if.ready)
                          || (execute_if.data.header.wb && ~slice_last);
        assign execute_if.ready = ~slice_blocked && exe_ready_extra && setup_ready;
        wire slice_issue = execute_if.valid && ~is_wgmma_setup && ~landq_credits_full
                        && (~fedp_done || result_if.ready) && exe_ready_extra;
        wire slice_done  = slice_delay_pipe[0];

        always @(posedge clk) begin
            if (reset) begin
                slice_in_r       <= '0;
                slice_out_r      <= '0;
                slice_delay_pipe <= '0;
            end else begin
                if (slice_issue) begin
                    slice_in_r <= slice_in_r + SLICE_W'(1);
                end
                if (slice_done) begin
                    slice_out_r <= slice_out_r + SLICE_W'(1);
                end
                slice_delay_pipe <= {slice_issue, slice_delay_pipe[PIPE_LATENCY-1:1]};
            end
        end

        for (genvar s = 0; s < PE_RATIO; ++s) begin : g_slice
            localparam ROW_BASE = PE_M * (s / PE_RATIO_N);
            localparam COL_BASE = PE_N * (s % PE_RATIO_N);
            if (s < PE_RATIO - 1) begin : g_held
                always @(posedge clk) begin
                    if (slice_done && slice_out_r == SLICE_W'(s)) begin
                        d_slices_r[s] <= d_pe;
                    end
                end
            end
            for (genvar i = 0; i < PE_M; ++i) begin : g_i
                for (genvar j = 0; j < PE_N; ++j) begin : g_j
                    if (s < PE_RATIO - 1) begin : g_held
                        assign d_val[ROW_BASE + i][COL_BASE + j] = d_slices_r[s][i][j];
                    end else begin : g_live
                        assign d_val[ROW_BASE + i][COL_BASE + j] = d_pe[i][j];
                    end
                end
            end
        end

        assign slice_idx   = slice_in_r;
        if (PE_RATIO > 2) begin : g_last_flag
            // the last slice as a flag, set as the one before it enters
            reg slice_last_r;
            always @(posedge clk) begin
                if (reset) begin
                    slice_last_r <= 1'b0;
                end else if (slice_issue) begin
                    slice_last_r <= (slice_in_r == SLICE_W'(PE_RATIO - 2));
                end
            end
            assign slice_last = slice_last_r;
            `RUNTIME_ASSERT (slice_last_r == (slice_in_r == SLICE_W'(PE_RATIO - 1)),
                ("%t: %s: last-slice flag out of step with the slice counter", $time, INSTANCE_ID))
        end else begin : g_last_bit
            assign slice_last = slice_in_r[0];
        end
        assign array_issue = slice_issue;

        `RUNTIME_ASSERT (fedp_done == (slice_done && slice_out_r == SLICE_W'(PE_RATIO - 1)),
            ("%t: %s: output slices out of step with their micro-op: fedp_done=%b, slice_done=%b, slice=%0d", $time, INSTANCE_ID, fedp_done, slice_done, slice_out_r))

    end else begin : g_no_slices
        assign execute_if.ready = admit_ready && setup_ready;
        assign slice_idx   = '0;
        assign array_issue = fedp_enqueue;
        assign d_val       = d_pe;
    end

    // -----------------------------------------------------------------------
    // Result landing queue
    // -----------------------------------------------------------------------
    // A stalled consumer parks completing results here (a slot was reserved
    // at admission), so the FEDP grid never needs a backpressure enable. An
    // unblocked result bypasses the queue and retires with no added latency.

    localparam RESULT_DATAW = TCU_TC_M * TCU_TC_N * 32;

    wire [RESULT_DATAW-1:0] landq_data;
    wire landq_empty, landq_full;

    // A setup result occupying the interface must neither bypass into nor
    // pop the landing queue: its slot carries no FEDP payload.
    wire landq_bypass = landq_empty && result_if.ready && ~setup_valid_r;
    wire landq_push   = fedp_done && ~landq_bypass;
    wire landq_pop    = result_fire && ~landq_empty && ~setup_valid_r;

    VX_fifo_queue #(
        .DATAW (RESULT_DATAW),
        .DEPTH (LANDQ_SIZE),
        .OUT_REG (1),
        .LUTRAM (1)
    ) landing_queue (
        .clk    (clk),
        .reset  (reset),
        .push   (landq_push),
        .pop    (landq_pop),
        .data_in(d_val),
        .data_out(landq_data),
        .empty  (landq_empty),
        `UNUSED_PIN(alm_empty),
        .full   (landq_full),
        `UNUSED_PIN(alm_full),
        `UNUSED_PIN(size)
    );

    assign result_if.valid = setup_valid_r || fedp_done || ~landq_empty;

    wire [RESULT_DATAW-1:0] result_data = landq_empty ? RESULT_DATAW'(d_val) : landq_data;

    `RUNTIME_ASSERT (~(landq_push && landq_full), ("%t: %s: result landing queue overflow", $time, INSTANCE_ID))

    // NaN-box the fp32 results for XLEN=64: upper 32 bits must be all-1s per RVF spec.
    for (genvar e = 0; e < TCU_TC_M * TCU_TC_N; ++e) begin : g_result
        if (`VX_CFG_XLEN > 32) begin : g_nanbox
            assign result_if.data.data[e] = {32'hffffffff, result_data[e * 32 +: 32]};
        end else begin : g_passthrough
            assign result_if.data.data[e] = result_data[e * 32 +: 32];
        end
    end

endmodule
