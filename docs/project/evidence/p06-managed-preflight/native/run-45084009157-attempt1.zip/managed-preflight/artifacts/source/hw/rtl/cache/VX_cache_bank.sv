// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_cache_define.vh"

module VX_cache_bank import VX_gpu_pkg::*; #(
    parameter `STRING INSTANCE_ID= "",
    parameter BANK_ID           = 0,
    parameter BANK_HASH         = 0,        // hashed bank select (cache_bank_hash)
    parameter SET_HASH          = 0,        // hashed set index (cache_set_hash)
    parameter NUM_REQS          = 1,
    parameter CACHE_SIZE        = 1024,     // cache size in bytes
    parameter LINE_SIZE         = 16,       // line size in bytes
    parameter NUM_BANKS         = 1,
    parameter NUM_WAYS          = 1,
    parameter WORD_SIZE         = 4,        // word size in bytes
    parameter SECTOR_SIZE       = LINE_SIZE,// sector (fill/eviction granule); = LINE_SIZE => 1 sector
    parameter CRSQ_SIZE         = 0,        // extra core-response queue slots over minimum
    parameter MSHR_SIZE         = 1,        // miss reservation queue size
    parameter MRSQ_SIZE         = 1,        // memory response queue size (sized at wrapper)
    parameter MREQ_SIZE         = 0,        // memory request queue size (0 = derived minimum)
    parameter WRITE_ENABLE      = 1,
    parameter WRITEBACK         = 0,
    parameter DIRTY_BYTES       = 0,
    parameter LAZY_FETCH        = 0,        // write miss allocates without a fill; a load to a partial sector refetches
    parameter WRITE_AROUND      = 0,        // a write miss flagged no-allocate is sent to memory instead
    parameter REPL_POLICY       = `CS_REPL_FIFO,
    parameter TAG_WIDTH         = UUID_WIDTH + 1,
    parameter CORE_OUT_BUF      = 0,
    parameter MEM_OUT_BUF       = 0,
    parameter IS_LLC            = 0,        // last-level cache: AMOs commit locally here
    parameter AMO_ENABLE        = 0,        // synthesize atomic-op logic
    parameter LATENCY           = 2,        // pipeline depth; >2 defers the data array to break the tag->data path
    // Words per core response. Above 1, response word k is the line's word
    // whose select rides in the request tag at RSP_WSEL_OFFS + k * RSP_WSEL_STRIDE.
    parameter RSP_WORDS         = 1,
    parameter RSP_WSEL_OFFS     = 0,
    parameter RSP_WSEL_STRIDE   = 0,
    parameter MERGE_GROUP       = 0,        // read-merge group: the tag's low bits mark the merged ports (0: none)
    parameter MSHR_ADDR_WIDTH   = `LOG2UP(MSHR_SIZE),
    parameter MEM_TAG_WIDTH     = UUID_WIDTH + MSHR_ADDR_WIDTH,
    parameter REQ_SEL_WIDTH     = `UP(`CS_REQ_SEL_BITS),
    parameter WORD_SEL_WIDTH    = `UP(`CS_WORD_SEL_BITS)
) (
    input wire clk,
    input wire reset,

`ifdef PERF_ENABLE
    output wire perf_read_miss,
    output wire perf_write_miss,
    output wire perf_evictions,
    output wire perf_mshr_stall,
`endif

    // Core request
    input wire                          core_req_valid,
    input wire [`CS_LINE_ADDR_WIDTH-1:0] core_req_addr,
    input wire                          core_req_rw,
    input wire [WORD_SEL_WIDTH-1:0]     core_req_wsel,
    input wire [WORD_SIZE-1:0]          core_req_byteen,
    input wire [`CS_WORD_WIDTH-1:0]     core_req_data,
    input wire [TAG_WIDTH-1:0]          core_req_tag,
    input wire [REQ_SEL_WIDTH-1:0]      core_req_idx,
    input wire [`UP(MEM_ATTR_WIDTH)-1:0] core_req_attr,
    output wire                         core_req_ready,

    // Core response
    output wire                         core_rsp_valid,
    output wire [RSP_WORDS-1:0][`CS_WORD_WIDTH-1:0] core_rsp_data,
    output wire [TAG_WIDTH-1:0]         core_rsp_tag,
    output wire [REQ_SEL_WIDTH-1:0]     core_rsp_idx,
    output wire [NUM_REQS-1:0]          core_rsp_targets, // the ports the response goes to
    input  wire                         core_rsp_ready,

    // Memory request (sector-granular; = line when 1 sector/line)
    output wire                         mem_req_valid,
    output wire [`CS_LINE_SECTOR_ADDR_WIDTH-1:0] mem_req_addr,
    output wire                         mem_req_rw,
    output wire [SECTOR_SIZE-1:0]       mem_req_byteen,
    output wire [`CS_SECTOR_WIDTH-1:0]  mem_req_data,
    output wire [MEM_TAG_WIDTH-1:0]     mem_req_tag,
    output wire [`UP(MEM_ATTR_WIDTH)-1:0] mem_req_attr,
    input  wire                         mem_req_ready,

    // Memory response
    input wire                          mem_rsp_valid,
    input wire [`CS_SECTOR_WIDTH-1:0]   mem_rsp_data,
    input wire [MEM_TAG_WIDTH-1:0]      mem_rsp_tag,
    output wire                         mem_rsp_ready,

    // Flush
    input wire                          flush_begin,
    input wire                          flush_skip,
    input wire [`UP(UUID_WIDTH)-1:0]    flush_uuid,
    output wire                         flush_end
);
    localparam PIPELINE_STAGES = LATENCY;
    localparam PIPE_EX = LATENCY - 2;       // extra data-deferral stages (0 = classic 2-stage)
    // mem-req queue depth (pow2): max of pipeline floor (2*PIPELINE) and writeback reservation (MSHR), plus MREQ_SIZE extra slots.
    // A writeback cache emits an eviction request alongside the fill on a dirty miss, so up to MSHR_SIZE writebacks can
    // enqueue at once (one per outstanding miss); reserving MSHR_SIZE slots keeps the queue from stalling the fill drain that frees them.
    localparam MREQ_QUEUE_SIZE = 1 << `CLOG2(`MAX(2 * PIPELINE_STAGES, WRITEBACK ? MSHR_SIZE : 0) + MREQ_SIZE);
    // core-rsp queue depth (pow2): registered-skid minimum (2) plus CRSQ_SIZE extra slots
    localparam CRSQ_QUEUE_SIZE = 1 << `CLOG2(2 + CRSQ_SIZE);
    `STATIC_ASSERT(LATENCY >= 2, ("invalid parameter: cache bank LATENCY must be >= 2"))
    `STATIC_ASSERT(!LAZY_FETCH || (WRITEBACK && DIRTY_BYTES && IS_LLC), ("invalid parameter: lazy fetch requires a write-back LLC with dirty bytes"))
    `STATIC_ASSERT(!WRITE_AROUND || (WRITEBACK && WRITE_ENABLE), ("invalid parameter: write-around requires a write-back cache"))
    `STATIC_ASSERT(RSP_WORDS == 1 || (!WRITE_ENABLE && !AMO_ENABLE), ("invalid parameter: multi-word responses are read-only"))
    `UNUSED_PARAM (MRSQ_SIZE)

    // ========================================================================
    // Pipeline payload types
    //
    // The request travels as a struct and the S0-computed lookup results are a
    // separate `lookup_t` delta, composed into `commit_t` for the response /
    // memory-request stage. Fill data never rides the pipeline: the sector is
    // staged in the fill buffer at accept and feeds the data array directly,
    // so `data_t` carries only the word payload and `tag_matches`.
    //   sel -> S0     : data_t  (st0)            -- request + word payload
    //   S0  -> stD    : data_t  (stD)            -- drives the data array
    //   S0  -> S1->stC: commit_t (st1, stC)      -- request + lookup delta
    // `way_idx` and `mshr_id` are reused across stages (flush_way/replay_id at
    // select; resolved way / allocated id at commit). PIPE_EX=0 collapses
    // stD->S0 and stC->S1: the classic 2-stage bank.
    // ========================================================================
    typedef struct packed {
        logic                           valid, is_init, is_fill, is_flush, is_creq, is_replay, is_passthru_fill, rw;
        logic [`UP(MEM_ATTR_WIDTH)-1:0] attr;
        logic [`CS_WAY_SEL_WIDTH-1:0]   way_idx;     // flush_way @sel, resolved way @S1
        logic [`CS_LINE_ADDR_WIDTH-1:0] addr;
        logic [WORD_SIZE-1:0]           byteen;
        logic [WORD_SEL_WIDTH-1:0]      word_idx;
        logic [REQ_SEL_WIDTH-1:0]       req_idx;
        logic [TAG_WIDTH-1:0]           tag;
        logic [MSHR_ADDR_WIDTH-1:0]     mshr_id;     // replay_id @sel, alloc/replay id @S1
        amo_req_t                       amo;
    } req_t;

    typedef struct packed {            // S0-computed lookup delta (commit side)
        logic                          is_hit, is_dirty, mshr_pending;
        logic                          is_refill; // fill into an already-resident line (sector refill)
        logic [`CS_SECTORS_PER_LINE-1:0] evict_dirty_mask; // per-sector dirty of the evict way
        logic [`CS_TAG_SEL_BITS-1:0]   evict_tag;
        logic [MSHR_ADDR_WIDTH-1:0]    mshr_previd;
    } lookup_t;

    typedef struct packed {            // data-array drive (S0 -> stD)
        req_t                          req;
        logic [`CS_WORD_WIDTH-1:0]     wdata;
        logic [NUM_WAYS-1:0]           tag_matches;
    } data_t;

    typedef struct packed {            // response + memory request (S0 -> S1 -> stC)
        req_t                          req;
        lookup_t                       lk;
    } commit_t;

    // Lazy-fetch request flavors ride a side pipeline beside the request; it
    // exists only when the feature is enabled.
    typedef struct packed {
        logic                          is_lazy;     // data-less fill of a write-miss root
        logic                          is_refetch;  // fill whose root refetches a partial sector
        logic                          is_retry;    // refetch re-issued after its sector was evicted
        logic                          is_park;     // replay parked on a partial sector: issues its refetch
        logic                          is_loop;     // fill taken from the loopback queue
    } lazy_req_t;

    data_t   sel_req, st0, dat_in, stD;   // request + fill line: sel -> S0 -> stD
    commit_t cmt_in, st1, stC;            // request + lookup delta: S0 -> S1 -> stC
    lookup_t lk_st0;                      // S0 lookup results

    // ------------------------------------------------------------------------
    // Shared signals
    // ------------------------------------------------------------------------
    wire crsp_queue_stall, mshr_alm_full;
    wire mshr_allocate_st0;
    (* max_fanout = 64 *) wire pipe_stall;
    // Authoritative "no entry held", straight off the MSHR's valid mask. The
    // pending-size counter below is a proxy: it is fed by separate increment and
    // decrement events and, as the finalize_is_pending comment above records,
    // can underflow on a double free. A flush gated on the proxy alone hangs
    // forever once it drifts high, so the gate consults both.
    wire mshr_valid_empty;
    wire mshr_probe_pending_ld, mshr_probe_pending_amo;
    wire mshr_any_ld, mshr_any_amo, mshr_persist_ld, mshr_persist_amo;
    wire mreq_queue_empty, mreq_queue_alm_full;
    wire [`CS_LINE_ADDR_WIDTH-1:0] mem_rsp_addr;
    wire [`UP(`CS_SECTOR_SEL_BITS)-1:0] mem_rsp_sector; // sector this fill installs
    wire [MSHR_ADDR_WIDTH-1:0] mshr_alloc_id, mshr_previd;
    wire mshr_fill_refetch, mshr_fill_retry, mshr_dequeue_reads;
    wire lazyq_empty, lazyq_alm_full, lazyq_full;
    wire mshr_pending_raw;
    wire mshr_pending_wr_raw;
    wire mshr_pending_ovl_raw;

    // MSHR replay (dequeue) sideband
    wire                           replay_valid, replay_ready, replay_rw;
    wire [`CS_LINE_ADDR_WIDTH-1:0] replay_addr;
    wire [WORD_SEL_WIDTH-1:0]      replay_wsel;
    wire [WORD_SIZE-1:0]           replay_byteen;
    wire [`CS_WORD_WIDTH-1:0]      replay_data;
    wire [TAG_WIDTH-1:0]           replay_tag;
    wire [REQ_SEL_WIDTH-1:0]       replay_idx;
    wire [MSHR_ADDR_WIDTH-1:0]     replay_id;
    amo_req_t                      replay_amo;

    // AMO engine interconnect (tied to 0 when the bank carries no AMO logic).
    wire                          amo_hit_st1, amo_commit_busy, amo_chain_stall, amo_wb_pending, amo_wbq_full;
    wire [`CS_WORD_WIDTH-1:0]     amo_rsp_data;
    wire [WORD_SIZE-1:0]          amo_rd_fwd_mask;
    wire [`CS_WORD_WIDTH-1:0]     amo_rd_fwd_data;
    wire [`CS_WORD_WIDTH-1:0]     read_word_fwd_stc;
    wire [`CS_LINE_ADDR_WIDTH-1:0] amo_wb_addr;
    wire [WORD_SEL_WIDTH-1:0]     amo_wb_word_idx;
    wire [WORD_SIZE-1:0]          amo_wb_byteen;
    wire [`CS_WORD_WIDTH-1:0]     amo_wb_data;
    wire [TAG_WIDTH-1:0]          amo_wb_tag;
    wire [REQ_SEL_WIDTH-1:0]      amo_wb_idx;
    wire [`UP(MEM_ATTR_WIDTH)-1:0] amo_wb_attr;
    wire                          is_amo_fwd_st0, is_amo_fwd_st1, is_amo_replay_st1;
    wire                          is_passthru_fill_sel, req_input_defer;
    wire [`CS_WORD_WIDTH-1:0]     amo_ptw_word_st1;

    wire flush_valid, flush_ready, init_valid;
    wire [`CS_LINE_SEL_BITS-1:0] flush_sel;
    wire [`CS_WAY_SEL_WIDTH-1:0] flush_way;

    // Fill-forwarding sideband.
    // fwd_head: the pending-chain head is a forwardable read this cycle;
    // fwd_fire: it completes at the forward-response port; fwd_pending: a
    // forward drain is in progress (blocks the next fill from re-staging).
    wire fwd_head, fwd_fire, fwd_pending;
    wire [`CS_WORD_WIDTH-1:0] fwd_word;

    // Fill buffer: the sector staged at fill accept; it feeds the forward-
    // response word and enters the fill-data delay line to the array write.
    reg [`CS_SECTOR_WIDTH-1:0] fbuf_data_r;
    reg [`CS_LINE_ADDR_WIDTH-1:0] fbuf_addr_r;

    // AMO sideband, extracted from the attr field (gated by AMO_ENABLE).
    amo_req_t core_req_amo;
    assign core_req_amo = AMO_ENABLE ? amo_req_t'(core_req_attr[MEM_ATTR_AMO_OFFS +: AMO_REQ_BITS])
                                     : amo_req_t'('0);

    // ------------------------------------------------------------------------
    // Per-stage decoded operations
    // ------------------------------------------------------------------------
    wire do_init_st0  = st0.req.valid && st0.req.is_init;
    wire do_flush_st0 = st0.req.valid && st0.req.is_flush;
    wire do_read_st0  = st0.req.valid && st0.req.is_creq && ~st0.req.rw;
    wire do_write_st0 = st0.req.valid && st0.req.is_creq && st0.req.rw;
    wire do_fill_st0  = st0.req.valid && st0.req.is_fill;
    wire do_lookup_st0 = do_read_st0 || do_write_st0;

    wire do_read_st1  = st1.req.valid && st1.req.is_creq && ~st1.req.rw;
    wire do_write_st1 = st1.req.valid && st1.req.is_creq && st1.req.rw;
    wire do_lookup_st1 = do_read_st1 || do_write_st1;

    wire do_read_stc  = stC.req.valid && stC.req.is_creq && ~stC.req.rw;
    wire do_write_stc = stC.req.valid && stC.req.is_creq && stC.req.rw;

    wire do_fill_std  = stD.req.valid && stD.req.is_fill;
    wire do_flush_std = stD.req.valid && stD.req.is_flush;
    wire do_read_std  = stD.req.valid && stD.req.is_creq && ~stD.req.rw;
    wire do_write_std = stD.req.valid && stD.req.is_creq && stD.req.rw;

    wire [`CS_LINE_SEL_BITS-1:0] line_idx_st0 = st0.req.addr[`CS_LINE_SEL_BITS-1:0];
    wire [`CS_TAG_SEL_BITS-1:0]  line_tag_st0 = `CS_LINE_ADDR_TAG(st0.req.addr);
    // Requested sector = top CS_SECTOR_SEL_BITS of the in-line word offset.
    wire [`UP(`CS_SECTOR_SEL_BITS)-1:0] sector_idx_st0;
    if (`CS_SECTOR_SEL_BITS != 0) begin : g_sector_idx
        assign sector_idx_st0 = st0.req.word_idx[`CS_WORD_SEL_BITS-1 -: `CS_SECTOR_SEL_BITS];
    end else begin : g_sector_idx0
        assign sector_idx_st0 = '0;
    end
    wire [`CS_WORD_WIDTH-1:0]    write_word_st0 = st0.wdata;
    wire [`CS_LINE_ADDR_WIDTH-1:0] addr_stc = stC.req.addr;

    // ------------------------------------------------------------------------
    // Bank-empty detection (gates flush). A request occupies S0, S1 and the
    // PIPE_EX commit-bubble stages (valid_st1 delayed 1..PIPE_EX); the parallel
    // data bubble S0->stD is subsumed by this window.
    // ------------------------------------------------------------------------
    wire pipe_inflight;
    if (PIPE_EX == 0) begin : g_no_bubble_occ
        assign pipe_inflight = st0.req.valid || st1.req.valid;
    end else begin : g_bubble_occ
        reg [PIPE_EX-1:0] commit_valid;
        always @(posedge clk) begin
            if (reset) begin
                commit_valid <= '0;
            end else if (~pipe_stall) begin
                commit_valid[0] <= st1.req.valid;
                for (int i = 1; i < PIPE_EX; ++i) begin
                    commit_valid[i] <= commit_valid[i-1];
                end
            end
        end
        assign pipe_inflight = st0.req.valid || st1.req.valid || (| commit_valid);
    end
    // Queued AMO results are still writes to land in the array.
    wire no_pending_req = ~pipe_inflight && mreq_queue_empty && lazyq_empty && ~amo_commit_busy;

    VX_cache_flush #(
        .CACHE_SIZE (CACHE_SIZE),
        .LINE_SIZE  (LINE_SIZE),
        .NUM_BANKS  (NUM_BANKS),
        .NUM_WAYS   (NUM_WAYS),
        .WRITEBACK  (WRITEBACK)
    ) cache_flush (
        .clk         (clk),
        .reset       (reset),
        .flush_begin (flush_begin),
        .flush_skip  (flush_skip),
        .flush_end   (flush_end),
        .flush_init  (init_valid),
        .flush_valid (flush_valid),
        .flush_line  (flush_sel),
        .flush_way   (flush_way),
        .flush_ready (flush_ready),
        // Gated on the MSHR's own valid mask, not on the pending-size counter.
        // The counter is a proxy fed by separate increment and decrement events
        // and can underflow on a double free (see the finalize_is_pending comment
        // below); once it drifts high the flush waits forever on a condition that
        // is already true. The mask is authoritative for entries actually held,
        // and the accept-to-allocate window is covered by bank_empty: a request
        // accepted at the input is still in the pipeline, so pipe_inflight holds
        // bank_empty low until allocation completes at st0.
        .mshr_empty  (mshr_valid_empty),
        .bank_empty  (no_pending_req)
    );

    // wb_hold pauses the commit while a multi-beat per-sector writeback drains
    // (0 for single-sector lines, so the baseline pipe is unaffected).
    wire wb_hold;
    // amo_chain_stall paces a same-line AMO behind an in-flight commit by one
    // cycle; it is 0 for non-AMO traffic, so the baseline pipe is unaffected.
    assign pipe_stall = crsp_queue_stall || amo_chain_stall || wb_hold;

    // ========================================================================
    // Input arbitration
    //   priority: init > replay > fill(mem_rsp) > flush > core-req
    // replay maximizes utilization (guaranteed hit); fill precedes flush/creq to
    // avoid deadlock on a miss; flush precedes creq for consistency.
    // ========================================================================
    // A chain head claimed by the forward port is masked from the arbiter
    // (it completes at the forward-response port instead of replaying); a
    // fill is held off while a forward drain is in progress so the staged
    // sector is not overwritten mid-chain.
    // The MSHR hides an entry being dequeued this cycle from the same-line
    // match (linking behind a slot invalidated the same cycle would orphan the
    // new entry). If that entry is a not-yet-applied chain member and a
    // same-line request is probing right now, the prober would sail past it as
    // a fresh hit/miss and break arrival order. Hold the replay for that cycle
    // instead — the entry stays valid, the prober links behind it, and the
    // drain resumes next cycle. The fill path is held with it so the dequeue
    // pointer cannot be re-armed mid-chain. The forward port needs no hold: it
    // answers from the staged fill sector, which a younger array access cannot
    // disturb.
    // The hold matters only when the vanishing entry would have constrained
    // the prober: same word, and at least one side writes. Read-after-read and
    // disjoint words carry no order constraint, so the entry may hide and the
    // prober proceed as a fresh hit — which keeps a streaming drain from being
    // stalled one cycle per incoming same-line beat.
    wire replay_link_hold = replay_valid && mshr_allocate_st0 && ~pipe_stall
                         && (st0.req.addr == replay_addr)
                         && (replay_rw || st0.req.rw)
                         && (replay_wsel == st0.req.word_idx);

    // Lazy fetch: a write-miss root's fill loops back (lazyq) as a data-less
    // fill below memory fills. A load/AMO head of a partial chain parks and
    // refetches. A refetch merges into its resident sector one stage late, at
    // stC; one whose sector was evicted installs nothing and retries as a
    // plain fill (nothing can dirty an absent sector, so its data is current).
    // A refetch whose sector is already fully written has nothing to read: it
    // loops back as a data-less refetch instead of going to memory.
    wire lazyq_valid = ~lazyq_empty;
    wire [MSHR_ADDR_WIDTH-1:0] lazyq_id;
    wire lazy_sel    = ~mem_rsp_valid && lazyq_valid;
    wire chain_partial, chain_retry;
    // Lazy-fetch request flavors, folded to constants when the feature is off.
    lazy_req_t lz_sel, lz_st0, lz_st1, lz_stc;
    wire lazy_st0     = lz_st0.is_lazy;
    wire refetch_st0  = lz_st0.is_refetch;
    wire retry_st0    = lz_st0.is_retry;
    wire park_st0     = lz_st0.is_park;
    wire park_stc     = lz_stc.is_park;
    wire refetch_stc  = lz_stc.is_refetch;
    wire retry_stc    = lz_stc.is_retry;
    `UNUSED_VAR ({lz_st1, lz_stc.is_lazy})
    wire park_sel     = (LAZY_FETCH != 0) && chain_partial && mshr_dequeue_reads;
    wire refetch_hold = st0.req.valid && st0.req.is_fill && refetch_st0;
    // The chain's head waits out a refetch at S0, and a head that would park
    // waits for memory-request room; nothing else is selected meanwhile. Built
    // from registers only and applied at the MSHR output, off the dequeue cone.
    wire replay_block = refetch_hold || (park_sel && mreq_queue_alm_full);

    // A fill starts a replay chain, and a chain carries at most one AMO (no
    // request enters behind a pending AMO), so a fill waits until the AMO
    // writeback queue has room for it; the queue drains meanwhile.
    wire replay_mux    = replay_valid && ~fwd_head && ~replay_link_hold;
    wire refetch_inflight;
    wire fill_mux      = (mem_rsp_valid || lazyq_valid) && ~fwd_pending && ~replay_link_hold && ~amo_wbq_full
                      && ~refetch_inflight && ~replay_block;

    wire replay_grant  = ~init_valid;
    wire replay_enable = replay_grant && replay_mux;
    wire fill_grant    = replay_grant && ~replay_enable;
    wire fill_enable   = fill_grant && fill_mux;
    wire flush_grant   = fill_grant && ~fill_enable;
    wire flush_enable  = flush_grant && flush_valid;
    wire creq_grant    = flush_grant && ~flush_enable;

    // A core-request slot fires from a real core_req or a pending LLC AMO
    // writeback (synthetic write injected after a commit); mutually exclusive.
    // amo_commit_busy/req_input_defer enforce AMO ordering (0 for non-AMO banks).
    wire amo_creq_path = core_req_valid && ~amo_commit_busy && ~req_input_defer;
    wire amo_wb_path   = amo_wb_pending && ~amo_hit_st1;
    wire creq_enable   = creq_grant && (amo_creq_path || amo_wb_path);

    assign replay_ready   = replay_grant && ~fwd_head && ~replay_link_hold && ~(!WRITEBACK && replay_rw && mreq_queue_alm_full) && ~pipe_stall;
    assign mem_rsp_ready  = fill_grant && ~fwd_pending && ~replay_link_hold && ~amo_wbq_full && ~refetch_inflight
                         && ~replay_block && ~(WRITEBACK && mreq_queue_alm_full) && ~pipe_stall;
    assign flush_ready    = flush_grant && ~(WRITEBACK && mreq_queue_alm_full) && ~pipe_stall;
    // a core request may become a write-miss root, which pushes to lazyq.
    wire   creq_alm_full  = mreq_queue_alm_full || lazyq_alm_full || replay_block;
    // A queued AMO result drains through the core-request slot, while a full
    // AMO writeback queue holds off the fills that drain the lazy queue. So
    // the writeback is not held to the lazy queue's pipeline reservation when
    // the pipe is empty: then only the writeback itself can push, and a free
    // slot is room enough.
    wire   lazyq_wb_block = lazyq_alm_full && (pipe_inflight || lazyq_full);
    wire   amo_wb_alm_full = mreq_queue_alm_full || lazyq_wb_block || replay_block;
    assign core_req_ready = creq_grant && ~creq_alm_full && ~mshr_alm_full && ~pipe_stall
                         && ~amo_commit_busy && ~req_input_defer;

    wire init_fire    = init_valid;
    wire replay_fire  = replay_valid && replay_ready;
    wire mem_rsp_fire = mem_rsp_valid && mem_rsp_ready;
    wire lazy_fire    = lazy_sel && mem_rsp_ready;
    wire fill_fire    = mem_rsp_fire || lazy_fire;
    wire park_fire    = replay_fire && park_sel;
    wire flush_fire   = flush_valid && flush_ready;
    // amo_wb_path already excludes the cycle a fresh AMO commits at S1, so the
    // writeback never races the chain update.
    wire amo_wb_fire   = amo_wb_path && creq_grant && ~amo_wb_alm_full && ~mshr_alm_full && ~pipe_stall;
    wire core_req_fire = ((amo_creq_path && ~creq_alm_full) || (amo_wb_path && ~amo_wb_alm_full))
                       && creq_grant && ~mshr_alm_full && ~pipe_stall;

    wire [MSHR_ADDR_WIDTH-1:0] mem_rsp_id = mem_rsp_tag[MSHR_ADDR_WIDTH-1:0];
    wire [MSHR_ADDR_WIDTH-1:0] fill_id    = lazy_sel ? lazyq_id : mem_rsp_id;

    // Fill word_idx: place the installed sector in the high (sector) bits of the
    // in-line word offset; low (word-in-sector) bits are don't-care for a fill.
    wire [WORD_SEL_WIDTH-1:0] fill_word_idx;
    if (`CS_SECTOR_SEL_BITS != 0) begin : g_fill_word_idx
        assign fill_word_idx = WORD_SEL_WIDTH'(mem_rsp_sector) << (`CS_WORD_SEL_BITS - `CS_SECTOR_SEL_BITS);
    end else begin : g_fill_word_idx0
        `UNUSED_VAR (mem_rsp_sector)
        assign fill_word_idx = '0;
    end

    // generate-guarded width selects (the dead branch must not elaborate an
    // out-of-range slice when the other width path is taken).
    wire [TAG_WIDTH-1:0] mem_rsp_tag_s;
    if (TAG_WIDTH > MEM_TAG_WIDTH) begin : g_mem_rsp_tag_s_pad
        assign mem_rsp_tag_s = {mem_rsp_tag, (TAG_WIDTH-MEM_TAG_WIDTH)'(1'b0)};
    end else begin : g_mem_rsp_tag_s_cut
        assign mem_rsp_tag_s = mem_rsp_tag[MEM_TAG_WIDTH-1 -: TAG_WIDTH];
        `UNUSED_VAR (mem_rsp_tag)
    end

    wire [TAG_WIDTH-1:0] flush_tag;
    if (UUID_WIDTH != 0) begin : g_flush_tag_uuid
        if (TAG_WIDTH > UUID_WIDTH) begin : g_pad
            assign flush_tag = {flush_uuid, (TAG_WIDTH-UUID_WIDTH)'(1'b0)};
        end else begin : g_cut
            assign flush_tag = flush_uuid[UUID_WIDTH-1 -: TAG_WIDTH];
        end
    end else begin : g_flush_tag_0
        `UNUSED_VAR (flush_uuid)
        assign flush_tag = '0;
    end

    // Word payload mux (store / AMO-writeback data). Fill data takes its own
    // delay line from the staged fill buffer to the data array.
    wire [`CS_WORD_WIDTH-1:0] wdata_sel;
    if (WRITE_ENABLE) begin : g_wdata_sel
        assign wdata_sel = replay_mux ? replay_data
                         : (amo_wb_pending ? amo_wb_data : core_req_data);
    end else begin : g_wdata_sel_ro
        assign wdata_sel = '0;
        `UNUSED_VAR ({core_req_data, replay_data, amo_wb_data})
    end

    // Input mux -> arbitrated request (whole-struct populate). AMO priority
    // matches the mux (replay > wb > core_req): a replay can fire during a
    // pending wb (chained AMO replays from MSHR after a fill) and must not be
    // cleared by amo_wb_pending; the synthetic writeback carries amo.valid=0 so
    // it never re-commits at S1.
    // The core-request slot's address: a pending LLC AMO writeback or the core
    // request. The MSHR takes its allocate match against it a cycle early.
    wire [`CS_LINE_ADDR_WIDTH-1:0] creq_addr_sel = amo_wb_pending ? amo_wb_addr : core_req_addr;
    wire [WORD_SEL_WIDTH-1:0]      creq_wsel_sel = amo_wb_pending ? amo_wb_word_idx : core_req_wsel;
    wire [`UP(`CS_SECTOR_SEL_BITS)-1:0] creq_sector_sel;
    if (`CS_SECTOR_SEL_BITS != 0) begin : g_creq_sector
        assign creq_sector_sel = creq_wsel_sel[`CS_WORD_SEL_BITS-1 -: `CS_SECTOR_SEL_BITS];
    end else begin : g_creq_sector_0
        assign creq_sector_sel = '0;
    end

    always @(*) begin
        sel_req = '0;
        sel_req.req.valid    = init_fire || replay_fire || fill_fire || flush_fire || core_req_fire;
        sel_req.req.is_init  = init_valid;
        sel_req.req.is_fill  = fill_enable;
        sel_req.req.is_flush = flush_enable;
        sel_req.req.is_creq  = creq_enable || replay_enable;
        sel_req.req.is_replay = replay_enable;
        sel_req.req.is_passthru_fill = is_passthru_fill_sel;
        sel_req.req.rw       = replay_mux ? replay_rw : (amo_wb_pending ? 1'b1 : core_req_rw);
        sel_req.req.attr     = amo_wb_pending ? amo_wb_attr : (core_req_valid ? core_req_attr : '0);
        sel_req.req.way_idx  = flush_way;
        sel_req.req.addr     = (init_valid | flush_valid) ? `CS_LINE_ADDR_WIDTH'(flush_sel)
                             : (replay_mux ? replay_addr : (fill_mux ? mem_rsp_addr : creq_addr_sel));
        sel_req.req.byteen   = replay_mux ? replay_byteen : (amo_wb_pending ? amo_wb_byteen : core_req_byteen);
        // a fill carries the installed sector in its word_idx high bits so the
        // tag/data stages mark/write the right sector (0 when 1 sector/line).
        sel_req.req.word_idx = replay_mux ? replay_wsel
                             : (fill_mux ? fill_word_idx
                             : creq_wsel_sel);
        sel_req.req.req_idx  = replay_mux ? replay_idx : (amo_wb_pending ? amo_wb_idx : core_req_idx);
        sel_req.req.tag      = (init_valid | flush_valid) ? (flush_valid ? flush_tag : '0)
                             : (replay_mux ? replay_tag : (fill_mux ? (lazy_sel ? '0 : mem_rsp_tag_s)
                             : (amo_wb_pending ? amo_wb_tag : core_req_tag)));
        sel_req.req.mshr_id  = replay_id;
        sel_req.req.amo      = replay_mux ? replay_amo : (amo_wb_pending ? amo_req_t'('0)
                             : (core_req_valid ? core_req_amo : amo_req_t'('0)));
        sel_req.wdata        = wdata_sel;
        // tag_matches is computed at S0; left 0 here (overridden at the data bubble).
    end

    assign lz_sel.is_lazy    = fill_enable && lazy_sel && ~mshr_fill_refetch;
    assign lz_sel.is_refetch = fill_enable && mshr_fill_refetch;
    assign lz_sel.is_retry   = fill_enable && ~lazy_sel && mshr_fill_retry;
    assign lz_sel.is_park    = replay_enable && park_sel;
    assign lz_sel.is_loop    = fill_enable && lazy_sel;

    // UUID extraction (debug + MSHR ordering): per stage, from the carried tag.
    wire [`UP(UUID_WIDTH)-1:0] req_uuid_sel, req_uuid_st0, req_uuid_st1, req_uuid_stc;
    if (UUID_WIDTH != 0) begin : g_req_uuid
        assign req_uuid_sel = sel_req.req.tag[TAG_WIDTH-1 -: UUID_WIDTH];
        assign req_uuid_st0 = st0.req.tag[TAG_WIDTH-1 -: UUID_WIDTH];
        assign req_uuid_st1 = st1.req.tag[TAG_WIDTH-1 -: UUID_WIDTH];
        assign req_uuid_stc = stC.req.tag[TAG_WIDTH-1 -: UUID_WIDTH];
    end else begin : g_req_uuid_0
        assign {req_uuid_sel, req_uuid_st0, req_uuid_st1, req_uuid_stc} = '0;
    end
    `UNUSED_VAR ({req_uuid_st0, req_uuid_st1})

    // S0 register
    VX_pipe_register #(
        .DATAW  ($bits(data_t)),
        .RESETW (1)
    ) reg_s0 (
        .clk      (clk),
        .reset    (reset),
        .enable   (~pipe_stall),
        .data_in  (sel_req),
        .data_out (st0)
    );

    // ========================================================================
    // S0 lookup: replacement + tags + way-encode + MSHR allocate
    // ========================================================================
    wire [`CS_WAY_SEL_WIDTH-1:0] victim_way;
    wire [NUM_WAYS-1:0] tag_matches_st0;
    wire [NUM_WAYS-1:0] line_present_st0;
    wire [`CS_WAY_SEL_WIDTH-1:0] hit_idx_st0;
    wire evict_dirty_st0, evict_valid_st0;
    `UNUSED_VAR (evict_valid_st0)
    wire [`CS_SECTORS_PER_LINE-1:0] evict_dirty_mask_st0;
    wire [`CS_TAG_SEL_BITS-1:0] evict_tag_st0;

    // A fill into a line that is already resident (a sector refill) must target
    // the resident way, not a fresh victim, so the new sector lands in the same
    // line copy. With 1 sector/line a fill's line is never already resident, so
    // this is gated off and the victim way is always used.
    wire line_present_any_st0 = (`CS_SECTORS_PER_LINE > 1) && (| line_present_st0);
    wire [`CS_WAY_SEL_WIDTH-1:0] present_way_st0;
    VX_onehot_encoder #(
        .N (NUM_WAYS)
    ) present_way_enc (
        .data_in  (line_present_st0),
        .data_out (present_way_st0),
        `UNUSED_PIN (valid_out)
    );
    wire [`CS_WAY_SEL_WIDTH-1:0] fill_way_st0 = line_present_any_st0 ? present_way_st0 : victim_way;
    wire [`CS_WAY_SEL_WIDTH-1:0] evict_way_st0 = st0.req.is_fill ? fill_way_st0 : st0.req.way_idx;
    // A refetch (first attempt) uses no victim: it merges into the way that
    // holds its sector, carried apart from evict_way so that the tag compare
    // stays off the array write enables.
    wire refetch_first_st0 = do_fill_st0 && refetch_st0 && ~retry_st0;
    wire [`CS_WAY_SEL_WIDTH-1:0] merge_way_st0 = refetch_first_st0 ? hit_idx_st0 : evict_way_st0;

    // Fill way as one-hot, straight from the per-way presence vector: routing
    // it through the binary encode -> evict_way -> per-way compare round trip
    // put the tag-read cone on the tag store's own write-enable pins. The
    // victim decode is early (replacement state is registered), and
    // line_present_st0 is one-hot by the tag-array invariant, so this selects
    // the exact way the binary path did.
    wire [NUM_WAYS-1:0] victim_way_oh = NUM_WAYS'(1'b1) << victim_way;
    wire [NUM_WAYS-1:0] fill_way_oh_st0 = line_present_any_st0 ? line_present_st0 : victim_way_oh;

    VX_cache_repl #(
        .CACHE_SIZE  (CACHE_SIZE),
        .LINE_SIZE   (LINE_SIZE),
        .NUM_BANKS   (NUM_BANKS),
        .NUM_WAYS    (NUM_WAYS),
        .REPL_POLICY (REPL_POLICY)
    ) cache_repl (
        .clk          (clk),
        .reset        (reset),
        .stall        (pipe_stall),
        .init         (do_init_st0),
        .lookup_valid (do_lookup_st1 && ~pipe_stall),
        .lookup_hit   (st1.lk.is_hit),
        .lookup_line  (st1.req.addr[`CS_LINE_SEL_BITS-1:0]),
        .lookup_way   (st1.req.way_idx),
        // only a new line takes a victim: a refetch merges into its resident
        // sector and a sector refill joins its resident line
        .repl_valid   (do_fill_st0 && ~st0.req.is_passthru_fill && ~refetch_first_st0 && ~line_present_any_st0 && ~pipe_stall),
        .repl_line    (line_idx_st0),
        .repl_line_n  (sel_req.req.addr[`CS_LINE_SEL_BITS-1:0]),
        .repl_way     (victim_way)
    );

    wire creq_hit_order_hazard_st0;

    // Loads and AMOs read the sector, so a partial one is a miss for them. The
    // array enables use the raw tag match (a partial sector is still resident);
    // only the commit decisions, registered at S1, see the partial check.
    wire needs_data_st0 = st0.req.is_creq && ~st0.req.rw;
    wire partial_match_st0;
    wire partial_miss_st0 = (LAZY_FETCH != 0) && needs_data_st0 && partial_match_st0;
    // A refetch finds its partial sector resident (it merges) unless the
    // sector was evicted meanwhile: its data may then predate the eviction's
    // writeback, so it installs nothing and its chain retries.
    wire fill_resident_st0 = (| tag_matches_st0);
    wire fill_evicted_st0  = refetch_first_st0 && ~fill_resident_st0;

    VX_cache_tags #(
        .CACHE_SIZE (CACHE_SIZE),
        .LINE_SIZE  (LINE_SIZE),
        .NUM_BANKS  (NUM_BANKS),
        .NUM_WAYS   (NUM_WAYS),
        .WORD_SIZE  (WORD_SIZE),
        .SECTOR_SIZE(SECTOR_SIZE),
        .WRITEBACK  (WRITEBACK),
        .LAZY_FETCH (LAZY_FETCH),
        .AMO_ENABLE ((AMO_ENABLE != 0) && (IS_LLC == 0))
    ) cache_tags (
        .clk         (clk),
        .reset       (reset),
        .stall       (pipe_stall),
        .init        (do_init_st0),
        .flush       (do_flush_st0 && ~pipe_stall),
        .fill        (do_fill_st0 && ~st0.req.is_passthru_fill && ~refetch_first_st0 && ~pipe_stall),
        .refetch     (refetch_first_st0 && ~pipe_stall),
        .read        (do_read_st0 && ~pipe_stall),
        .write       (do_write_st0 && ~pipe_stall),
        // non-LLC AMO forwards downstream and invalidates its own copy so the
        // issuer's later plain load refetches the new value. Only the hit's
        // qualifiers are passed (a forwarded AMO has no order hazard): the
        // array ANDs in each way's own tag match, which keeps the OR over the
        // ways off the valid store's write enables.
        .invalidate  (is_amo_fwd_st0 && ~partial_miss_st0 && ~pipe_stall),
        .fill_nodata (lazy_st0),
        .line_idx    (line_idx_st0),
        .line_idx_n  (sel_req.req.addr[`CS_LINE_SEL_BITS-1:0]),
        .line_tag    (line_tag_st0),
        .sector_idx  (sector_idx_st0),
        .evict_way   (evict_way_st0),
        .flush_way   (st0.req.way_idx),
        // a writeback leaves only from a fresh fill's victim or a flushed way
        .wb_way      (st0.req.is_fill ? victim_way : st0.req.way_idx),
        .fill_way_oh (fill_way_oh_st0),
        .victim_way_oh (victim_way_oh),
        .tag_matches (tag_matches_st0),
        .line_present (line_present_st0),
        .evict_dirty (evict_dirty_st0),
        .evict_valid (evict_valid_st0),
        .evict_dirty_mask (evict_dirty_mask_st0),
        .evict_tag   (evict_tag_st0),
        .partial_match (partial_match_st0)
    );

    VX_onehot_encoder #(
        .N (NUM_WAYS)
    ) way_idx_enc (
        .data_in  (tag_matches_st0),
        .data_out (hit_idx_st0),
        `UNUSED_PIN (valid_out)
    );

    // A tags-hit is completable only while no OLDER same-WORD MSHR chain entry
    // could still change the word (a chained write not yet applied) or observe
    // it (any chained entry, against a write request): chained entries replay
    // through the pipe AFTER this request's data-array access, so completing
    // the hit would invert arrival order — a load reads pre-store data, or a
    // store lands before an older chained load reads. Demote such a hit to a
    // chained miss: the request links onto the line's chain (it is pending, so
    // no fill is issued) and replays in arrival order once the chain drains.
    // A chained entry's replay touches exactly its own word, so hits to
    // disjoint words — the common case in streaming, where the whole warp's
    // beats land on one sector — keep the fast release path, as does
    // read-after-read on the same word.
    // (the probes carry their own pending test; see VX_cache_mshr)
    assign creq_hit_order_hazard_st0 = st0.req.is_creq && ~st0.req.is_replay
                                    && (mshr_pending_wr_raw || (st0.req.rw && mshr_pending_ovl_raw))
                                    && ~is_amo_fwd_st0
                                    && ~((AMO_ENABLE != 0) && st0.req.amo.amo_valid);

    // S0 lookup delta (single combinational driver). The AMO requester is forced
    // non-pending so it never coalesces onto a prior same-line entry.
    always @(*) begin
        lk_st0 = '0;
        lk_st0.is_hit       = (| tag_matches_st0) && ~partial_miss_st0 && ~creq_hit_order_hazard_st0;
        lk_st0.is_dirty     = evict_dirty_st0;
        lk_st0.is_refill    = st0.req.is_fill && line_present_any_st0;
        lk_st0.evict_dirty_mask = evict_dirty_mask_st0;
        lk_st0.evict_tag    = evict_tag_st0;
        lk_st0.mshr_previd  = mshr_previd;
        // a parked replay is its own chain's root: it issues the refetch.
        lk_st0.mshr_pending = mshr_pending_raw && ~is_amo_fwd_st0 && ~park_st0;
    end

    // ========================================================================
    // Pipeline registration
    //
    // Tags / replacement / MSHR (allocate AND finalize) stay at S0/S1: the MSHR
    // coalescing chain requires allocate(S0)->finalize(S1) exactly one cycle
    // apart (deferring it orphans coalesced same-line entries -> deadlock). Only
    // the data array (stD) and the commit consumers (stC) defer by PIPE_EX, so
    // the array is driven by *registered* tag-compare results — breaking the
    // tag->data critical path. Read and write both move to the same deferred
    // stage, so pipeline order is preserved (no store->load hazard logic).
    // ========================================================================

    // data path: carry the request + fill line + tag compare, resolving the way
    // for the data array (victim way for fill/flush, hit way otherwise).
    // A tags-hit demoted to a chained miss must not touch the array: its store
    // would land ahead of the older chained requests it is ordered behind, and
    // it writes on its in-order replay instead.
    always @(*) begin
        dat_in = st0;
        dat_in.req.way_idx = evict_way_st0;
        dat_in.tag_matches = tag_matches_st0 & {NUM_WAYS{~creq_hit_order_hazard_st0}};
    end

    // commit path: the request (with the resolved hit/victim way and MSHR id)
    // plus the lookup delta. The word payload is dropped here.
    always @(*) begin
        cmt_in.req = st0.req;
        cmt_in.req.way_idx = st0.req.is_creq ? hit_idx_st0 : merge_way_st0;
        cmt_in.req.mshr_id = st0.req.is_replay ? st0.req.mshr_id : mshr_alloc_id;
        cmt_in.lk = lk_st0;
    end

    VX_pipe_register #(
        .DATAW  ($bits(data_t)),
        .RESETW (1),
        .DEPTH  (PIPE_EX)
    ) reg_dat (
        .clk      (clk),
        .reset    (reset),
        .enable   (~pipe_stall),
        .data_in  (dat_in),
        .data_out (stD)
    );

    VX_pipe_register #(
        .DATAW  ($bits(commit_t)),
        .RESETW (1)
    ) reg_s1 (
        .clk      (clk),
        .reset    (reset),
        .enable   (~pipe_stall),
        .data_in  (cmt_in),
        .data_out (st1)
    );

    // stP is the stage that feeds stC: the dirty-byte mask is read there, so
    // stC gets it from a register. In the 2-stage bank that stage is S0.
    commit_t stP;
    VX_pipe_register #(
        .DATAW  ($bits(commit_t)),
        .RESETW (1),
        .DEPTH  ((PIPE_EX != 0) ? (PIPE_EX - 1) : 0)
    ) reg_cmt_p (
        .clk      (clk),
        .reset    (reset),
        .enable   (~pipe_stall),
        .data_in  (st1),
        .data_out (stP)
    );

    // The {way, line} the dirty-byte mask is read at: stP's, or S0's when stP
    // is stC itself.
    wire [`CS_WAY_SEL_WIDTH-1:0] mask_rway_stp  = (PIPE_EX != 0) ? stP.req.way_idx : cmt_in.req.way_idx;
    wire [`CS_LINE_SEL_BITS-1:0] mask_rline_stp = (PIPE_EX != 0) ? stP.req.addr[`CS_LINE_SEL_BITS-1:0]
                                                                 : cmt_in.req.addr[`CS_LINE_SEL_BITS-1:0];

    VX_pipe_register #(
        .DATAW  ($bits(commit_t)),
        .RESETW (1),
        .DEPTH  ((PIPE_EX != 0) ? 1 : 0)
    ) reg_cmt (
        .clk      (clk),
        .reset    (reset),
        .enable   (~pipe_stall),
        .data_in  (stP),
        .data_out (stC)
    );

    // A refetch whose sector is still resident merges at stC; a data-less or
    // refetch fill writes no data at stD.
    wire fill_merge_st0  = refetch_first_st0 && fill_resident_st0;
    wire fill_nodata_st0 = lazy_st0 || refetch_first_st0;
    wire fill_merge_stc, fill_nodata_std, loop_std, partial_miss_stc;
    if (LAZY_FETCH != 0) begin : g_lazy_pipe
        wire fill_merge_st1, partial_miss_st1;
        VX_pipe_register #(
            .DATAW  ($bits(lazy_req_t)),
            .RESETW ($bits(lazy_req_t))
        ) reg_lz_s0 (
            .clk      (clk),
            .reset    (reset),
            .enable   (~pipe_stall),
            .data_in  (lz_sel),
            .data_out (lz_st0)
        );
        VX_pipe_register #(
            .DATAW  ($bits(lazy_req_t) + 2),
            .RESETW ($bits(lazy_req_t) + 2)
        ) reg_lz_s1 (
            .clk      (clk),
            .reset    (reset),
            .enable   (~pipe_stall),
            .data_in  ({lz_st0, fill_merge_st0, partial_miss_st0}),
            .data_out ({lz_st1, fill_merge_st1, partial_miss_st1})
        );
        VX_pipe_register #(
            .DATAW  ($bits(lazy_req_t) + 2),
            .RESETW ($bits(lazy_req_t) + 2),
            .DEPTH  (PIPE_EX)
        ) reg_lz_cmt (
            .clk      (clk),
            .reset    (reset),
            .enable   (~pipe_stall),
            .data_in  ({lz_st1, fill_merge_st1, partial_miss_st1}),
            .data_out ({lz_stc, fill_merge_stc, partial_miss_stc})
        );
        VX_pipe_register #(
            .DATAW  (2),
            .RESETW (2),
            .DEPTH  (PIPE_EX)
        ) reg_lz_dat (
            .clk      (clk),
            .reset    (reset),
            .enable   (~pipe_stall),
            .data_in  ({lz_st0.is_loop, fill_nodata_st0}),
            .data_out ({loop_std, fill_nodata_std})
        );
    end else begin : g_no_lazy_pipe
        assign lz_st0          = '0;
        assign lz_st1          = '0;
        assign lz_stc          = '0;
        assign fill_merge_stc  = 1'b0;
        assign fill_nodata_std = 1'b0;
        assign loop_std        = 1'b0;
        assign partial_miss_stc = 1'b0;
        `UNUSED_VAR ({lz_sel, fill_merge_st0, fill_nodata_st0, lz_st0.is_loop, lz_stc.is_loop})
    end

    // a passthru-AMO replay carries its result word instead of an installed
    // line, so it counts as a hit at the commit stage. The AMO commit signals
    // (is_amo_replay_st1) resolve at stC, so the replay-must-hit check is taken
    // there; with PIPE_EX>0 an st1-staged check would sample them a stage early.
    wire eff_hit_stc = stC.lk.is_hit || is_amo_replay_st1;
    `RUNTIME_ASSERT (~(stC.req.valid && stC.req.is_replay && ~park_stc && ~eff_hit_stc), ("missed mshr replay"))

    // ========================================================================
    // Data array (driven at stD; outputs land at stC)
    // ========================================================================
    wire[`CS_WORDS_PER_LINE-1:0][`CS_WORD_WIDTH-1:0] read_data_stc;
    wire [LINE_SIZE-1:0] evict_byteen_stc;
    wire [`CS_SECTORS_PER_LINE-1:0] evict_sec_full_stc;
    wire [`CS_WORD_WIDTH-1:0] read_word_stc = read_data_stc[stC.req.word_idx];

    // Sector being accessed at the data-array stage = top bits of word_idx.
    wire [`UP(`CS_SECTOR_SEL_BITS)-1:0] sector_idx_std;
    if (`CS_SECTOR_SEL_BITS != 0) begin : g_sector_idx_std
        assign sector_idx_std = stD.req.word_idx[`CS_WORD_SEL_BITS-1 -: `CS_SECTOR_SEL_BITS];
    end else begin : g_sector_idx_std0
        assign sector_idx_std = '0;
    end

    // A fill's sector is staged when the fill enters S0 and then rides beside
    // it to its data-array write at stD, so the next fill may restage the
    // buffer right behind it. Each stage has one source and holds on the
    // pipeline enable; without a reset, deep stages map onto shift registers.
    wire [`CS_SECTOR_WIDTH-1:0] fill_data_std;
    VX_pipe_register #(
        .DATAW  (`CS_SECTOR_WIDTH),
        .DEPTH  (PIPE_EX)
    ) reg_fill_data (
        .clk      (clk),
        .reset    (reset),
        .enable   (~pipe_stall),
        .data_in  (fbuf_data_r),
        .data_out (fill_data_std)
    );
`ifndef SYNTHESIS
    wire [`CS_LINE_ADDR_WIDTH-1:0] fill_addr_std;
    VX_pipe_register #(
        .DATAW  (`CS_LINE_ADDR_WIDTH),
        .DEPTH  (PIPE_EX)
    ) reg_fill_addr (
        .clk      (clk),
        .reset    (reset),
        .enable   (~pipe_stall),
        .data_in  (fbuf_addr_r),
        .data_out (fill_addr_std)
    );
    `RUNTIME_ASSERT (~(do_fill_std && ~stD.req.is_passthru_fill && ~loop_std) || (stD.req.addr == fill_addr_std), ("%t: %s fill sector misaligned with its array write: addr=0x%0h, staged=0x%0h", $time, INSTANCE_ID, `CS_BANK_TO_FULL_ADDR(stD.req.addr, BANK_ID), `CS_BANK_TO_FULL_ADDR(fill_addr_std, BANK_ID)))
`endif

    // The fill sector, replicated across the line so each sector's slices see
    // their words; the data array writes only the installed sector (per-slice
    // gate). One copy == the full line when 1 sector/line.
    wire [`CS_LINE_WIDTH-1:0] fbuf_line = {`CS_SECTORS_PER_LINE{fill_data_std}};

    // sector of the request at commit (the missed sector of a fill request).
    wire [`UP(`CS_SECTOR_SEL_BITS)-1:0] sector_idx_stc;
    // a refetch merges into its resident sector at stC (see refetch_hold)
    wire do_merge_stc = stC.req.valid && stC.req.is_fill && fill_merge_stc;
    // Dirty-byte mask updates land at stC in pipeline order, once per request:
    // a fill held at stC by its writeback beats still reads the evicted mask.
    wire refetch_first_stc = stC.req.is_fill && refetch_stc && ~retry_stc;
    wire mask_set_stc      = do_write_stc && stC.lk.is_hit;
    wire mask_fill_stc     = stC.req.valid && stC.req.is_fill && ~stC.req.is_passthru_fill && ~refetch_first_stc;
    wire mask_clr_line_stc = (mask_fill_stc && ~stC.lk.is_refill) || (stC.req.valid && stC.req.is_flush);
    wire mask_clr_sec_stc  = mask_fill_stc && stC.lk.is_refill;

    // The data slices a read returns: its word's, or under multi-word
    // responses the whole line, since a merged read may take any word (and
    // decoding the slots' selects here would sit on the array's enable path).
    wire [`CS_WORDS_PER_LINE-1:0] read_words_std;
    if (RSP_WORDS > 1) begin : g_read_words
        assign read_words_std = '1;
    end else begin : g_read_word
        assign read_words_std = `CS_WORDS_PER_LINE'(1) << stD.req.word_idx;
    end

    VX_cache_data #(
        .CACHE_SIZE   (CACHE_SIZE),
        .LINE_SIZE    (LINE_SIZE),
        .NUM_BANKS    (NUM_BANKS),
        .NUM_WAYS     (NUM_WAYS),
        .WORD_SIZE    (WORD_SIZE),
        .SECTOR_SIZE  (SECTOR_SIZE),
        .WRITE_ENABLE (WRITE_ENABLE),
        .WRITEBACK    (WRITEBACK),
        .DIRTY_BYTES  (DIRTY_BYTES),
        .LAZY_FETCH   (LAZY_FETCH)
    ) cache_data (
        .clk          (clk),
        .reset        (reset),
        .fill         (do_fill_std && ~stD.req.is_passthru_fill && ~pipe_stall),
        .fill_nodata  (fill_nodata_std),
        .mask_write   ((mask_set_stc || mask_clr_line_stc || mask_clr_sec_stc) && ~pipe_stall),
        .mask_set     (mask_set_stc),
        .mask_clr_line (mask_clr_line_stc),
        .mask_clr_sector (mask_clr_sec_stc),
        .mask_way     (stC.req.way_idx),
        .mask_line    (stC.req.addr[`CS_LINE_SEL_BITS-1:0]),
        .mask_word    (stC.req.word_idx),
        .mask_byteen  (stC.req.byteen),
        .mask_sector  (sector_idx_stc),
        .mask_read    (~pipe_stall),
        .mask_rway    (mask_rway_stp),
        .mask_rline   (mask_rline_stp),
        .merge_write  (do_merge_stc && ~pipe_stall),
        .flush        (do_flush_std && ~pipe_stall),
        .read         (do_read_std && ~pipe_stall),
        .write        (do_write_std && ~pipe_stall),
        .evict_way    (stD.req.way_idx),
        .tag_matches  (stD.tag_matches),
        .line_idx     (stD.req.addr[`CS_LINE_SEL_BITS-1:0]),
        .fill_data    (fbuf_line),
        .write_word   (stD.wdata),
        .word_idx     (stD.req.word_idx),
        .read_words   (read_words_std),
        .sector_idx   (sector_idx_std),
        .write_byteen (stD.req.byteen),
        .read_data    (read_data_stc),
        .evict_byteen (evict_byteen_stc),
        .evict_sec_full (evict_sec_full_stc)
    );

    // stD write word delayed to stC for its consumers there (the AMO RMW
    // operand and the write-through or write-around memory payload); elided
    // when no stC consumer exists.
    wire [`CS_WORD_WIDTH-1:0] word_stc;
    if ((WRITE_ENABLE != 0) && (!WRITEBACK || (AMO_ENABLE != 0 && IS_LLC != 0) || (WRITE_AROUND != 0))) begin : g_word_stc
        VX_pipe_register #(
            .DATAW (`CS_WORD_WIDTH)
        ) reg_word_stc (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (~pipe_stall),
            .data_in  (stD.wdata),
            .data_out (word_stc)
        );
    end else begin : g_no_word_stc
        assign word_stc = '0;
        `UNUSED_VAR (word_stc)
    end

    // ========================================================================
    // MSHR (allocate at S0, finalize at S1)
    // ========================================================================
    assign mshr_allocate_st0 = st0.req.valid && st0.req.is_creq && ~st0.req.is_replay;
    wire mshr_finalize_st1 = st1.req.valid && st1.req.is_creq && ~st1.req.is_replay;

    // A forwarded (non-LLC passthru) AMO keeps its entry until its downstream
    // response returns (fill/dequeue frees it), so never release it. This is an
    // st1 decision, but the AMO unit resolves is_amo_fwd at its stC-fed port; at
    // PIPE_EX>0 those stages differ, so evaluate the forwarded-AMO condition on
    // the st1 request itself — otherwise a forwarded AMO sitting at stC would
    // gate an unrelated store at st1 and strand its MSHR entry.
    wire is_amo_fwd_rel = (AMO_ENABLE != 0) && (IS_LLC == 0)
                        && st1.req.amo.amo_valid && st1.req.valid
                        && st1.req.is_creq && ~st1.req.is_replay;

    // release the entry on a hit.
    wire mshr_release_st1;
    if (WRITEBACK) begin : g_mshr_release
        // a write-around miss keeps nothing: it leaves for memory at stC.
        wire write_around_st1 = (WRITE_AROUND != 0) && st1.req.rw && st1.req.attr[MEM_ATTR_NOALLOC_OFFS]
                              && ~st1.lk.is_hit && ~st1.lk.mshr_pending;
        assign mshr_release_st1 = (st1.lk.is_hit || write_around_st1) && ~is_amo_fwd_rel;
    end else begin : g_mshr_release_ro
        // keep missed writes in MSHR if a pending entry exists for the line, so a
        // pending fill arriving without the write content replays them locally.
        assign mshr_release_st1 = (st1.lk.is_hit || (st1.req.rw && ~st1.lk.mshr_pending)) && ~is_amo_fwd_rel;
    end
    wire mshr_release_fire = mshr_finalize_st1 && mshr_release_st1 && ~pipe_stall;

    wire [1:0] mshr_dequeue;
    `POP_COUNT(mshr_dequeue, {((replay_fire && ~park_fire) || fwd_fire), mshr_release_fire});

    VX_pending_size #(
        .SIZE  (MSHR_SIZE),
        .DECRW (2)
    ) mshr_pending_size (
        .clk   (clk),
        .reset (reset),
        .incr  (core_req_fire),
        .decr  (mshr_dequeue),
        `UNUSED_PIN (empty),
        `UNUSED_PIN (alm_empty),
        .full  (mshr_alm_full),
        `UNUSED_PIN (alm_full),
        `UNUSED_PIN (size)
    );

    VX_cache_mshr #(
        .INSTANCE_ID (`SFORMATF(("%s-mshr", INSTANCE_ID))),
        .BANK_ID     (BANK_ID),
        .BANK_HASH   (BANK_HASH),
        .SET_HASH    (SET_HASH),
        .CACHE_SIZE  (CACHE_SIZE),
        .NUM_WAYS    (NUM_WAYS),
        .LINE_SIZE   (LINE_SIZE),
        .SECTOR_SIZE (SECTOR_SIZE),
        .NUM_BANKS   (NUM_BANKS),
        .MSHR_SIZE   (MSHR_SIZE),
        .AMO_ENABLE  (AMO_ENABLE != 0),
        .AMO_PASSTHRU ((AMO_ENABLE != 0) && (IS_LLC == 0)),
        .WORD_SEL_WIDTH (WORD_SEL_WIDTH),
        .LAZY_FETCH  (LAZY_FETCH),
        .DATA_WIDTH  (WORD_SEL_WIDTH + WORD_SIZE + `CS_WORD_WIDTH + TAG_WIDTH + REQ_SEL_WIDTH + AMO_REQ_BITS)
    ) cache_mshr (
        .clk                 (clk),
        .reset               (reset),
        .deq_req_uuid        (req_uuid_sel),
        .alc_req_uuid        (req_uuid_st0),
        .fin_req_uuid        (req_uuid_st1),
        .fill_valid          (fill_fire),
        .fill_id             (fill_id),
        .fill_addr           (mem_rsp_addr),
        .fill_sector         (mem_rsp_sector),
        .fill_refetch        (mshr_fill_refetch),
        .fill_retry          (mshr_fill_retry),
        .probe_addr          (core_req_addr),
        .probe_pending_ld    (mshr_probe_pending_ld),
        .probe_pending_amo   (mshr_probe_pending_amo),
        .probe_any_ld        (mshr_any_ld),
        .probe_any_amo       (mshr_any_amo),
        .persist_ld          (mshr_persist_ld),
        .persist_amo         (mshr_persist_amo),
        .dequeue_valid       (replay_valid),
        .dequeue_addr        (replay_addr),
        .dequeue_rw          (replay_rw),
        .dequeue_reads       (mshr_dequeue_reads),
        .dequeue_data        ({replay_wsel, replay_byteen, replay_data, replay_tag, replay_idx, replay_amo}),
        .dequeue_id          (replay_id),
        .dequeue_ready       (replay_ready || fwd_fire),
        .dequeue_fwd         (fwd_fire),
        .dequeue_park        (park_sel),
        .dequeue_park_retry  (chain_retry),
        .dequeue_block       (replay_block),
        .allocate_valid      (mshr_allocate_st0 && ~pipe_stall),
        .allocate_addr       (st0.req.addr),
        .allocate_sector     (sector_idx_st0),
        .allocate_addr_n     (creq_addr_sel),
        .allocate_sector_n   (creq_sector_sel),
        .allocate_adv        (~pipe_stall),
        .allocate_word_idx   (st0.req.word_idx),
        .allocate_rw         (st0.req.rw),
        // Only non-LLC AMOs must not coalesce; at the LLC same-line AMOs coalesce
        // and serialize their commits on the single filled line.
        .allocate_is_amo     (AMO_ENABLE ? st0.req.amo.amo_valid : 1'b0),
        .allocate_refetch    (needs_data_st0 && partial_match_st0),
        .allocate_data       ({st0.req.word_idx, st0.req.byteen, write_word_st0, st0.req.tag, st0.req.req_idx, st0.req.amo}),
        .allocate_id         (mshr_alloc_id),
        .allocate_pending    (mshr_pending_raw),
        .allocate_pending_wr (mshr_pending_wr_raw),
        .allocate_pending_ovl (mshr_pending_ovl_raw),
        .allocate_previd     (mshr_previd),
        `UNUSED_PIN (allocate_ready),
        .finalize_valid      (mshr_finalize_st1 && ~pipe_stall),
        .finalize_is_release (mshr_release_st1),
        // Only link an entry into the pending chain if it is KEPT (a miss). A
        // released (hit) entry must never become a chain member: otherwise the
        // prev's fill would later dequeue and replay the already-released slot
        // (double free -> MSHR pending-size underflow). This case arises when a
        // request hits a line that is still draining its fill chain — common
        // with sectoring, where a hot line accumulates a long same-line chain.
        .finalize_is_pending (st1.lk.mshr_pending && ~mshr_release_st1),
        .finalize_id         (st1.req.mshr_id),
        .finalize_previd     (st1.lk.mshr_previd),
        .empty               (mshr_valid_empty)
    );

    // ========================================================================
    // AMO engine
    //
    // The read word lands at the deferred commit stage stC; the engine consumes
    // it at S1 (== stC when PIPE_EX=0, the validated case).
    // ========================================================================
    if (AMO_ENABLE) begin : g_amo
        // Look-ahead {line address, byteen} for the AMO engine: the request
        // entering the commit stage (stC) next cycle, so a registered consumer
        // lands at stC. stC = st1 delayed by PIPE_EX; one stage earlier is
        // st0 (PIPE_EX=0) or st1 delayed by PIPE_EX-1 (PIPE_EX>0). The address
        // feeds the reservation cache's sync-BRAM read, the chain-stall match
        // and the writeback-queue matches; the byteen feeds the byte-offset
        // encoder.
        wire [`CS_LINE_ADDR_WIDTH-1:0] amo_res_addr_n;
        wire [WORD_SIZE-1:0]           amo_byteen_n;
        wire [WORD_SEL_WIDTH-1:0]      amo_word_idx_n;
        if (PIPE_EX == 0) begin : g_resn0
            assign amo_res_addr_n = st0.req.addr;
            assign amo_byteen_n   = st0.req.byteen;
            assign amo_word_idx_n = st0.req.word_idx;
        end else begin : g_resn
            VX_pipe_register #(
                .DATAW (`CS_LINE_ADDR_WIDTH + WORD_SIZE + WORD_SEL_WIDTH),
                .DEPTH (PIPE_EX - 1)
            ) reg_resn (
                .clk      (clk),
                .reset    (reset),
                .enable   (~pipe_stall),
                .data_in  ({st1.req.addr, st1.req.byteen, st1.req.word_idx}),
                .data_out ({amo_res_addr_n, amo_byteen_n, amo_word_idx_n})
            );
        end

        VX_cache_amo #(
            .IS_LLC          (IS_LLC),
            .NUM_RES_ENTRIES (`VX_CFG_AMO_RS_SIZE),
            .LINE_ADDR_BITS  (`CS_LINE_ADDR_WIDTH),
            .WORD_WIDTH      (`CS_WORD_WIDTH),
            .WORD_SIZE       (WORD_SIZE),
            .WORD_SEL_WIDTH  (WORD_SEL_WIDTH),
            .TAG_WIDTH       (TAG_WIDTH),
            .REQ_SEL_WIDTH   (REQ_SEL_WIDTH),
            .ATTR_WIDTH      (`UP(MEM_ATTR_WIDTH)),
            .MSHR_SIZE       (MSHR_SIZE),
            .MSHR_ADDR_WIDTH (MSHR_ADDR_WIDTH),
            .WORDS_PER_LINE  (`CS_WORDS_PER_LINE),
            .WORDS_PER_SECTOR(`CS_WORDS_PER_SECTOR),
            .PIPE_EX         (PIPE_EX)
        ) amo (
            .clk                    (clk),
            .reset                  (reset),
            .pipe_stall             (pipe_stall),
            .amo_st0                (st0.req.amo),
            .valid_st0              (st0.req.valid),
            .is_creq_st0            (st0.req.is_creq),
            // Atomics are exempt from the hit-order hazard, so their S0 hit is
            // the raw tag match; the MSHR probe stays off the commit_busy cone.
            .is_hit_st0             ((| tag_matches_st0) && ~partial_miss_st0),
            .is_replay_st0          (st0.req.is_replay),
            // Commit ports are fed from stC (the deferred data-output stage), so
            // the AMO RMW operands and the read word align at PIPE_EX>0. At
            // PIPE_EX=0, stC == S1 and this is identical to the classic bank.
            .amo_st1                (stC.req.amo),
            .valid_st1              (stC.req.valid),
            .is_creq_st1            (stC.req.is_creq),
            .is_hit_st1             (stC.lk.is_hit),
            .is_replay_st1          (stC.req.is_replay),
            .do_write_st1           (do_write_stc),
            .read_word_st1          (read_word_stc),
            .read_word_fwd_st1      (read_word_fwd_stc),
            .byteen_st1             (stC.req.byteen),
            .write_word_st1         (word_stc),
            .word_idx_st0           (st0.req.word_idx),
            .word_idx_st1           (stC.req.word_idx),
            .addr_st1               (addr_stc),
            .res_addr_n             (amo_res_addr_n),
            .byteen_n               (amo_byteen_n),
            .word_idx_n             (amo_word_idx_n),
            .tag_st1                (stC.req.tag),
            .req_idx_st1            (stC.req.req_idx),
            .attr_st1               (stC.req.attr),
            .wb_fire                (amo_wb_fire),
            .mshr_allocate_st0      (mshr_allocate_st0),
            .mshr_alloc_id_st0      (mshr_alloc_id),
            .mshr_id_st1            (stC.req.mshr_id),
            .mem_rsp_fire           (mem_rsp_fire),
            .mem_rsp_id             (mem_rsp_id),
            .mem_rsp_data           (mem_rsp_data),
            .is_fill_sel            (fill_enable),
            .core_req_valid         (core_req_valid),
            .core_req_is_amo        (core_req_amo.amo_valid),
            .core_req_rw            (core_req_rw),
            .core_req_fire          (core_req_fire),
            .rw_st0                 (st0.req.rw),
            .mshr_probe_pending_ld  (mshr_probe_pending_ld),
            .mshr_probe_pending_amo (mshr_probe_pending_amo),
            .mshr_any_ld            (mshr_any_ld),
            .mshr_any_amo           (mshr_any_amo),
            .mshr_persist_ld        (mshr_persist_ld),
            .mshr_persist_amo       (mshr_persist_amo),
            .amo_hit_st1            (amo_hit_st1),
            .commit_busy            (amo_commit_busy),
            .chain_stall            (amo_chain_stall),
            .wb_pending             (amo_wb_pending),
            .wbq_full               (amo_wbq_full),
            .rsp_data               (amo_rsp_data),
            .rd_fwd_mask            (amo_rd_fwd_mask),
            .rd_fwd_data            (amo_rd_fwd_data),
            .wb_addr                (amo_wb_addr),
            .wb_word_idx            (amo_wb_word_idx),
            .wb_byteen              (amo_wb_byteen),
            .wb_data                (amo_wb_data),
            .wb_tag                 (amo_wb_tag),
            .wb_idx                 (amo_wb_idx),
            .wb_attr                (amo_wb_attr),
            .is_amo_fwd_st0         (is_amo_fwd_st0),
            .is_amo_fwd_st1         (is_amo_fwd_st1),
            .is_amo_replay_st1      (is_amo_replay_st1),
            .is_passthru_fill_sel   (is_passthru_fill_sel),
            .amo_ptw_word_st1       (amo_ptw_word_st1),
            .req_input_defer        (req_input_defer)
        );
    end else begin : g_no_amo
        assign {amo_hit_st1, amo_commit_busy, amo_wb_pending, amo_chain_stall, amo_wbq_full} = '0;
        assign {amo_rd_fwd_mask, amo_rd_fwd_data} = '0;
        assign {amo_rsp_data, amo_wb_addr, amo_wb_word_idx, amo_wb_byteen} = '0;
        assign {amo_wb_data, amo_wb_tag, amo_wb_idx, amo_wb_attr} = '0;
        assign {is_amo_fwd_st0, is_amo_fwd_st1, is_amo_replay_st1} = '0;
        assign {is_passthru_fill_sel, amo_ptw_word_st1, req_input_defer} = '0;
        // S1-only signals consumed solely by the AMO engine.
        `UNUSED_VAR ({amo_wb_fire, mshr_probe_pending_ld, mshr_probe_pending_amo, st1.req.amo, st1.req.attr, st1.req.req_idx, st1.req.word_idx, st1.req.byteen})
        `UNUSED_VAR ({mshr_any_ld, mshr_any_amo, mshr_persist_ld, mshr_persist_amo})
    end

    // ========================================================================
    // Core response (stC)
    //
    // Fires for reads (and LLC AMO commits) on hit, never for the synthetic
    // writeback (rw=1). A non-LLC AMO's first pass forwards downstream and must
    // not respond locally (its result returns via the passthru replay). Suppress
    // while a same-line AMO is chain-stalled so a held read enqueues once.
    // ========================================================================
    wire crsp_queue_valid = do_read_stc && eff_hit_stc && ~is_amo_fwd_st1 && ~amo_chain_stall;
    wire crsp_queue_ready;
    // Plain-read responses byte-merge the AMO engine's in-flight writeback
    // bytes over the array word (stale until the writeback lands).
    if (AMO_ENABLE && IS_LLC) begin : g_read_word_fwd
        for (genvar b = 0; b < WORD_SIZE; ++b) begin : g_b
            assign read_word_fwd_stc[b*8 +: 8] = amo_rd_fwd_mask[b] ? amo_rd_fwd_data[b*8 +: 8]
                                                                    : read_word_stc[b*8 +: 8];
        end
    end else begin : g_read_word_raw
        assign read_word_fwd_stc = read_word_stc;
        `UNUSED_VAR ({amo_rd_fwd_mask, amo_rd_fwd_data})
    end

    wire [`CS_WORD_WIDTH-1:0] crsp_queue_data = is_amo_replay_st1 ? amo_ptw_word_st1
                                              : (amo_hit_st1 ? amo_rsp_data : read_word_fwd_stc);

    // ========================================================================
    // Fill forwarding
    //
    // The fill sector is staged at fill accept; the MSHR dequeue stream (which
    // walks the pending chain in order, including late joiners) then completes
    // its leading run of plain reads straight into the response queue — no
    // pipeline traversal, and the input arbiter stays open to new requests.
    // The first write/AMO head closes the window: it and every later chain
    // entry replay through the pipeline as usual, preserving program order
    // (an older store must merge before a younger same-line read responds).
    // ========================================================================
    reg fwd_active_r;

    // A refetch fill stages its sector for the array write but cannot answer
    // the chain: the staged copy lacks the dirty bytes the array merges in.
    wire fbuf_stage = mem_rsp_fire && ~is_passthru_fill_sel;
    wire fwd_stage  = fbuf_stage && ~mshr_fill_refetch;
    wire fwd_close = replay_valid && fwd_active_r
                  && (replay_rw || replay_amo.amo_valid);

    // every chain entry matches the staged {line, sector} by construction
    // (miss coalescing keys on both), so one staged sector serves them all.
    // The head is only claimed when the response slot is free this cycle
    // (the commit-stage response has priority); otherwise it stays visible
    // to the arbiter and drains through the replay path — a busy hit
    // stream must not starve the chain. The ~pipe_stall gate keeps the
    // dequeue aligned with S1 finalize so a stalled late joiner cannot be
    // orphaned mid-link.
    assign fwd_head    = fwd_active_r && replay_valid
                      && ~replay_rw && ~replay_amo.amo_valid
                      && ~crsp_queue_valid && ~pipe_stall;
    assign fwd_pending = fwd_active_r && replay_valid;
    assign fwd_fire    = fwd_head && crsp_queue_ready;

    always @(posedge clk) begin
        if (reset) begin
            fwd_active_r <= 1'b0;
        end else begin
            if (fwd_stage) begin
                fwd_active_r <= 1'b1;
            end else if (fwd_close || ((LAZY_FETCH != 0) && fill_fire)) begin
                fwd_active_r <= 1'b0;
            end
        end
        if (fbuf_stage) begin
            fbuf_data_r <= mem_rsp_data;
            fbuf_addr_r <= mem_rsp_addr;
        end
    end

    if (`CS_WORDS_PER_SECTOR > 1) begin : g_fwd_word
        wire [`CLOG2(`CS_WORDS_PER_SECTOR)-1:0] fwd_wsel = replay_wsel[`CLOG2(`CS_WORDS_PER_SECTOR)-1:0];
        assign fwd_word = fbuf_data_r[fwd_wsel * `CS_WORD_WIDTH +: `CS_WORD_WIDTH];
    end else begin : g_fwd_word_1
        assign fwd_word = fbuf_data_r[`CS_WORD_WIDTH-1:0];
    end

    // A multi-word response takes each word its tag selects, from the line at
    // commit or from the staged sector on a forward.
    wire [RSP_WORDS-1:0][`CS_WORD_WIDTH-1:0] crsp_words, fwd_words;
    if (RSP_WORDS > 1) begin : g_rsp_words
        for (genvar k = 0; k < RSP_WORDS; ++k) begin : g_word
            wire [WORD_SEL_WIDTH-1:0] wsel_stc = stC.req.tag[RSP_WSEL_OFFS + k * RSP_WSEL_STRIDE +: WORD_SEL_WIDTH];
            wire [WORD_SEL_WIDTH-1:0] wsel_fwd = replay_tag[RSP_WSEL_OFFS + k * RSP_WSEL_STRIDE +: WORD_SEL_WIDTH];
            assign crsp_words[k] = read_data_stc[wsel_stc];
            if (`CS_WORDS_PER_SECTOR > 1) begin : g_fwd
                wire [`CLOG2(`CS_WORDS_PER_SECTOR)-1:0] fwd_k = wsel_fwd[`CLOG2(`CS_WORDS_PER_SECTOR)-1:0];
                assign fwd_words[k] = fbuf_data_r[fwd_k * `CS_WORD_WIDTH +: `CS_WORD_WIDTH];
            end else begin : g_fwd_1
                assign fwd_words[k] = fbuf_data_r[`CS_WORD_WIDTH-1:0];
                `UNUSED_VAR (wsel_fwd)
            end
        end
        `UNUSED_VAR ({crsp_queue_data, fwd_word})
    end else begin : g_rsp_word
        assign crsp_words = crsp_queue_data;
        assign fwd_words  = fwd_word;
    end

    `RUNTIME_ASSERT (~fwd_fire || (replay_addr == fbuf_addr_r), ("%t: %s fill-forward address mismatch: addr=0x%0h, staged=0x%0h", $time, INSTANCE_ID, `CS_BANK_TO_FULL_ADDR(replay_addr, BANK_ID), `CS_BANK_TO_FULL_ADDR(fbuf_addr_r, BANK_ID)))
    `RUNTIME_ASSERT (~(flush_fire && fwd_pending), ("%t: %s flush during fill-forward drain", $time, INSTANCE_ID))

    // The ports a response goes to, decoded as it enters the queue so that
    // the response arbiters start from registers: its own port and, under
    // read merging, the merged ports of its group the tag's low bits mark.
    wire [TAG_WIDTH-1:0]     crsp_in_tag = crsp_queue_valid ? stC.req.tag : replay_tag;
    wire [REQ_SEL_WIDTH-1:0] crsp_in_idx = crsp_queue_valid ? stC.req.req_idx : replay_idx;
    wire [NUM_REQS-1:0]      crsp_in_targets;
    if (MERGE_GROUP > 1) begin : g_merge_targets
        localparam GROUP_BITS = `CLOG2(MERGE_GROUP);
        wire [REQ_SEL_WIDTH-1:0] group_base = (crsp_in_idx >> GROUP_BITS) << GROUP_BITS;
        assign crsp_in_targets = (NUM_REQS'(1) << crsp_in_idx)
                               | (NUM_REQS'(crsp_in_tag[MERGE_GROUP-1:0]) << group_base);
    end else begin : g_port_target
        assign crsp_in_targets = NUM_REQS'(1) << crsp_in_idx;
    end

    VX_elastic_buffer #(
        .DATAW   (NUM_REQS + TAG_WIDTH + RSP_WORDS * `CS_WORD_WIDTH + REQ_SEL_WIDTH),
        .SIZE    (CRSQ_QUEUE_SIZE),
        .OUT_REG (`TO_OUT_BUF_REG(CORE_OUT_BUF))
    ) core_rsp_queue (
        .clk       (clk),
        .reset     (reset),
        .valid_in  (crsp_queue_valid || fwd_head),
        .ready_in  (crsp_queue_ready),
        .data_in   ({crsp_in_targets, crsp_in_tag, (crsp_queue_valid ? crsp_words : fwd_words), crsp_in_idx}),
        .data_out  ({core_rsp_targets, core_rsp_tag, core_rsp_data, core_rsp_idx}),
        .valid_out (core_rsp_valid),
        .ready_out (core_rsp_ready)
    );
    assign crsp_queue_stall = crsp_queue_valid && ~crsp_queue_ready;

    // ========================================================================
    // Memory request (stC) — sector-granular
    //
    // A read/write miss issues a fill request for the missed sector. A dirty
    // eviction writes back each dirty sector as its own sector-sized beat: the
    // sequencer below drains one dirty sector per cycle, holding the commit at
    // stC until the last beat is accepted. With 1 sector/line this is a single
    // beat (wb_hold never asserts).
    // ========================================================================
    localparam SEC = `CS_SECTORS_PER_LINE;
    wire mreq_queue_push, mreq_queue_pop;
    wire [`CS_SECTOR_WIDTH-1:0] mreq_queue_data;
    wire [SECTOR_SIZE-1:0] mreq_queue_byteen;
    wire [`CS_LINE_SECTOR_ADDR_WIDTH-1:0] mreq_queue_addr;
    wire [MEM_TAG_WIDTH-1:0] mreq_queue_tag;
    wire mreq_queue_rw;

    wire is_fill_or_flush_stc = stC.req.is_fill || (stC.req.is_flush && WRITEBACK);
    // a no-allocate write miss with no fill pending on its line is sent to
    // memory as is: nothing is allocated or fetched.
    wire write_around_stc = (WRITE_AROUND != 0) && do_write_stc && stC.req.attr[MEM_ATTR_NOALLOC_OFFS]
                          && ~stC.lk.is_hit && ~stC.lk.mshr_pending;
    // a write-miss root under lazy fetch loops its fill back instead.
    wire lazy_alloc_stc = (LAZY_FETCH != 0) && do_write_stc && ~stC.lk.is_hit && ~stC.lk.mshr_pending
                       && ~write_around_stc;
    // a refetch root (a partial-miss read or a parked head) whose sector every
    // store already covers loops back instead of reading memory, while the
    // loopback has the room a new request is admitted with: a parked head is
    // not admitted against it, and memory always has room for the refetch.
    wire refetch_root_stc = (LAZY_FETCH != 0) && do_read_stc && ~stC.lk.is_hit && ~stC.lk.mshr_pending
                         && partial_miss_stc;
    wire refetch_loop_stc = refetch_root_stc && evict_sec_full_stc[sector_idx_stc] && ~lazyq_alm_full;
    // the mask of the request's sector, as of every older store
    wire [SECTOR_SIZE-1:0] sector_byteen_stc = evict_byteen_stc[sector_idx_stc * SECTOR_SIZE +: SECTOR_SIZE];
    `RUNTIME_ASSERT (~refetch_root_stc || (evict_sec_full_stc[sector_idx_stc] == (& sector_byteen_stc)), ("%t: %s sector-full flag disagrees with the dirty-byte mask: addr=0x%0h, full=%b, mask=0x%0h", $time, INSTANCE_ID, `CS_BANK_TO_FULL_ADDR(addr_stc, BANK_ID), evict_sec_full_stc[sector_idx_stc], sector_byteen_stc))
    wire do_fill_or_flush_stc = stC.req.valid && is_fill_or_flush_stc;
    // a sector refill keeps the resident line (no eviction), so never writes back.
    wire do_writeback_stc = do_fill_or_flush_stc && stC.lk.is_dirty && ~stC.lk.is_refill && ~refetch_first_stc;
    wire [`CS_LINE_ADDR_WIDTH-1:0] evict_addr_stc = {stC.lk.evict_tag, stC.req.addr[`CS_LINE_SEL_BITS-1:0]};

    if (`CS_SECTOR_SEL_BITS != 0) begin : g_sector_idx_stc
        assign sector_idx_stc = stC.req.word_idx[`CS_WORD_SEL_BITS-1 -: `CS_SECTOR_SEL_BITS];
    end else begin : g_sector_idx_stc0
        assign sector_idx_stc = '0;
    end

    // Per-sector writeback sequencer. wb_mask_cur is the set of dirty sectors
    // still to write back; one is drained per cycle (lowest first). wb_done_r
    // latches once the current commit's writeback fully drains so an unrelated
    // hold of stC (crsp/amo) cannot re-inject it; it clears when the commit
    // finally advances.
    reg [SEC-1:0] wb_mask_r;
    reg wb_done_r;
    wire wb_active = (| wb_mask_r);
    wire [SEC-1:0] wb_mask_cur = wb_active ? wb_mask_r
                               : ((do_writeback_stc && ~wb_done_r) ? stC.lk.evict_dirty_mask : {SEC{1'b0}});
    wire is_wb_beat = (| wb_mask_cur);
    wire [`UP(`CS_SECTOR_SEL_BITS)-1:0] wb_sector;
    VX_priority_encoder #(
        .N (SEC)
    ) wb_sector_sel (
        .data_in   (wb_mask_cur),
        .index_out (wb_sector),
        `UNUSED_PIN (valid_out),
        `UNUSED_PIN (onehot_out)
    );
    wire [SEC-1:0] wb_sec_oh = SEC'(1) << wb_sector;
    wire wb_beat_accept = is_wb_beat && ~mreq_queue_alm_full;
    wire [SEC-1:0] wb_mask_nxt = wb_beat_accept ? (wb_mask_cur & ~wb_sec_oh) : wb_mask_cur;
    assign wb_hold = (| wb_mask_nxt); // beats remain after this cycle -> hold stC
    always @(posedge clk) begin
        if (reset) begin
            wb_mask_r <= '0;
            wb_done_r <= 1'b0;
        end else begin
            wb_mask_r <= wb_mask_nxt;
            // latch done on the last accepted beat while stC is still held;
            // clear once the commit advances (so the next commit starts fresh).
            if (is_wb_beat && ~wb_hold) begin
                wb_done_r <= 1'b1;
            end
            if (~pipe_stall) begin
                wb_done_r <= 1'b0;
            end
        end
    end

    // sector-granular addresses: {line, sector} with sector in the low bits
    // (cache.sv re-inserts the bank id above the sector).
    wire [`CS_LINE_SECTOR_ADDR_WIDTH-1:0] wb_mreq_addr, rd_mreq_addr;
    if (`CS_SECTOR_SEL_BITS != 0) begin : g_sec_addr
        assign wb_mreq_addr = {evict_addr_stc, wb_sector};
        assign rd_mreq_addr = {addr_stc, sector_idx_stc};
    end else begin : g_no_sec_addr
        `UNUSED_VAR (sector_idx_stc)
        assign wb_mreq_addr = evict_addr_stc;
        assign rd_mreq_addr = addr_stc;
    end

    // selected writeback sector: data slice + per-byte dirty mask of that sector.
    // flatten the packed word-array before bit-slicing the sector out.
    wire [`CS_LINE_WIDTH-1:0]   read_data_flat_stc = read_data_stc;
    wire [`CS_SECTOR_WIDTH-1:0] wb_data_sec = read_data_flat_stc[wb_sector*`CS_SECTOR_WIDTH +: `CS_SECTOR_WIDTH];
    wire [SECTOR_SIZE-1:0]      wb_byteen_sec = evict_byteen_stc[wb_sector*SECTOR_SIZE +: SECTOR_SIZE];

    if (WRITE_ENABLE) begin : g_mreq_queue
        if (WRITEBACK) begin : g_wb
            if (DIRTY_BYTES) begin : g_dirty_bytes
                wire has_dirty_bytes = (| evict_byteen_stc);
                // a refetch evicts nothing: the mask it reads is its resident way's
                wire check_evict_bytes = do_fill_or_flush_stc && ~refetch_first_stc;
            `ifndef SYNTHESIS
                // An invalid way's mask is undefined: the reset walk leaves the
                // mask alone and every install clears its line's mask, so only a
                // valid victim's bytes must agree with its dirty flag.
                wire evict_valid_stc;
                VX_pipe_register #(
                    .DATAW  (1),
                    .DEPTH  (1 + PIPE_EX)
                ) reg_evict_valid (
                    .clk      (clk),
                    .reset    (reset),
                    .enable   (~pipe_stall),
                    .data_in  (evict_valid_st0),
                    .data_out (evict_valid_stc)
                );
                `RUNTIME_ASSERT (~(check_evict_bytes && evict_valid_stc) || (stC.lk.is_dirty == has_dirty_bytes), ("missmatch dirty bytes: dirty_line=%b, dirty_bytes=%b, addr=0x%0h", stC.lk.is_dirty, has_dirty_bytes, `CS_BANK_TO_FULL_ADDR(addr_stc, BANK_ID)))
            `endif
                // per-sector: a dirty sector must carry dirty bytes, or its writeback beat is dropped.
                wire [SEC-1:0] sec_has_dirty_bytes;
                for (genvar s = 0; s < SEC; ++s) begin : g_sec_has_dirty_bytes
                    assign sec_has_dirty_bytes[s] = (| evict_byteen_stc[s*SECTOR_SIZE +: SECTOR_SIZE]);
                end
                `RUNTIME_ASSERT (~check_evict_bytes || ((stC.lk.evict_dirty_mask & ~sec_has_dirty_bytes) == '0), ("dirty sector without dirty bytes: dirty_mask=%b, dirty_bytes=%b, addr=0x%0h", stC.lk.evict_dirty_mask, sec_has_dirty_bytes, `CS_BANK_TO_FULL_ADDR(addr_stc, BANK_ID)))
            end
            // fill request on a read/write miss (one sector); multi-beat writeback
            // on a dirty eviction. The two are mutually exclusive (a writeback is a
            // fill/flush commit; a fill request is a creq commit).
            wire fill_req_push = (do_read_stc || do_write_stc) && ~stC.lk.is_hit && ~stC.lk.mshr_pending
                              && ~lazy_alloc_stc && ~refetch_loop_stc && ~write_around_stc && ~pipe_stall;
            wire wa_req_push = write_around_stc && ~pipe_stall;
            assign mreq_queue_push   = fill_req_push || wa_req_push || wb_beat_accept;
            assign mreq_queue_addr   = is_wb_beat ? wb_mreq_addr : rd_mreq_addr;
            assign mreq_queue_rw     = is_wb_beat || write_around_stc;
            if (WRITE_AROUND != 0) begin : g_wa_data
                wire [LINE_SIZE-1:0] full_byteen;
                VX_demux #(
                    .DATAW (WORD_SIZE),
                    .N     (`CS_WORDS_PER_LINE)
                ) byteen_demux (
                    .sel_in   (stC.req.word_idx),
                    .data_in  (stC.req.byteen),
                    .data_out (full_byteen)
                );
                wire [SECTOR_SIZE-1:0] sec_byteen = full_byteen[sector_idx_stc*SECTOR_SIZE +: SECTOR_SIZE];
                assign mreq_queue_data   = is_wb_beat ? wb_data_sec : {`CS_WORDS_PER_SECTOR{word_stc}};
                assign mreq_queue_byteen = is_wb_beat ? wb_byteen_sec : (write_around_stc ? sec_byteen : {SECTOR_SIZE{1'b1}});
            end else begin : g_no_wa_data
                assign mreq_queue_data   = wb_data_sec; // read fill request: data unused
                assign mreq_queue_byteen = is_wb_beat ? wb_byteen_sec : {SECTOR_SIZE{1'b1}};
                `UNUSED_VAR (stC.req.byteen)
            end
            `UNUSED_VAR (stC.req.is_replay)
        end else begin : g_wt
            // word byte-enable demuxed over the line, then sliced to the word's sector.
            wire [LINE_SIZE-1:0] full_byteen;
            VX_demux #(
                .DATAW (WORD_SIZE),
                .N     (`CS_WORDS_PER_LINE)
            ) byteen_demux (
                .sel_in   (stC.req.word_idx),
                .data_in  (stC.req.byteen),
                .data_out (full_byteen)
            );
            wire [SECTOR_SIZE-1:0] sec_byteen = full_byteen[sector_idx_stc*SECTOR_SIZE +: SECTOR_SIZE];
            // fill on a read miss; memory write on a write (don't resend replays);
            // forward a non-LLC AMO downstream (its passthru replay must not refill).
            assign mreq_queue_push = ((do_read_stc && ~eff_hit_stc && ~stC.lk.mshr_pending)
                                  || (do_write_stc && ~stC.req.is_replay)
                                  || is_amo_fwd_st1) && ~pipe_stall;
            assign mreq_queue_addr = rd_mreq_addr;
            assign mreq_queue_rw = stC.req.rw;
            assign mreq_queue_data = {`CS_WORDS_PER_SECTOR{word_stc}};
            assign mreq_queue_byteen = (stC.req.rw || is_amo_fwd_st1) ? sec_byteen : {SECTOR_SIZE{1'b1}};
            `UNUSED_VAR ({is_wb_beat, wb_beat_accept, wb_mreq_addr, wb_data_sec, wb_byteen_sec, wb_sector, evict_addr_stc, stC.lk.evict_tag, stC.lk.is_dirty, stC.lk.evict_dirty_mask, write_around_stc})
        end
    end else begin : g_mreq_queue_ro
        assign mreq_queue_push = (do_read_stc && ~stC.lk.is_hit && ~stC.lk.mshr_pending) && ~pipe_stall;
        assign mreq_queue_addr = rd_mreq_addr;
        assign mreq_queue_rw = 0;
        assign mreq_queue_data = '0;
        assign mreq_queue_byteen = {SECTOR_SIZE{1'b1}};
        `UNUSED_VAR ({is_wb_beat, wb_beat_accept, wb_mreq_addr, wb_data_sec, wb_byteen_sec, wb_sector, do_writeback_stc, evict_addr_stc, evict_byteen_stc, stC.lk.evict_tag, stC.lk.is_dirty, stC.lk.evict_dirty_mask, stC.req.byteen, stC.req.word_idx, stC.req.is_replay, do_write_stc, write_around_stc})
    end

    if (UUID_WIDTH != 0) begin : g_mreq_queue_tag_uuid
        assign mreq_queue_tag = {req_uuid_stc, stC.req.mshr_id};
    end else begin : g_mreq_queue_tag
        assign mreq_queue_tag = stC.req.mshr_id;
    end

    assign mreq_queue_pop = mem_req_valid && mem_req_ready;

    VX_fifo_queue #(
        .DATAW    (1 + `CS_LINE_SECTOR_ADDR_WIDTH + SECTOR_SIZE + `CS_SECTOR_WIDTH + MEM_TAG_WIDTH + `UP(MEM_ATTR_WIDTH)),
        .DEPTH    (MREQ_QUEUE_SIZE),
        .ALM_FULL (MREQ_QUEUE_SIZE - PIPELINE_STAGES),
        .OUT_REG  (`TO_OUT_BUF_REG(MEM_OUT_BUF))
    ) mem_req_queue (
        .clk      (clk),
        .reset    (reset),
        .push     (mreq_queue_push),
        .pop      (mreq_queue_pop),
        .data_in  ({mreq_queue_rw, mreq_queue_addr, mreq_queue_byteen, mreq_queue_data, mreq_queue_tag, stC.req.attr}),
        .data_out ({mem_req_rw, mem_req_addr, mem_req_byteen, mem_req_data, mem_req_tag, mem_req_attr}),
        .empty    (mreq_queue_empty),
        .alm_full (mreq_queue_alm_full),
        `UNUSED_PIN (full),
        `UNUSED_PIN (alm_empty),
        `UNUSED_PIN (size)
    );
    assign mem_req_valid = ~mreq_queue_empty;

    // Lazy-fetch loopback: write-miss roots awaiting their data-less fill, and
    // refetch roots whose sector needs no data.
    // Sized like the memory request queue's reservation: a core request is
    // admitted only while every request already in the pipe still fits.
    if (LAZY_FETCH != 0) begin : g_lazyq
        // Room for twice the pipe, so a few queued entries leave the
        // reservation (and the refetch loopback, which needs it) open.
        localparam LAZYQ_SIZE = 1 << `CLOG2(2 * PIPELINE_STAGES);
        VX_fifo_queue #(
            .DATAW    (MSHR_ADDR_WIDTH),
            .DEPTH    (LAZYQ_SIZE),
            .ALM_FULL (LAZYQ_SIZE - PIPELINE_STAGES)
        ) lazy_queue (
            .clk      (clk),
            .reset    (reset),
            .push     ((lazy_alloc_stc || refetch_loop_stc) && ~pipe_stall),
            .pop      (lazy_fire),
            .data_in  (stC.req.mshr_id),
            .data_out (lazyq_id),
            .empty    (lazyq_empty),
            .alm_full (lazyq_alm_full),
            .full     (lazyq_full),
            `UNUSED_PIN (alm_empty),
            `UNUSED_PIN (size)
        );

        // The partial state of the draining chain's sector: set by a data-less
        // fill, cleared by a data fill, and corrected at S0 when a refetch
        // finds its sector evicted (the replay waits out that cycle).
        reg chain_partial_r, chain_retry_r;
        always @(posedge clk) begin
            if (reset) begin
                chain_partial_r <= 1'b0;
                chain_retry_r   <= 1'b0;
            end else if (fill_fire) begin
                chain_partial_r <= lazy_fire && ~mshr_fill_refetch;
                chain_retry_r   <= 1'b0;
            end else if (refetch_hold && ~pipe_stall) begin
                chain_partial_r <= fill_evicted_st0;
                chain_retry_r   <= fill_evicted_st0;
            end
        end
        assign chain_partial = chain_partial_r;
        assign chain_retry   = chain_retry_r;

        // A refetch's fill sector must stay staged until its stC merge.
        reg refetch_inflight_r;
        always @(posedge clk) begin
            if (reset) begin
                refetch_inflight_r <= 1'b0;
            end else if (mem_rsp_fire && mshr_fill_refetch) begin
                refetch_inflight_r <= 1'b1;
            end else if (stC.req.valid && stC.req.is_fill && refetch_stc && ~lz_stc.is_loop && ~pipe_stall) begin
                refetch_inflight_r <= 1'b0;
            end
        end
        assign refetch_inflight = refetch_inflight_r;
        // A memory refetch keeps its sector staged until its stC merge.
        `RUNTIME_ASSERT (~(stC.req.valid && stC.req.is_fill && refetch_stc && ~lz_stc.is_loop) || refetch_inflight_r,
            ("%t: %s memory refetch reached its merge unstaged: addr=0x%0h", $time, INSTANCE_ID, `CS_BANK_TO_FULL_ADDR(addr_stc, BANK_ID)))

        `RUNTIME_ASSERT (~((lazy_alloc_stc || refetch_loop_stc) && ~pipe_stall && lazyq_full && ~lazy_fire),
            ("%t: %s lazy queue overflow", $time, INSTANCE_ID))
        // A looped-back refetch carries no data: its merge must find every byte written.
        `RUNTIME_ASSERT (~(do_merge_stc && lz_stc.is_loop) || (& sector_byteen_stc),
            ("%t: %s looped-back refetch of an incompletely written sector: addr=0x%0h", $time, INSTANCE_ID, `CS_BANK_TO_FULL_ADDR(addr_stc, BANK_ID)))
        `RUNTIME_ASSERT (~(park_fire && fwd_fire), ("%t: %s park and forward in one cycle", $time, INSTANCE_ID))
        `RUNTIME_ASSERT (~replay_valid || (mshr_dequeue_reads == (~replay_rw || replay_amo.amo_valid)),
            ("%t: %s chain head read flag disagrees with its payload", $time, INSTANCE_ID))
        // Nothing is selected behind a refetch, so its stC merge has the array
        // to itself and the next lookup reads the cleared partial bit.
        `RUNTIME_ASSERT (~(refetch_hold && sel_req.req.valid), ("%t: %s request selected behind a refetch", $time, INSTANCE_ID))
        `RUNTIME_ASSERT (~(st0.req.valid && park_st0 && (| tag_matches_st0) && ~partial_miss_st0), ("%t: %s parked replay hit", $time, INSTANCE_ID))
        // Only a refetch can find its sector resident.
        `RUNTIME_ASSERT (~(do_fill_st0 && ~refetch_first_st0 && ~st0.req.is_passthru_fill && fill_resident_st0),
            ("%t: %s fill into a resident sector: addr=0x%0h", $time, INSTANCE_ID, `CS_BANK_TO_FULL_ADDR(st0.req.addr, BANK_ID)))
    end else begin : g_no_lazyq
        assign lazyq_id       = '0;
        assign lazyq_empty    = 1'b1;
        assign lazyq_alm_full = 1'b0;
        assign lazyq_full     = 1'b0;
        assign chain_partial    = 1'b0;
        assign chain_retry      = 1'b0;
        assign refetch_inflight = 1'b0;
        `UNUSED_VAR ({lazy_alloc_stc, refetch_loop_stc, sector_byteen_stc, lazy_fire, refetch_hold, fill_resident_st0, fill_evicted_st0, partial_match_st0})
    end

    `UNUSED_VAR (do_lookup_st0)

///////////////////////////////////////////////////////////////////////////////

`ifdef PERF_ENABLE
    assign perf_read_miss  = do_read_st1 && ~st1.lk.is_hit && ~lz_st1.is_park;
    assign perf_write_miss = do_write_st1 && ~st1.lk.is_hit;
    assign perf_evictions  = do_writeback_stc;
    assign perf_mshr_stall = mshr_alm_full;
`endif

`ifdef DBG_TRACE_CACHE
    wire crsp_queue_fire = crsp_queue_valid && crsp_queue_ready;
    wire input_stall = (replay_valid || mem_rsp_valid || core_req_valid || flush_valid)
                   && ~(replay_fire || mem_rsp_fire || core_req_fire || flush_fire);

    wire [`VX_CFG_XLEN-1:0] mem_rsp_full_addr = `CS_BANK_TO_FULL_ADDR(mem_rsp_addr, BANK_ID);
    wire [`VX_CFG_XLEN-1:0] replay_full_addr = `CS_BANK_TO_FULL_ADDR(replay_addr, BANK_ID);
    wire [`VX_CFG_XLEN-1:0] core_req_full_addr = `CS_BANK_TO_FULL_ADDR(core_req_addr, BANK_ID);
    wire [`VX_CFG_XLEN-1:0] full_addr_st0 = `CS_BANK_TO_FULL_ADDR(st0.req.addr, BANK_ID);
    wire [`VX_CFG_XLEN-1:0] full_addr_st1 = `CS_BANK_TO_FULL_ADDR(st1.req.addr, BANK_ID);
    wire [`CS_LINE_ADDR_WIDTH-1:0] mreq_queue_line = mreq_queue_addr[`CS_LINE_SECTOR_ADDR_WIDTH-1 -: `CS_LINE_ADDR_WIDTH];
    wire [`VX_CFG_XLEN-1:0] mreq_queue_full_addr = `CS_BANK_TO_FULL_ADDR(mreq_queue_line, BANK_ID)
        | ((`VX_CFG_XLEN'(mreq_queue_addr) & `VX_CFG_XLEN'((1 << `CS_SECTOR_SEL_BITS) - 1)) << `CLOG2(SECTOR_SIZE));

    always @(posedge clk) begin
        if (input_stall || pipe_stall) begin
            `TRACE(4, ("%t: *** %s stall: crsq=%b, mreq=%b, mshr=%b\n", $time, INSTANCE_ID,
                crsp_queue_stall, mreq_queue_alm_full, mshr_alm_full))
        end
        if (mem_rsp_fire) begin
            `TRACE(2, ("%t: %s fill-rsp: addr=0x%0h, mshr_id=%0d, refetch=%b, retry=%b, data=0x%h (#%0d)\n", $time, INSTANCE_ID,
                mem_rsp_full_addr, mem_rsp_id, mshr_fill_refetch, mshr_fill_retry, mem_rsp_data, req_uuid_sel))
        end
        if (lazy_fire) begin
            `TRACE(2, ("%t: %s lazy-fill: addr=0x%0h, mshr_id=%0d, refetch=%b\n", $time, INSTANCE_ID,
                mem_rsp_full_addr, lazyq_id, mshr_fill_refetch))
        end
        if (park_fire) begin
            `TRACE(2, ("%t: %s mshr-park: addr=0x%0h, tag=0x%0h, req_idx=%0d (#%0d)\n", $time, INSTANCE_ID,
                replay_full_addr, replay_tag, replay_idx, req_uuid_sel))
        end
        if (replay_fire) begin
            `TRACE(2, ("%t: %s mshr-pop: addr=0x%0h, tag=0x%0h, req_idx=%0d (#%0d)\n", $time, INSTANCE_ID,
                replay_full_addr, replay_tag, replay_idx, req_uuid_sel))
        end
        if (fwd_fire) begin
            `TRACE(2, ("%t: %s fwd-rsp: addr=0x%0h, tag=0x%0h, req_idx=%0d, data=0x%h\n", $time, INSTANCE_ID,
                replay_full_addr, replay_tag, replay_idx, fwd_word))
        end
        if (core_req_fire) begin
            if (core_req_rw) begin
                `TRACE(2, ("%t: %s core-wr-req: addr=0x%0h, tag=0x%0h, req_idx=%0d, byteen=0x%h, data=0x%h (#%0d)\n", $time, INSTANCE_ID,
                    core_req_full_addr, core_req_tag, core_req_idx, core_req_byteen, core_req_data, req_uuid_sel))
            end else begin
                `TRACE(2, ("%t: %s core-rd-req: addr=0x%0h, tag=0x%0h, req_idx=%0d (#%0d)\n", $time, INSTANCE_ID,
                    core_req_full_addr, core_req_tag, core_req_idx, req_uuid_sel))
            end
        end
        if (do_init_st0) begin
            `TRACE(3, ("%t: %s tags-init: addr=0x%0h, line=%0d\n", $time, INSTANCE_ID, full_addr_st0, line_idx_st0))
        end
        if (do_fill_st0 && ~pipe_stall) begin
            `TRACE(3, ("%t: %s tags-fill: addr=0x%0h, way=%0d, line=%0d, dirty=%b (#%0d)\n", $time, INSTANCE_ID,
                full_addr_st0, evict_way_st0, line_idx_st0, lk_st0.is_dirty, req_uuid_st0))
        end
        if (do_flush_st0 && ~pipe_stall) begin
            `TRACE(3, ("%t: %s tags-flush: addr=0x%0h, way=%0d, line=%0d, dirty=%b (#%0d)\n", $time, INSTANCE_ID,
                full_addr_st0, evict_way_st0, line_idx_st0, lk_st0.is_dirty, req_uuid_st0))
        end
        if (do_lookup_st0 && ~pipe_stall) begin
            if (lk_st0.is_hit) begin
                `TRACE(3, ("%t: %s tags-hit: addr=0x%0h, rw=%b, way=%0d, line=%0d, tag=0x%0h (#%0d)\n", $time, INSTANCE_ID,
                    full_addr_st0, st0.req.rw, hit_idx_st0, line_idx_st0, line_tag_st0, req_uuid_st0))
            end else begin
                `TRACE(3, ("%t: %s tags-miss: addr=0x%0h, rw=%b, way=%0d, line=%0d, tag=0x%0h (#%0d)\n", $time, INSTANCE_ID,
                    full_addr_st0, st0.req.rw, hit_idx_st0, line_idx_st0, line_tag_st0, req_uuid_st0))
            end
        end
        if (do_fill_st0 && ~pipe_stall) begin
            `TRACE(3, ("%t: %s data-fill: addr=0x%0h, way=%0d, line=%0d, data=0x%h (#%0d)\n", $time, INSTANCE_ID,
                full_addr_st0, evict_way_st0, line_idx_st0, fbuf_data_r, req_uuid_st0))
        end
        if (do_flush_st0 && ~pipe_stall) begin
            `TRACE(3, ("%t: %s data-flush: addr=0x%0h, way=%0d, line=%0d (#%0d)\n", $time, INSTANCE_ID,
                full_addr_st0, evict_way_st0, line_idx_st0, req_uuid_st0))
        end
        if (do_read_st1 && st1.lk.is_hit && ~pipe_stall) begin
            `TRACE(3, ("%t: %s data-read: addr=0x%0h, way=%0d, line=%0d, wsel=%0d (#%0d)\n", $time, INSTANCE_ID,
                full_addr_st1, st1.req.way_idx, st1.req.addr[`CS_LINE_SEL_BITS-1:0], st1.req.word_idx, req_uuid_st1))
        end
        if (do_write_st1 && st1.lk.is_hit && ~pipe_stall) begin
            `TRACE(3, ("%t: %s data-write: addr=0x%0h, way=%0d, line=%0d, wsel=%0d, byteen=0x%h (#%0d)\n", $time, INSTANCE_ID,
                full_addr_st1, st1.req.way_idx, st1.req.addr[`CS_LINE_SEL_BITS-1:0], st1.req.word_idx, st1.req.byteen, req_uuid_st1))
        end
        if (crsp_queue_fire) begin
            `TRACE(2, ("%t: %s core-rd-rsp: addr=0x%0h, tag=0x%0h, req_idx=%0d, data=0x%h (#%0d)\n", $time, INSTANCE_ID,
                addr_stc, stC.req.tag, stC.req.req_idx, crsp_queue_data, req_uuid_stc))
        end
        if (mreq_queue_push) begin
            if (!WRITEBACK && do_write_stc) begin
                `TRACE(2, ("%t: %s writethrough: addr=0x%0h, byteen=0x%h, data=0x%h (#%0d)\n", $time, INSTANCE_ID,
                    mreq_queue_full_addr, mreq_queue_byteen, mreq_queue_data, req_uuid_stc))
            end else if (WRITEBACK && do_writeback_stc) begin
                `TRACE(2, ("%t: %s writeback: addr=0x%0h, byteen=0x%h, data=0x%h (#%0d)\n", $time, INSTANCE_ID,
                    mreq_queue_full_addr, mreq_queue_byteen, mreq_queue_data, req_uuid_stc))
            end else begin
                `TRACE(2, ("%t: %s fill-req: addr=0x%0h, mshr_id=%0d (#%0d)\n", $time, INSTANCE_ID,
                    mreq_queue_full_addr, stC.req.mshr_id, req_uuid_stc))
            end
        end
    end
`endif

endmodule
