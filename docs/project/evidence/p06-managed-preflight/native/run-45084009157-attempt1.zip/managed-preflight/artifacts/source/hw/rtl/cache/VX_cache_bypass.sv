// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_cache_define.vh"

module VX_cache_bypass import VX_gpu_pkg::*; #(
    parameter NUM_REQS          = 1,
    parameter MEM_PORTS         = 1,
    parameter TAG_SEL_IDX       = 0,

    parameter CACHE_ENABLE      = 0,

    parameter WORD_SIZE         = 1,
    parameter LINE_SIZE         = 1,

    parameter CORE_ADDR_WIDTH   = 1,

    parameter CORE_TAG_WIDTH    = 1,

    parameter MEM_ADDRW    = 1,
    parameter MEM_TAG_IN_WIDTH  = 1,

    parameter CORE_OUT_BUF      = 0,
    parameter MEM_OUT_BUF       = 0
 ) (
    input wire clk,
    input wire reset,

    VX_mem_bus_if.slave     core_bus_in_if [NUM_REQS],
    VX_mem_bus_if.master    core_bus_out_if [NUM_REQS],
    VX_mem_bus_if.slave     mem_bus_in_if [MEM_PORTS],
    VX_mem_bus_if.master    mem_bus_out_if [MEM_PORTS],

    // no uncached or outgoing request held short of the memory side
    output wire             req_empty
);
    localparam DIRECT_PASSTHRU   = !CACHE_ENABLE && (`CS_WORD_SEL_BITS == 0) && (NUM_REQS == MEM_PORTS);
    localparam CORE_DATA_WIDTH   = WORD_SIZE * 8;
    localparam WORDS_PER_LINE    = LINE_SIZE / WORD_SIZE;
    localparam WSEL_BITS         = `CLOG2(WORDS_PER_LINE);
    localparam CORE_TAG_ID_WIDTH = CORE_TAG_WIDTH - UUID_WIDTH;
    localparam MEM_TAG_ID_WIDTH  = `CLOG2(`CDIV(NUM_REQS, MEM_PORTS)) + CORE_TAG_ID_WIDTH;
    localparam MEM_TAG_NC1_WIDTH = UUID_WIDTH + MEM_TAG_ID_WIDTH;
    localparam MEM_TAG_NC2_WIDTH = MEM_TAG_NC1_WIDTH + WSEL_BITS;
    localparam MEM_TAG_OUT_WIDTH = CACHE_ENABLE ? `MAX(MEM_TAG_IN_WIDTH, MEM_TAG_NC2_WIDTH) : MEM_TAG_NC2_WIDTH;
    // Beside a cache, the memory-side arbiter grants on valid, so spreading
    // uncached requests over more memory ports by their ready would close a
    // valid-ready loop: with fewer core ports, core port i keeps memory port i.
    localparam NC_PORTS          = CACHE_ENABLE ? `MIN(NUM_REQS, MEM_PORTS) : MEM_PORTS;
    `STATIC_ASSERT(0 == (`VX_MEM_IO_BASE_ADDR % `VX_CFG_MEM_BLOCK_SIZE), ("invalid parameter"))
    VX_mem_bus_if #(
        .DATA_SIZE (WORD_SIZE),
        .TAG_WIDTH (CORE_TAG_WIDTH)
    ) core_bus_nc_switch_if[(CACHE_ENABLE ? 2 : 1) * NUM_REQS]();
    wire [NUM_REQS-1:0] core_req_nc_sel;
    for (genvar i = 0; i < NUM_REQS; ++i) begin : g_core_req_is_nc
        if (CACHE_ENABLE) begin : g_cache
            // a flush token always reaches the cache, whatever its io kind bit
            assign core_req_nc_sel[i] = ~core_bus_in_if[i].req_data.attr[MEM_ATTR_IO_OFFS]
                                      | core_bus_in_if[i].req_data.attr[MEM_ATTR_FLUSH_OFFS];
        end else begin : g_no_cache
            assign core_req_nc_sel[i] = 1'b0;
        end
    end
    VX_mem_bus_switch #(
        .NUM_INPUTS  (NUM_REQS),
        .NUM_OUTPUTS ((CACHE_ENABLE ? 2 : 1) * NUM_REQS),
        .DATA_SIZE   (WORD_SIZE),
        .TAG_WIDTH   (CORE_TAG_WIDTH),
        .ARBITER     ("R"),
        .REQ_OUT_BUF (0),
        .RSP_OUT_BUF (DIRECT_PASSTHRU ? 0 : CORE_OUT_BUF)
    ) core_bus_nc_switch (
        .clk       (clk),
        .reset     (reset),
        .bus_sel   (core_req_nc_sel),
        .bus_in_if (core_bus_in_if),
        .bus_out_if(core_bus_nc_switch_if)
    );
    VX_mem_bus_if #(
        .DATA_SIZE (WORD_SIZE),
        .TAG_WIDTH (CORE_TAG_WIDTH)
    ) core_bus_in_nc_if[NUM_REQS]();
    for (genvar i = 0; i < NUM_REQS; ++i) begin : g_core_bus_nc_switch_if
        assign core_bus_in_nc_if[i].req_valid = core_bus_nc_switch_if[0 * NUM_REQS + i].req_valid;
        assign core_bus_in_nc_if[i].req_data  = core_bus_nc_switch_if[0 * NUM_REQS + i].req_data;
        assign core_bus_nc_switch_if[0 * NUM_REQS + i].req_ready = core_bus_in_nc_if[i].req_ready;
        assign core_bus_nc_switch_if[0 * NUM_REQS + i].rsp_valid = core_bus_in_nc_if[i].rsp_valid;
        assign core_bus_nc_switch_if[0 * NUM_REQS + i].rsp_data  = core_bus_in_nc_if[i].rsp_data;
        assign core_bus_in_nc_if[i].rsp_ready = core_bus_nc_switch_if[0 * NUM_REQS + i].rsp_ready;
        if (CACHE_ENABLE) begin : g_cache
            assign core_bus_out_if[i].req_valid = core_bus_nc_switch_if[1 * NUM_REQS + i].req_valid;
            assign core_bus_out_if[i].req_data  = core_bus_nc_switch_if[1 * NUM_REQS + i].req_data;
            assign core_bus_nc_switch_if[1 * NUM_REQS + i].req_ready = core_bus_out_if[i].req_ready;
            assign core_bus_nc_switch_if[1 * NUM_REQS + i].rsp_valid = core_bus_out_if[i].rsp_valid;
            assign core_bus_nc_switch_if[1 * NUM_REQS + i].rsp_data  = core_bus_out_if[i].rsp_data;
            assign core_bus_out_if[i].rsp_ready = core_bus_nc_switch_if[1 * NUM_REQS + i].rsp_ready;
        end else begin : g_no_cache
            `INIT_VX_MEM_BUS_IF (core_bus_out_if[i])
        end
    end
    VX_mem_bus_if #(
        .DATA_SIZE (WORD_SIZE),
        .TAG_WIDTH (MEM_TAG_NC1_WIDTH)
    ) core_bus_nc_arb_if[NC_PORTS]();
    VX_mem_bus_arb #(
        .NUM_INPUTS (NUM_REQS),
        .NUM_OUTPUTS(NC_PORTS),
        .DATA_SIZE  (WORD_SIZE),
        .TAG_WIDTH  (CORE_TAG_WIDTH),
        .TAG_SEL_IDX(TAG_SEL_IDX),
        .ARBITER    (CACHE_ENABLE ? "P" : "R"),
        .REQ_OUT_BUF(0),
        .RSP_OUT_BUF(0)
    ) core_bus_nc_arb (
        .clk        (clk),
        .reset      (reset),
        .bus_in_if  (core_bus_in_nc_if),
        .bus_out_if (core_bus_nc_arb_if)
    );
    VX_mem_bus_if #(
        .DATA_SIZE (LINE_SIZE),
        .TAG_WIDTH (MEM_TAG_NC2_WIDTH)
    ) mem_bus_out_nc_if[MEM_PORTS]();
    for (genvar i = 0; i < NC_PORTS; ++i) begin : g_mem_bus_out_nc
        wire                        core_req_nc_arb_rw;
        wire [WORD_SIZE-1:0]        core_req_nc_arb_byteen;
        wire [CORE_ADDR_WIDTH-1:0]  core_req_nc_arb_addr;
        wire [MEM_ATTR_WIDTH-1:0] core_req_nc_arb_attr;
        wire [CORE_DATA_WIDTH-1:0]  core_req_nc_arb_data;
        wire [MEM_TAG_NC1_WIDTH-1:0] core_req_nc_arb_tag;
        assign {
            core_req_nc_arb_rw,
            core_req_nc_arb_addr,
            core_req_nc_arb_data,
            core_req_nc_arb_byteen,
            core_req_nc_arb_attr,
            core_req_nc_arb_tag
        } = core_bus_nc_arb_if[i].req_data;
        logic [MEM_ADDRW-1:0] core_req_nc_arb_addr_w;
        logic [WORDS_PER_LINE-1:0][WORD_SIZE-1:0] core_req_nc_arb_byteen_w;
        logic [WORDS_PER_LINE-1:0][CORE_DATA_WIDTH-1:0] core_req_nc_arb_data_w;
        logic [CORE_DATA_WIDTH-1:0] core_rsp_nc_arb_data_w;
        wire [MEM_TAG_NC2_WIDTH-1:0] core_req_nc_arb_tag_w;
        wire [MEM_TAG_NC1_WIDTH-1:0] core_rsp_nc_arb_tag_w;
        if (WORDS_PER_LINE > 1) begin : g_multi_word_line
            wire [WSEL_BITS-1:0] rsp_wsel;
            wire [WSEL_BITS-1:0] req_wsel = core_req_nc_arb_addr[WSEL_BITS-1:0];
            always @(*) begin
                core_req_nc_arb_byteen_w = '0;
                core_req_nc_arb_byteen_w[req_wsel] = core_req_nc_arb_byteen;
                core_req_nc_arb_data_w = 'x;
                core_req_nc_arb_data_w[req_wsel] = core_req_nc_arb_data;
            end
            VX_bits_insert #(
                .N   (MEM_TAG_NC1_WIDTH),
                .S   (WSEL_BITS),
                .POS (TAG_SEL_IDX)
            ) wsel_insert (
                .data_in  (core_req_nc_arb_tag),
                .ins_in   (req_wsel),
                .data_out (core_req_nc_arb_tag_w)
            );
            VX_bits_remove #(
                .N   (MEM_TAG_NC1_WIDTH + WSEL_BITS),
                .S   (WSEL_BITS),
                .POS (TAG_SEL_IDX)
            ) wsel_remove (
                .data_in  (mem_bus_out_nc_if[i].rsp_data.tag),
                .sel_out  (rsp_wsel),
                .data_out (core_rsp_nc_arb_tag_w)
            );
            assign core_req_nc_arb_addr_w   = core_req_nc_arb_addr[WSEL_BITS +: MEM_ADDRW];
            assign core_rsp_nc_arb_data_w   = mem_bus_out_nc_if[i].rsp_data.data[rsp_wsel * CORE_DATA_WIDTH +: CORE_DATA_WIDTH];
        end else begin : g_single_word_line
            assign core_req_nc_arb_addr_w   = core_req_nc_arb_addr;
            assign core_req_nc_arb_byteen_w = core_req_nc_arb_byteen;
            assign core_req_nc_arb_data_w   = core_req_nc_arb_data;
            assign core_req_nc_arb_tag_w    = MEM_TAG_NC2_WIDTH'(core_req_nc_arb_tag);
            assign core_rsp_nc_arb_data_w   = mem_bus_out_nc_if[i].rsp_data.data;
            assign core_rsp_nc_arb_tag_w    = MEM_TAG_NC1_WIDTH'(mem_bus_out_nc_if[i].rsp_data.tag);
        end
        assign mem_bus_out_nc_if[i].req_valid = core_bus_nc_arb_if[i].req_valid;
        assign mem_bus_out_nc_if[i].req_data = {
            core_req_nc_arb_rw,
            core_req_nc_arb_addr_w,
            core_req_nc_arb_data_w,
            core_req_nc_arb_byteen_w,
            core_req_nc_arb_attr,
            core_req_nc_arb_tag_w
        };
        assign core_bus_nc_arb_if[i].req_ready = mem_bus_out_nc_if[i].req_ready;
        assign core_bus_nc_arb_if[i].rsp_valid = mem_bus_out_nc_if[i].rsp_valid;
        assign core_bus_nc_arb_if[i].rsp_data = {
            core_rsp_nc_arb_data_w,
            core_rsp_nc_arb_tag_w
        };
        assign mem_bus_out_nc_if[i].rsp_ready = core_bus_nc_arb_if[i].rsp_ready;
    end
    for (genvar i = NC_PORTS; i < MEM_PORTS; ++i) begin : g_mem_bus_out_nc_idle
        `INIT_VX_MEM_BUS_IF (mem_bus_out_nc_if[i])
    end
    VX_mem_bus_if #(
        .DATA_SIZE (LINE_SIZE),
        .TAG_WIDTH (MEM_TAG_OUT_WIDTH)
    ) mem_bus_out_src_if[(CACHE_ENABLE ? 2 : 1) * MEM_PORTS]();
    for (genvar i = 0; i < MEM_PORTS; ++i) begin : g_mem_bus_out_src
        `ASSIGN_VX_MEM_BUS_IF_EX(mem_bus_out_src_if[0 * MEM_PORTS + i], mem_bus_out_nc_if[i], MEM_TAG_OUT_WIDTH, MEM_TAG_NC2_WIDTH, UUID_WIDTH);
        if (CACHE_ENABLE) begin : g_cache
            `ASSIGN_VX_MEM_BUS_IF_EX(mem_bus_out_src_if[1 * MEM_PORTS + i], mem_bus_in_if[i], MEM_TAG_OUT_WIDTH, MEM_TAG_IN_WIDTH, UUID_WIDTH);
        end else begin : g_no_cache
            `UNUSED_VX_MEM_BUS_IF(mem_bus_in_if[i])
        end
    end
    VX_mem_bus_arb #(
        .NUM_INPUTS ((CACHE_ENABLE ? 2 : 1) * MEM_PORTS),
        .NUM_OUTPUTS(MEM_PORTS),
        .DATA_SIZE  (LINE_SIZE),
        .TAG_WIDTH  (MEM_TAG_OUT_WIDTH),
        .ARBITER    ("R"),
        .REQ_OUT_BUF(DIRECT_PASSTHRU ? 0 : MEM_OUT_BUF),
        .RSP_OUT_BUF(0)
    ) mem_bus_out_arb (
        .clk        (clk),
        .reset      (reset),
        .bus_in_if  (mem_bus_out_src_if),
        .bus_out_if (mem_bus_out_if)
    );

    if (!DIRECT_PASSTHRU) begin : g_req_pending
        localparam NUM_SRCS = NUM_REQS + (CACHE_ENABLE ? MEM_PORTS : 0);
        wire [NUM_SRCS-1:0]  src_fire;
        wire [MEM_PORTS-1:0] dst_fire;
        for (genvar i = 0; i < NUM_REQS; ++i) begin : g_nc_fire
            assign src_fire[i] = core_bus_in_nc_if[i].req_valid && core_bus_in_nc_if[i].req_ready;
        end
        if (CACHE_ENABLE) begin : g_cache_fire
            for (genvar i = 0; i < MEM_PORTS; ++i) begin : g_mem_in_fire
                assign src_fire[NUM_REQS + i] = mem_bus_in_if[i].req_valid && mem_bus_in_if[i].req_ready;
            end
        end
        for (genvar i = 0; i < MEM_PORTS; ++i) begin : g_dst_fire
            assign dst_fire[i] = mem_bus_out_if[i].req_valid && mem_bus_out_if[i].req_ready;
        end
        VX_mem_req_pending #(
            .NUM_INPUTS  (NUM_SRCS),
            .NUM_OUTPUTS (MEM_PORTS)
        ) req_pending (
            .clk      (clk),
            .reset    (reset),
            .in_fire  (src_fire),
            .out_fire (dst_fire),
            .empty    (req_empty)
        );
    end else begin : g_no_req_pending
        assign req_empty = 1'b1;
    end
endmodule
