//!/bin/bash

// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_raster_define.vh"

module VX_raster_dcr import VX_gpu_pkg::*, VX_raster_pkg::*;
`ifdef VX_CFG_RASTER_EARLYZ_ENABLE
    import VX_om_pkg::*;   // early-Z depth-config DCRs
`endif
#(
    parameter `STRING INSTANCE_ID = ""
) (
    input wire clk,
    input wire reset,

    // Inputs
    VX_dcr_bus_if.slave     dcr_bus_if,

    // Output
    output raster_dcrs_t    raster_dcrs
);
    `UNUSED_SPARAM (INSTANCE_ID)
`ifndef VX_CFG_RASTER_EARLYZ_ENABLE
    `UNUSED_VAR (reset)
`endif

    // Decode write strobe from the req-style DCR bus
    wire write_valid = dcr_bus_if.req_valid && dcr_bus_if.req_data.rw;
    wire [VX_DCR_ADDR_WIDTH-1:0] write_addr = dcr_bus_if.req_data.addr;
    wire [VX_DCR_DATA_WIDTH-1:0] write_data = dcr_bus_if.req_data.data;
    `UNUSED_VAR (write_data[31])

    // Tie off response side
    assign dcr_bus_if.rsp_valid = 1'b0;
    assign dcr_bus_if.rsp_data  = '0;

    // DCR registers
    raster_dcrs_t dcrs;

    // DCRs write. The early-Z gate resets off: a draw that never programs the
    // OM depth state must not cull, or read a depth buffer at a power-on
    // address.
    always @(posedge clk) begin
    `ifdef VX_CFG_RASTER_EARLYZ_ENABLE
        if (reset) begin
            dcrs.earlyz_safe <= 1'b0;
            dcrs.depth_func  <= OM_DEPTH_FUNC_BITS'(`VX_OM_DEPTH_FUNC_ALWAYS);
        end else
    `endif
        if (write_valid) begin
            case (write_addr)
                `VX_DCR_RASTER_TBUF_ADDR: begin
                    dcrs.tbuf_addr <= write_data[`RASTER_ADDR_BITS-1:0];
                end
                `VX_DCR_RASTER_TILE_COUNT: begin
                    dcrs.tile_count <= write_data[`RASTER_TILE_BITS-1:0];
                end
                `VX_DCR_RASTER_PBUF_ADDR: begin
                    dcrs.pbuf_addr <= write_data[`RASTER_ADDR_BITS-1:0];
                end
                `VX_DCR_RASTER_PBUF_STRIDE: begin
                    dcrs.pbuf_stride <= write_data[`VX_RASTER_STRIDE_BITS-1:0];
                end
               `VX_DCR_RASTER_SCISSOR_X: begin
                    dcrs.dst_xmin <= write_data[0 +: `VX_RASTER_DIM_BITS];
                    dcrs.dst_xmax <= write_data[16 +: `VX_RASTER_DIM_BITS];
                end
                `VX_DCR_RASTER_SCISSOR_Y: begin
                    dcrs.dst_ymin <= write_data[0 +: `VX_RASTER_DIM_BITS];
                    dcrs.dst_ymax <= write_data[16 +: `VX_RASTER_DIM_BITS];
                end
            `ifdef VX_CFG_RASTER_EARLYZ_ENABLE
                // Early-Z: snoop the shared OM depth-buffer config. The DCR bus is
                // broadcast to every graphics unit, so the raster unit decodes the
                // OM depth DCRs directly (no extra routing).
                `VX_DCR_OM_ZBUF_ADDR: begin
                    dcrs.zbuf_addr <= write_data[`RASTER_ADDR_BITS-1:0];
                end
                `VX_DCR_OM_ZBUF_PITCH: begin
                    dcrs.zbuf_pitch <= write_data[OM_PITCH_BITS-1:0];
                end
                `VX_DCR_OM_DEPTH_FUNC: begin
                    dcrs.depth_func <= write_data[OM_DEPTH_FUNC_BITS-1:0];
                end
                `VX_DCR_OM_EARLYZ_SAFE: begin
                    dcrs.earlyz_safe <= write_data[0];
                end
            `endif
                default:;
            endcase
        end
    end

    assign raster_dcrs = dcrs;

`ifdef DBG_TRACE_RASTER
    always @(posedge clk) begin
        if (write_valid) begin
            `TRACE(1, ("%d: %s-raster-dcr: state=", $time, INSTANCE_ID))
            `TRACE_RASTER_DCR(1, write_addr)
            `TRACE(1, (", data=0x%0h\n", write_data))
        end
    end
`endif

endmodule
