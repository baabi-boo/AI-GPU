// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

module VX_tcu_tfr_mul_f8 import VX_tcu_pkg::*;
#(
    parameter `STRING INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10,
    parameter USE_DSP = 0,  // map mantissa multipliers onto DSP48 slices
    parameter PROD_REG = 0  // product/flag register stages (multiply-stage seam)
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,

    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_f,

    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
`ifdef VX_CFG_TCU_MX_ENABLE
    input wire [7:0]                sf_a,
    input wire [7:0]                sf_b,
`endif

    // result_exp/exceptions are pre-seam (classify cycle); result_sig and
    // sig_zero are post-seam (PROD_REG cycles later). sig_zero flags exact
    // cancellation of the two sub-products: the joined exponent must be
    // zeroed so the lane is excluded from the max-exponent search.
    output logic [TCK-1:0][24:0]      result_sig,
    output logic [TCK-1:0][EXP_W-1:0] result_exp,
    output fedp_excep_t [TCK-1:0]     exceptions,
    output wire  [TCK-1:0]            sig_zero
);
    `UNUSED_SPARAM (INSTANCE_ID)
    `UNUSED_VAR ({clk, req_id, valid_in})
    `UNUSED_VAR (vld_mask)

    localparam F32_BIAS  = 127;
    localparam S_FP32    = 23;
    localparam S_SUPER   = 22;
    // f8 lanes need 2*ALIGN_SHIFT (one per sub-product)
    localparam BIAS_BASE = F32_BIAS + 2*(S_FP32 - S_SUPER) - W + WA - 1 + 128;

    localparam E_FP8 = VX_tcu_pkg::exp_bits(TCU_FP8_ID);
    localparam S_FP8 = VX_tcu_pkg::sign_pos(TCU_FP8_ID);
    localparam B_FP8 = (1 << (E_FP8 - 1)) - 1;
    localparam [7:0] BIAS_CONST_FP8  = 8'(BIAS_BASE - 2*B_FP8);

    localparam E_BF8 = VX_tcu_pkg::exp_bits(TCU_BF8_ID);
    localparam S_BF8 = VX_tcu_pkg::sign_pos(TCU_BF8_ID);
    localparam B_BF8 = (1 << (E_BF8 - 1)) - 1;
    localparam [7:0] BIAS_CONST_BF8  = 8'(BIAS_BASE - 2*B_BF8);

    for (genvar i = 0; i < TCK; ++i) begin : g_lane

        wire [1:0] lane_valid = {vld_mask[i * 4 + 2], vld_mask[i * 4 + 0]};
        wire is_bfloat = tcu_fmt_is_bfloat(fmt_f);

        wire [1:0][4:0] ea_sel, eb_sel;
        wire [1:0][3:0] ma_sel, mb_sel;
        wire [1:0]      zero_sel, sign_sel, nan_sel, inf_sel;

        for (genvar j = 0; j < 2; ++j) begin : g_extract
            localparam OFF = (i % 2) * 16 + j * 8;

            wire [7:0] raw_a = a_row[i/2][OFF +: 8];
            wire [7:0] raw_b = b_col[i/2][OFF +: 8];

            logic [4:0] raw_ea, raw_eb;
            logic [2:0] raw_ma, raw_mb;
            logic       raw_sa, raw_sb;

            always_comb begin
                if (is_bfloat) begin // TCU_BF8_ID (E5M2)
                    raw_ea  = 5'(raw_a[S_BF8-1 -: E_BF8]);
                    raw_eb  = 5'(raw_b[S_BF8-1 -: E_BF8]);
                    raw_ma  = {raw_a[1:0], 1'b0};
                    raw_mb  = {raw_b[1:0], 1'b0};
                    raw_sa  = raw_a[7];
                    raw_sb  = raw_b[7];
                end else begin       // TCU_FP8_ID (E4M3)
                    raw_ea  = 5'(raw_a[S_FP8-1 -: E_FP8]);
                    raw_eb  = 5'(raw_b[S_FP8-1 -: E_FP8]);
                    raw_ma  = raw_a[2:0];
                    raw_mb  = raw_b[2:0];
                    raw_sa  = raw_a[7];
                    raw_sb  = raw_b[7];
                end
            end

            fedp_class_t cls_a;
            VX_tcu_tfr_classifier #(
                .EXP_W (5),
                .MAN_W (3)
            ) class_a (
                .exp (raw_ea),
                .man (raw_ma),
                .cls (cls_a)
            );

            fedp_class_t cls_b;
            VX_tcu_tfr_classifier #(
                .EXP_W (5),
                .MAN_W (3)
            ) class_b (
                .exp (raw_eb),
                .man (raw_mb),
                .cls (cls_b)
            );

            wire is_ea_zero = (raw_ea == 0);
            wire is_eb_zero = (raw_eb == 0);

            assign ea_sel[j] = is_ea_zero ? 5'b1 : raw_ea;
            assign eb_sel[j] = is_eb_zero ? 5'b1 : raw_eb;
            // Invalid lanes zero the A mantissa so the product is zero.
            assign ma_sel[j] = lane_valid[j] ? {~is_ea_zero, raw_ma} : 4'b0;
            assign mb_sel[j] = {~is_eb_zero, raw_mb};
            `UNUSED_VAR (cls_a.is_sub)
            `UNUSED_VAR (cls_b.is_sub)

            assign sign_sel[j] = raw_sa ^ raw_sb;
            assign zero_sel[j] = cls_a.is_zero | cls_b.is_zero;

            // Exception resolution
            wire a_is_inf = is_bfloat ? cls_a.is_inf : 1'b0;
            wire b_is_inf = is_bfloat ? cls_b.is_inf : 1'b0;
            wire a_is_nan = is_bfloat ? cls_a.is_nan : (raw_ea == 5'h0F) && (raw_ma == 3'b111);
            wire b_is_nan = is_bfloat ? cls_b.is_nan : (raw_eb == 5'h0F) && (raw_mb == 3'b111);

            wire nan_in = a_is_nan | b_is_nan;
            wire inf_z  = (a_is_inf & cls_b.is_zero) | (cls_a.is_zero & b_is_inf);
            wire inf_op = a_is_inf | b_is_inf;

            assign nan_sel[j] = nan_in | inf_z;
            assign inf_sel[j] = inf_op & ~inf_z;
        end

        wire [5:0] pre_sum_0, pre_sum_1;

        VX_ks_adder #(
            .N(6),
            .BYPASS(`FORCE_BUILTIN_ADDER(6))
        ) exp_add1_0 (
            .dataa(6'(ea_sel[0])),
            .datab(6'(eb_sel[0])),
            .cin(1'b0),
            .sum(pre_sum_0),
            `UNUSED_PIN(cout)
        );

        VX_ks_adder #(
            .N(6),
            .BYPASS(`FORCE_BUILTIN_ADDER(6))
        ) exp_add1_1 (
            .dataa(6'(ea_sel[1])),
            .datab(6'(eb_sel[1])),
            .cin(1'b0),
            .sum(pre_sum_1),
            `UNUSED_PIN(cout)
        );

        wire v0 = ~zero_sel[0] && lane_valid[0];
        wire v1 = ~zero_sel[1] && lane_valid[1];

        // Pre-sort by exponent and compute both differences in parallel.
        wire [6:0] diff_0_minus_1 = {1'b0, pre_sum_0} - {1'b0, pre_sum_1};
        wire [6:0] diff_1_minus_0 = {1'b0, pre_sum_1} - {1'b0, pre_sum_0};
        `UNUSED_VAR (diff_1_minus_0[6])

        wire term0_ge_term1 = ~diff_0_minus_1[6];
        // A zero or masked sub-product never sets the lane exponent.
        wire term0_is_max = (v0 & ~v1) || (v0 & v1 & term0_ge_term1);
        wire diff_sign = term0_is_max;

        wire [5:0] diff_abs = term0_is_max ? diff_0_minus_1[5:0] : diff_1_minus_0[5:0];
        wire [5:0] max_pre_sum = term0_is_max ? pre_sum_0 : pre_sum_1;

        wire [7:0] bias_sel = is_bfloat ? BIAS_CONST_BF8 : BIAS_CONST_FP8;

        // One bit wider than the exponent, signed: the E8M0 scales (2^-254 ..
        // 2^256 together) can take a lane below the exponent range, where it
        // only adds to the sticky bit.
        localparam SX = EXP_W + 1;
        wire [SX-1:0] max_pre_sum_cpa, bias_sel_cpa;
        wire [SX-1:0] final_exp_s;

    `ifdef VX_CFG_TCU_MX_ENABLE
        wire [SX-1:0] bias_cpa_sum, bias_cpa_carry;
        wire [3*SX-1:0] sf_comp = fmt_f[3] ? {SX'(sf_a), SX'(sf_b), -SX'(254)} : (3*SX)'(0);
        VX_csa_tree #(
            .N(4),
            .W(SX),
            .S(SX)
        ) exp_sf_csa (
            .operands ({SX'(bias_sel), sf_comp}),
            .sum      (bias_cpa_sum),
            .carry    (bias_cpa_carry)
        );
        VX_ks_adder #(
            .N(SX),
            .BYPASS(`FORCE_BUILTIN_ADDER(SX))
        ) exp_bias_add (
            .dataa(bias_cpa_sum),
            .datab(bias_cpa_carry),
            .cin(1'b0),
            .sum(bias_sel_cpa),
            `UNUSED_PIN(cout)
        );
    `else
        assign bias_sel_cpa = SX'(bias_sel);
    `endif
        assign max_pre_sum_cpa = SX'(max_pre_sum);
        VX_ks_adder #(
            .N(SX),
            .BYPASS(`FORCE_BUILTIN_ADDER(SX))
        ) exp_final_add (
            .dataa(max_pre_sum_cpa),
            .datab(bias_sel_cpa),
            .cin(1'b0),
            .sum(final_exp_s),
            `UNUSED_PIN(cout)
        );
        wire [EXP_W-1:0] final_exp = final_exp_s[SX-1] ? '0 : final_exp_s[EXP_W-1:0];

        // The two fp8 mantissa products in a lane are independent unsigned 4x4
        // multiplies — small enough to pack into a single DSP48 (USE_DSP),
        // halving the f8 DSP count vs one DSP per product. PROD_REG lands the
        // products in the DSP48 PREG.
        wire [1:0][7:0] man_prod;
        VX_tcu_tfr_wmul #(
            .N       (4),
            .LANES   (2),
            .USE_DSP (USE_DSP),
            .OUT_REG (PROD_REG)
        ) wtmul (
            .clk    (clk),
            .enable (enable),
            .a (ma_sel),
            .b (mb_sel),
            .p (man_prod)
        );

        // Sort/align controls depend only on exponents and signs: pre-seam
        // compute, post-seam use.
        wire       diff_sign_r;
        wire       diff_ge_32_r;
        wire [4:0] shamt_r;
        wire [1:0] sign_sel_r;
        wire       pre_sum_eq_r;
        VX_pipe_register #(
            .DATAW (1 + 1 + 5 + 2 + 1),
            .DEPTH (PROD_REG)
        ) pipe_ctrl (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  ({diff_sign,   diff_abs[5],  diff_abs[4:0], sign_sel,   (pre_sum_0 == pre_sum_1)}),
            .data_out ({diff_sign_r, diff_ge_32_r, shamt_r,       sign_sel_r, pre_sum_eq_r})
        );

        wire [7:0] prod_max = diff_sign_r ? man_prod[0] : man_prod[1];
        wire [7:0] prod_min = diff_sign_r ? man_prod[1] : man_prod[0];
        wire       sign_max = diff_sign_r ? sign_sel_r[0] : sign_sel_r[1];
        wire       sign_min = diff_sign_r ? sign_sel_r[1] : sign_sel_r[0];

        // Alignment
        wire [23:0] sig_max = {prod_max, 16'b0};
        wire [23:0] sig_min_shifted = diff_ge_32_r ? 24'b0 : ({prod_min, 16'b0} >> shamt_r);

        // Add/sub reduction
        wire [24:0] sig_max_ext = {1'b0, sig_max};
        wire [24:0] sig_min_ext = {1'b0, sig_min_shifted};

        wire do_sub = sign_sel_r[0] ^ sign_sel_r[1];

        wire [24:0] add_raw;
        VX_ks_adder #(
            .N(25),
            .BYPASS(`FORCE_BUILTIN_ADDER(25))
        ) add_adder (
            .dataa(sig_max_ext),
            .datab(sig_min_ext),
            .cin(1'b0),
            .sum(add_raw),
            `UNUSED_PIN(cout)
        );

        wire [24:0] sub_raw;
        VX_ks_adder #(
            .N(25),
            .BYPASS(`FORCE_BUILTIN_ADDER(25))
        ) sub_adder (
            .dataa(sig_max_ext),
            .datab(~sig_min_ext),
            .cin(1'b1),
            .sum(sub_raw),
            `UNUSED_PIN(cout)
        );

        // The reverse difference runs beside the forward one, so the magnitude
        // is a select rather than a negate behind the subtract.
        wire [24:0] sub_rev;
        VX_ks_adder #(
            .N(25),
            .BYPASS(`FORCE_BUILTIN_ADDER(25))
        ) sub_rev_adder (
            .dataa(sig_min_ext),
            .datab(~sig_max_ext),
            .cin(1'b1),
            .sum(sub_rev),
            `UNUSED_PIN(cout)
        );

        wire sub_neg = sub_raw[24];
        wire [24:0] sub_abs = sub_neg ? sub_rev : sub_raw;
        wire [24:0] sig_add_raw = do_sub ? sub_abs : add_raw;

        // Scaling by 1 avoids renormalization.
        wire [23:0] sig_add = sig_add_raw[24:1];
        `UNUSED_VAR (sig_add_raw[0])

        wire mag_is_equal = pre_sum_eq_r && (man_prod[0] == man_prod[1]);
        wire is_zero_out = do_sub && mag_is_equal;

        wire sig_sign_raw = sub_neg ? sign_min : sign_max;
        wire sig_sign = is_zero_out ? 1'b0 : sig_sign_raw;

        assign result_sig[i] = {sig_sign, sig_add};
        assign sig_zero[i]   = is_zero_out;
        assign result_exp[i] = (v0 || v1) ? final_exp : '0;

        // Exception merging. Not gated by lane_valid: a lane masked for a zero
        // operand still has to turn Inf x 0 and NaN x 0 into NaN.
        wire pos_inf_0 = inf_sel[0] && ~sign_sel[0];
        wire neg_inf_0 = inf_sel[0] &&  sign_sel[0];
        wire pos_inf_1 = inf_sel[1] && ~sign_sel[1];
        wire neg_inf_1 = inf_sel[1] &&  sign_sel[1];

        wire add_nan = (pos_inf_0 && neg_inf_1) || (neg_inf_0 && pos_inf_1);

    `ifdef VX_CFG_TCU_MX_ENABLE
        // an E8M0 scale of 0xFF is NaN, and so is every element it scales
        wire sf_nan = fmt_f[3] && ((sf_a == 8'hFF) || (sf_b == 8'hFF));
    `else
        wire sf_nan = 1'b0;
    `endif
        wire any_nan = (|nan_sel) || add_nan || sf_nan;
        wire any_inf = (|inf_sel) && ~any_nan;

        wire final_sign_inf = inf_sel[0] ? sign_sel[0] : sign_sel[1];

        // The sign field is only consumed for infinity lanes downstream.
        assign exceptions[i].is_nan = any_nan;
        assign exceptions[i].is_inf = any_inf;
        assign exceptions[i].sign   = final_sign_inf;

    `ifdef DBG_TRACE_TCU
        wire        trace_valid;
        wire [31:0] trace_req_id;
        wire [1:0]  trace_lane_valid;
        VX_pipe_register #(
            .DATAW (1 + 32 + 2),
            .DEPTH (PROD_REG)
        ) pipe_trace (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  ({valid_in,    req_id,       lane_valid}),
            .data_out ({trace_valid, trace_req_id, trace_lane_valid})
        );
        always_ff @(posedge clk) begin
            if (trace_valid && trace_lane_valid != 0) begin
                `TRACE(4, ("%t: %s FEDP-REDUCE(%0d) lane=%0d: ", $time, INSTANCE_ID, trace_req_id, i));
                `TRACE(4, ("max=(%0d, 0x%0h), ", sign_max, sig_max));
                `TRACE(4, ("min=(%0d, 0x%0h) ", sign_min, sig_min_shifted));
                `TRACE(4, ("-> s=%0d, P=0x%0h\n", sig_sign, sig_add));
            end
        end
    `endif

    end

endmodule
