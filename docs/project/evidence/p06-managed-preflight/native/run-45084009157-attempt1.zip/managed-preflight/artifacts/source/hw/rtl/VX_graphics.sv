// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Cluster-level wrapper that owns the shared RASTER and OM units
// and their associated caches (rcache / ocache).

`include "VX_define.vh"

module VX_graphics import VX_gpu_pkg::*
`ifdef VX_CFG_EXT_OM_ENABLE
    , VX_om_pkg::*
`endif
; #(
    parameter `STRING INSTANCE_ID = ""
) (
    `SCOPE_IO_DECL

    input wire              clk,
    input wire              reset,

    input wire [CLUSTER_ID_WIDTH-1:0] cluster_id,

`ifdef PERF_ENABLE
`ifdef VX_CFG_EXT_RASTER_ENABLE
    output raster_perf_t    raster_perf,
    output cache_perf_t     rcache_perf,
`endif
`ifdef VX_CFG_EXT_OM_ENABLE
    output om_perf_t        om_perf,
    output cache_perf_t     ocache_perf,
`endif
`endif

`ifdef VX_CFG_EXT_RASTER_ENABLE
    // Fragment launches out of the cluster's raster engines, merged onto the
    // cluster's KMU launch stream (the stamp rides inside the launch).
    VX_kmu_bus_if.master    raster_kmu_bus_if[1],
    VX_mem_bus_if.master    rcache_mem_bus_if,
    // Delegated draw launch (device KMU → raster engines)
    VX_raster_launch_if.slave raster_launch_if[1],
`endif

`ifdef VX_CFG_EXT_OM_ENABLE
    // Socket->L2 trunk in/out: VX_om_steer peels the fragment-export writes off it.
    // The socket->L2 trunk passes through here: the OM aperture steer peels the
    // fragment-export writes off it, so the whole OM path lives in this module.
    VX_mem_bus_if.slave     socket_mem_bus_if [L2_SOCKET_REQS],
    VX_mem_bus_if.master    l2_out_bus_if     [L2_SOCKET_REQS],
    VX_mem_bus_if.master    ocache_mem_bus_if,
`endif

    // DCR (raw cluster-level slave; each unit's DCR slave filters by addr)
    VX_dcr_bus_if.slave     dcr_bus_if,

    // Cluster-level flush trigger.
    VX_dcr_flush_if.slave   cluster_flush_if,

`ifdef CLUSTER_UNIT_MMU_ENABLE
    // Address-space change (SATP commit): the rcache and ocache are virtually
    // tagged, so the ocache drains its writes and both invalidate.
    VX_dcr_flush_if.slave   mmu_flush_if,
`endif

    // Producer busy — the raster engine signals frame drain out-of-band (it has
    // no in-band `done`); the cluster ORs this into the device busy aggregation.
    output wire             busy
);

`ifdef SCOPE
`ifdef VX_CFG_EXT_RASTER_ENABLE
    localparam scope_raster_cnt = `VX_CFG_NUM_RASTER_CORES;
`else
    localparam scope_raster_cnt = 0;
`endif
`ifdef VX_CFG_EXT_OM_ENABLE
    localparam scope_om_cnt = `VX_CFG_NUM_OM_CORES;
`else
    localparam scope_om_cnt = 0;
`endif
    `SCOPE_IO_SWITCH (scope_raster_cnt + scope_om_cnt);
`endif
    `UNUSED_SPARAM (INSTANCE_ID)
`ifndef VX_CFG_EXT_RASTER_ENABLE
    `UNUSED_VAR (cluster_id)
`endif

    wire rcache_req_empty;
    wire ocache_req_empty;

    // Fan one DCR slave input out to one master per consumer unit. Each
    // unit's internal case-statement filters by DCR address range. The
    // VX_dcr_arb owns the rsp_valid/rsp_data signaling on dcr_bus_if so
    // VX_graphics doesn't drive them itself.
    localparam NUM_DCR_REQS = `VX_CFG_EXT_RASTER_ENABLED * `VX_CFG_NUM_RASTER_CORES
                            + `VX_CFG_EXT_OM_ENABLED * `VX_CFG_NUM_OM_CORES;

    VX_dcr_bus_if per_unit_dcr_bus_if [`UP(NUM_DCR_REQS)] ();

    VX_dcr_arb #(
        .NUM_REQS    (NUM_DCR_REQS),
        .REQ_OUT_BUF ((NUM_DCR_REQS > 1) ? 1 : 0)
    ) dcr_unit_arb (
        .clk        (clk),
        .reset      (reset),
        .bus_in_if  (dcr_bus_if),
        .bus_out_if (per_unit_dcr_bus_if)
    );

`ifdef VX_CFG_EXT_RASTER_ENABLE
    localparam DCR_RASTER_BASE = 0;
`endif
`ifdef VX_CFG_EXT_OM_ENABLE
    localparam DCR_OM_BASE     = `VX_CFG_EXT_RASTER_ENABLED * `VX_CFG_NUM_RASTER_CORES;
`endif

    /////////////////////////////////////////////////////////////////////////////
    // RASTER
    /////////////////////////////////////////////////////////////////////////////

`ifdef VX_CFG_EXT_RASTER_ENABLE

    VX_mem_bus_if #(
        .DATA_SIZE (RCACHE_WORD_SIZE),
        .TAG_WIDTH (RCACHE_TAG_WIDTH)
    ) rcache_bus_if [`VX_CFG_NUM_RASTER_CORES * RCACHE_NUM_REQS] ();

    VX_kmu_bus_if raster_core_kmu_if [`VX_CFG_NUM_RASTER_CORES] ();

`ifdef VX_CFG_RASTER_EARLYZ_ENABLE
    // Early-Z committed-depth read ports: one OCACHE_NUM_REQS group per raster
    // engine, attached as extra ocache NUM_INPUTS in the OM block below so the
    // read is coherent with the OM's write-through depth stores.
    VX_mem_bus_if #(
        .DATA_SIZE (OCACHE_WORD_SIZE),
        .TAG_WIDTH (OCACHE_EARLYZ_TAG_WIDTH)
    ) earlyz_ocache_bus_if [`VX_CFG_NUM_RASTER_CORES * OCACHE_NUM_REQS] ();
`endif

`ifdef PERF_ENABLE
    VX_raster_perf_if per_core_raster_perf_if [`VX_CFG_NUM_RASTER_CORES] ();
`endif

    VX_raster_launch_if per_core_raster_launch_if[`VX_CFG_NUM_RASTER_CORES]();
    VX_raster_launch_fork #(
        .NUM_OUTPUTS (`VX_CFG_NUM_RASTER_CORES)
    ) raster_launch_fork (
        .clk        (clk),
        .reset      (reset),
        .bus_in_if  (raster_launch_if[0]),
        .bus_out_if (per_core_raster_launch_if)
    );

    wire [`VX_CFG_NUM_RASTER_CORES-1:0] raster_busy_w;

    for (genvar i = 0; i < `VX_CFG_NUM_RASTER_CORES; ++i) begin : g_raster_core
        VX_raster_core #(
            .INSTANCE_ID     (`SFORMATF(("%s-raster%0d", INSTANCE_ID, i))),
            .NUM_INSTANCES   (`VX_CFG_NUM_CLUSTERS * `VX_CFG_NUM_RASTER_CORES),
            .NUM_SLICES      (`VX_CFG_RASTER_NUM_SLICES),
            // The front end's top-level walk unit is a coarse bin: bin_x/bin_y
            // arrive at BIN_LOG_SIZE granularity and VX_raster_te recursively
            // refines bin -> block -> quad, so the core's TILE_LOGSIZE must
            // carry BIN_LOG_SIZE to match. Note the te TILE_FIFO_DEPTH grows
            // as 4^(BIN-BLOCK).
            .TILE_LOGSIZE    (`VX_CFG_RASTER_BIN_LOG_SIZE),
            .BLOCK_LOGSIZE   (`VX_CFG_RASTER_BLOCK_LOG_SIZE),
            .MEM_FIFO_DEPTH  (`VX_CFG_RASTER_MEM_FIFO_DEPTH),
            .QUAD_FIFO_DEPTH (`VX_CFG_RASTER_QUAD_FIFO_DEPTH),
            .OUTPUT_QUADS    (`VX_CFG_NUM_THREADS)
        ) raster_core (
            `SCOPE_IO_BIND (i)
            .clk             (clk),
            .reset           (reset),
            .instance_idx    (`LOG2UP(`VX_CFG_NUM_CLUSTERS * `VX_CFG_NUM_RASTER_CORES)'(cluster_id) * `LOG2UP(`VX_CFG_NUM_CLUSTERS * `VX_CFG_NUM_RASTER_CORES)'(`VX_CFG_NUM_RASTER_CORES)
                            + `LOG2UP(`VX_CFG_NUM_CLUSTERS * `VX_CFG_NUM_RASTER_CORES)'(i)),
        `ifdef PERF_ENABLE
            .perf_raster_if  (per_core_raster_perf_if[i]),
        `endif
            .dcr_bus_if      (per_unit_dcr_bus_if[DCR_RASTER_BASE + i]),
            .launch_if       (per_core_raster_launch_if[i]),
            .kmu_bus_if      (raster_core_kmu_if[i]),
            .cache_bus_if    (rcache_bus_if[i * RCACHE_NUM_REQS +: RCACHE_NUM_REQS]),
        `ifdef VX_CFG_RASTER_EARLYZ_ENABLE
            .earlyz_cache_bus_if (earlyz_ocache_bus_if[i * OCACHE_NUM_REQS +: OCACHE_NUM_REQS]),
        `endif
            .busy            (raster_busy_w[i])
        );
    end

`ifdef PERF_ENABLE
    wire [`VX_CFG_NUM_RASTER_CORES-1:0][PERF_CTR_BITS-1:0] ras_mr_w, ras_ml_w, ras_sc_w;
    for (genvar i = 0; i < `VX_CFG_NUM_RASTER_CORES; ++i) begin : g_ras_perf_pack
        assign ras_mr_w[i] = per_core_raster_perf_if[i].mem_reads;
        assign ras_ml_w[i] = per_core_raster_perf_if[i].mem_latency;
        assign ras_sc_w[i] = per_core_raster_perf_if[i].stall_cycles;
    end
    raster_perf_t raster_perf_sum;
    always @(*) begin
        raster_perf_sum = '0;
        for (int i = 0; i < `VX_CFG_NUM_RASTER_CORES; ++i) begin
            raster_perf_sum.mem_reads    = raster_perf_sum.mem_reads    + ras_mr_w[i];
            raster_perf_sum.mem_latency  = raster_perf_sum.mem_latency  + ras_ml_w[i];
            raster_perf_sum.stall_cycles = raster_perf_sum.stall_cycles + ras_sc_w[i];
        end
    end
    assign raster_perf = raster_perf_sum;
`endif

    // Merge the engines' launch streams into the one this cluster hands to its
    // launch arbiter. Message-granular, so a multi-beat fragment launch stays
    // whole.
    //
    // OUT_BUF holds launch descriptors that have left the raster engine but not yet
    // reached the launch arbiter, so a beat resident in it is folded into
    // `raster_kmu_busy` below, keeping the grid busy until every fragment launch drains.
    VX_kmu_bus_arb #(
        .NUM_INPUTS  (`VX_CFG_NUM_RASTER_CORES),
        .NUM_OUTPUTS (1),
        .ARBITER     ("R"),
        .OUT_BUF     (3)   // register the cluster-crossing launch stream
    ) raster_kmu_merge (
        .clk        (clk),
        .reset      (reset),
        .bus_in_if  (raster_core_kmu_if),
        .bus_out_if (raster_kmu_bus_if)
    );

    // Launch liveness: a fragment launch beat still in the merge -- at a raster core
    // input or in the registered merge output skid -- folds into graphics busy so the
    // grid does not complete with fragment launches queued.
    wire [`VX_CFG_NUM_RASTER_CORES-1:0] raster_core_kmu_valid;
    for (genvar i = 0; i < `VX_CFG_NUM_RASTER_CORES; ++i) begin : g_raster_kmu_valid
        assign raster_core_kmu_valid[i] = raster_core_kmu_if[i].valid;
    end
    wire raster_kmu_busy = (| raster_core_kmu_valid) | raster_kmu_bus_if[0].valid;

    VX_mem_bus_if #(
        .DATA_SIZE (RCACHE_LINE_SIZE),
        .TAG_WIDTH (RCACHE_MEM_TAG_WIDTH)
    ) rcache_mem_bus_tmp_if [RCACHE_MEM_PORTS] ();

    VX_mem_bus_if #(
        .DATA_SIZE (RCACHE_WORD_SIZE),
        .TAG_WIDTH (RCACHE_BUS_TAG_WIDTH)
    ) rcache_flushable_bus_if [`VX_CFG_NUM_RASTER_CORES * RCACHE_NUM_REQS] ();

    VX_dcr_flush_if rcache_flush_if();
`ifdef CLUSTER_UNIT_MMU_ENABLE
    assign rcache_flush_if.req = cluster_flush_if.req || mmu_flush_if.req;
`else
    assign rcache_flush_if.req = cluster_flush_if.req;
`endif

    VX_dcr_flush #(
        .WORD_SIZE   (RCACHE_WORD_SIZE),
        .TAG_WIDTH   (RCACHE_TAG_WIDTH),
        .REQ_OUT_BUF (3) // register cache-request master boundary; rsp registered by cache CORE_OUT_BUF
    ) rcache_dcr_flush (
        .clk          (clk),
        .reset        (reset),
        .dcr_flush_if (rcache_flush_if),
        .l1_only      (1'b0),
        .core_bus_if  (rcache_bus_if[0]),
        .cache_bus_if (rcache_flushable_bus_if[0])
    );

    for (genvar i = 1; i < `VX_CFG_NUM_RASTER_CORES * RCACHE_NUM_REQS; ++i) begin : g_rcache_passthru
        `ASSIGN_VX_MEM_BUS_IF_EX (rcache_flushable_bus_if[i], rcache_bus_if[i],
                                  RCACHE_BUS_TAG_WIDTH, RCACHE_TAG_WIDTH, 0);
    end

    VX_cache_cluster #(
        .INSTANCE_ID    (`SFORMATF(("%s-rcache", INSTANCE_ID))),
        .NUM_UNITS      (`VX_CFG_NUM_RCACHES),
        .NUM_INPUTS     (`VX_CFG_NUM_RASTER_CORES),
        .TAG_SEL_IDX    (0),
        .CACHE_SIZE     (`VX_CFG_RCACHE_SIZE),
        .LINE_SIZE      (RCACHE_LINE_SIZE),
        .NUM_BANKS      (`VX_CFG_RCACHE_NUM_BANKS),
        .NUM_WAYS       (`VX_CFG_RCACHE_NUM_WAYS),
        .WORD_SIZE      (RCACHE_WORD_SIZE),
        .NUM_REQS       (RCACHE_NUM_REQS),
        .MEM_PORTS      (RCACHE_MEM_PORTS),
        .CRSQ_SIZE      (`VX_CFG_RCACHE_CRSQ_SIZE),
        .MSHR_SIZE      (`VX_CFG_RCACHE_MSHR_SIZE),
        .MRSQ_SIZE      (`VX_CFG_RCACHE_MRSQ_SIZE),
        .MREQ_SIZE      (`VX_CFG_RCACHE_MREQ_SIZE),
        .TAG_WIDTH      (RCACHE_BUS_TAG_WIDTH),
        .WRITE_ENABLE   (0),
        .WRITEBACK      (0),
        .DIRTY_BYTES    (0),
        .NC_ENABLE      (0),
        // read-only: no dirty data, and the dcache's flush walks the shared levels
        .FLUSH_FORWARD  (0),
        .CORE_OUT_BUF   (3),
        .MEM_OUT_BUF    (3)
    ) rcache (
        .clk            (clk),
        .reset          (reset),
    `ifdef PERF_ENABLE
        .cache_perf     (rcache_perf),
    `endif
        .core_bus_if    (rcache_flushable_bus_if),
        .mem_bus_if     (rcache_mem_bus_tmp_if),
        .req_empty      (rcache_req_empty)
    );

    `ASSIGN_VX_MEM_BUS_IF_EX (rcache_mem_bus_if, rcache_mem_bus_tmp_if[0],
                              L2_TAG_WIDTH, RCACHE_MEM_TAG_WIDTH, UUID_WIDTH);

`endif // VX_CFG_EXT_RASTER_ENABLE

    /////////////////////////////////////////////////////////////////////////////
    // OM
    /////////////////////////////////////////////////////////////////////////////

`ifdef VX_CFG_EXT_OM_ENABLE

    VX_mem_bus_if #(
        .DATA_SIZE (OCACHE_WORD_SIZE),
        .TAG_WIDTH (OCACHE_TAG_WIDTH)
    ) ocache_bus_if [`VX_CFG_NUM_OM_CORES * OCACHE_NUM_REQS] ();

    VX_om_bus_if #(
        .NUM_LANES (OM_CORE_LANES)
    ) om_bus_if [`VX_CFG_NUM_OM_CORES] ();

    om_dcrs_t om_core_dcrs [`VX_CFG_NUM_OM_CORES];
    wire [L2_SOCKET_REQS-1:0] om_ingress_busy;
    wire [L2_SOCKET_REQS-1:0] om_ingress_pending;
    // The DCRs are broadcast, so every OM core decodes identical values; the
    // ingresses read the aperture fields from core 0.
    om_dcrs_t om_dcrs;
    assign om_dcrs = om_core_dcrs[0];

    // Fragments now reach the OM only as aperture stores: one ingress per
    // socket->L2 trunk input. The dedicated per-core/per-socket om bus and its
    // two arbiter levels are gone.
    localparam OM_ARB_INPUTS = L2_SOCKET_REQS;

    VX_om_bus_if #(
        .NUM_LANES (OM_CORE_LANES)
    ) om_arb_in_if [OM_ARB_INPUTS] ();

    // Peel the aperture writes off each trunk input BEFORE the L2. This join is the
    // last point at which a request has left the socket and has not yet touched
    // anything L2-owned, which is the deadlock argument: a full OM ingress blocks
    // this trunk input while holding no L2 resource, and the OM drains through the
    // ocache, which owns its own disjoint L2 input port.
    VX_mem_bus_if #(
        .DATA_SIZE (`VX_CFG_L1_LINE_SIZE),
        .TAG_WIDTH (L2_TAG_WIDTH)
    ) om_aperture_bus_if [L2_SOCKET_REQS]();

    // Flush tokens are held at the steers until the OM side is flushed (below).
    wire [L2_SOCKET_REQS-1:0] steer_flush_req;
    wire [L2_SOCKET_REQS-1:0] steer_flush_l1_only;
    reg  [L2_SOCKET_REQS-1:0] steer_flush_ack_r;
    wire [L2_SOCKET_REQS-1:0] steer_om_pending;
    wire [L2_SOCKET_REQS-1:0] steer_req_empty;

    for (genvar i = 0; i < L2_SOCKET_REQS; ++i) begin : g_om_steer
        VX_om_steer #(
            .INSTANCE_ID (`SFORMATF(("%s-om-steer%0d", INSTANCE_ID, i))),
            .DATA_SIZE   (`VX_CFG_L1_LINE_SIZE),
            .TAG_WIDTH   (L2_TAG_WIDTH),
            .OUT_BUF     (3)
        ) om_steer (
            .clk        (clk),
            .reset      (reset),
            .bus_in_if  (socket_mem_bus_if[i]),
            .l2_out_if  (l2_out_bus_if[i]),
            .om_out_if  (om_aperture_bus_if[i]),
            .flush_req  (steer_flush_req[i]),
            .flush_l1_only (steer_flush_l1_only[i]),
            .flush_ack  (steer_flush_ack_r[i]),
            .om_pending (steer_om_pending[i])
        );
        wire [1:0] steer_out_fire = {
            om_aperture_bus_if[i].req_valid && om_aperture_bus_if[i].req_ready,
            l2_out_bus_if[i].req_valid && l2_out_bus_if[i].req_ready
        };
        VX_mem_req_pending #(
            .NUM_INPUTS  (1),
            .NUM_OUTPUTS (2)
        ) steer_pending (
            .clk      (clk),
            .reset    (reset),
            .in_fire  (socket_mem_bus_if[i].req_valid && socket_mem_bus_if[i].req_ready),
            .out_fire (steer_out_fire),
            .empty    (steer_req_empty[i])
        );
    end

    for (genvar i = 0; i < L2_SOCKET_REQS; ++i) begin : g_om_ingress
        VX_om_ingress #(
            .INSTANCE_ID (`SFORMATF(("%s-om-ingress%0d", INSTANCE_ID, i))),
            .DATA_SIZE   (`VX_CFG_L1_LINE_SIZE),
            .TAG_WIDTH   (L2_TAG_WIDTH),
            .NUM_LANES   (OM_CORE_LANES),
            .OUT_BUF     (3)
        ) om_ingress (
            .clk          (clk),
            .reset        (reset),
            .dcrs         (om_dcrs),
            .mem_bus_if   (om_aperture_bus_if[i]),
            .om_bus_if    (om_arb_in_if[i]),
            .busy         (om_ingress_busy[i]),
            .frag_pending (om_ingress_pending[i])
        );
    end

    VX_om_bus_arb #(
        .NUM_INPUTS  (OM_ARB_INPUTS),
        .NUM_LANES   (OM_CORE_LANES),
        .NUM_OUTPUTS (`VX_CFG_NUM_OM_CORES),
        .ARBITER     ("R"),
        .OUT_BUF     ((OM_ARB_INPUTS != `VX_CFG_NUM_OM_CORES) ? 3 : 0) // register only on fan-out (avoid double on 1:1 passthrough)
    ) om_cluster_arb (
        .clk        (clk),
        .reset      (reset),
        .bus_in_if  (om_arb_in_if),
        .bus_out_if (om_bus_if)
    );

`ifdef PERF_ENABLE
    VX_om_perf_if per_core_om_perf_if [`VX_CFG_NUM_OM_CORES] ();
`endif

    wire [`VX_CFG_NUM_OM_CORES-1:0] om_busy_w;

    for (genvar i = 0; i < `VX_CFG_NUM_OM_CORES; ++i) begin : g_om_core
        VX_om_core #(
            .INSTANCE_ID (`SFORMATF(("%s-om%0d", INSTANCE_ID, i))),
            .NUM_LANES   (OM_CORE_LANES)
        ) om_core (
            `SCOPE_IO_BIND (scope_raster_cnt + i)
            .clk          (clk),
            .reset        (reset),
        `ifdef PERF_ENABLE
            .perf_om_if   (per_core_om_perf_if[i]),
        `endif
            .dcr_bus_if   (per_unit_dcr_bus_if[DCR_OM_BASE + i]),
            .om_bus_if    (om_bus_if[i]),
            .cache_bus_if (ocache_bus_if[i * OCACHE_NUM_REQS +: OCACHE_NUM_REQS]),
            .busy         (om_busy_w[i]),
            .om_dcrs      (om_core_dcrs[i])
        );
    end

`ifdef PERF_ENABLE
    wire [`VX_CFG_NUM_OM_CORES-1:0][PERF_CTR_BITS-1:0] om_mr_w, om_mw_w, om_ml_w, om_sc_w;
    for (genvar i = 0; i < `VX_CFG_NUM_OM_CORES; ++i) begin : g_om_perf_pack
        assign om_mr_w[i] = per_core_om_perf_if[i].mem_reads;
        assign om_mw_w[i] = per_core_om_perf_if[i].mem_writes;
        assign om_ml_w[i] = per_core_om_perf_if[i].mem_latency;
        assign om_sc_w[i] = per_core_om_perf_if[i].stall_cycles;
    end
    om_perf_t om_perf_sum;
    always @(*) begin
        om_perf_sum = '0;
        for (int i = 0; i < `VX_CFG_NUM_OM_CORES; ++i) begin
            om_perf_sum.mem_reads    = om_perf_sum.mem_reads    + om_mr_w[i];
            om_perf_sum.mem_writes   = om_perf_sum.mem_writes   + om_mw_w[i];
            om_perf_sum.mem_latency  = om_perf_sum.mem_latency  + om_ml_w[i];
            om_perf_sum.stall_cycles = om_perf_sum.stall_cycles + om_sc_w[i];
        end
    end
    assign om_perf = om_perf_sum;
`endif

    VX_mem_bus_if #(
        .DATA_SIZE (OCACHE_LINE_SIZE),
        .TAG_WIDTH (OCACHE_MEM_TAG_WIDTH)
    ) ocache_mem_bus_tmp_if [OCACHE_MEM_PORTS] ();

    // Ocache core-side inputs: OM cores occupy the first NUM_OM_CORES input
    // groups; with early-Z, the raster engines' depth-read requesters occupy the
    // trailing NUM_RASTER_CORES input groups (coherent with OM write-through).
    VX_mem_bus_if #(
        .DATA_SIZE (OCACHE_WORD_SIZE),
        .TAG_WIDTH (OCACHE_BUS_TAG_WIDTH)
    ) ocache_flushable_bus_if [OCACHE_NUM_INPUTS * OCACHE_NUM_REQS] ();

    // OM-side flush. Each round serves the requests present when it starts: the
    // steers holding a flush token (every aperture store their trunk carried
    // before it is past the steer) and the cluster flush. It waits until no
    // complete fragment is left in the OM, so the ocache's flush tokens queue
    // behind its writes, then flushes the ocache and releases those requesters.
    // A half-received two-word record is not waited for: its depth beat can sit
    // behind a held token, and it belongs to a store the token does not order.
    localparam OMF_IDLE  = 0;
    localparam OMF_DRAIN = 1;
    localparam OMF_FLUSH = 2;
    localparam OMF_REARM = 3;

    VX_dcr_flush_if ocache_flush_if();

    reg [1:0]                omf_state_r;
    reg [L2_SOCKET_REQS-1:0] omf_steers_r;   // steers this round answers
    reg                      omf_cluster_r;  // this round answers the cluster flush
    reg                      omf_cluster_done_r;
    reg                      omf_l1_only_r;  // every requester of this round is L1-only
    wire omf_cluster_req = cluster_flush_if.req && ~omf_cluster_done_r;
    // The address-space change is an L1-only requester: the ocache drains its
    // writes and invalidates, and the L2 (physically tagged) is left alone.
`ifdef CLUSTER_UNIT_MMU_ENABLE
    reg  omf_mmu_r;
    reg  omf_mmu_done_r;
    wire omf_mmu_req = mmu_flush_if.req && ~omf_mmu_done_r;
`else
    wire omf_mmu_req = 1'b0;
`endif

    // The cluster flush takes its kind from the broadcast write that starts it,
    // which every core receives too. The cores raise the cluster flush request
    // only after taking that write, so the latch is current by then.
    reg cluster_flush_l1_only_r;
    always @(posedge clk) begin
        if (reset) begin
            cluster_flush_l1_only_r <= 1'b0;
        end else if (dcr_bus_if.req_valid && dcr_bus_if.req_data.rw
                  && (dcr_bus_if.req_data.addr == `VX_DCR_BASE_CACHE_FLUSH)) begin
            cluster_flush_l1_only_r <= (dcr_bus_if.req_data.data & VX_DCR_DATA_WIDTH'(`VX_CACHE_FLUSH_L1_ONLY)) != 0;
        end
    end
    wire omf_drained = ~(| om_busy_w) && ~(| om_ingress_pending) && ~(| steer_om_pending);

`ifndef SYNTHESIS
    // Each cluster flush round must find the latch written for it, strictly
    // before the round takes the request.
    wire cluster_flush_kind_wr = dcr_bus_if.req_valid && dcr_bus_if.req_data.rw
                              && (dcr_bus_if.req_data.addr == `VX_DCR_BASE_CACHE_FLUSH);
    wire omf_cluster_take = (omf_state_r == OMF_IDLE) && omf_cluster_req;
    reg  cluster_flush_kind_new_r;
    always @(posedge clk) begin
        if (reset) begin
            cluster_flush_kind_new_r <= 1'b0;
        end else if (cluster_flush_kind_wr) begin
            cluster_flush_kind_new_r <= 1'b1;
        end else if (omf_cluster_take) begin
            cluster_flush_kind_new_r <= 1'b0;
        end
    end
    `RUNTIME_ASSERT (~omf_cluster_take || (cluster_flush_kind_new_r && ~cluster_flush_kind_wr),
        ("%t: cluster flush taken before its kind was latched", $time))
`endif

    always @(posedge clk) begin
        if (reset) begin
            omf_state_r        <= OMF_IDLE;
            omf_steers_r       <= '0;
            omf_cluster_r      <= 1'b0;
            omf_cluster_done_r <= 1'b0;
            omf_l1_only_r      <= 1'b0;
            steer_flush_ack_r  <= '0;
        end else begin
            steer_flush_ack_r <= '0;
            if (~cluster_flush_if.req) begin
                omf_cluster_done_r <= 1'b0;
            end
            case (omf_state_r)
            OMF_IDLE: begin
                if ((| steer_flush_req) || omf_cluster_req || omf_mmu_req) begin
                    omf_steers_r  <= steer_flush_req;
                    omf_cluster_r <= omf_cluster_req;
                    omf_l1_only_r <= (& (~steer_flush_req | steer_flush_l1_only))
                                  && (~omf_cluster_req || cluster_flush_l1_only_r);
                    omf_state_r   <= OMF_DRAIN;
                end
            end
            OMF_DRAIN: begin
                if (omf_drained) begin
                    omf_state_r <= OMF_FLUSH;
                end
            end
            OMF_FLUSH: begin
                if (ocache_flush_if.done) begin
                    steer_flush_ack_r <= omf_steers_r;
                    if (omf_cluster_r) begin
                        omf_cluster_done_r <= 1'b1;
                    end
                    omf_state_r <= OMF_REARM;
                end
            end
            default: begin // OMF_REARM: the injectors re-arm once req drops
                if (~ocache_flush_if.done) begin
                    omf_state_r <= OMF_IDLE;
                end
            end
            endcase
        end
    end
    assign ocache_flush_if.req = (omf_state_r == OMF_FLUSH);

`ifdef CLUSTER_UNIT_MMU_ENABLE
    // The address-space change joins a round like the cluster flush does.
    always @(posedge clk) begin
        if (reset) begin
            omf_mmu_r      <= 1'b0;
            omf_mmu_done_r <= 1'b0;
        end else begin
            if (~mmu_flush_if.req) begin
                omf_mmu_done_r <= 1'b0;
            end
            if ((omf_state_r == OMF_IDLE) && ((| steer_flush_req) || omf_cluster_req || omf_mmu_req)) begin
                omf_mmu_r <= omf_mmu_req;
            end
            if ((omf_state_r == OMF_FLUSH) && ocache_flush_if.done && omf_mmu_r) begin
                omf_mmu_done_r <= 1'b1;
            end
        end
    end
`endif

    // OM-core flush chain carries the OM tag + 1 flush bit. When early-Z widens
    // the shared bus tag (a wider early-Z requester), the flushed OM bus is
    // zero-extended up to OCACHE_BUS_TAG_WIDTH below. Each OM input is a
    // separately ordered write path into the ocache, so each carries its own
    // flush token behind its writes.
    localparam OCACHE_OM_INPUTS = `VX_CFG_NUM_OM_CORES * OCACHE_NUM_REQS;
    localparam OCACHE_OM_FLUSH_TAG_WIDTH = OCACHE_TAG_WIDTH + 1;
    VX_mem_bus_if #(
        .DATA_SIZE (OCACHE_WORD_SIZE),
        .TAG_WIDTH (OCACHE_OM_FLUSH_TAG_WIDTH)
    ) ocache_om_flush_bus_if [OCACHE_OM_INPUTS] ();

    VX_dcr_flush_if ocache_om_flush_if [OCACHE_OM_INPUTS] ();
    wire [OCACHE_OM_INPUTS-1:0] ocache_om_flush_done;

    for (genvar i = 0; i < OCACHE_OM_INPUTS; ++i) begin : g_ocache_om_flush
        assign ocache_om_flush_if[i].req = ocache_flush_if.req;
        assign ocache_om_flush_done[i] = ocache_om_flush_if[i].done;

        VX_dcr_flush #(
            .WORD_SIZE   (OCACHE_WORD_SIZE),
            .TAG_WIDTH   (OCACHE_TAG_WIDTH),
            .REQ_OUT_BUF (3) // register cache-request master boundary; rsp registered by cache CORE_OUT_BUF
        ) ocache_dcr_flush (
            .clk          (clk),
            .reset        (reset),
            .dcr_flush_if (ocache_om_flush_if[i]),
            .l1_only      (omf_l1_only_r),
            .core_bus_if  (ocache_bus_if[i]),
            .cache_bus_if (ocache_om_flush_bus_if[i])
        );

        `ASSIGN_VX_MEM_BUS_IF_EX (ocache_flushable_bus_if[i], ocache_om_flush_bus_if[i],
                                  OCACHE_BUS_TAG_WIDTH, OCACHE_OM_FLUSH_TAG_WIDTH, 0);
    end
    assign ocache_flush_if.done = (& ocache_om_flush_done);

`ifdef VX_CFG_RASTER_EARLYZ_ENABLE
    // Attach the early-Z depth readers as the trailing ocache inputs. Each reader
    // presents OCACHE_EARLYZ_TAG_WIDTH; zero-extend to the shared bus tag width.
    for (genvar i = 0; i < `VX_CFG_NUM_RASTER_CORES * OCACHE_NUM_REQS; ++i) begin : g_earlyz_ocache_in
        localparam DST = `VX_CFG_NUM_OM_CORES * OCACHE_NUM_REQS + i;
        `ASSIGN_VX_MEM_BUS_IF_EX (ocache_flushable_bus_if[DST], earlyz_ocache_bus_if[i],
                                  OCACHE_BUS_TAG_WIDTH, OCACHE_EARLYZ_TAG_WIDTH, 0);
    end
`endif

    VX_cache_cluster #(
        .INSTANCE_ID    (`SFORMATF(("%s-ocache", INSTANCE_ID))),
        .NUM_UNITS      (`VX_CFG_NUM_OCACHES),
        .NUM_INPUTS     (OCACHE_NUM_INPUTS),
        .TAG_SEL_IDX    (0),
        .CACHE_SIZE     (`VX_CFG_OCACHE_SIZE),
        .LINE_SIZE      (OCACHE_LINE_SIZE),
        .NUM_BANKS      (`VX_CFG_OCACHE_NUM_BANKS),
        .NUM_WAYS       (`VX_CFG_OCACHE_NUM_WAYS),
        .WORD_SIZE      (OCACHE_WORD_SIZE),
        .NUM_REQS       (OCACHE_NUM_REQS),
        .MEM_PORTS      (OCACHE_MEM_PORTS),
        .CRSQ_SIZE      (`VX_CFG_OCACHE_CRSQ_SIZE),
        .MSHR_SIZE      (`VX_CFG_OCACHE_MSHR_SIZE),
        .MRSQ_SIZE      (`VX_CFG_OCACHE_MRSQ_SIZE),
        .MREQ_SIZE      (`VX_CFG_OCACHE_MREQ_SIZE),
        .TAG_WIDTH      (OCACHE_BUS_TAG_WIDTH),
        .WRITE_ENABLE   (1),
        .WRITEBACK      (0),
        .DIRTY_BYTES    (0),
        .NC_ENABLE      (0),
        .CORE_OUT_BUF   (3),
        .MEM_OUT_BUF    (3)
    ) ocache (
        .clk            (clk),
        .reset          (reset),
    `ifdef PERF_ENABLE
        .cache_perf     (ocache_perf),
    `endif
        .core_bus_if    (ocache_flushable_bus_if),
        .mem_bus_if     (ocache_mem_bus_tmp_if),
        .req_empty      (ocache_req_empty)
    );

    `ASSIGN_VX_MEM_BUS_IF_EX (ocache_mem_bus_if, ocache_mem_bus_tmp_if[0],
                              L2_TAG_WIDTH, OCACHE_MEM_TAG_WIDTH, UUID_WIDTH);

`endif // VX_CFG_EXT_OM_ENABLE

    // ── Cluster-level gfx-cache flush done aggregation ─────────────────
    // Each gfx cache participates in flushing only if its extension is
    // compiled in; the inactive ones contribute a tied-1 so the AND still
    // resolves to the active set's combined done.
    wire rcache_flush_done;
    wire ocache_flush_done;
`ifdef VX_CFG_EXT_RASTER_ENABLE
    assign rcache_flush_done = rcache_flush_if.done;
`else
    assign rcache_flush_done = 1'b1;
`endif
`ifdef VX_CFG_EXT_OM_ENABLE
    assign ocache_flush_done = omf_cluster_done_r;
`else
    assign ocache_flush_done = 1'b1;
`endif
    assign cluster_flush_if.done = rcache_flush_done & ocache_flush_done;

`ifdef CLUSTER_UNIT_MMU_ENABLE
`ifdef VX_CFG_EXT_OM_ENABLE
    assign mmu_flush_if.done = rcache_flush_done & omf_mmu_done_r;
`else
    assign mmu_flush_if.done = rcache_flush_done;
`endif
`endif

    // Producer busy = a raster engine still draining a frame (out-of-band
    // drain) or an OM core with fragments in flight (vx_om4 is fire-and-forget,
    // so nothing else holds the device busy until the ROP commits).
`ifdef VX_CFG_EXT_RASTER_ENABLE
    // ... plus any launch descriptor still sitting in the raster launch merge's
    // output register (see raster_kmu_merge).
    wire raster_busy_any = (| raster_busy_w) || raster_kmu_busy;
`else
    wire raster_busy_any = 1'b0;
`endif
`ifdef VX_CFG_EXT_OM_ENABLE
    wire om_busy_any = (| om_busy_w) || (| om_ingress_busy);
    // requests held in a steer's buffers on the way to L2 or the OM
    wire om_req_busy = ~(& steer_req_empty);
`else
    wire om_busy_any = 1'b0;
    wire om_req_busy = 1'b0;
    assign ocache_req_empty = 1'b1;
`endif
`ifndef VX_CFG_EXT_RASTER_ENABLE
    assign rcache_req_empty = 1'b1;
`endif
    assign busy = raster_busy_any || om_busy_any || om_req_busy || ~rcache_req_empty || ~ocache_req_empty;

endmodule
