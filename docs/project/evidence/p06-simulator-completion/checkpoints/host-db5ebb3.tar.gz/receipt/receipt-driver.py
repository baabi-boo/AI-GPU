#!/usr/bin/env python3
"""One source-bound host focused-suite receipt; never writes to the repository."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
HERE = Path(__file__).resolve().parent
GIB, MIB = 1024 ** 3, 1024 ** 2
ARGV = ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'ci/project',
        '-p', 'test_p06_simulator_*.py', '-v']
BUDGET = dict(timeout_seconds=300, min_free_bytes=GIB,
              max_log_bytes=8 * MIB, max_rss_bytes=GIB, poll_seconds=0.1)


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    requested = Path(os.path.abspath(path))
    resolved = requested.resolve(strict=True)
    return dict(path=str(requested), resolved_path=str(resolved),
                sha256=digest(resolved), size_bytes=resolved.stat().st_size)


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def command(argv, env):
    result = subprocess.run(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
    if result.returncode:
        raise RuntimeError(f'{argv!r}: exit {result.returncode}: '
                           + result.stderr.decode('utf-8', 'replace')[-2048:])
    return result.stdout


def source(env):
    git = lambda *args: command(['git', *args], env)
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    status = git('status', '--porcelain=v1', '--untracked-files=all').decode()
    object_format = git('rev-parse', '--show-object-format').decode().strip()
    records, mismatches = {}, []
    for entry in git('ls-tree', '-r', '-z', '--full-tree', 'HEAD').split(b'\0'):
        if not entry:
            continue
        metadata, raw_name = entry.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        name = os.fsdecode(raw_name)
        row = dict(mode=mode, kind=kind, git_object=oid)
        path = ROOT / name
        if kind == 'blob':
            if mode == '120000':
                data = os.fsencode(os.readlink(path))
                row.update(size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                           symlink_target=os.fsdecode(data))
                git_digest = hashlib.new(object_format, b'blob ' + str(len(data)).encode() + b'\0' + data)
                if path.is_file():
                    row['resolved_target'] = identity(path)
            else:
                size = path.stat().st_size
                sha = hashlib.sha256()
                git_digest = hashlib.new(object_format, b'blob ' + str(size).encode() + b'\0')
                with path.open('rb') as stream:
                    for chunk in iter(lambda: stream.read(MIB), b''):
                        sha.update(chunk)
                        git_digest.update(chunk)
                row.update(size_bytes=size, sha256=sha.hexdigest())
            row['working_git_blob'] = git_digest.hexdigest()
            if row['working_git_blob'] != oid:
                mismatches.append(name)
        records[name] = row
    return dict(head=head, tree=tree, status_porcelain=status, object_format=object_format,
                tracked_files=records, working_blob_mismatches=mismatches)


def resources():
    memory = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        key, value = line.split(':', 1)
        if key in ('MemTotal', 'MemAvailable'):
            memory[key + '_bytes'] = int(value.split()[0]) * 1024
    cgroup = {}
    for name in ('memory.max', 'memory.current'):
        path = Path('/sys/fs/cgroup') / name
        if path.exists():
            cgroup[name] = path.read_text().strip()
    available = memory.get('MemAvailable_bytes', 0)
    if cgroup.get('memory.max', 'max') != 'max' and 'memory.current' in cgroup:
        available = min(available, int(cgroup['memory.max']) - int(cgroup['memory.current']))
    disk = {str(path): shutil.disk_usage(path)._asdict() for path in (ROOT, HERE, Path('/tmp'))}
    return dict(memory=memory, cgroup=cgroup, effective_available_bytes=available, disk=disk,
                ready=available >= GIB and all(row['free'] >= GIB for row in disk.values()))


def tools_snapshot(env):
    names = ('python3', 'c++', 'g++', 'git', 'make', 'bash', 'env', 'realpath',
             'find', 'basename', 'sed', 'mkdir', 'cp', 'cat', 'chmod', 'ldd')
    rows = {'sys.executable': identity(sys.executable)}
    probes = {}
    for scope, search in (('suite', env['PATH']),
                          ('isolated_test', str(Path(sys.executable).parent) + os.pathsep + os.defpath)):
        for name in names:
            path = shutil.which(name, path=search)
            if not path:
                raise RuntimeError('Missing host tool: ' + name)
            rows[scope + ':' + name] = identity(path)
    for name in names:
        argv = [rows['suite:' + name]['path'], '--version']
        probes['version-' + name] = dict(argv=argv, output=command(argv, env).decode('utf-8', 'replace'))
    py_argv = ['python3', '-B', '-c', 'import json,sys;print(json.dumps(dict(executable=sys.executable,version=sys.version)))']
    probes['executing-python'] = dict(argv=py_argv, output=command(py_argv, env).decode())
    witness = json.loads(probes['executing-python']['output'])
    if identity(witness['executable'])['resolved_path'] != rows['sys.executable']['resolved_path']:
        raise RuntimeError('python3 differs from the receipt interpreter')
    compiler = rows['suite:c++']['path']
    for flag, names_ in (('-print-prog-name=', ('cc1plus', 'collect2', 'as', 'ld')),
                         ('-print-file-name=', ('libstdc++.so', 'libubsan.so', 'libgcc_s.so', 'libgcc.a', 'crtbegin.o', 'crtend.o'))):
        for name in names_:
            argv = [compiler, flag + name]
            value = command(argv, env).decode().strip()
            probes['compiler-' + name] = dict(argv=argv, output=value)
            found = value if Path(value).is_file() else shutil.which(value, path=env['PATH'])
            if found:
                rows['compiler-support:' + name] = identity(found)
            else:
                raise RuntimeError('Compiler support file not resolved: ' + name)
    return dict(files=rows, probes=probes, python=witness,
                selected_fixture_compiler=rows['suite:c++'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-head', required=True)
    expected = parser.parse_args().expected_head
    if not re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}', expected):
        raise ValueError('A full expected commit is required')
    attempt = HERE / ('attempt-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    attempt.mkdir()
    (attempt / 'tmp').mkdir()
    with (attempt / 'receipt-driver.py').open('xb') as stream:
        stream.write(Path(__file__).read_bytes())
    env = dict(PATH=os.environ.get('PATH', os.defpath), LC_ALL='C', LANG='C',
               PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(attempt / 'tmp'),
               CCACHE_DISABLE='1', MAKEFLAGS='-j1')
    report = dict(schema_version=1, started_at=now(), expected_head=expected,
                  cwd=str(ROOT), argv=ARGV, command="python3 -B -m unittest discover -s ci/project -p 'test_p06_simulator_*.py' -v",
                  environment_allowlist=env, budget=BUDGET, outcome='blocked',
                  scope='HOST: controlled completion/public-runtime/SimObject fixtures and policy tests',
                  native_execution='not_run', native_policy_process_calls='mocked',
                  limitations=['No native GPU/processor/RTL execution, vendor build, performance or phase acceptance is claimed.',
                               'Full tracked-file byte hashes bind the suite to the commit; gitlinks are pinned identities only.',
                               'Before/after identities detect observed drift, not transient replacement restored between samples.',
                               'Compiler-support hashes do not inventory every system header or dynamic library.',
                               'Nested run_host_command groups have their own 1 GiB RSS and disk monitors; the outer peak does not aggregate those separate groups.'])
    before_source = before_tools = before_driver = None
    try:
        report['resources_before'] = resources()
        if not report['resources_before']['ready']:
            raise RuntimeError('Insufficient memory or disk before source collection')
        before_source = source(env)
        save(attempt / 'source-before.json', before_source)
        if before_source['head'] != expected or before_source['status_porcelain'] or before_source['working_blob_mismatches']:
            raise RuntimeError('Source is not the exact clean expected checkpoint')
        before_driver = identity(__file__)
        before_tools = tools_snapshot(env)
        save(attempt / 'tools-before.json', before_tools)
        report['driver_before'] = before_driver
        report['base_helpers'] = {name: row for name, row in before_source['tracked_files'].items()
                                  if name.startswith('ci/project/baseline_') and name.endswith('.py')
                                  or name == 'ci/project/tensor_host_tools.py'}
        report['focused_test_files'] = sorted(name for name in before_source['tracked_files']
                                             if re.fullmatch(r'ci/project/test_p06_simulator_.*\.py', name))
        save(attempt / 'invocation.json', report)
        sys.path.insert(0, str(ROOT / 'ci/project'))
        from baseline_process import run_bounded
        if digest(ROOT / 'ci/project/baseline_process.py') != report['base_helpers']['ci/project/baseline_process.py']['sha256']:
            raise RuntimeError('Bounded helper changed before execution')
        report['execution_started_at'] = now()
        report['process'] = run_bounded(ARGV, ROOT, env, attempt / 'focused-suite.log',
                                         resource_paths=(attempt, Path('/tmp')), **BUDGET)
        report['execution_finished_at'] = now()
        report['outcome'] = report['process']['outcome']
        if not report['process']['cleanup_complete']:
            report['outcome'] = 'fail'
    except Exception as error:
        report['error'] = str(error)
        report['exception'] = traceback.format_exc()
    finally:
        try:
            after_source, after_tools, after_driver = source(env), tools_snapshot(env), identity(__file__)
            save(attempt / 'source-after.json', after_source)
            save(attempt / 'tools-after.json', after_tools)
            report['driver_after'] = after_driver
            report['integrity'] = dict(source_unchanged=before_source == after_source,
                                       tools_unchanged=before_tools == after_tools,
                                       driver_unchanged=before_driver == after_driver,
                                       retained_driver_matches=digest(attempt / 'receipt-driver.py') == after_driver['sha256'],
                                       head_matches_expected=after_source['head'] == expected,
                                       clean_after=not after_source['status_porcelain'],
                                       all_working_blobs_match_commit=not after_source['working_blob_mismatches'])
            if not all(report['integrity'].values()):
                report['outcome'] = 'fail' if 'process' in report else 'blocked'
        except Exception:
            report['integrity_error'] = traceback.format_exc()
            report['outcome'] = 'fail' if 'process' in report else 'blocked'
        report['resources_after'] = resources()
        report['finished_at'] = now()
        log = attempt / 'focused-suite.log'
        if log.exists():
            text = log.read_text(encoding='utf-8', errors='replace')
            matches = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', text, re.MULTILINE)
            report['unittest_summary'] = dict(count=int(matches[-1][0]), duration_seconds=float(matches[-1][1])) if matches else None
            report['unittest_ok_without_skips'] = bool(re.search(r'^OK$', text, re.MULTILINE))
            if report['outcome'] == 'pass' and (not matches or not report['unittest_ok_without_skips']):
                report['outcome'] = 'fail'
            report['log'] = identity(log)
        report['artifacts'] = {path.name: identity(path) for path in sorted(attempt.iterdir()) if path.is_file()}
        save(attempt / 'report.json', report)
        print(json.dumps(dict(attempt=str(attempt), outcome=report['outcome'],
                              report_sha256=digest(attempt / 'report.json'),
                              process=report.get('process'), integrity=report.get('integrity'),
                              unittest_summary=report.get('unittest_summary'), error=report.get('error')), indent=2))
    return 0 if report['outcome'] == 'pass' else 1


if __name__ == '__main__':
    raise SystemExit(main())
