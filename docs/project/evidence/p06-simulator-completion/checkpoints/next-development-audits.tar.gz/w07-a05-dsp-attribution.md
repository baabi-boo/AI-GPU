# Wave 7 / agent 5 — inherited tensor DSP attribution

**Disposition:** the documented tensor DSP-area F2 remains unresolved. This completion patch changes no tensor-synthesis source, configuration, baseline, or threshold. That source comparison establishes no new completion-patch area regression; it does **not** establish a passing area gate or a fresh DSP measurement at the current head.

Reviewer: `/root/w07_a05_dsp_attribution` (overall assignment 41/60). Read-only review of base `42809ff0c1b81384d7c9b079e4ef786be8407600` → head `db5ebb3a16770004423f2456ec6d0caaa0aced6d`, head tree `1536393fef63bd4a4639505ce797c27303db1cc7`. CI observation window: **2026-11-22 09:26–09:27 UTC**. No Beacon, Yosys, native build, workflow mutation, baseline update, or threshold waiver was performed.

## What the inherited measurement establishes

I reread AGENTS, the review/bug-fix policies, the MPM audit and handoff, and the retained evidence reviews; independently decompressed both complete retained logic-gate logs and checked their hashes, executed checkout lines, failure lines, and 14 displayed circuit rows. [Prior independent attribution](https://github.com/baabi-boo/AI-GPU/blob/db5ebb3a16770004423f2456ec6d0caaa0aced6d/docs/project/evidence/p06-mpm-transport/reviews/broader-logic-gate-review.md) and its [structured review](https://github.com/baabi-boo/AI-GPU/blob/db5ebb3a16770004423f2456ec6d0caaa0aced6d/docs/project/evidence/p06-mpm-transport/reviews/broader-logic-gate-review.json) reconcile with those logs.

| Retained execution | Actual checkout | Result |
|---|---|---|
| [Historical run 44705486919 / job 136199969543](https://github.com/baabi-boo/AI-GPU/actions/runs/44705486919/job/136199969543) | `10ace66193686e3862c3c218760b66c044f1d4ae` | 13 of 14 default builds pass; tensor fails |
| [MPM run 44983573278 / job 137094134318](https://github.com/baabi-boo/AI-GPU/actions/runs/44983573278/job/137094134318) | PR merge `6e6426a0bf761baab11e932a4c86b49a5de81217` | Same 14 verdicts and displayed circuit metrics |

Both ran `ci/logic_gate.py -j 2` at **XLEN32** and exited **1**. The tensor wrapper is `VX_tensor_top`, with 16 threads/16 warps and the catalog's 250 MHz target on `xcu55c-fsvh2892-2L-e`. Its DSP count is **267 baseline → 283 observed**: +16, +5.9925% (reported +6.0%), above the unchanged **5%** area tolerance. Both rows report 259,593 LUT, 161,523 FF, 114.5 BRAM, depth 25, and estimated Fmax 253.4 MHz. After removing only timestamps and elapsed-time columns, all 14 raw-log rows match.

This is **Beacon timing/resource estimation through the Xilinx DUT flow**, not a generic Yosys result, placed/routed timing, physical FPGA measurement, or whole-GPU result. The separate opt-in MPM wrapper's raw RV64 area failures are different measurements and remain separate.

Both logs resolve toolchain tag `v3.0.2` to `6cff3efdc1b721e4fec9165801ecd405be34dd11` and download the same named 4,804,521-byte FoldSim archive. Historical/current cache profiles are `full`/`lite`; absent synthesis-executable hashes prevent asserting byte-identical tool installations. The earlier review binds the MPM merge tree to candidate `18c888058ac851b802350c99770ed9ac2d27b582`; this review verified the retained log checkout, not a new remote reconstruction of that merge object.

### Verified retained SHA-256 identities

| Evidence | SHA-256 |
|---|---|
| Historical decompressed log, 136,438 bytes | `94a77aaf385709cc0d0b442da0e02eba4498ed1a849b7a8759b72d79ccbd1573` |
| MPM decompressed log, 95,492 bytes | `b26ba3a4e0846202863b42bae26f925a8cb78a63eab2cfd8192c44511218be6e` |
| Historical log index | `1c14e80c74a3a49001110857500d4cf0055358adc1328ed25a96d2b05bffafe8` |
| MPM log index | `ff42e077bf179be48a8330bc3c3dc9795e763fb4369239aaf790b8c2f16e0a93` |
| Structured attribution review | `fe0e99b0e1ea13d7dc94c2887bc30857e12f67f6adaa678815b8723ad85a8e83` |

The logs and indices are under [`docs/project/evidence/p06-mpm-transport/hosted/`](https://github.com/baabi-boo/AI-GPU/tree/db5ebb3a16770004423f2456ec6d0caaa0aced6d/docs/project/evidence/p06-mpm-transport/hosted), named `broader-logic-gate{,-prior}.{json,log.gz}`.

## Why the completion patch is excluded at source level

`git diff --exit-code BASE HEAD -- <protected inputs>` returned **0**. Equal Git objects include:

| Unchanged scope | Object ID at both base and head |
|---|---|
| Entire `hw/` tree, including RTL, wrappers, Xilinx/Yosys flows and calibration | `6c3ce08581ee8528278de2173b52a005d449a524` |
| `hw/rtl/` tree | `97dcaa93fefae711ec60621f3f91f7ee154adb2e` |
| `profiles/` tree | `423aa86f244918888341f759dd5bc88b74fa2737` |
| All `ci/baselines/` | `5654a345f7eba410f0e9ea968041eef72fd2d46e` |
| All `ci/testcases/` | `683f41f8ac73dea493f438a6a5bf9e97a3001174` |
| `VX_config.toml` | `fdf49ad7e1459dff3bd4bb607ffb607a92a88fa5` |
| `ci/synth_gate.py` | `b986ac225e604552555bc3273d592cb5d7080179` |
| `ci/baselines/synthesis/beacon/tensor.json` | `36d6b1775224175a70a66068d0ae7dd351cdb134` |

The comparison also checked `VX_types.toml`, `configure`, `ci/gen_config.py`, `ci/{logic_gate,beacon,fpga_gate,asic_gate,synth_report}.py`, `VERSION`, toolchain resolution/install inputs, the setup action, and `.github/workflows/ci.yml`. The entire prior MPM evidence tree is unchanged. All **18** current blobs named in the prior attribution's `source_scope.git_blob_ids` equal its recorded measured-MPM-candidate blobs. [The unchanged Beacon implementation](https://github.com/baabi-boo/AI-GPU/blob/db5ebb3a16770004423f2456ec6d0caaa0aced6d/ci/synth_gate.py) still assigns `0.05` to every area metric, including DSP; its zero depth tolerance is a different rule.

The completion diff adds/changes simulator/runtime C++, its build fragments, tests, workflow and documentation. Those C++ paths are not inputs to tensor RTL synthesis. For the earlier MPM exclusion, the tensor wrapper contains no `VX_core`; the only production `VX_csr_mpm` instance is in `VX_core`. The narrower MPM RV32 paired controls also remained identical, as the prior review records. Neither argument supplies physical equivalence.

## Attribution limit, pending CI, and next action

The introducing cause is **unproved**. [The P04 audit](https://github.com/baabi-boo/AI-GPU/blob/db5ebb3a16770004423f2456ec6d0caaa0aced6d/docs/project/p04-audit.md) records earlier identical failures at `fd803750198eb9f6ec11071abfdad211d8858100` and `9006939aa123452b198bc0987e34aae8fab45fdd`. Its wider MX scale-index arithmetic hypothesis at `1a898f7fb292e2b554ddd5c2065710a6cb5faba5` remains a static candidate, not a measured causal bisect. Those two older jobs were not freshly retrieved in this review.

The read-only GitHub commit-run query for **db5ebb3a** returned [general CI 45006726449](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726449) as queued: plan and advisory change-impact jobs had passed, while setup job `137161763026` was queued; no current logic-gate result was available. [Completion run 45006726571](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726571) also remained queued at prerequisite job `137159859409`. These are point-in-time, first-page connector observations, not terminal results. **Do not attribute 283 DSP to a fresh db5ebb3a execution, report the current CI as green, or call the inherited finding repaired.**

For this completion delivery, refresh the actual head/merge-bound CI results and reconcile its native completion evidence. Keep the inherited F2 and absence of physical acceptance explicit. Tensor root-cause work is a separate bounded change under bug-fix policy §6: distinguish tool/design effects, establish a stable matched case, measure/bisect the suspect change and per-unit mechanism, then qualify an equivalent correction with the existing MX WGMMA NRC=16 RTL/parity coverage. Preserve the required wide index, the 267 golden and 5% threshold; this note proposes no waiver or unrelated compensating optimization.
