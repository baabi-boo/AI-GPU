# Wave 7 / Agent 2 — cumulative counter lifetime and no-wrap guard audit

## Decision and scope

**A prospective, bounded no-wrap mechanism is feasible for the exact timed RV64 `p02-tfr`, `PERF=1` warm route, but no absolute no-wrap bound is established by the current source.** The smallest defensible next implementation is a lifetime tick budget that survives every launch reset, supplemented by bounded memory-request admission and checked pending-read accounting. Most required counters can then use conservative, source-proved per-tick bounds. The request caps give the memory-latency accumulator a rigorous bound without guessing a DRAM latency or maximum queue occupancy.

This is a read-only source audit of `/workspace/scratch/ea983fdea786/AI-GPU` at `db5ebb3a16770004423f2456ec6d0caaa0aced6d`. `git status --short` was empty during inspection. I read `AGENTS.md`, the counter qualification plan, the frozen warm contract and relevant updater/readout/completion code. The earlier `w01-a01-counter-semantics.md` was context, not current implementation evidence. No guards, counters, pipeline behavior, goldens, acceptances or repository files were modified; no builds or tests were run. This report is the only authored artifact.

The exact measurement scope is one fresh process and one context per policy batch, with one excluded prime plus 32 explicitly closed serial operations, RV64 timing SimX, one cluster/core/socket, four warps of four threads, issue width one, TFR tensor and STD scalar arithmetic, ordinary dense FP16/BF16 WMMA, `PERF_ENABLE`, and no `SIMX_FUNCTIONAL` or `SIMX_MT`. L2/L3, VM, WGMMA, DSM, sparse and matrix-load/store routes are outside the frozen execution scope. There are **33 available selectors and 12 unavailable L2/L3 rows**, all queried with representative core ID zero. The complete attempt has 24 separate process/context lifetimes, not one counter lifetime spanning 792 launches. [Sources: `ci/project/p06_warm_contract.json`, `profiles/p02-tfr.json`, `docs/designs/warm_workspace_benchmark_v1.md:36–45,78–90,202–230`.]

## 1. The lifetime domains that must remain distinct

| Domain or boundary | Current behavior | Consequence for no-wrap proof |
|---|---|---|
| Model construction / device context birth | `ProcessorImpl` initializes the process-wide platform, constructs the objects, then calls `reset()`. Required backing fields have zero initializers. | Establish zero origin at actual construction, before any initialization work, and bind it to the sole context in the process. An `after_open` sample alone cannot prove earlier execution was wrap-free. |
| Individual launch | `run()` calls `launch_reset()`. With `CP_ON_L2=CP_ON_L3=0`, that calls full `reset()`. | The launch clock restarts; required cumulative MPM fields survive. A per-launch ceiling must be accumulated across all launches and all other model work to become a context bound. |
| Ordinary full model reset | `SimPlatform::reset()` resets object execution state and assigns `cycles_=0`; it requires quiescence. `ProcessorImpl::reset()` zeros pending memory reads, not cumulative read/write/latency totals. | This is not a new MPM epoch. A new guard must not clear its lifetime budget or failure latch here. Pending-accounting resets need proof that no old response can arrive afterward. |
| Launch-keep reset | `reset_launch()` resets only objects outside `LaunchKeepScope` and preserves elapsed time/events for kept objects. | This is a different route, unused by the exact no-LLC warm profile. Its existence is not permission to replace the current reset behavior. Reject its configuration until separately proved. |
| Operation close and owner close | The warm harness explicitly waits/closes each operation; snapshots are collected after the prime, after operation 32, and within device-release wrapping. | Closing an operation does not reset counters or replenish a budget. Include prime, inter-operation work, cleanup work and the before-release observation, not just the 32 primary host intervals. |
| Host wall clock and CP model ticks | Host intervals/timeout are elapsed real time. Backend MMIO callbacks can call functional `cp_.tick()`; model time advances only through the applicable processor/platform path. | Neither a 180-second timeout nor a count of CP polls is an absolute simulated-event bound. A guard must count actual `SimPlatform::tick()` calls. |
| Complete platform/device destruction | Backend destruction joins the async task; processor destruction calls `finalize()`/`cleanup()`. Cleanup retires abandoned channel accounting after stopping workers and deleting platform work. | This disposes of the old lifetime. It does not validate that lifetime or recover its failed backend. A new context may start a fresh budget only after complete prior-context disposal. |

Source locations: `sim/simx/processor.cpp:41–59,201–233,310–345,358–400,429–449`; `sim/simx/processor_impl.h:118–126`; `sim/common/simobject.h:231–261,1209–1273,1344–1381`; `sw/runtime/simx/vortex.cpp:46–62,165–223`; `tests/regression/ai_warm_workspace/main.cpp:364–443,445–463`; `observer.cpp:188–225` in the same harness directory.

### Why the current cycle counter cannot be the absolute bound

`SimPlatform::cycles_` is launch-relative on this route. The core MPM `cycles` field is independently cumulative and increments only when the core has work; it excludes idle platform ticks. Other fields grow by warp population, lane population, bank work or pending memory reads. A small final `cycles_`, or even a bound on every launch's active-core cycles, therefore does not bound the sums being read after 33 launches.

There are also model ticks outside the kernel run loop: cache flushing calls `tick()` at `processor.cpp:286,300,306`; CP-transfer and launch-fence routes have further calls at `377,395`; the stepping entry calls it at `448`. The exact profile disables CP-on-LLC transfers, but cache/control paths still need the source inventory. Initialization, flush/drain and teardown observations must not fall through a guard that was added only to `ProcessorImpl::run()`. Model construction's current `initialize()` is a no-op, so it is not an existing lifetime counter-reset mechanism. [Sources: `sim/common/simobject.h:238–246,1270–1273`; `sim/simx/core.cpp:473–495`; the processor call sites above.]

The existing monotonicity check in `ai_warm_workspace/main.cpp:174–187` detects a decreasing reported value. It cannot exclude a hidden unsigned wrap that ends above the earlier snapshot, nor prove the history before that snapshot. A fixed launch population and fixed wall-clock timeout likewise provide no maximum number of simulated increments by themselves.

## 2. Actual backing fields, reset behavior and readout arithmetic

| Required observations | Actual updater / backing field | Lifetime and arithmetic to prove |
|---|---|---|
| `cycles`, `instructions`; eleven core rows | `Core::PerfStats` fields in `core.h:40–72`; updates in `core.cpp:480–495,524–569,776–794,980–983,1198–1212`; loads/stores in `lsu_unit.cpp:813–819` | Zero-initialized `uint64_t`; `Core::Impl::reset()` deliberately preserves them at `core.cpp:473–477`. `instructions` counts retired macroinstruction end markers, not lanes. |
| I-cache reads, read misses, MSHR stalls; D-cache reads, writes, read/write misses, evictions, MSHR stalls | `CacheBank` fields in `mem/cache.h:61–80`; writes at `cache.cpp:1194–1230,1292–1297,1341–1342,1434,1755,2128–2129,2173,2232` | Bank counters survive reset (`873–874`). Required readout is a sum across cache banks (`3472–3479`) and cache instances (`cache_cluster.cpp:83–88`), not simply one raw field. Both leaf and aggregate bounds matter. |
| Local-memory reads/writes/bank stalls | `local_mem.cpp:215,232,237,310–347` | Fields start at zero (`local_mem.h:44–52`) and survive reset (`local_mem.cpp:452–473`). The lane-service loop can increment reads/writes more than once per tick. DMA row service is a separate path; these fields are not a total of every local-memory traffic source. |
| Coalescer misses | `mem_coalescer.cpp:284–286` | Boolean increment per built non-final round; reset at `44–49` does not clear the statistic. `csr_unit.cpp:215–217` sums all LSU-block coalescers. |
| Global memory reads/writes | Request-arrival callbacks in `processor.cpp:202–208` | `perf_mem_reads_` / `perf_mem_writes_` are cumulative `uint64_t`. Do not infer their maximum arrival rate merely from the number of DRAM banks. Delivery callbacks can reflect upstream queues, bypasses and scheduled work. |
| `memory_lt` | `perf_mem_latency_ += perf_mem_pending_reads_`, `processor.cpp:344,449`; pending-read increment/decrement at `207,211` | A request-cycle integral over the run/step sites, not all elapsed host time or every flush tick. Pending reads are another unsigned state variable: an underflow at the response callback would invalidate a latency bound even if the total tick count were small. |
| `memory_bank_st` | `Memory::perf_stats()` copies `mem_xbar_->collisions()` (`memory.cpp:76–78`); `TxCrossBar::on_tick()` adds `has_collision` per output (`types.h:1741–1784`) | Crossbar collisions initialize to zero (`types.h:1695`) and survive its reset (`1724–1725`). Count the output-loop cardinality. `dram_sim.cpp:363` derives memory channels from the configured platform bank count. |
| TCU buffer stalls/hits/local reads | `tcu_unit.cpp:873,876,906`; `tcu_tbuf.cpp:194`; `TcuUnit::perf_stats()` assigns the sum from `tbuf()->reads()` (`tcu_unit.cpp:1298–1301`) | TCU counters and per-buffer read counts survive reset (`tcu_unit.cpp:359–360`, `tcu_tbuf.cpp:68–72`). The readout adds all buffer counts at `tcu_tbuf.cpp:106–111`. Stalls/hits are in the WGMMA-only function; compiled exclusion must be verified, not inferred from a zero measurement. |

**Do not broaden this to “all MPM counters are cumulative.”** `CachePortArb::on_reset()` zeros its own `collisions_` (`cache.cpp:2503–2507`), which feeds cache bank-stall readouts. The frozen required set omits the D-cache bank-stall selector. The required `memory_bank_st` uses the distinct, persistent crossbar field described above. Adding a selector requires a fresh lifetime proof.

`CsrUnit::set_csr()` has no supported write/reset entry for these MPM fields (`csr_unit.cpp:337–389`). Host MPM selection reads the fields: the repaired RV64 `Core::Impl::dcr_read()` reads the full low-address CSR and selects a 32-bit half (`core.cpp:1258–1273`). `vx_device_mpm_query()` still does low then high DCR transactions and combines them (`sw/runtime/common/perf.cpp:277–286`). Its all-core summation branch (`289–301`) is not used by the frozen core-zero requests.

In the exact single-owner serial harness, the backend's DCR hook waits for execution, the model run ends at its declared idle boundary, and MPM reads themselves do not advance the model. This supports stable halves and stable successive selector observations, subject to a complete route/configuration proof. It is not an atomic public snapshot API, and coherence does not itself prove no wrap. [Sources: `sw/runtime/simx/vortex.cpp:208–222`; `processor.cpp:339–345`; `ai_warm_workspace/observer.cpp:100–141`; `main.cpp:433–443`.]

## 3. Recommended minimal guard design — prospective, not implemented

### 3.1 Fixed lifetime and request ceilings

Use a separately versioned qualification implementation with two fixed, independently reviewed constants:

```text
T = 2^32 - 1     maximum charged platform ticks in one model lifetime
E = 2^32 - 1     maximum cumulative memory reads, and separately writes
M = 2^64 - 1     maximum value of a required SimX backing counter
```

These proposed limits are mathematical guard choices, not estimates of this workload's execution or measured limits. Freeze them before performance collection. A smaller reviewed ceiling is also valid. Reject any violation and retain the entire failed attempt; never restart a failed batch to replace it.

1. **Install one context-owned lifetime ledger before any model work.** Initialize it with the new required-counter backing objects. Charge at the single `SimPlatform::tick()` entry before any domain tick, immediate event, due event or worker release. On `ticks >= T`, latch failure and throw before doing model work; otherwise increment the ledger and run the unchanged tick. Count a partially executed tick as charged. Use comparison before addition, so the ledger cannot wrap itself.
2. **Preserve that ledger through `reset()` and `reset_launch()`, operation/owner close, queries and flushes.** A device-lifetime failure must likewise remain sticky. Reinitialization is legal only for a genuinely new model lifetime after full disposal. The singleton platform requires a definite owner/epoch boundary; do not reset a global ledger merely because a second `initialize()` call occurs.
3. **Guard the memory request callbacks before mutations.** Before admitting a read, require cumulative reads `< E` and pending reads `< E`; before admitting a write, require cumulative writes `< E`. Check every predicate for that arrival before incrementing any of its fields. Before a response decrement, require pending reads `> 0`. Thus, starting from zero and using only quiescent pending resets, `0 <= pending_reads <= cumulative_reads <= E`. Caps apply to delivered requests across the whole context, including outside-run delivery if any supported path supplies it.
4. **Retain the existing latency definition.** It adds pending reads at most once after each charged `run()`/`cycle()` tick. Therefore, throughout the lifetime:

   `memory_lt <= T * E = (2^32 - 1)^2 = 2^64 - 2^33 + 1 < 2^64`.

   Flush ticks with no latency addition only make this an overestimate. No DRAM completion-time estimate or queue-capacity guess is needed. If an implementation chooses not to enforce the request caps, it must instead prove an admission/occupancy bound or use a checked addition at every latency update; a tick ceiling alone is insufficient.
5. **For every other required field and readout, prove `C_j(t) <= R_j * t`, with zero origin and `R_j * T <= M`.** Include all relevant bank/cache/coalescer/buffer sums in `R_j`, not just the individual leaf maximum. Evaluate bounds using checked arithmetic or division (`R_j <= M / T`), never an overflowing multiplication or floating-point approximation. Nonnegative summands and a bound on their complete sum also bound every intermediate sum.
6. **Close the configuration and execution route.** Require the exact generated C++ configuration, effective constant dimensions and worker count, all selector availability, timing mode, `PERF_ENABLE`, immutable guard constants and guarded binaries. `SIMX_MT` absence resolves to one model worker (`sim/simx/types.h:49–60`); separately reject alternate worker/configuration paths. Test-only counter seeds or adjustable tiny limits must not be available in the measurement executable. Do not accept an environment-variable opt-out, caller flag or self-asserted qualification ID.

The record need not change any MPM selector or reinterpret a counter's width. A private qualification diagnostic can retain guard version, limit, model-epoch identity, ticks consumed and failure reason alongside the four snapshots and final close outcome. Its trustworthy force comes from reviewed source/binary/configuration binding and all successful public outcomes, not the witness string alone. The ledger must remain active through the final observation and close; it cannot be discarded as soon as `after_batch` is collected.

This narrow design adds one branch/increment per platform tick and a few checks at the already existing memory callback sites. It still changes host instrumentation cost, so it requires one fresh matched attempt with identical guarded binaries for both policies. It supplies no retroactive qualification for old observations.

### 3.2 Required maximum-rate proofs

The following are conservative source candidates, not completed independent qualification. They show that the remaining proof is finite and identify the places a reviewer must close. `N_I` and `N_D` mean total banks across the queried I/D-cache instances; `K_b` is the number of sector slots in a bank; `S_b` is sectors per line. Use **effective compiled** cardinalities. The historical expanded compiler-map values are not a substitute for C++ constants that depend on unresolved header expressions (`constants.h:74–86,111–128`).

| Required group | Candidate maximum increment in one charged tick | Proof obligation |
|---|---:|---|
| Active core cycles; scheduler idle | 1 each | One `Core::tick()` and one scheduling pass per platform tick. Idle platform work still consumes budget. |
| Active/stalled warps | 4 each | Masks are four-warps wide; no other updater. |
| Issued warps / threads | 1 / 4 | Count the `FETCH_WIDTH` loop, not issue width by analogy; prove effective fetch width one. |
| Scoreboard, LSU and TCU stalls | 1 each | Dispatch and scoreboard loops are each bounded by effective issue width one, with one increment per selected field per loop iteration. |
| Instructions / TCU instruction count | Safe upper bound 6 each | `commit()` can invoke `retire()` in its per-FU gather path as well as the final granted path. Five FU iterations plus at most one final retirement give a conservative bound at issue width one. Do not assert one retirement solely from the commit-beat comment. Tightening this bound is unnecessary. |
| Loads / stores | 4 each | One `process_request_step` per single LSU block and at most one active beat with a four-lane mask; the earlier `while` only skips inactive beats. Audit metadata/atomic branches and their compiled exclusions. |
| Local-memory reads / writes / bank stalls | 4 / 4 / 1 | One engine at one LSU block; at most four served lanes and one incomplete-pass stall per engine tick. Inventory DMA and atomic paths instead of assuming all local traffic has this accounting. |
| Coalescer misses | 1 | One boolean increment per coalescer tick; exactly one LSU-block coalescer in scope. Include its readout sum if dimensions change. |
| I/D-cache reads or writes; MSHR stalls | `N_I` or `N_D` each | One admission path per bank tick; MSHR failure alternatives return after their increment. |
| I/D-cache read/write misses | `2*N_I` or `2*N_D` each | A pipe-exit miss and an admission-coalescing miss may both occur within one bank tick. Inventory both sites. |
| D-cache evictions | Conservative sum of `K_b + 2*S_b + 1` across banks | Count ordinary fill-victim sectors, the AMO branch, full flush walks and token-flush walks. `processFlush()` has nested loops over the cache, so one eviction per bank/tick is not a valid generic proof. A looser safe bound avoids relying on transient queue capacity. |
| Memory reads / writes | Directly capped by `E` | Enforce at every relevant request callback. Without these checks, prove the complete callback arrival/production rate through bypass, queue and scheduled delivery paths. Counting ports alone is not such a proof. |
| Memory latency | At most `E` per update; at most `T` updates | Prove checked nonnegative pending accounting and the unique post-tick accumulation sites. No assumption about reads completing quickly. |
| Memory bank stalls | Number of memory-crossbar outputs, configured as two channels here | `has_collision` is a boolean per output loop. Bind actual `DramSim::platform_config()` and crossbar construction. |
| TCU buffer stalls / hits | Zero on the exact WGMMA-disabled route | Confirm the only increments are inside compiled-out `tbuf_step()`. If retained in a wider build, a safe candidate is `1 + NUM_TCU_BLOCKS` stalls and one hit per tick, requiring separate review. |
| TCU local-memory reads | At most 1 across all buffers | `TcuTbuf::tick()` calls `issue()` for at most one selected buffer, then breaks; `issue()` increments one bank-row count even if it sends multiple port packets. Prove/read the backing sum, not a mutable temporary `TcuUnit::PerfStats` copy. Ordinary WMMA also has a candidate zero-path proof, but the bound of one avoids depending on it. |

Completing this table requires a call-graph check that every required increment is inside one charged tick or one directly guarded callback, no reset recreates a positive starting value, no observer query mutates a required cumulative value except by safely assembling its backing sum, and each object is ticked at most once per global tick. Source updates, new topology, new selectors or other entry points invalidate the reviewed table until reviewed again.

If these static proofs cannot be closed cleanly, the rigorous fallback is checked arithmetic before **every** required backing-field increment and every required aggregate addition, with the same sticky failure path. That alternative is wider instrumentation, but it establishes non-wrap at the operation rather than guessing maximum rates. Checking only snapshots, checking a sum after it already wrapped, or saturating without failing cannot qualify the intended exact counters.

## 4. Current exception and teardown support — the old blocker has changed

The Wave 1 report's warning that a thrown guard would be swallowed described the old runtime. Current `Processor::run_checked()` calls `impl_->run()` without the legacy catch/return conversion (`processor.cpp:622–624`), and the SimX runtime schedules that checked entry (`vortex.cpp:218–219`). `AsyncRun` consumes exceptional futures, retains failure, rejects later execution and joins pending work (`sw/runtime/common/async_run.h:22–58,70–97`). Guarded CP register callbacks latch failure and return the existing nonzero HAL result (`vortex.cpp:74–104`). Thus the proposed single-worker guard can use a C++ exception that reaches the task future or the synchronous guarded callback.

The existing full-platform cleanup now clears abandoned channel accounting only after whole-platform work is disposed (`simobject.h:1344–1378`). It does not erase a live backend's `AsyncRun` failure. Budget failure during an event or tick must leave that device unusable until complete destruction; it cannot take a shortcut through `reset()`, manual counter clearing or mid-flight accounting repair.

This audit does **not** establish transport of exceptions from every internal platform worker, same-thread direct tick reuse after an exception, cancellation of a stuck worker, fatal-abort/signal recovery or reuse of a failed context. The current completion contract explicitly excludes those claims (`docs/designs/simulator_completion_v1.md:124–143`). The exact one-worker runtime route is essential: exceptions thrown from arbitrary internal worker threads need their own coordination, and a future only captures exceptions that reach its task. A valid legacy register-derived result of `-1` remains normal completion and must not become a guard-failure sentinel.

I did not rerun or infer native completion results. The code enables the failure mechanism; the parent task's separately reviewed native/public evidence must establish the execution scope before the new qualification layer uses it.

## 5. Failure-before-wrap verification to require next

These are proposed targeted tests, not tests executed for this report.

1. **Budget edge and action ordering:** use a test-only seam to set ledger state to `T-1`; allow the final permitted tick, then require the next tick to fail before any object tick, immediate callback, registered delivery or backing counter changes. Cover a small test ceiling as well as the production constant. Test comparison-before-increment, including an invalid over-limit ledger value. Keep injected seeds visibly separate from reachable native execution evidence.
2. **Across-launch lifetime:** run successive short launches whose individual clocks remain small but whose combined charged ticks cross the test ceiling. Full launch resets and explicit operation closes must not replenish the budget. Exercise initialization/flush/drain calls so active-core `cycles` can remain small while the same ledger is charged.
3. **Request/pending boundaries:** admit a read/write at `E-1`, then reject the next same-type arrival at `E` before any related counter mutation. Reject a response at pending zero before unsigned decrement. Exercise permitted quiescent reset of pending state without changing cumulative requests or the lifetime ledger; do not simulate recovery by discarding outstanding responses.
4. **Latency near its derived maximum:** seed a declared test seam with `ticks=T-1`, `pending=reads=E`, and latency at `(T-1)*E`; the final permitted update stays at `T*E`, and further model progress is rejected. This is a directed arithmetic/ordering test, not a claim that the workload naturally reaches that state. Verify the bound calculation itself uses non-overflowing arithmetic.
5. **Actual updater and aggregate coverage:** exercise maximum applicable warp/lane activity, simultaneous cache pipe/admission misses, dirty-sector flushes, coalescer rounds and crossbar collisions. Verify per-tick maxima against the frozen proof table and sum actual backing fields at their real readout sites. A passing transport fixture with injected stable values does not establish these update-rate/lifetime properties. Retain directed low-half crossings and relevant 64-bit boundary tests without falsely requiring unreachable near-maximum states to be production-valid.
6. **Public persistent failure:** inject the guard failure into the exact guarded timing/profile runtime; require unsuccessful public operation/event/queue waits, repeated failure, failed subsequent launch/DCR access, no valid warm success summary and no acceptance of partial counter snapshots. Test both a pending task and a task that fails before the first busy poll. Cleanup must join and dispose of the failed device; a fresh context may subsequently work, while reuse of the failed backend remains rejected.
7. **Qualification/replay rejection:** reject absent/disabled/mismatched guard binaries, a changed limit/rate table, unsupported selectors/topology/workers, wrong zero origin or epoch continuity, failed guards, incomplete 33-operation batches and missing before-release/close results. Cover favorable and unfavorable statistics with invalid qualification. Preserve v1's unconditional `P06-WARM-RV64-MPM-HIGH-HALF`, `qualified=false` and `absolute_no_wrap_bound="not_established"` behavior.

A boundary helper test proves its arithmetic and branch placement; an actual framework fixture proves the framework path; a native linked test proves its declared native path. None substitutes for the others, and none by itself proves a static maximum-rate table.

## 6. Concrete next action and unresolved obligations

**Next action: freeze and independently review a versioned counter-lifetime specification and proof table for the exact 33-selector timing SimX route, using the tick/request-cap design above, before implementing it or collecting performance data.** The implementer should own the narrow guard plus versioned diagnostic/enforcement changes; a different reviewer must validate updater coverage, lifetime boundaries, arithmetic and fail-closed replay. Then implement only that reviewed guard and its boundary tests, complete source-bound native/public qualification, and collect the unchanged fresh warm matrix once all prerequisites pass.

Remaining proof obligations are explicit:

- Resolve and bind all effective C++ dimensions and source/configuration/binary identities; a profile name and historical compiler dictionary alone are insufficient.
- Close every row's call graph and maximum-rate calculation, including aggregate readout arithmetic, full-cache flush loops and the retirement gather path.
- Establish zero origin and guard coverage before the first model work; preserve budget/failure across all launch resets and through before-release/close.
- Prove or guard pending-read bookkeeping and the quiescent-reset premise. Current unchecked `--perf_mem_pending_reads_` is not itself evidence against underflow.
- Verify the guard exception on the actual supported public runtime and complete teardown path, without extending the claim to internal-worker exceptions or failed-context reuse.
- Keep coherent read proof, repaired transport coverage and no-wrap proof separate and all mandatory in the new qualification layer.
- Independently review the new record/replay rejection behavior and retain the frozen v1 block, accepted cold records, numerical fixtures, policy order, sample population, thresholds and failed attempts unchanged.

No current native result, measured speedup, RTL-wide lifetime proof, P06-A02/A03 acceptance or physical-device property follows from this audit.
