# W07-A01 — exact P06 counter coverage handoff

**Audit scope:** read-only inspection of clean `db5ebb3a16770004423f2456ec6d0caaa0aced6d`. No builds, tests, feature changes, gate changes or golden changes were performed. The inventory arithmetic below was recomputed directly from the frozen JSON. This is a prospective technical handoff, not acceptance.

**Priority:** after source-bound completion verification/review, freeze and independently review the **exact RV64 `p02-tfr`, SimX timing, `PERF=1` selector and stable-read contract**. Then qualify all 33 available selectors through their actual backing sources and the public snapshot route. The old representative transport matrix is insufficient. Absolute lifetime/no-wrap proof and versioned evidence enforcement remain separate blockers. [Plan](AI-GPU/docs/project/p06-mpm-qualification-plan.md)

## 1. Exact route to bind

The warm manifest requires RV64; SimX timing; one cluster, core and socket; four warps × four threads; issue width one; native TFR tensor and STD scalar arithmetic; one ALU/LSU/FPU/TCU block, four TCU lanes; TFR PE ratio 1, latency 4 and `USE_DSP=0`. ICACHE/DCACHE and 16 KiB local memory are enabled; L2/L3 and VM are disabled. The shared FP16 bank supports both FP16 and BF16. TF32, FP8, FP4, INT8, INT4, MX, MXFP4, NVFP4, sparse, DSM, WGMMA, matrix load/store and FEDP2K are excluded. `SIMX_FUNCTIONAL`, `SIMX_MT` and tracing/debug overrides are excluded; the serial executor therefore resolves to one worker. The frozen ISA value is **2420223512872 (`0x23380901128`)**. [Manifest](AI-GPU/ci/project/p06_warm_contract.json), [profile](AI-GPU/profiles/p02-tfr.json), [compile guards](AI-GPU/sw/common/ai_matmul_profile.h), [configuration validator](AI-GPU/ci/project/p06_compiler_records.py), [worker derivation](AI-GPU/sim/simx/types.h)

The actual runner configures `--xlen=64 --profile=p02-tfr`, then uses `CONFIGS="-DITYPE=fp16|bf16 -DOTYPE=fp32 -DKUNROLL=1"` and `PERF=1`. Exactly the backend role receives `PERF_ENABLE=1`; runtime, kernel and host must not acquire it. Original records and independently expanded headers must agree. Each format must retain identical host/runtime/kernel bytes across both policies. The kernel is ordinary dense `wmma_context<..., false, 8, 0, false>`, tile `(8,4,8)`, ordinary fragment loads, `mma_sync`, and FP32 output—not the WGMMA or shared-memory matrix-descriptor route. [Runner](AI-GPU/ci/project/p06_warm_execute.py), [role validator](AI-GPU/ci/project/p06_warm_compiler_records.py), [kernel](AI-GPU/sw/kernel/ai/matmul.cpp)

## 2. Independently reconciled selector inventory

Availability was recomputed as `required_isa == 0 || (isa & required_isa) == required_isa`: **BASE 2 + CORE 11 + ICACHE 3 + DCACHE 6 + MEM 8 + TCU 3 = 33 available**, plus **6 L2 + 6 L3 = 12 unavailable**. Every row targets `core_id=0`; scope is core except ICACHE/DCACHE (socket), L2 (cluster), L3 and `memory_*` (global). The frozen manifest and actual `kCounters` descriptor array agree. [Manifest](AI-GPU/ci/project/p06_warm_contract.json), [producer inventory](AI-GPU/tests/regression/ai_bench_common/counters.h), [availability implementation](AI-GPU/tests/regression/ai_warm_workspace/observer.cpp)

In the following table, “old seed” means a nonconstant backing-counter test in the retained TCU-disabled native harness, **not coverage of the warm configuration**. `i` is the low host selector (`CSR - 0xB00`).

| Class | CSR / i | Required available row | Old SimX seed | Old RTL seed |
|---:|---|---|:---:|:---:|
| 0 | B00 / 0 | cycles | Yes | Yes |
| 0 | B02 / 2 | instructions | Yes | Yes |
| 1 | B03 / 3 | core_sched_idle | Yes | Yes |
| 1 | B04 / 4 | core_active_warps | Yes | Yes |
| 1 | B05 / 5 | core_stalled_warps | No | No |
| 1 | B06 / 6 | core_issued_warps | No | No |
| 1 | B07 / 7 | core_issued_threads | No | No |
| 1 | B0A / 10 | core_stall_scrb | No | No |
| 1 | B0E / 14 | core_stall_lsu | No | No |
| 1 | B10 / 16 | core_stall_tcu | No | No |
| 1 | B17 / 23 | core_instr_tcu | No | No |
| 1 | B1C / 28 | core_loads | No | Yes |
| 1 | B1E / 30 | core_stores | Yes | Yes |
| 3 | B03 / 3 | icache_reads | No | Yes |
| 3 | B04 / 4 | icache_miss_r | No | Yes |
| 3 | B05 / 5 | icache_mshr_st | No | Yes |
| 4 | B03 / 3 | dcache_reads | No | Yes |
| 4 | B04 / 4 | dcache_writes | No | Yes |
| 4 | B05 / 5 | dcache_miss_r | No | No |
| 4 | B06 / 6 | dcache_miss_w | No | No |
| 4 | B07 / 7 | dcache_evicts | No | No |
| 4 | B09 / 9 | dcache_mshr_st | No | Yes |
| 7 | B07 / 7 | lmem_reads | No | Yes |
| 7 | B08 / 8 | lmem_writes | No | Yes |
| 7 | B09 / 9 | lmem_bank_st | No | Yes |
| 7 | B0A / 10 | coalescer_miss | No | Yes |
| 7 | B03 / 3 | memory_reads | No | Yes |
| 7 | B04 / 4 | memory_writes | No | Yes |
| 7 | B05 / 5 | memory_lt | No | Yes |
| 7 | B06 / 6 | memory_bank_st | No | No; no RTL mapping |
| 11 | B03 / 3 | tcu_tbuf_stalls | No | No |
| 11 | B04 / 4 | tcu_tbuf_cache_hits | No | No |
| 11 | B05 / 5 | tcu_lmem_reads | No | No |

The unavailable rows are exactly `l2cache_{reads,writes,miss_r,miss_w,evicts,mshr_st}` under class 5 and `l3cache_{reads,writes,miss_r,miss_w,evicts,mshr_st}` under class 6, with low CSR addresses `B03,B04,B05,B06,B07,B09` respectively. They must remain present as `enabled=false,status=null,value=null` and receive **no native query**. A reported zero is not the unavailable representation. TCU class 11 remains available because EXT_TCU is enabled even though WGMMA is disabled; a workload-zero value does not remove its selector obligation. [Observer](AI-GPU/tests/regression/ai_warm_workspace/observer.cpp), [warm contract §6](AI-GPU/docs/designs/warm_workspace_benchmark_v1.md)

For every available row, the public API issues low then high at DCR `0x001`: `tag_lo=(class<<22)|(i<<16)|0`; `tag_hi=tag_lo|0x00200000`. The high selector is `i+32`, corresponding to internal address `0xB80+i`; it is **not** a second valid public CSR argument. Example TCU stalls: `0x02c30000` / `0x02e30000`. SimX reads the full RV64 low-address CSR value and shifts by 0/32; two successful unsigned replies reconstruct `(uint64_t(hi)<<32)|lo`. [Public implementation](AI-GPU/sw/runtime/common/perf.cpp), [Core adapter](AI-GPU/sim/simx/core.cpp), [wire contract](AI-GPU/docs/designs/host_mpm_transport_v1.md)

## 3. Exact limits of retained evidence

The reviewed packet's eight cells use **empty profile and CONFIGS, TCU disabled**, RV32/RV64 × PERF off/on × linked SimX/RTL leaf. SimX deliberately runs no ticks between seeding and reading. It seeds only cycles, instructions, CORE indices 3, 4 and 30: **5/33 required rows; 28 remain uncovered**. Cycling through other class numbers at indices 0/2 exercises class-independent base counters, not each class's user selectors. Merely enabling TCU in this existing harness would still not test class-11 indices 3/4/5. [Packet](AI-GPU/docs/project/evidence/p06-mpm-transport/README.md), [SimX harness](AI-GPU/tests/unittest/mpm_transport/main.cpp)

The retained RTL leaf seeds **19/33 relevant rows** and six additional L2/L3 rows that are unavailable in warm. The 14 omissions are seven CORE rows, three DCACHE rows, `memory_bank_st`, and three TCU rows. More fundamentally, `memory_bank_st` (`7:B06`) has a SimX backing source (`memsim.bank_stalls`) but no case in RTL's MEM decoder; RTL leaves it zero. A future 33-row SimX qualification must not be described as all-33 RTL parity. The public reconstruction fixture uses controlled storage/responders and is not an end-to-end native public-runtime test. [RTL harness](AI-GPU/hw/unittest/mpm_transport/main.cpp), [RTL wrapper](AI-GPU/hw/unittest/mpm_transport/VX_mpm_transport_top.sv), [RTL decoder](AI-GPU/hw/rtl/core/VX_csr_mpm.sv), [SimX decoder](AI-GPU/sim/simx/csr_unit.cpp), [host fixture](AI-GPU/ci/project/fixtures/p06_mpm_transport_host.cpp)

## 4. Smallest additional native matrix and pass/fail conditions

| Obligation | Smallest useful new coverage | Explicit pass / fail |
|---|---|---|
| Exact selector route | One RV64 `p02-tfr` / timing / PERF=1 hardware configuration; run the 33-row selector matrix against each distinct format-bound backend artifact (normally FP16 and BF16 builds). | Actual Processor→Cluster→Socket→Core→CSR route; real backing counters; all rows and halves exact. Missing selector, wrong class/source, truncation, stale reply, changed class or unmatched configuration fails. |
| Stable boundary vectors | Reuse all ten frozen SimX vectors for each row: zero, one, the 32-bit boundary and successor, patterned/high 44-bit values, bit 44, a 64-bit pattern, UINT64_MAX. Hold sources stable; low-first, high-first, repeat and alternate unequal class/selector values. | Independently specified low/high/reconstructed values agree exactly, including bits above 43. No copied decoder or synthetic array replacing production routing. A zero-only TCU/cache test fails to establish selection. |
| Actual public snapshot coherence | FP16/BF16 × both policies = **four diagnostic processes**, using the unchanged 33-operation caller and all four snapshot locations. This is 132 launches/4,224 checked words, not the full warm experiment. | Sixteen snapshots contain 528 enabled public queries/1,056 half replies, and 192 unavailable rows with no query. Prove/observe completed successful execution, serial CP ownership, no queued launch/DMA capable of advancing model state, and stable model state throughout each two-half read. Actual numerical outputs and cleanup must pass. |
| Failure containment | A bounded qualification-guard failure at its eventual native enforcement point, plus normal controls under the same configuration. | Failure reaches public wait/query, remains sticky on repeated observation, suppresses later work, and produces failed evidence. Error-as-zero, success after failure, or a completed/qualified record after guard violation fails. This is future guard testing, not a rerun or replacement of completion evidence. |

These cells should be frozen/reviewed before collecting performance results. For source-only reasoning about coherence, the relevant chain is: `ProcessorImpl::run()` returns after cores stop **and** `SimPlatform::idle()`; backend DCR reads call `run_.wait()`; the MPM DCR/CSR route itself does not tick the platform; the warm caller explicitly closes each operation before its snapshot. This is a strong candidate proof route, but its preconditions need execution-bound enforcement/evidence. Exact warm configuration has `CP_ON_L2=CP_ON_L3=0`; broader LLC-client transfer paths that preserve memory-side work must not be silently included. [Run loop](AI-GPU/sim/simx/processor.cpp), [backend hooks](AI-GPU/sw/runtime/simx/vortex.cpp), [CP derivation](AI-GPU/sim/simx/constants.h), [caller](AI-GPU/tests/regression/ai_warm_workspace/main.cpp)

Seeding must address actual origins: cache/socket aggregates, local memory, coalescers, processor memory counts and TCU/TcuTbuf. In particular, `TcuUnit::perf_stats()` overwrites `lmem_reads` from `tbuf()->reads()`; assigning a temporary returned stats copy does not test this row. Only cycles/instructions require positive warm batch deltas; available auxiliary zeros are valid. If any required counter can advance between halves, the stable-read cell fails and a separately reviewed coherent-read algorithm plus adversarial rollover evidence is necessary. Repeated equality or small monotonic values cannot substitute for the proof. [CSR origins](AI-GPU/sim/simx/csr_unit.cpp), [TCU getter](AI-GPU/sim/simx/tcu/tcu_unit.cpp), [qualification obligations](AI-GPU/docs/project/p06-mpm-qualification-plan.md)

## 5. What the completion fix now enables

`Processor::run_checked()` propagates exceptions from the actual model loop while ignoring legitimate legacy `gp` values, including `-1`. SimX launches that checked entry. `AsyncRun::collect()` consumes `future.get()`, latches `failed_` and rethrows; `require_healthy()` rejects later operations. CP callbacks catch the exception and return their existing HAL failure; `CallbacksAdapter` maps it to `VX_ERR_INVALID_VALUE`, and CP polling checks the error before accepting a completion sequence number. Thus a future throwing counter guard can become an observable persistent public failure instead of apparent success. This does not make `abort()` or a hung task recoverable. [Checked entry](AI-GPU/sim/simx/processor.cpp), [AsyncRun](AI-GPU/sw/runtime/common/async_run.h), [backend](AI-GPU/sw/runtime/simx/vortex.cpp), [adapter](AI-GPU/sw/runtime/common/vortex2_internal.h), [polling](AI-GPU/sw/runtime/common/device.cpp), [completion contract](AI-GPU/docs/designs/simulator_completion_v1.md)

This audit establishes no counter lifetime/reset proof, no absolute no-wrap bound, no completion acceptance and no warm qualification. Preserve `P06-WARM-RV64-MPM-HIGH-HALF`, `qualified=false`, `absolute_no_wrap_bound="not_established"`, cold pins and historical failures. New qualification must separately bind complete source/configuration, actual interpreter, tools and binaries, be independently reviewed, and only then permit a fresh full 24-process warm attempt under unchanged rules. [Frozen block](AI-GPU/ci/project/p06_warm_analyze.py), [qualification plan](AI-GPU/docs/project/p06-mpm-qualification-plan.md)
