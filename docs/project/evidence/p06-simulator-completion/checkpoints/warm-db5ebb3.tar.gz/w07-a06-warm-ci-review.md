# Wave 7 agent 6 — Existing warm CI on the simulator-completion checkpoint

## Review decision

**The existing warm-workspace CI packet is valid bounded integration evidence for the current completion checkpoint.** The original GitHub artifact was downloaded and matched against GitHub's published ZIP digest. Data-only replay passes, reconciles the complete fixed experiment, and retains the unconditional warm-v1 qualification block. This review makes no performance or phase acceptance claim.

**Dedicated completion evidence remains pending in this review.** Run `45006726571` and its required native unit and public-success regression are separate obligations. The warm run does not substitute for them, regardless of its larger successful-launch count.

This was a read-only review of repository `baabi-boo/AI-GPU`. No repository file, workflow, gate, threshold, golden, acceptance record, or commit was changed. No local native build, retained binary, or archive script was executed. The repository working tree was clean at review completion.

## 1. Source, run, job, and archive identity

| Identity | Observed value |
| --- | --- |
| Repository / PR | `baabi-boo/AI-GPU`, PR [#6](https://github.com/baabi-boo/AI-GPU/pull/6) |
| Branch | `codex/p06-simulator-completion-20261122` |
| Run API head SHA | `db5ebb3a16770004423f2456ec6d0caaa0aced6d` |
| PR base | `42809ff0c1b81384d7c9b079e4ef786be8407600` |
| Actual checkout / retained source revision | `782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd` |
| Branch and merge tree | `1536393fef63bd4a4639505ce797c27303db1cc7` |
| Workflow / run | [P06 Warm Workspace, run 45006726455](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726455), run number 8, attempt 1, `pull_request` |
| Workflow path | `.github/workflows/p06-warm-workspace.yml` |
| Job | [137159859123 — Matched warm workspace experiment](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726455/job/137159859123) |
| Job result / runner | `completed/success`; `ubuntu-22.04`; runner ID `1000004112` |
| Job interval | 2026-11-22 09:17:03–09:21:25 UTC |
| Retained execution interval | 2026-11-22 09:18:19–09:21:19 UTC |
| Artifact | [14748485277](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726455/artifacts/14748485277) |
| Artifact name | `p06-warm-workspace-782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd-run45006726455-attempt1` |
| ZIP bytes | `5,870,951` |
| ZIP SHA-256 | `9abac0ec3611c111528968460121db19e3449ad7184e7b8c433e0ad20b54e744` |
| Artifact expiry | 2026-12-22 09:21:20 UTC; `expired=false` when inspected |
| Original `warm-workspace/report.json` SHA-256 | `fe3f1abe0577dadb2c5133b213a81ed76cbde1279fdd46fb978dd9d4edd8e289` |

The distinction between run head and executed merge is explicit: checkout logs fetch `refs/pull/6/merge`, `git log -1` prints the merge SHA, and retained `job.json` and source snapshots name that same merge. The [GitHub Git-commit API](https://api.github.com/repos/baabi-boo/AI-GPU/git/commits/782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd) independently confirms the two parents and the tree above. The local branch commit has that identical tree; no source-revision relabeling was used for replay.

The full jobs and artifacts API responses each report `total_count=1`, eliminating a first-page ambiguity in the convenience wrappers. All 15 returned job steps completed successfully, including source preparation, native warm execution, and artifact upload. The upload log's digest, artifact ID, size, and name agree with the API metadata and downloaded bytes. The ZIP has 1,256 members totaling 32,746,229 uncompressed bytes. It was read directly without extracting or executing its contents.

Raw receipts are retained under `/workspace/scratch/ea983fdea786/w07-a06-warm-ci/`: `run-api.json`, `merge-api.json`, `jobs-full-api.json`, `artifacts-full-api.json`, and `job-137159859123.log`.

## 2. What actually executed

The workflow restored identified tool and dependency inputs, quarantined pre-existing untracked cocogfx cache products, verified a clean source checkout, and ran the existing warm runner with `--jobs 2 --timeout-seconds 1800 --run-timeout-seconds 180`. Its sole backend was **timing SimX**, with FP16 and BF16 builds and both workspace policies.

The retained command inventory contains 53 commands: five tool-version checks, twelve configure/build/header checks per format, and twelve experiment processes per format. All 53 records report a started process, exit code zero, pass outcome, and completed cleanup. Replay validates the exact command sequence, environment, raw-log identities, configuration records, and process bindings. The runtime-build logs contain compilation of the changed `sim/simx/processor.cpp` and `sw/runtime/simx/vortex.cpp` in both builds. The commands still pass through a ccache wrapper in one backend compile command, with `CCACHE_DISABLE=1` recorded in the enforced environment.

| Format | Policy | Processes | Warm-up / measured processes | Launches | Exact checked FP32 words | Tensor creates / releases |
| --- | --- | ---: | --- | ---: | ---: | ---: |
| FP16 | `per_operation` | 6 | 1 / 5 | 198 | 6,336 | 594 / 594 |
| FP16 | `reusable_single_tile` | 6 | 1 / 5 | 198 | 6,336 | 18 / 18 |
| BF16 | `per_operation` | 6 | 1 / 5 | 198 | 6,336 | 594 / 594 |
| BF16 | `reusable_single_tile` | 6 | 1 / 5 | 198 | 6,336 | 18 / 18 |
| **Total** | | **24** | **4 / 20** | **792** | **25,344** | **1,224 / 1,224** |

Each process contains one excluded prime followed by 32 operations. Pair zero is the separately excluded warm-up pair for each format. The measured population is therefore 20 processes, 640 operations, and 20,480 checked words. The replay recomputed these totals and validated the fixed alternating policy order. There were no failed processes, output mismatches, or final live tensor buffers. The reported 320-byte peak is requested tensor payload and the memory observations are simulator accounting; neither establishes physical memory reclamation.

The original runner report says `outcome=pass`, `full_matrix_completed=true`, and `hypothesis_evaluation=not_evaluated`. It also says `acceptance_claimed=false`, `performance_acceptance=false`, `phase_acceptance=false`, and `phase_complete=false`. Job-initialization and preparation records retain their stage-specific `native_execution=not_run`; those early-stage fields do not erase the subsequent process records and are not completion-test evidence.

## 3. Source, tool, configuration, and binary binding

All 987 retained source bodies pass the packet verifier's inventory, size, hash, and before/after stability checks. An additional independent Git-blob comparison matches **794** retained bodies to the checkpoint tree, with zero mismatches. This includes all ten changed production/build files retained by this warm packet: both SimObject headers, the SimX completion build fragment, processor source/header, `async_run.h`, and the two runtime Makefile/source pairs.

The other **193** bodies are third-party headers: 186 under ramulator and seven under softfloat. Their archive identities are consistent, but local submodule Git objects were unavailable, so this review does not claim independent Git membership for them. All five top-level submodule gitlinks match the checkpoint; three nested cvfpu gitlinks remain retained identities without local object verification. The complete matched and unverified inventories are in `source-git-membership.json`. Retaining an RTL-runtime source file or functional-framework header is not evidence that those routes executed in this SimX timing experiment.

The preparation binds toolchain ID `v3.0.2-6cff3efdc1b721e4fec9165801ecd405be34dd11`, cache key `Linux-toolchain-v3.0.2-6cff3efdc1b721e4fec9165801ecd405be34dd11-lite`, and dependency cache key `Linux-thirdparty-cbe0d7fc3a5ec7c6d1b71c86a227694d83e413fccc1d512acfa661fdbe86c7ac`. The packet retains 20 tool/library identities and separately identifies three reused dependency libraries. Cache-key matching is supplemented by actual file hashes.

| Executing tool | Recorded version | SHA-256 of recorded executable |
| --- | --- | --- |
| CPython | 3.12.14; provisioned interpreter and `python3` resolve together | `d13074847cd54749b1189cd5a798fdbf32328ecfa297fd61ee457d767de3e6bd` |
| Host g++ | Ubuntu 11.4.0-1ubuntu1~22.04.3 | `2360901d864cf10bfd6296e261cb2c14053552a80377761ab07146ec9ec9a2c0` |
| Vortex clang | 20.1.8; LLVM source revision `f44a6bb2af4c62847585305bbdc760fbe0e3645f` | `92f2fbf93bb013f414871b9dde08174f42832b169389f59cd373451d373cf3cf` |
| RISC-V GCC | 12.2.0; banner `g2ee5e430018-dirty` | `1d45ae00898529ef4781942ffa2ac403abc2fe2dc559b4eb01014d170d52e408` |

The dirty text in the prebuilt GCC version banner is preserved; it is not rewritten into a claim about that tool's upstream build cleanliness. The hashes identify the actual recorded tool files but do not inventory every compiler support file, system header, or dynamically loaded system library.

Generated headers, expanded macros, and separate runtime/backend/kernel/host compiler records bind both variants to RV64 `p02-tfr`: one core, one cluster, socket size one, four warps, four threads, issue width one, tensor TFR, scalar STD, and `PERF_ENABLE=1`. `SIMX_FUNCTIONAL` and `SIMX_MT` are absent. The measured fixture remains `single-dense_boundaries`, shape M=8, N=4, K=8, with FP32 output. The profile digest is `79a551bd7ba51b5aa4b221eeb9c8f68b0f3078e6282ce71a1f28e9bc4593a102`.

| Per-format build binding | Exact ID |
| --- | --- |
| `simx-fp16` | `f970aa26400cbb4aa903abc94a3f60f3080e1093231c37b0b89cfcac6cc1ac37` |
| `simx-bf16` | `1e3746f05fd0ab637c4d7be25eb5a12d615ec463de61356def845650b40e46c0` |

Every policy within a format uses that format's same host executable, kernel, and runtime identities. Artifact before/after snapshots remain equal. FP16 and BF16 appropriately have different application/kernel identities; the recorded runtime-library identities match across both builds. Full binary, generated-header, tool, dependency, and source identities are retained in the original ZIP and `audit-summary.json`. This is provenance and retained-data verification, not a binary replay.

## 4. V1 qualification and acceptance remain unchanged

Git comparison against parent `42809ff0c1b81384d7c9b079e4ef786be8407600` shows byte-identical warm workflow, runner, JSON contract, analyzer, replay, and benchmark design contract. In particular:

| Preserved file | SHA-256 |
| --- | --- |
| Warm workflow | `26f4be747d1d6fcb828532281dcea6dfff60469ea73460e03b5b1ac53a66668b` |
| `p06_warm_contract.json` | `893d85401b1d5f7757d82cb7c743a89b36264fe19c7d08c239b7f216b7a8cbbd` |
| `p06_warm_analyze.py` | `ac273f587f759900d16ad41c7c63c2d2b10ca0864d5018f8403572f75e5a3e88` |
| `p06_warm_replay.py` | `8982c9ec5b1599080c8df09dd685ecf7aae7488af4708463dda819c4bcb62890` |

AST inspection confirms `_full_hypothesis_qualification()` still consists of its docstring and an unconditional literal return. It returns `status=blocked`, `qualified=false`, finding `P06-WARM-RV64-MPM-HIGH-HALF`, `counter_transport=unqualified_low_32_bits`, and `absolute_no_wrap_bound=not_established`. This preserves the historical v1 classification and qualification requirement. It is not a new determination that the separately repaired current transport implementation still discards the high half. No versioned qualification layer was introduced by this checkpoint.

Replay also computes the existing conditional diagnostics, which are **not satisfied**:

| Format | Candidate/reference host median ratio | Median at most 95% | No slower measured host pair | No increased reported-cycle pair |
| --- | ---: | --- | --- | --- |
| FP16 | 1.0038353230 | false | false | true |
| BF16 | 0.9793735607 | false | false | true |

These describe instrumented host time, including validation and observer work, over five measured pairs per format. They are not qualified modeled-cycle or physical-performance results. No sampling, thresholds, outlier rules, replacement rules, or stopping conditions changed. Even favorable predicates would not lift the unconditional qualification block.

## 5. Replay performed and evidence limits

The following command completed with exit zero, from the current repository source root:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 ci/project/p06_warm_replay.py \
  --archive /workspace/scratch/ea983fdea786/w07-a06-warm-ci/p06-warm-run45006726455-artifact14748485277.zip \
  --sha256 9abac0ec3611c111528968460121db19e3449ad7184e7b8c433e0ad20b54e744 \
  --source-revision 782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd \
  --output /workspace/scratch/ea983fdea786/w07-a06-warm-ci/replay.json
```

The local result is `outcome=pass`, `native_execution=not_run`, `archive_provenance_validation=pass`, and `hypothesis_evaluation=blocked`. It checks 53 commands and 987 retained source files and recomputes the complete counts. Its SHA-256 is `25cfc3fcbd9aaddf3a90ded0675af48fce2e8633c1cb07e9f2d5f5a89f78fb59`. The original runner did not execute this analyzer; these diagnostics come from the current unchanged trusted replay code applied to the original artifact.

The success supports the existing positive warm-workspace route on the checkpoint. It does not establish the dedicated native unit's deliberate x3 values 7 and -1, real bounded-RAM exception through asynchronous get, or failed-context destruction followed by fresh normal execution. It also does not establish the dedicated public-success regression's intentional global-data/gp exercise and six-launch/two-context scenario. Those exact obligations remain pending for the separately owned completion run.

This review likewise supplies no new exceptional public-runtime path, immediate-completion schedule proof, functional SimX execution, processor RTL execution, native multicore/multiworker exception transport, full-AFU or vendor execution, FPGA/silicon result, circuit cost/timing qualification, absolute counter lifetime bound, P06-A02/A03 acceptance, or phase completion. Original artifact provenance and data consistency do not independently authenticate arbitrary producer honesty.

## 6. Safe artifact-reference transfer for the completion artifact

The available read-only tool is `mcp__codex_apps__github_download_workflow_artifact`. Use the specified GitHub connection and repository, an artifact ID obtained from run metadata, and an optional local-friendly filename. The tool follows GitHub's temporary redirect and returns an opaque reusable file-reference object.

In this session, `result.structuredContent.file_uri` is **an object**, not a filesystem path. Its `download_url` field is the transferable HTTPS URL. The same value is duplicated at `result.structuredContent.structuredContent.download_url`. Read the fields programmatically; do not print the complete result, the signed URL, or archive bytes.

The successful transfer used Python `urllib.request.urlopen` with a 45-second timeout, wrote to a new scratch file, checked `Content-Length` when available, and enforced a streaming cap of 209,715,200 bytes (200 MiB). It then required the exact API size and SHA-256 before accepting the local ZIP. The URL stayed in tool memory/command input and was not printed or retained in the evidence files. Error handling printed only an exception type, avoiding accidental URL disclosure.

For the later completion artifact: inspect metadata first, refuse an over-budget archive, call the dedicated artifact download tool, transfer the returned reference within the same bounded approach, and verify the original artifact digest before inspection. The generic GitHub text-fetch tool rejects binary responses and is not the archive-download route. A plain file-reference ID by itself is not a local path.

## Retained review products

All paths below are under `/workspace/scratch/ea983fdea786/w07-a06-warm-ci/`:

- `p06-warm-run45006726455-artifact14748485277.zip`: original digest-matched archive.
- `job-137159859123.log`: decoded original hosted job log.
- `run-api.json`, `merge-api.json`, `jobs-full-api.json`, `artifacts-full-api.json`: read-only GitHub metadata receipts.
- `download-receipt.json`: transfer method and safe file identity, with no signed URL.
- `replay.json`: complete retained-data verifier output, including limitations and all process checks.
- `audit-summary.json`: source, tool, binary, matrix, preservation, and conditional-diagnostic details.
- `source-git-membership.json`: 794 matched Git blobs, 193 explicitly unverified third-party headers, and submodule-gitlink scope.
