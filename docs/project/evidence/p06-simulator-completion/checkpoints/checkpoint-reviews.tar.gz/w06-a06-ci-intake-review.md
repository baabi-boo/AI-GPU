# Wave 6, agent 6: native CI intake and trust review

**Reviewer:** independent agent `/root/w06_a06_ci_intake_review` (overall assignment 36/60).  
**Review date:** 2026-11-22 UTC; report prepared at approximately 09:19 UTC.  
**Repository:** `baabi-boo/AI-GPU`; [PR #6](https://github.com/baabi-boo/AI-GPU/pull/6).

## Verdict and current boundary

**Source/trust verdict: favorable within the assigned scope.** I found no F2/F3 source defect in the native completion workflow, its CI contract tests, or the relevant source-preparation behavior. The intended exposure is ordinary pull requests, path-filtered pushes to `master`, and manual dispatch without tuning inputs. The job is hosted, has read-only repository permission, restores rather than saves caches, verifies clean source and tool identities, invokes the fixed runner, propagates producer failures, and always attempts to upload the retained evidence directory.

**Execution verdict: native completion remains `not_run` in the observed intake snapshot.** The native job and PR governance job were queued. The push governance job had started but had no conclusion. No native command, successful native cell, completed workflow conclusion, or artifact contents were observed in this assignment. This review does not close native completion, counter qualification, P06-A02/A03, or any broader acceptance obligation.

The execution blocker is the missing completed native run and independently reviewed packet. A queued workflow is scheduling metadata, not execution evidence. No source change is requested by this review.

## Exact source and merge identities

- Reviewed local `HEAD`: **`db5ebb3a16770004423f2456ec6d0caaa0aced6d`**.
- Local `git status --porcelain=v1 --untracked-files=all` was empty at review start and at the final inspection.
- Every file in the digest table below was compared byte-for-byte with `git show db5ebb3a16770004423f2456ec6d0caaa0aced6d:<path>` and matched.
- Parent-supplied generated merge revision for PR #6: **`782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd`**. This object is not present locally (`git cat-file -t` could not resolve it), and the permitted jobs API response does not include a run `head_sha`. I therefore do not independently certify the generated merge tree or the run-to-merge binding here. The eventual packet must establish its actual `GITHUB_SHA`, clean checkout revision/tree, retained source bytes, and relationship to the reviewed branch checkpoint.
- No repository files were edited; no local build, test suite, toolchain download, commit, push, or workflow mutation was performed. This report is the only created deliverable.

## One-time live CI intake

Each listed run's latest-attempt job metadata was read **once** through the GitHub connector using the authorized `baabi-boo` account. No polling, log retrieval, artifact download, or wait for completion followed.

| Run and primary link | Job | Observed status | Conclusion and evidence boundary |
|---|---|---|---|
| [Native simulator completion, run 45006726571](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726571) | [137159859409 — Native simulator completion prerequisites](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726571/job/137159859409) | `queued` | `conclusion: null`, `steps: null`, `logs_url: null`; no native execution observed |
| [PR governance, run 45006726409](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726409) | [137159859008 — governance](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726409/job/137159859008) | `queued` | `conclusion: null`, `steps: null`, `logs_url: null`; no completed governance result |
| [Push governance, run 45006702879](https://github.com/baabi-boo/AI-GPU/actions/runs/45006702879) | [137159782839 — governance](https://github.com/baabi-boo/AI-GPU/actions/runs/45006702879/job/137159782839) | `in_progress` | `conclusion: null`; tooling tests running, checkout post-step pending |

For the push run, the observed successful steps were job setup, checkout, system Python 3.12 verification, governance-prerequisite inspection, project/evidence validation, and published-baseline packet consistency. `Test governance tooling` was still `in_progress`. These partial step results do not establish a passing workflow and do not establish native simulator completion.

The snapshot is intentionally time-bounded. Status may have advanced after this single observation; this report makes no later-status claim.

## Source findings

### Intended event exposure and hosted trust

The [reviewed workflow](https://github.com/baabi-boo/AI-GPU/blob/db5ebb3a16770004423f2456ec6d0caaa0aced6d/.github/workflows/p06-simulator-completion.yml) admits exactly `push`, `pull_request`, and empty `workflow_dispatch`. Pushes are restricted to `master`; push and PR filters cover the workflow, shared preparation workflow, project helpers, configuration, toolchain identity/dependency installer, simulator/runtime/hardware inputs, directed native tests, third-party inputs, profile, and contract. The [CI tests](https://github.com/baabi-boo/AI-GPU/blob/db5ebb3a16770004423f2456ec6d0caaa0aced6d/ci/project/test_p06_simulator_ci.py) derive retained/build source requirements and check both complete coverage and absence of unrelated patterns.

There is one `ubuntu-22.04` job, with no matrix or dynamic runner expression. Top-level permissions contain only `contents: read`; checkout uses recursive submodules, depth 1, and `persist-credentials: false`. There are no `secrets` references, `pull_request_target`, `workflow_run`, `self-hosted`, OIDC/write permissions, `continue-on-error`, or write-cache action in this workflow. A fork PR is deliberately eligible for the hosted job and has no path in this workflow to a self-hosted runner or repository secrets. Event/ref-specific concurrency uses `cancel-in-progress: false`.

This assessment covers the committed workflow and its normal execution, not every repository workflow or organization-level runner configuration. The review policy treats workflow exposure as an independently reviewed contract; this report supplies that technical review input and is not maintainer approval.

### Python, tools, and cache identity

CPython is explicitly requested as `3.12.14`, x64, with `check-latest: false`. The following isolated Python block writes `python-provision.json` before rejecting any mismatch in exact version, CPython implementation, Linux platform, or the resolved identity of `python3` versus `sys.executable`. Job identity and a copy/hash of the workflow are created before Python provisioning, preserving earlier-stage identity if provisioning fails.

`ci/toolchain_rev.sh` resolves the `VERSION` tag (`TOOLCHAIN_REV=v3.0.2`) to a 40-hex commit and emits the tag-plus-commit cache identity. It resolves a rolling tag at run time; the tag name alone is not an immutable content guarantee. The workflow validates the output shape. The [preparation helper](https://github.com/baabi-boo/AI-GPU/blob/db5ebb3a16770004423f2456ec6d0caaa0aced6d/ci/project/p04_ci_prepare.py) requires that the identity match `VERSION`, and accepts only exact `Linux-toolchain-<identity>-lite` or `-full` matched keys. Thus the restore prefix cannot silently admit an arbitrary suffix. Dependency cache identity is an exact `Linux-thirdparty-<64-hex hash>` key derived from `third_party/Makefile` and `.gitmodules`, with equality checked again during preparation.

Both cache steps use `actions/cache/restore@v4`; neither saves a cache. Missing matching inputs result in blocked preparation with a stated cache-warming remedy; the qualification job does not install a whole Vortex toolchain or rebuild third-party libraries. Baseline apt dependencies are installed only when both cache matched keys are nonempty. That install has a 15-minute timeout and a retained combined log.

The shared clean environment begins its PATH with the executing Python directory, then `/usr/bin` and `/bin` (an optional host-tool directory exists in the runner API but is not supplied by this workflow). The runner retains selected tool/dependency file identities and both PATH `python3` and the actual executing interpreter, then verifies stability around execution. This supports observed executable provenance; as the runner explicitly states, it does not inventory every host header, compiler support file, or dynamic library.

### Clean source preparation and fresh builds

Preparation requires the selected checkout's own helper, a fresh outside-source workspace, safe paths without symlink traversal, and no pre-existing preparation receipt. It checks the exact 40-hex workflow SHA before moving restored tools, refuses tracked files under `tools`, requires same-filesystem relocation, and moves the tools outside the checkout.

Its cocogfx exception is narrow: the committed gitlink and index must match, the initialized submodule HEAD must match, tracked/index changes are rejected, and only a small allowlist of unused build products may move to quarantine. Those files are hashed before and after atomic relocation. Unrecognized untracked inputs, changed source, or the wrong submodule revision are rejected. It then requires a clean complete checkout and recursively validated submodule provenance. No reset, clean, or source-repair operation masks a dirty checkout.

The [native runner](https://github.com/baabi-boo/AI-GPU/blob/db5ebb3a16770004423f2456ec6d0caaa0aced6d/ci/project/p06_simulator_execute.py) independently requires formal clean-source provenance and fresh non-overlapping work/output directories. It retains source bytes, configures a fresh RV64 `p02-tfr` build with the identified tools, validates generated configuration and compiler records, and checks source/tools/dependencies/configuration/binaries for observed drift before and after execution. The native scope is fixed timing SimX with `PERF=1`; successful execution of these cells cannot qualify native functional SimX or processor RTL.

### Fixed CLI and resource bounds

The execution command supplies only source, tools, work, and output roots. There are no event-controlled backend, case, threshold, skip, timeout, thread, memory, or disk knobs. The runner parser exposes those path arguments plus the optional host compiler directory; this workflow does not use the latter. Its two native cells are the linked processor/bounded-RAM unit and six successful public-runtime launches across two contexts.

| Bound | Committed value |
|---|---|
| Hosted job timeout | 90 minutes |
| Baseline host dependency installation | 15 minutes |
| Build concurrency / simulator threads | 2 jobs / 1 thread |
| Required disk reserve | 15 GiB |
| Process-group RSS budget | 4 GiB |
| Per-command raw-log budget | 16 MiB |
| Configure / build / native run / probe timeout | 120 / 1,800 / 180 / 30 seconds |

The shared process monitor enforces sampled resource budgets and process-group cleanup, not hard cgroup quotas. Its retained limitations explicitly disclose missed between-sample peaks, shared-page accounting, and descendants deliberately leaving the process group. The budget claim should preserve those qualifications.

### Failure propagation and retained evidence

Toolchain resolution and every producer-to-`tee` pipeline use `set -euo pipefail`. Dependency installation, preparation, and native execution combine stderr and stdout into their retained log. Neither a failed producer nor failed preparation can be converted into a successful pipeline by `tee`. The CI test source includes an executable synthetic producer that exits 37, checking both retained streams and the actual shell return code for all three pipelines. I inspected those tests but did not execute them in this assignment.

The native runner checkpoints report state around commands, requires actual process start, zero exit, passing process receipt, and completed cleanup, then validates raw output and retained identities. Preparation leaves `native_execution: not_run` and `acceptance_claimed: false`; the native report keeps `qualified: false` and `acceptance_claimed: false` even when both bounded cells pass.

The last workflow step uses `if: always()` and `actions/upload-artifact@v4`, with the evidence directory selected independently of prior step outputs. Its name binds commit, run, and attempt; retention is 30 days, hidden files are included, and a missing directory is an error. The intended contents include job/workflow identity, Python identity when reached, preparation receipts/logs, and the native source/configuration/command packet when reached.

`always()` guarantees an upload attempt under normal Actions step handling, not that an artifact exists after a checkout/initialization failure or runner loss. Earlier failures can legitimately leave only earlier-stage receipts. The eventual review must inspect actual artifact contents and failed-attempt receipts, rather than infer them from the upload declaration.

## Required later review

The next evidence intake should bind the native run/attempt and actual merge SHA to the reviewed source, verify preparation and Python/toolchain/cache receipts, and confirm both native cells from raw logs, process results, output witnesses, compiler/configuration records, and retained hashes. Preserve any failed or blocked attempt. The contract separately requires host fault-path evidence and built-parent behavioral sensitivity; this native workflow does not replace those obligations. A passing governance conclusion alone is insufficient.

## Reviewed file digests

All values are SHA-256 of the reviewed local bytes, confirmed equal to the exact branch checkpoint above.

| Path | SHA-256 |
|---|---|
| `AGENTS.md` | `fdd82f39a11d5b9bc96fe2c15f5779e2c08d359e89dc666595adbf30a01d1e0b` |
| `docs/designs/simulator_completion_v1.md` | `d407a6d57be4806800ba37a60dacbd54c4e160286c5a65b08413a5e08b22b87b` |
| `.github/workflows/p06-simulator-completion.yml` | `233521df10f3b3c90035a533849a17e783a5977a705023609ef73d07ca21b65c` |
| `ci/project/test_p06_simulator_ci.py` | `7952b5e5655729e9a6869f56d800ece61514a93971e31183d4aa211047616e02` |
| `ci/project/p04_ci_prepare.py` | `b0eeaf430387b685be039276891d3c49f93ef4513142e8aad262c23e5037c3ab` |
| `ci/project/p06_simulator_execute.py` | `373ed9ba9141db73e740c87ec812872bb1dc2131b29819a7f001eda7e59e5641` |
| `ci/project/p02_matrix.py` | `e65eca7ac42705f175c296165d9579389d7db8a2deb7542d6eded8337bc83c17` |
| `ci/project/baseline_inventory.py` | `ae98afa10a19703c4247b22bdf3d7218cba12ef37b95da8a7caefb788ad7b259` |
| `ci/toolchain_rev.sh` | `04d3f4895f41a0c9bfad48e5aa993063c5f22006e1ae8987bd6b8433c76fc5bd` |
| `ci/install_dependencies.sh` | `8c2b232891b8f06b31adc958f5a5b8f03bb779342f64c631f32eff2dde14472d` |
| `VERSION` | `018ec3baa6903a49e5fee8cd88e3a235e50f36e6b40a54c0540e1f4339c675fe` |
