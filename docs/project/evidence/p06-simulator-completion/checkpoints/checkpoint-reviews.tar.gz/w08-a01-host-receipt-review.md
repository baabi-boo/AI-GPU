# Wave 8 agent 1 — final host receipt audit

## Verdict

**ACCEPT within the declared HOST scope.** The retained result is a genuine 78-test, zero-skip unittest pass under the inspected driver semantics; no artifact, tracked-source, interpreter, compiler, or recorded support-tool discrepancy was found. The specific prior gap—host results accompanied only by a later source archive, without a contemporaneous source inventory—is closed for this new run. This establishes bracketed tracked-source provenance, with the evidence limits below. **Native GPU/processor/RTL completion remains unobserved (`not_run`).**

Receipt: `/workspace/scratch/ea983fdea786/w06-a05-host-receipt/attempt-20261122T091646248351Z`.

Independent audit used current commit objects with replacement objects disabled (`git --no-replace-objects`, including `ls-tree` and `cat-file --batch`), read-only file hashing and static source inspection. No tests, builds, repository edits, or native commands were performed by this audit. Repository status was clean at both audit checks.

## Exact retained artifacts

Every file's SHA-256, byte size, requested path and resolved path matches its report entry; the report's own digest matches the coordinator-supplied anchor. The original `run_receipt.py`, its before/after identities and the retained driver copy also agree.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `report.json` | 12967 | `b10b2822291f1d4c718db4dedbfc8c3b1c2d742b764b6b6f435aea41ce061fee` |
| `focused-suite.log` | 15231 | `ec57c7c7771a9b85f8c7617a0244ad038069994fd24182e84727d418c2c97ea2` |
| `receipt-driver.py` | 13473 | `c47f319e96a35f084c7dfa8c0b2f62939fd810d320fe5505ef6063b5c73cc665` |
| `invocation.json` | 7586 | `30e915fc19189e2856ce077f290332613ad2fd7c1c4537df2004487c3c51d92c` |
| `source-before.json` | 1798250 | `e1bf1efec51a2c049baa203e7dab2936d8017863b545f8bb1c314023910646fa` |
| `source-after.json` | 1798250 | `e1bf1efec51a2c049baa203e7dab2936d8017863b545f8bb1c314023910646fa` |
| `tools-before.json` | 19748 | `9c5b37585edd3b7bad64b275d70bc00943073099037721afe3acd2f9988ee9bd` |
| `tools-after.json` | 19748 | `9c5b37585edd3b7bad64b275d70bc00943073099037721afe3acd2f9988ee9bd` |

## Result and source binding

The exact command is `python3 -B -m unittest discover -s ci/project -p 'test_p06_simulator_*.py' -v`. The log has **78 unique test records, all `ok`**, one `Ran 78 tests in 68.480s` summary and one bare `OK`; it contains no skipped, failed, erroneous, expected-failure or unexpected-success result. Static enumeration of the nine committed test modules also yields 78 methods.

| Module suffix | Tests | Evidence exercised |
|---|---:|---|
| `async_run` | 8 | Actual C++17/UBSan `AsyncRun` fixture |
| `completion` | 6 | Actual production backend/CP host code with controlled Processor/RAM faults |
| `public` | 3 | Actual common public runtime and backend libraries with controlled Processor/RAM faults |
| `platform` | 4 | Actual timing and functional SimObject headers |
| `build` | 1 | Configure and Make dependency/dry-run checks; no simulator-library build |
| `ci` | 14 | Workflow, shell and interpreter policy checks |
| `execute` | 11 | Output, compiler-record and preflight validation |
| `parent` | 16 | Parent replay policy; synthetic compile/run boundary, plus a real temporary Git replacement-ref check |
| `runner_failures` | 15 | Adversarial native-runner receipts with mocked native process calls |

The 21 C++ host test methods correspond to 52 fixture-group invocations in the checked harnesses: 8 helper, 24 backend, 12 public and 8 framework. That invocation count is derived from the committed loops and successful assertions; the retained outer log is a unittest transcript, not a separate child-command trace. The parent test named `test_all_eight_cells_compile_real_old_sources_with_the_shared_argv_producer` uses `ReplayFixture.command`; its pass is policy evidence, not eight actual parent compilations or native executions.

Both retained source snapshots are byte-identical and contain:

- HEAD `db5ebb3a16770004423f2456ec6d0caaa0aced6d`;
- tree `1536393fef63bd4a4639505ce797c27303db1cc7`;
- empty porcelain status and zero working-blob mismatches;
- exactly **5,105 blob records plus five gitlinks**.

I independently hashed all **370,657,002 tracked blob bytes** from the unreplaced commit, reconstructed their Git blob identities, and compared each path/mode/type/object ID/size/SHA-256 with the retained inventory and current working bytes. All agree. Gitlinks identify commits only, as disclosed. The driver's own Git calls do not explicitly disable replacement refs, but the independent original-object comparison removes that ambiguity for this retained attempt.

The inventory covers all nine test drivers, all 12 recorded baseline/host helpers, both backend sources, public runtime sources and headers, `async_run.h`, CP sources, both SimObject frameworks, fixture sources, configuration inputs and generators. The driver saves the before snapshots before importing `run_bounded`, checks the bounded-helper source digest, executes the suite, then saves and compares after snapshots. Each of the four real C++ harnesses also checks its declared source identities around fixture cells. Consequently this run supplies contemporaneous source binding for backend, public-runtime, helper and framework tests; it does not retroactively supply provenance to older logs.

## Tool identity and bounds

The tool snapshots are byte-identical: **43 file identities and 27 probes**. All 43 current file bytes, sizes and resolved paths also match. They cover the actual receipt interpreter, suite and isolated-test PATH tools, and ten compiler-support files (`cc1plus`, `collect2`, `as`, `ld`, `crtbegin.o`, `crtend.o`, `libgcc.a`, `libgcc_s.so`, `libstdc++.so`, `libubsan.so`).

- Python is 3.12.14, resolving to `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12`, SHA-256 `fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7`. The PATH execution witness and `sys.executable` resolve to the same interpreter.
- Selected `c++` and `g++` resolve to `/usr/bin/x86_64-linux-gnu-g++-14`, Debian GCC 14.2.0-19, SHA-256 `6b3696e4dcb85e1c949c732a02befa50e3983ecf94ce7e8e58d9d503b954b79d`. The committed fixtures select this available `c++` first.

Execution ran from `2026-11-22T09:16:48.203442+00:00` to `2026-11-22T09:17:56.890237+00:00`. The monitor records `process_started=true`, exit 0, `cleanup_complete=true`, no reason, duration **68.686608 s**, and sampled outer-group peak RSS **50,954,240 bytes**. The outer budget is 300 s, 1 GiB RSS, 1 GiB free-disk reserve, 8 MiB retained output, polled every 0.1 s. These settings match the hashed `baseline_process.py` implementation and invocation. Recorded initial and final resource inventories were ready.

Nested `run_host_command` calls create separate process groups and apply their own 1 GiB RSS/disk monitors, 1 MiB output budget and finite per-command deadlines. The report explicitly discloses that the outer RSS peak does not aggregate them. Direct host policy subprocesses have their own timeouts and remain subject to the outer monitor. Bounds are polled budgets, not hard quotas; neither the outer peak nor `cleanup_complete` is a cgroup-wide or recursively detached-descendant guarantee. The helper's retained limitations and the receipt's nested-group statement accurately preserve those distinctions.

## Residual evidence limits / nonblocking observations

1. Before/after identities do not detect temporary replacement restored between samples. System headers and every transitive dynamic library are not inventoried. These limitations are already disclosed.
2. **Additional cache qualification:** `-B`/`PYTHONDONTWRITEBYTECODE` suppress bytecode writes, not reads. Preexisting ignored Python caches are outside the retained source inventory. Read-only static inspection found that every currently valid examined cache agrees with current source code; the two stale focused-test caches inspected have invalid timestamp/size validation. No stale-code execution discrepancy is observed, but this later check is not a historical bytecode-use record.
3. Successful child-command logs, generated configurations and fixture binaries live in temporary directories and are cleaned by the tests. This receipt retains their unittest assertions and bracketed source/tool identities, not per-fixture binary hashes or raw child logs. It therefore supports the declared host-test claim at that evidence level, without establishing a hermetic replay packet.

No finding invalidates the observed 78-test host pass. No native completion, native functional SimX, vendor execution, performance qualification, phase acceptance or hardware result follows from it.
