# W06-A01 — pinned-parent runner evidence review

**Reviewer:** `/root/w06_a01_parent_review` (wave 6, assignment 31/60).  
**Date:** 2026-11-22.  
**Repository/base:** `/workspace/scratch/ea983fdea786/AI-GPU`, HEAD and required parent `42809ff0c1b81384d7c9b079e4ef786be8407600`; candidate tree contains the acknowledged uncommitted completion work.  
**Final disposition:** the one confirmed F2 provenance blocker is closed by the independently reviewed repair in the addendum below. No additional blocker found in the bounded command, assertion acceptance, dependency/drift, or final-report logic. The initial finding and reviewed pre-fix source hashes are retained; final clean-checkpoint execution remains a separate obligation.

## Finding W06-A01-F2-01: replacement objects can substitute the pinned parent

**Severity:** F2. **Confidence:** high. **Evidence:** static proof, confirmed by a bounded real Git-object experiment outside the production repository.

`ci/project/p06_simulator_parent.py` constructs its child environment at lines 220–223 without `GIT_NO_REPLACE_OBJECTS=1`. The Git commands at lines 254–267 also omit `--no-replace-objects`. A local `refs/replace/<PARENT>` can therefore replace the commit's tree during both `rev-parse PARENT:path` and `show PARENT:path`. `rev-parse PARENT^{commit}` still returns the original named commit. The extracted-file SHA-1 check passes because the selected blob ID and extracted bytes both come from the replacement tree. A replacement changing only the transport sources can preserve the shared-input equality checks and intended old failure, resulting in a reported pass attributed to the wrong parent bytes.

The coordinator authorized a narrow throwaway experiment after the static finding. It used the installed `/usr/local/bin/git`, a fresh temporary repository, `hash-object`, `mktree`, and `update-ref`; each subprocess had a five-second timeout. It built two tiny commit objects and installed one replacement ref. No production repository file or ref changed; the temporary directory was removed.

| Observation | Runner-style Git | Git with `--no-replace-objects` |
|---|---|---|
| `rev-parse ORIGINAL^{commit}` | Original commit | Original commit |
| `rev-parse ORIGINAL:transport.cpp` | Replacement blob | Original blob |
| `show ORIGINAL:transport.cpp` | Replacement bytes | Original bytes |
| Runner's recomputed blob SHA-1 equals returned blob ID | Yes | Yes |

Experiment identities:

- Original commit: `3b3068d62cd7cbeea04fc5790a8dd774c9742786`.
- Replacement commit: `5f7dadbd7c712bb1036fa635ab2fda1fb4165e9d`.
- Original blob: `88bf48294a182dcfc17bcda03fa1b3c97a404266`, containing `original production transport\n`.
- Replacement blob: `c69601866319ee29011722e42d22df4f8112707e`, containing `different transport with the same assertion outcome\n`.

**Required correction:** force `GIT_NO_REPLACE_OBJECTS=1` in the runner's explicit environment, or pass `--no-replace-objects` on every Git invocation. Add a boundary check that this protection reaches the commands and cannot be overridden by caller environment. A real temporary replacement-object test should show that the runner's Git selection returns original bytes even while an unprotected control selects replacement bytes. Recheck the narrow diff and changed source hashes independently, then retain the coordinator's planned final clean-checkpoint replay. Do not modify or relabel the historical packet.

## Historical packet independently audited

Packet: `/workspace/scratch/ea983fdea786/p06-parent-w03a04-report1/report.json`. SHA-256: `f21466bd924689636312c7800aa2e19dd94d4a3e4043992180b2e2aa5d24b5ba`.

The production repository currently has no replacement refs. A read-only audit compared every one of the packet's **24 parent blob IDs** with `git --no-replace-objects rev-parse PARENT:path`: all matched. I also recomputed hashes and sizes for **51 retained command logs, 65 retained candidate/parent/configuration input files, and both retained binaries**. All matched the report. All eight run logs contain exactly the claimed group-specific assertion line, and their retained raw results are `fail`, exit 1, `nonzero_exit`, with `process_started=true` and `cleanup_complete=true`.

The retained `configure-rv64-p02-tfr`, `build-simx`, and `build-rtlsim` commands each completed with exit 0. The compiler argv names each extracted old `sw/runtime/<backend>/vortex.cpp`, the actual unchanged `sim/common/cmd_processor.cpp`, the real controlled fixture `main.cpp`, the fixture include directory, generated RV64 headers, and UBSan. All 20 shared production/configuration input comparisons are true. This supports the historical host sensitivity result; it does not execute the present candidate.

The historical runner precedes the runtime-library rebinding hardening. Current fixture differences from the retained packet add braces without changing control flow. These are still different source bytes and must not be silently relabelled as the final execution. The planned clean-checkpoint replay remains necessary for that identity.

## Audited acceptance and execution boundaries

- **Actual old transport and shared inputs:** lines 257–276 extract and retain both old backend sources, validate Git blob contents, and require identical CP, callback, support, and configuration input bytes before compiling. `compile_backend` changes only the selected backend source path; it does not rewrite old backend or CP bodies. Its include order intentionally substitutes controlled `Processor`/RAM headers. The generated configuration is fresh RV64 `p02-tfr`, retained and rechecked. The replacement-ref finding above is the remaining parent-selection gap.
- **Controlled exception semantics:** the SimX fixture's legacy `run()` catches injected standard/unknown exceptions and returns `-1`; its normal return remains the controlled legacy `gp` value. The old backend discards this integer in its `future<void>` task. The RTL fixture throws through its void `run()` into the future, which the old backend only waits on. The candidate fixture exposes `run_checked()` separately; the success group sets legacy `gp=7` and requires checked execution. Thus sensitivity is not manufactured by treating ordinary nonzero `gp` as failure. Native `gp=-1` qualification belongs to the separately required native unit.
- **Intended behavioral marker:** `main.cpp` holds a real asynchronous task, verifies it remains pending, queues a later DCR command, releases the task, and fails at `await_terminal(1) != 0` when the old backend accepts failure. Parent cells stop at that first intended assertion. They establish sensitivity to failed-launch retirement, not independent execution of every later sticky-error assertion.
- **Eight strict cells:** both backends × standard/unknown exceptions × RAM/LLC mode. `verify_expected_failure` requires exact full text including the final newline, raw exit 1, `nonzero_exit`, process start, and complete cleanup. Compile failure, timeout, unrelated assertion, extra output, wrong group, unexpected success, or partial matrix cannot count.
- **Bounds:** every process uses the existing bounded process-group monitor; one sequential build job, 1 GiB disk reserve and RSS budget, 1 MiB combined log budget; probes/runs have ten-second limits, configure/build sixty-second limits. The existing limitations accurately identify sampled resource budgets and escaped process-group descendants.
- **Binding:** helper bytes are compared with the loaded-source snapshot; candidate/parent/configuration bytes and resolved tool identities are retained and rechecked; `sys.executable` is bound to the configure `python3` shim. Compiler support and linked runtime dependencies are hashed where discoverable. The strengthened second-backend path rejects replacing an already bound runtime-library identity. Each binary is hashed before/after execution.
- **Late failures:** finalization rechecks sources, tools, parent, generated configuration, extra tools, binaries, retained logs and snapshots, and final disk reserve. Drift overwrites the prospective pass with failure. `full_matrix_completed` is derived after these checks and requires both final pass and eight expected failures. Intermediate checkpoints do not publish a completed passing matrix.

I inspected all 15 boundary-test definitions, including compilation failure with the marker, one bad matrix cell, source/tool/binary/config/log/snapshot drift, and cross-backend dependency replacement. I did not rerun them or duplicate the real parent replay. The only new execution in this assignment was the authorized small Git-object experiment. No native build, GPU/RTL run, download, repository edit, commit, or push occurred.

## Scope and closure

This is old-backend **host exception-transport sensitivity** evidence. The controlled headers do not include either production SimObject framework; production cleanup-header changes therefore require their own actual-framework and native evidence. RAM/LLC selections in the parent exception matrix do not themselves prove native memory/cache behavior. The report's `native_execution=false`, `qualified=false`, and `acceptance_claimed=false` are appropriate. No phase gate, native arithmetic, performance, physical device, or recovery qualification is granted here.

Closure requires independent review of the replacement-object fix and its boundary evidence, plus the coordinator's final clean-checkpoint parent replay. Native completion obligations remain separately tracked by the current contract.

## Reviewed source identities (SHA-256, before replacement-object repair)

| File | SHA-256 |
|---|---|
| `AGENTS.md` | `fdd82f39a11d5b9bc96fe2c15f5779e2c08d359e89dc666595adbf30a01d1e0b` |
| `docs/review/code-review-policy.md` | `99426ced05c04c1b14422f4fdacabcce3c680600461c4887b14e5eabf8b0587d` |
| `docs/designs/simulator_completion_v1.md` | `d407a6d57be4806800ba37a60dacbd54c4e160286c5a65b08413a5e08b22b87b` |
| `ci/project/p06_simulator_parent.py` | `8f830adb7930dedff26253f3e55aecb746994768613ee743d05bb5ec922407ee` |
| `ci/project/test_p06_simulator_parent.py` | `bbc23ae281322e4017b6020e8c3a6b3b6105dd5f8d5cf204b80acfd94781a944` |
| `ci/project/test_p06_simulator_completion.py` | `764101eeae4c30bfcf44b312e0037ee9dd0fa3c54279456c770ada3d95673199` |
| `ci/project/baseline_process.py` | `54ae2d6756c47349f4cf33a91209addcff447de1618a35892e0ac3e344506daa` |
| `ci/project/tensor_host_tools.py` | `ee664a6a70e9485e92158cc6c7870d0c13a223cface41763c4480c61a689382f` |
| `ci/project/fixtures/simulator_completion/control.h` | `1d23cbdbbb873385edd51857ee8bad91448bcdad7b351f72a5a5c5da3d40ead8` |
| `ci/project/fixtures/simulator_completion/main.cpp` | `d9f8a8c010c1d1d8a35b6d7016cd5f1fdaf741375d72b81e1893b922f24f1cc9` |
| `ci/project/fixtures/simulator_completion/mem.h` | `cd8744c3adef4540ed35606572601c6b73dc65d2d46f8d9c3f74f9275ce5428b` |
| `ci/project/fixtures/simulator_completion/processor.h` | `5783124e76bd13df030acfeaebf9d598e389c9aa489ab0e7be329f0859fc7e28` |
| `sw/runtime/simx/vortex.cpp` | `61a14d8c29f9c2e9bef292d4ef8bbc5892ff6b13ad62110a80915f788917edd4` |
| `sw/runtime/rtlsim/vortex.cpp` | `048f7e96625243024a7f4952fb7e616b4f28c47744e1670e346917b554b6fce4` |
| `sim/common/cmd_processor.cpp` | `c7090583f8dd1774d71755dc96f11845ff4d96340e51451643ec1ab16b14dd42` |
| `sim/common/cmd_processor.h` | `8efce8fe5ff166cc0742b3846dc37ae5dd93463a10e71c154959d4b2daacda11` |

## Closure addendum — independent review of the separate repair

**Finding W06-A01-F2-01: closed at source/boundary-test scope.** Agent `/root/w06_a02_parent_identity` changed only the runner and its boundary tests. I independently inspected the complete before/after diff, the real-Git test body, the retained failing and passing logs, and the source identity records. The current files match those records.

The runner now explicitly sets `GIT_NO_REPLACE_OBJECTS=1` in the environment shared by every bounded subprocess. The new test creates a real replacement ref in a temporary repository, first verifies that unprotected Git selects substituted bytes while retaining the named original commit, then executes the runner's actual Git commands through the saved `run_bounded`. It checks the original blob identity, retained original bytes, and the fixed variable on every recorded Git and synthetic command, while the caller environment supplies `GIT_NO_REPLACE_OBJECTS=0`. Compiler/backend processes remain synthetic and are accurately disclosed.

The retained pre-fix run reports exactly one failure among 16 tests: the new test reached a reported runner pass but found the replacement blob instead of the pinned blob. The post-fix run reports **16 tests passed in 2.512 seconds**, exit 0, for `PYTHONPATH=ci/project PYTHONDONTWRITEBYTECODE=1 python3 -m unittest ci/project/test_p06_simulator_parent.py -v`. I audited these repair-agent execution records; I did not duplicate the suite or perform a real parent/native build.

| Closure artifact | SHA-256 |
|---|---|
| `ci/project/p06_simulator_parent.py` | `af9da75aa37f22102680aa1f7eba70262916c2b0d39d55ad70a3606b56618bb5` |
| `ci/project/test_p06_simulator_parent.py` | `f275834f90853a5945e5518d6f96d5cce1f904f8a5e630ddc9ea3d1c6ea11f31` |
| `/workspace/scratch/ea983fdea786/w06-a02/before-fix-tests.log` | `80a6921d8c37e3c53d39f2333566666670d751d885970b56858bbc76d20402c2` |
| `/workspace/scratch/ea983fdea786/w06-a02/after-fix-tests.log` | `b87190ae714bd767f131c3bd7f1cfd9941c477ae487fceea980a3b82b62f3c0c` |
| `/workspace/scratch/ea983fdea786/w06-a02/result.json` | `679205fb2d8db93a95c432dbfbadc760e7b5055cb3e49996e574f1a3b6bdfe70` |
| `/workspace/scratch/ea983fdea786/w06-a02/source-after.json` | `6f3361ebb8d44e0f547722cccd5628139f2956f3e59c26cf5a4dd6c71e74a39c` |

The correction resolves the identified provenance gap without changing the eight-cell matrix or its assertion requirements. The historical packet remains an honest record of its original sources. The coordinator's final clean-checkpoint real parent replay and the contract's separate native obligations remain pending; this closure does not relabel either as executed.
