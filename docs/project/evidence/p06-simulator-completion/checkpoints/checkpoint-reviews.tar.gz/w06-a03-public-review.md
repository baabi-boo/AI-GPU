# Wave 6 / agent 3 — independent public-runtime evidence review

## Verdict and boundary

**No blocking defect found in the assigned public fixture or its host-evidence claim.** The test builds and loads the actual public `libvortex.so`, common runtime, callback adapter, simulator backend and command processor. Processor and RAM are controlled substitutes. This supports public **host error transport**, not native SimX/RTL execution or native public fault recovery.

Reviewed the uncommitted worktree based on `42809ff0c1b81384d7c9b079e4ef786be8407600`; the base commit alone does not identify the candidate. Applied the repository `code-review` and `simx-review` guidance, read `AGENTS.md`, current completion contract, review/coding/bug-fix rules and simulator architecture context. This is a scoped evidence audit, not a substitute for review of every production/CI hunk. No source edits, builds, downloads, broad retests, commits or pushes were performed. The only new file is this requested report.

## Actual code exercised

- `test_p06_simulator_public.py:119–188` configures a fresh out-of-tree RV64 `p02-tfr` tree, obtains complete configuration definitions from the production generator, and compiles with C++17, warnings as errors, `-DNDEBUG`, UBSan with nonrecovering errors, and pthreads. The `COMMON_SOURCES` list matches the 13 common translation units in the production `sw/runtime/stub/Makefile` source list. The test also compiles the real stub dispatcher into `libvortex.so` and links the public fixture using `-lvortex`.
- Each `libvortex-{simx,rtlsim}.so` consists of the actual backend `vortex.cpp`, actual `sim/common/cmd_processor.cpp`, and the fixture's small control-export branch. Only the first include directory introduces replacement `processor.h` and `mem.h`; it also supplies the shared fixture `control.h`. Production `callbacks.inc`, `AsyncRun`, `CommandProcessor`, runtime headers and callback adapter are not replaced.
- The public branch of `simulator_public_completion.cpp` includes `vortex2.h` and uses public device/queue/event/enqueue functions. `Controls` opens the selected backend only to obtain arm/await/release/counter functions. Production `stub/vortex.cpp:49–87` independently resolves `vx_dev_init` through its normal `VORTEX_DRIVER` dispatcher. The bounded process environment sets the build directory as `LD_LIBRARY_PATH`, so these are the freshly built libraries.
- The controlled RAM is a sparse byte map, with a per-request size/overflow guard. The controlled Processor gates execution, throws either `std::runtime_error` or integer `17`, counts DCR/entry/destruction operations, and selects RAM/LLC hooks. It supplies a legacy SimX result of `7`, while the test asserts that runtime execution uses `run_checked()` and never calls legacy `run()`. No real instruction stream, native Processor/RAM, actual LLC implementation, SimPlatform or Verilator model is linked.

The production failure chain is explicit: backend `run_.start(...)` executes the controlled task; `AsyncRun::collect()` consumes the future and latches failure; both backend CP callbacks catch and return a nonzero HAL result (`simx/vortex.cpp:74–104`, `rtlsim/vortex.cpp:73–99`). `callbacks.inc:61–72` forwards those callbacks. `CallbacksAdapter::r` maps failure to `VX_ERR_INVALID_VALUE` (`vortex2_internal.h:206–217`); `Device::cp_poll_seqnum_` tests the callback result before accepting the sequence number (`device.cpp:769–791`). The queue records the error and completes the event (`queue.cpp:98–154`); `Event::wait_value` returns the retained error before treating its counter as success (`event.cpp:31–63`). A generic exception escaping into the queue would map to `VX_ERR_INTERNAL`, so the fixture's exact `VX_ERR_INVALID_VALUE` expectation meaningfully checks the intended HAL/adapter route.

The real CP launch FSM waits for busy to rise and then fall (`cmd_processor.cpp:404–420`), and retirement increments the sequence number only after its launch state becomes idle (`:587–622`). The public fixture observes public results; it does **not** directly inspect failure-before-retirement or force immediate-completion timing. Those obligations belong to the dedicated backend/helper evidence.

## Assertion audit

| Observation | What the fixture establishes | Exact scope limit |
|---|---|---|
| Pending/timeout | `pending()` waits until the worker has entered, confirms timeline value zero, and requires a zero-duration wait to return `VX_ERR_TIMEOUT` (`fixture:171–177`). | A gated nonblocking timeout; not positive-duration timeout accuracy, cancellation or hung-worker reclamation. |
| Serial success/nonzero legacy value | Three launches per success process each pass a wait, repeated zero wait, dependent DCR command and queue finish; SimX checked-entry counts match task entries and legacy-call count remains zero (`:195–214`, `:274–277`). | Controlled legacy value is `7`; no native `gp` semantics or separate `-1` case is proved here. |
| Standard and unknown exception | Separate groups arm the two throw paths; the launch and dependent command must report exactly `VX_ERR_INVALID_VALUE` (`:216–228`, `:267–270`). | Controlled C++ exceptions reaching a future, not a native fault/abort mechanism. |
| Repeated event observations | Failure survives repeated target-1 waits, a higher target-2 wait, value query showing completed timeline `1`, and `vx_event_wait_values` (`:180–192`). | The plural API is called with `n=1`; this does not prove multi-event scheduling/aggregation. |
| Dependency suppression | The pending launch gets a dependent DCR enqueue before release; both events fail and the DCR-write count is unchanged (`:223–228`). | Same queue: dependency failure and sticky queue error both suppress work. The test does not isolate cross-queue dependency semantics. |
| Queue finish versus backend failure | First finish reports the queue error, second succeeds, original event still fails; a later command without a dependency fails without adding DCR writes; finish then reports the new error (`:229–239`). | The successful second finish is queue-local error consumption, not repaired backend execution. This is specifically checked. |
| New queue | A second queue on the same device accepts an enqueue but its event/finish fail, and Processor entry count does not increase (`:241–247`). | A fresh queue cannot rehabilitate the existing failed backend. |
| Fresh device | After explicit event/queue/device release and observed Processor destruction, a new device completes a normal launch/DCR/finish/cleanup sequence (`:248–251`). | Sequential controlled Processor instances; no simultaneous native contexts, native platform teardown or physical recovery. |
| Cleanup | Explicit event, queue and device releases succeed, destruction count rises exactly once per context, and no active-Processor destruction is recorded (`:147–159`, `:211–214`, `:248–250`). | Passing paths already waited for completion. They do not dynamically prove destruction joins pending work, host allocation leak freedom or free-order instrumentation; the separate backend fixture owns those checks. Backend source statically places `run_.join()` before host-region release. |

## Counts and retained outcomes

**Exactly 3 public test groups × 2 backend libraries × 2 RAM/LLC settings = 12 public host cells**, including **8 exception cells**. Success loops, recovery launches and individual `checks=` increments are assertions/work inside a cell, not additional matrix cells. Both libraries use a controlled Processor, so the `rtlsim` label is not RTL execution. Repeated attempts are not extra coverage cells.

- `/workspace/scratch/ea983fdea786/simulator-braced-host.log` records **9 passing unittest methods in 28.756 s**: six direct-backend methods and the three public methods. Only the latter three correspond to this public matrix.
- `host/initial-public-runtime-tests.log` records **3 passing methods in 21.998 s**. The harness loops all four backend/memory combinations per method, checks each process result and an anchored PASS line, and rejects nonzero/timeout/resource/cleanup failures through `run_host_command`.
- `host/initial-public-build-failure.log` remains a genuine earlier **setup failure, zero tests run**, caused by missing resolved configuration macros. The current harness obtains the complete production configuration definitions. The failed attempt is not converted into passing evidence.

The harness hashes its declared source inputs and verifies them before and after every cell. Those identities and successful subprocess raw logs live in a temporary build directory; the retained unittest logs alone do not include an execution-time source inventory, binary hashes or full compiler identity. I verified that seven relevant current files (public driver/fixture/control, both backends, `async_run.h`, completion contract) exactly match their manifest hashes **and archived bytes** in `source-at-assembly.tar.gz`. As the archive's own policy says, a later matching snapshot does not retroactively supply missing run-time provenance. This review binds the inspected current source and retained logs below; final exact-checkpoint execution/reconciliation remains a coordinator obligation. No fresh pass is claimed by this audit.

## Remaining qualification boundary

The current contract separately requires the linked native SimX Processor/RAM unit and native public-success regression. Their execution remains **`not_run`** in the reviewed checkpoint. Even their eventual success would not create a native public-runtime injected-fault result: native public fault transport, native functional SimX fault recovery, processor RTL execution and physical-device recovery remain unproved by this host packet. This fixture supplies no numerical, cycle, performance, warm-qualification or phase-acceptance result.

## Reviewed source identities

SHA-256, captured from the inspected worktree. Key review inputs were rechecked unchanged before writing this report. These identities identify this review, not a clean candidate commit or an inferred earlier execution.

| Source | SHA-256 |
|---|---|
| `AGENTS.md` | `fdd82f39a11d5b9bc96fe2c15f5779e2c08d359e89dc666595adbf30a01d1e0b` |
| `docs/designs/simulator_completion_v1.md` | `d407a6d57be4806800ba37a60dacbd54c4e160286c5a65b08413a5e08b22b87b` |
| `ci/project/test_p06_simulator_public.py` | `5258035e883eaed32214472c11f2d0015865108a7c892f1e4b993836a4589a7c` |
| `ci/project/fixtures/simulator_public_completion.cpp` | `68c18324ce4786940f5c06eb46d8388fd5e7f1fa96f6d2826e249209d7d56174` |
| `ci/project/fixtures/simulator_completion/control.h` | `1d23cbdbbb873385edd51857ee8bad91448bcdad7b351f72a5a5c5da3d40ead8` |
| `sw/runtime/stub/Makefile` | `e6aae339e07e2a3086cc0334c9353001521f774afdc9e921acf1e126b115b941` |
| `sw/runtime/stub/vortex.cpp` | `6a1f791d430f6bc9b6111eb13de39e4171f91e8eb7664d83d4d29dbabcdcbb77` |
| `sw/runtime/common/device.cpp` | `9b32e38a9bbc0460a7f2af522fd5efdc96e1c06e359e28c5151285557f89d90a` |
| `sw/runtime/common/queue.cpp` | `1d785262d128de3ffbf1feb32cc2b32f6457a6644df6ef9a04d4e8b4d45c962e` |
| `sw/runtime/common/event.cpp` | `7a9b9a39a0d77295f62a8435a0a962d367fa0d2623d3ca580a3b2ba748c11b67` |
| `sw/runtime/common/vortex2_internal.h` | `3997d6ecca442eb04cf1df3129d0b90a9c0ec66015c798fc4d4510b93dd1f9ce` |
| `sw/runtime/common/callbacks.inc` | `13852934ab10776964fd2a68036ac8876303a60d2a3f3fce415186a3a13d10f2` |
| `sw/runtime/common/async_run.h` | `17e229eb116c6d50d273780bb969630d0e0141a8aec39f22c0ab0fb62b74d2ed` |
| `sw/runtime/simx/vortex.cpp` | `61a14d8c29f9c2e9bef292d4ef8bbc5892ff6b13ad62110a80915f788917edd4` |
| `sw/runtime/rtlsim/vortex.cpp` | `048f7e96625243024a7f4952fb7e616b4f28c47744e1670e346917b554b6fce4` |
| `sim/common/cmd_processor.cpp` | `c7090583f8dd1774d71755dc96f11845ff4d96340e51451643ec1ab16b14dd42` |
| `sim/common/cmd_processor.h` | `8efce8fe5ff166cc0742b3846dc37ae5dd93463a10e71c154959d4b2daacda11` |
| `ci/project/tensor_host_tools.py` | `ee664a6a70e9485e92158cc6c7870d0c13a223cface41763c4480c61a689382f` |
| `ci/project/baseline_process.py` | `54ae2d6756c47349f4cf33a91209addcff447de1618a35892e0ac3e344506daa` |

| Generated substitute definition | SHA-256 |
|---|---|
| `MEMORY_SHIM` UTF-8 bytes | `c70fe07c78a925037038d4437a0dcdd74ab2dbe2ac35a1766af96e4fd41cd795` |
| `PROCESSOR_SHIM` UTF-8 bytes | `360d1dd194562bddfad6755f134d4e5d62ffee8d22b9ec5b9dd84406546e15bb` |

## Retained log identities

| Log | SHA-256 |
|---|---|
| `/workspace/scratch/ea983fdea786/simulator-braced-host.log` | `fb528297c87a7b9f242c818cf6c562bd2a046a6da5976b8667c50d038811b8e2` |
| `docs/project/evidence/p06-simulator-completion/host/initial-public-runtime-tests.log` | `b1e3e2513eeed05e9a1bedd8039e4509781bb51c7f8f44103aac34058fd4997b` |
| `docs/project/evidence/p06-simulator-completion/host/initial-public-build-failure.log` | `51624ec2b4104febc20783e158fe154cd69cbf54ea6a02bc90427e10859c5601` |

**Class/depth and disposition:** scoped independent R3-contract evidence review input. No F2/F3 public-fixture finding or source fix is requested. Retain the fixture and its scoped host outcomes; the overall completion change still needs final exact-source evidence, required native execution and its separately assigned full-change review/approval. This report grants no waiver or maintainer approval.
