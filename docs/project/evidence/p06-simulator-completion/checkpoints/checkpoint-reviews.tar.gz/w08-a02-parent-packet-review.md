# W08-A02 — final pinned-parent packet review

**Reviewer:** `/root/w08_a02_parent_packet_review`, wave 8, assignment 44/60.  
**Date:** 2026-11-22.  
**Verdict: PASS at the declared host parent-sensitivity scope. No concrete mismatch or blocking finding.**

The final packet binds the actual old SimX and processor-RTL runtime backends to the unchanged production CommandProcessor and the candidate's controlled Processor/RAM fixture. Both compilations succeeded and produced retained executable ELF binaries. Every one of the eight exception cells reached the required group-specific behavioral assertion and exited 1. The report does not count a compiler failure, timeout, or unrelated error as sensitivity. This independently reconciles the clean-checkpoint parent replay left pending by the [W06-A01 review](sandbox:/workspace/scratch/ea983fdea786/w06-a01-parent-review.md).

This assignment performed read-only source, Git-object, metadata, and file-hash inspection. **No test suite, replay cell, compiler, build, or native binary was run; the repository was not modified.**

## Exact packet and commit binding

| Identity | Value |
|---|---|
| Final packet | `/workspace/scratch/ea983fdea786/p06-parent-db5ebb3-report/report.json` |
| Packet SHA-256 | `8e510ac417eb9494b3fb2d6bdf5605e22d90a277c1612c8420adec2fe7c29867` |
| Candidate commit | `db5ebb3a16770004423f2456ec6d0caaa0aced6d` |
| Candidate tree | `1536393fef63bd4a4639505ce797c27303db1cc7` |
| Pinned parent, also candidate's direct parent | `42809ff0c1b81384d7c9b079e4ef786be8407600` |
| Pinned-parent tree | `2aa7f9dd71b80f7c01aa7d9e519579764a3a76b6` |
| Recorded execution interval, UTC | `2026-11-22T09:18:25.151110+00:00` to `2026-11-22T09:18:38.735479+00:00` |
| Final state | `finished`, `outcome=pass`, `full_matrix_completed=true`, `reason=null` |

The recorded candidate status is empty; its retained status log is zero bytes. The working repository was also clean at the named candidate during this audit. I compared **all 33 candidate input files** with their exact candidate-commit blobs and **all 24 parent input files** with their exact pinned-parent blobs. Every retained byte, length, SHA-256, and parent Git blob ID agrees. These comparisons used both `git --no-replace-objects` and `GIT_NO_REPLACE_OBJECTS=1`; the repository currently has no replacement refs.

The retained runner unconditionally sets `GIT_NO_REPLACE_OBJECTS=1` in its explicit subprocess environment. Its actual bounded command path passes that environment to `subprocess.Popen(env=env)`. The packet records the same setting. The runner hash below exactly matches W06-A01's independently reviewed repair, closing the earlier replacement-object selection gap for this replay.

| Selected pinned input | Parent Git blob | Parent SHA-256 |
|---|---|---|
| `sw/runtime/simx/vortex.cpp` | `cc0bbf532c1bc6ea26cceb7797655daea3a096cb` | `5558f262394cb278db3b5d170e976162c2c1ccf84b6479204bad83f5afab91a3` |
| `sw/runtime/rtlsim/vortex.cpp` | `1a81930e20d66a546f5967b228af91cb47737783` | `c984089e2f47bff1077387fd9321826ddf6e0e02d3831a21f8e1efcb51f7ed30` |
| `sim/common/cmd_processor.cpp` | `2e8c510594feb4ef028c4a2b6ff89487991eedbf` | `c7090583f8dd1774d71755dc96f11845ff4d96340e51451643ec1ab16b14dd42` |

## Successful actual builds and eight intended failures

The report retains complete absolute compiler argv, working directories, result records, and logs under command IDs `build-simx` and `build-rtlsim`. I compared each argv with the retained compiler-argument producer. Each compiles the corresponding extracted parent backend, actual production `sim/common/cmd_processor.cpp`, and candidate fixture `main.cpp`; the first include directory intentionally selects controlled Processor/RAM headers, followed by the fresh generated headers and production support headers. Neither backend nor CP body is rewritten.

Both use `/usr/bin/c++`, resolved to `/usr/bin/x86_64-linux-gnu-g++-14`, recorded as Debian GCC `14.2.0-19`, with C++17, `-O1`, warnings as errors, RV64 definitions, pthreads, UBSan, `-fno-sanitize-recover=undefined`, and `--wrap=free`. Only the SimX build adds `-DCOMPLETION_SIMX`. Compiler SHA-256: `6b3696e4dcb85e1c949c732a02befa50e3983ecf94ce7e8e58d9d503b954b79d`.

| Command | Exit / outcome | Recorded seconds | Produced binary SHA-256 / bytes |
|---|---|---:|---|
| `configure-rv64-p02-tfr` | 0 / pass | 3.428187 | Generated `XLEN=64`, `PROFILE=p02-tfr` |
| `build-simx` | 0 / pass | 3.307822 | `c93e2260d89c3394cce35e861f37bccc3f69df5cc725577f1af298562b0345b3` / 410176 |
| `build-rtlsim` | 0 / pass | 3.258080 | `cbb477be26b437c4b5faec1fb9dcf12548b7c8c49589561c67b67dee6bb205a0` / 410464 |

The binaries remain at `/workspace/scratch/ea983fdea786/p06-parent-db5ebb3-work/rv64-p02-tfr/{simx,rtlsim}-completion`. Both are executable ELF files and match their before/after identities. Empty configure/compiler logs are correctly retained and hashed; successful raw results and the produced binaries establish compilation, rather than a diagnostic marker alone.

| Backend | Exception group | Memory selection | Raw exit / reason | Exact assertion |
|---|---|---|---|---|
| SimX | `standard_exception` | RAM | 1 / `nonzero_exit` | Match |
| SimX | `standard_exception` | LLC | 1 / `nonzero_exit` | Match |
| SimX | `unknown_exception` | RAM | 1 / `nonzero_exit` | Match |
| SimX | `unknown_exception` | LLC | 1 / `nonzero_exit` | Match |
| Processor RTL | `standard_exception` | RAM | 1 / `nonzero_exit` | Match |
| Processor RTL | `standard_exception` | LLC | 1 / `nonzero_exit` | Match |
| Processor RTL | `unknown_exception` | RAM | 1 / `nonzero_exit` | Match |
| Processor RTL | `unknown_exception` | LLC | 1 / `nonzero_exit` | Match |

Each log is exactly `FAIL simulator-completion GROUP: failed launch was accepted as successful\n`, with the correct group and one final newline. Standard-exception logs are 87 bytes, SHA-256 `a388117461ebd2964bb795b60cee06e7f90c619b11332a3c5bc5be40ba908478`; unknown-exception logs are 86 bytes, SHA-256 `17f5027ff72429e0488406d46eb02288b0dc9a4db64738bce6251c384d361400`. Every run has `process_started=true`, `cleanup_complete=true`, raw `outcome=fail`, and cell `outcome=expected_failure`. All **43 other commands** have exit 0, `outcome=pass`, and no failure reason. Every recorded duration is below its bound; none reports timeout, resource failure, or incomplete cleanup.

## Complete integrity and stability reconciliation

- Recomputed the SHA-256 and length of **all 51 command logs** and **all 65 retained input/configuration files**: 33 candidate, 24 parent, and 8 generated. The directories contain exactly those manifested files. Parent extraction logs also equal their retained parent-source bytes, and the ordered blob-ID log matches the actual Git objects.
- All source, parent, generated, tool, and dependency before/after maps agree. The corresponding current source/work files and **15 host-tool entries plus 12 compiler-support/runtime-library entries** still match their recorded resolved paths, hashes, and sizes. The configure Python shim resolves to the same interpreter as `sys.executable`.
- All **20 shared production/configuration inputs** equal the parent bytes. Both retained dependency logs resolve all libraries; every listed filesystem dependency is represented in the extra-tool manifest. The runner rejects a runtime-library identity changing between backend builds and rechecks final binaries, logs, and input snapshots before allowing a completed pass.
- Budgets remain one sequential build job, 1 GiB disk reserve/RSS budget, 1 MiB log budget, 60-second configure/build bounds and 10-second probe/run bounds. Recorded final disk reserve is 2,387,415,040 bytes per monitored path. These remain sampled budgets, with the limitations already disclosed in the report.

## Reviewed source identities and scope

| Reviewed file | SHA-256 |
|---|---|
| `AGENTS.md` | `fdd82f39a11d5b9bc96fe2c15f5779e2c08d359e89dc666595adbf30a01d1e0b` |
| `docs/designs/simulator_completion_v1.md` | `d407a6d57be4806800ba37a60dacbd54c4e160286c5a65b08413a5e08b22b87b` |
| `ci/project/p06_simulator_parent.py` | `af9da75aa37f22102680aa1f7eba70262916c2b0d39d55ad70a3606b56618bb5` |
| `ci/project/test_p06_simulator_completion.py` | `764101eeae4c30bfcf44b312e0037ee9dd0fa3c54279456c770ada3d95673199` |
| Fixture `main.cpp` | `d9f8a8c010c1d1d8a35b6d7016cd5f1fdaf741375d72b81e1893b922f24f1cc9` |
| Fixture `processor.h` | `5783124e76bd13df030acfeaebf9d598e389c9aa489ab0e7be329f0859fc7e28` |
| `ci/project/baseline_process.py` | `54ae2d6756c47349f4cf33a91209addcff447de1618a35892e0ac3e344506daa` |
| Prior `w06-a01-parent-review.md` | `45442185ec9bae9fd68554e4a8a6ec2b26014751ffba17399e5889d17c72b6e5` |

The fixture holds a real async task pending, confirms it has not retired, queues a later DCR command, releases it, and fails at the intended `await_terminal(1) != 0` check. Parent cells stop there; they do not independently execute later sticky-error assertions. The controlled SimX legacy `run()` catches injected exceptions and returns `-1`, which the actual old void launch lambda discards. The RTL fixture throws into a future whose old backend observes only readiness/wait. This demonstrates the old exception-transport defect without interpreting an ordinary nonzero `gp` value as failure.

The report correctly retains `native_execution=false`, `qualified=false`, and `acceptance_claimed=false`. Controlled Processor/RAM and RAM/LLC selections establish no native processor/RTL arithmetic, native cache behavior, whole-platform cleanup, native public-runtime failure, performance, or device-recovery qualification. Production Processor files retained as context are not linked into these binaries. System headers and all transitive tool dependencies are not a hermetic toolchain image. Native obligations and phase acceptance remain separate under the current completion contract.
