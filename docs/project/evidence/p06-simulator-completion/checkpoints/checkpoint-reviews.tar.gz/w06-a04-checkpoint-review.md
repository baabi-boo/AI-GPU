# W06-A04 — independent completion checkpoint and scope review

## Disposition

**No new F2/F3 production defect or scope regression found. An explicitly unqualified validation-branch checkpoint is supportable. Required native completion execution remains NOT RUN; this review does not recommend a master-ready or native-qualified claim.**

Reviewer: `/root/w06_a04_checkpoint_review`, wave 6, assignment 34/60; independent of implementation. Repository: `/workspace/scratch/ea983fdea786/AI-GPU`. Base: `42809ff0c1b81384d7c9b079e4ef786be8407600`.

**Exact reviewed checkpoint:** `db5ebb3a16770004423f2456ec6d0caaa0aced6d`; tree `1536393fef63bd4a4639505ce797c27303db1cc7`; local branch `codex/p06-simulator-completion-20261122`. Local HEAD and tree matched those identities and `git status --porcelain=v1` was empty during final review. The 87-file commit inventory was checked against the base. All 18 primary source hashes below match the actual commit blobs. The commit message explicitly retains native execution and final integration receipts as pending and claims no performance or phase acceptance.

This reviewer made no repository edits, commits, checkout/reset/stash/clean operations, builds, native runs, downloads, pushes or approvals. Only the requested report, extracted immutable base classifier/policies, and supporting static identity records were written outside the repository.

## Review scope and prerequisites

Read the repository `code-review` and `simx-review` skills, `AGENTS.md`, C++/Verilog rules, bug-fix discipline, review policy, SimObject design and SimX architecture. Read the completion contract and current status/acceptance context. Reviewed every production hunk in the common asynchronous owner, both backend transports, additive checked Processor entry, both full-cleanup headers, runtime Makefile dependencies and the additive native build fragment. Inspected the native unit/public-success source so the required native obligations remain concrete.

Reconciled the requested independent reports `w03-a06-r3-review.md`, `w04-a06-runner-review.md`, `w05-a04-cleanup-review.md` and `w06-a01-parent-review.md`, including W06-A01's repair addendum. Current code hashes were compared with those reports. This review relies on their retained execution evidence as reviewed historical evidence; it does not relabel those executions as new checkpoint runs.

## Findings and remaining obligations

### F2 high missing-test — required native completion observations remain NOT RUN

Exact commit `db5ebb3a16770004423f2456ec6d0caaa0aced6d`. Paths: `docs/designs/simulator_completion_v1.md` (Required verification), `tests/unittest/simx_completion/main.cpp`, `tests/regression/simx_completion/`, `ci/project/p06_simulator_execute.py`.

**What:** Neither the real linked Processor/bounded-RAM unit nor the generated public-runtime success regression has an executed native result at this checkpoint. This is the existing qualification obligation identified by W03-A06 and retained by the later independent reviews, not a newly discovered code defect.

**Scenario:** Controlled host Processor/RAM headers can establish error transport while a real checked entry, generated native kernel, bounded-RAM exception, full failed-context teardown or fresh-context execution still fails to compile or execute. Source-presence, the actual-header cleanup fixture and runner parser tests cannot settle those native behaviors.

**Required closure:** Run the fixed hosted native runner from the exact clean checkpoint and a fresh configured build tree, preserving the original resource bounds and failed attempts. Independently reconcile raw unit/public results, source/configuration/tool/compiler identities and the completed report. The timing-SimX RV64 `p02-tfr`, `PERF=1` unit must retain x3 values 7 and -1, unchanged legacy success/caught-exception behavior, real bounded-RAM `OutOfRange` consumed through `future.get()`, complete failed-context destruction and a subsequent fresh normal context. The public cell must retain six serial successful launches across two contexts, nonzero low `gp`, global data, exact output checks, waits and cleanup.

This blocks completed native qualification/master-ready claims. It does not prevent the explicitly unqualified validation checkpoint whose purpose is obtaining that evidence. This review grants no waiver or acceptance.

### F1 high static-proof — historical development status still names the cleanup source defect as open

Paths: `docs/project/p06-simulator-completion-audit.md` (Decision, Implementation scope, Next bounded action), `docs/project/status.md` (completion prerequisite), and related backlog wording.

**What:** These checkpoint narratives still describe cleanup repair as an implementation action in progress, while the current two headers, completion contract and W05-A04 review establish the source repair and bounded host-framework proof. The native evidence limitation remains accurate.

**Disposition:** The coordinator acknowledged that these are historical development-checkpoint statements and committed to reconciliation in the final status/evidence pass after hosted CI. They conservatively understate completion and do not establish a false native pass. Preserve their historical observations; update the current-action wording and link the final packet before final publication/master readiness. This is not an additional F2 checkpoint blocker.

## Production review conclusions

| Area | Independent conclusion |
|---|---|
| Successful immediate completion | `start_pending_` is independent of future validity. `check`, `wait` and `wait_for` may consume a ready successful future without removing the required first busy edge. `busy()` checks exceptional completion first, then consumes that edge once. |
| Exceptional completion | Every operational observer requires a healthy owner; `collect()` consumes `future.get()`, latches failure and rethrows. A failed task cannot be reported idle by the busy hook. |
| Overlap and async creation failure | `start()` checks health, rejects an active future or unobserved start edge, preserves the original owned task and latches terminal failure. Task-construction exceptions are also latched. |
| Twin guarded callbacks | Both read/write transactions check before/after their existing bounded CP tick burst. A thrown hook exits the burst immediately and latches failure; later transactions fail before touching the CP. Failed reads do not assign their output pointer. |
| Memory and register synchronization | Existing LLC/DCR waits, and the processor-RTL drain wait, now consume results. Direct RAM/host-memory routing and the common CP's serial command ordering remain unchanged. This adds no independent concurrent-host access support. |
| Destruction | Explicit `run_.join()` precedes registered host-memory release. It still waits after an earlier sticky failure and catches exceptions only at the destruction boundary. The Processor and RAM outlive their asynchronous task. |
| Checked vs legacy entry | `run_checked()` calls the unchanged `impl_->run()` and discards its register-derived result. Nonzero architectural x3, including -1, is not interpreted as an error. The legacy `Processor::run()` body, catch/log behavior and -1 return are preserved byte-for-byte. |
| Full-platform cleanup | Each framework adds exactly two comment lines and one relaxed zero-store to in-flight accounting. The store follows healthy-worker shutdown/join, object ownership release, event disposal, execution-domain/inbox disposal and cross-pending reset. It retires abandoned accounting, without marking the failed launch successful. |
| Late owners | Existing channel destruction does not invoke ordinary queue-pop accounting, so destruction-only retained owners cannot subtract old occupancy from fresh accounting. Operating finalized owners, simultaneous live contexts, same-thread direct-exception recovery and internal multiworker exception recovery remain excluded by the contract. |
| Normal model behavior | Exact byte subtraction proves the Processor source/header contain only the checked-entry addition and each framework contains only its three cleanup lines. Normal run/reset/cycle logic, packet reserve/pop, queue capacity, event scheduling, launch-keep behavior, arithmetic and retirement code are unchanged. No measured parity/performance result is inferred from this fact. |
| Build dependencies | Each runtime library target adds the shared helper header as a prerequisite; its recipe still compiles only `SRCS`. The new `completion.mk` includes the accepted SimX Makefile and reuses production model objects/configuration without editing that Makefile. Configure already copies `*.mk`; no configure change is needed. |
| Native test obligations | Both native sources retain all required success, legacy-gp, exception, teardown and fresh-context controls. The additive test build fragment preserves separate legacy/candidate test objects. These are inspected source obligations, not native execution results. |

## Protected-scope proof

The retained static proof establishes the following against the pinned base:

- Removing only the single `run_checked()` definition/declaration additions makes `processor.cpp` and `processor.h` exactly equal to their base blobs. This proves the legacy run body and all original Processor logic are intact.
- Removing only the exact three added cleanup lines from either framework header makes that whole header exactly equal to its base blob. Normal packet flow, reset, launch reset, cycles, worker scheduling and topology code are intact.
- The protected `sim/simx/Makefile` equals base, SHA-256 `c719966647f32fef5421dd798a89d3eeddccd692e7c61046e5744b7a8e722403`.
- `docs/assets/img/vortex_framework_stack.svg` equals base byte-for-byte, SHA-256 `db123c71024f85f379c2504c7465c03ee9df8959a5d17fc3d3e94a94a1cd3aa4`; README still embeds its exact path.
- `processor_impl.h`, the common CP source/header, configuration/ISA TOMLs, VERSION, configure/config template, root installation Makefile, review policy and machine-readable acceptance roadmap equal base.
- Exact commit inventory confirms zero changes to installed public headers/ABI, shared ABI/common code, RTL/hardware, ISA decode/operand sources, existing test catalogs, golden data, gate code/thresholds, profiles/toolchain/install inputs, frozen warm/serial-workspace contracts, acceptance policy, acceptance records and the canonical roadmap. The internal additive C++ checked entry and observable completion semantics still require manual R3 review depth even though installed public ABI bytes are unchanged.

## Prior-finding reconciliation

| Review | Current disposition |
|---|---|
| W03-A06 new-fixture brace F2 | Closed in the current fixture source: the named new control bodies have braces. Original production/native/build hashes remain unchanged. |
| W03-A06 immediate successful `check()` F1 | Closed at declared Linux host-test scope. Current source waits for the identified async worker to disappear from procfs before invoking `check()` as the first successful collector. Retained W04-A03 evidence shows this case passes, the targeted `check()` edge-clearing mutation fails the intended assertion with exit 1, and all seven older groups still pass that mutant. No sleeps or lucky repeated scheduling replace the readiness witness. |
| W03-A06 native missing-test F2 | Remains open exactly as described above. |
| W04-A06 runner option/include/provenance repair | Current native-runner and reviewed validator/build hashes match the repaired-source review. Its earlier full-run/compiler-path conclusions remain bounded to their recorded evidence; native execution is not claimed. |
| W05-A04 cleanup review | All matching current cleanup, test, native-source and contract hashes in that review agree. Its actual-header and healthy-worker-shutdown evidence is separate from native Processor qualification and from internal multiworker exception transport. |
| W06-A01 parent provenance F2 | Closed at source/boundary-test scope. The current runner forces `GIT_NO_REPLACE_OBJECTS=1`; runner/test hashes match the independently reviewed closure addendum. Historical parent bytes and logs remain historical. A final clean-checkpoint real parent replay remains required for final source identity. |

The supporting `prior-review-reconciliation.json` retains all compared records, including superseded hashes rather than silently updating old reports. W03 has expected superseded runner, contract, ready-check and brace-fix inputs; W04 has expected later contract/AGENTS refinements. W05 and the W06 closure inputs match the current reviewed scope.

## Classification and evidence limits

Manual impact class: **R3**, because the change alters externally observable completion/error behavior and adds CI enforcement. A lower advisory path result cannot lower this review depth.

The workflow touches `.github/**`, so its CI classification cannot be trusted as the independent classification. The exact base blobs of `ci/change_impact.py`, `docs/review/change-impact.yaml` and `docs/review/code-review-policy.md` were extracted with replacement objects disabled into the reviewer-owned scratch directory. Their SHA-256 values are respectively `bd2ef579de90b14b7ab4cd5ef2f6b7c911753e154c4201aaf0f0d0b25a460779`, `489d1018c790bb6c383b774b119223889bb508be6c63db654d5c6c80520d0333`, and `99426ced05c04c1b14422f4fdacabcce3c680600461c4887b14e5eabf8b0587d`. Both extracted-base commands ran successfully against `42809ff0c1b81384d7c9b079e4ef786be8407600..db5ebb3a16770004423f2456ec6d0caaa0aced6d` with Python isolated mode and `GIT_NO_REPLACE_OBJECTS=1`. Both exited 0 with empty stderr. Policy version 3 gives advisory **R2**, `indeterminate=false`, 87 files and no detected contract findings. Manual review remains **R3** for the externally observable completion/error contract.

| Base-classifier evidence item | Disposition |
|---|---|
| `simx-rtl-lockstep` warning on `processor.cpp`/`.h` | Confirmed functional completion-entry addition only. Exact subtraction restores both full base files; the legacy body and underlying loop are unchanged. Each framework also differs only at full teardown. There is no new normal pipeline/cycle operation to mirror in RTL, and no parity result is claimed. |
| `configure-copied` notice for the fragment and Makefiles | Valid obligation. Configure must run before execution from a generated build tree. The runner/build path and independent W04-A06 review retain this requirement; this static assignment did not build or run native tests. |

The new workflow was inspected at source scope: hosted `ubuntu-22.04`, `contents: read`, checkout credentials not persisted, restore-only cache actions, no self-hosted runner, no secret interpolation or privileged fork-trigger combination, no `continue-on-error`, and retained failure artifacts. No elevated workflow trust exposure was identified. Its definition is not evidence that hosted execution occurred.

Reproducible classification command (the parallel `explain` call substitutes `explain` and omits `--format json`):

```sh
GIT_NO_REPLACE_OBJECTS=1 PYTHONDONTWRITEBYTECODE=1 python3 -I \
  /workspace/scratch/ea983fdea786/w06-a04-checkpoint-review/change_impact.py \
  --repo /workspace/scratch/ea983fdea786/AI-GPU \
  --policy /workspace/scratch/ea983fdea786/w06-a04-checkpoint-review/change-impact.yaml \
  classify --base 42809ff0c1b81384d7c9b079e4ef786be8407600 \
  --head db5ebb3a16770004423f2456ec6d0caaa0aced6d --format json
```


Direct reviewer execution: read-only Git/source/hash comparisons, preserved-base `classify` and `explain` (both exit 0), and exact-range `git diff --check` (passed). No host suite or compiler was rerun, and no native model/public test, RTL elaboration, parity, performance, synthesis or hardware experiment was run. Previous reports' tests were read and reconciled, not duplicated. Existing warm `qualified=false`, unestablished absolute no-wrap bound, P06-A02/A03, P01-A03, framework acceptance and inherited DSP-area failures are not changed by this review.

## Reviewed source identities

These frozen production/contract bytes were inspected before publication and independently verified equal to their blobs at `db5ebb3a16770004423f2456ec6d0caaa0aced6d`.

| Repository-relative file | SHA-256 |
|---|---|
| `sw/runtime/common/async_run.h` | `17e229eb116c6d50d273780bb969630d0e0141a8aec39f22c0ab0fb62b74d2ed` |
| `sw/runtime/simx/vortex.cpp` | `61a14d8c29f9c2e9bef292d4ef8bbc5892ff6b13ad62110a80915f788917edd4` |
| `sw/runtime/rtlsim/vortex.cpp` | `048f7e96625243024a7f4952fb7e616b4f28c47744e1670e346917b554b6fce4` |
| `sw/runtime/simx/Makefile` | `a904a327b54481567d5efd205da7cba3fed0f7ecb6410ab641753d789c8ee975` |
| `sw/runtime/rtlsim/Makefile` | `1a2e731e8a676d3f57a891dfa380c4992d42ed066c81256a82ea278e78602ab4` |
| `sim/simx/processor.cpp` | `569cf629d1e25ec9a295b20bfadfabbe21cd0989127f2b825fceee99a8062b78` |
| `sim/simx/processor.h` | `588db10c3997e91dd471771cd12bb0329dacbc3902248b84353beebd19bc0438` |
| `sim/common/simobject.h` | `0e0369f5ea1ba85f5e461e03b85e9723bb47f0e118499ba2b21a7923594f7004` |
| `sim/common/simobject_functional.h` | `0a62df63e18f340096bda900ccb858e00a3c2d54d7688c92737c5cca06210984` |
| `sim/simx/completion.mk` | `371f1cc7ad00e00094cb80e03074e114bf38134c59e03a617f34ec9fe209f235` |
| `tests/unittest/simx_completion/main.cpp` | `343f68f1cf90ea5e81ae9d97d8428df9e5db246fb35ac29af163c5b099b1727e` |
| `tests/regression/simx_completion/main.cpp` | `07687cbb532f3f6901d928da5de181fa76d8c0efc8796bfd578d0c485008b468` |
| `tests/regression/simx_completion/kernel.cpp` | `15f6df7b29f9211b4fdf8ac589265241c177e8059e9a2bebcb479bc3baef8cc6` |
| `tests/regression/simx_completion/common.h` | `ab20e7e7dff9ede29b045f9a38405ee0eab8f366517cc51f9fb1a836b521b926` |
| `tests/regression/simx_completion/Makefile` | `a2f83c95a4b976ea179a5e6f850799f5795646042cff4e2df9afcc1ca4ecbad7` |
| `ci/project/p06_simulator_execute.py` | `373ed9ba9141db73e740c87ec812872bb1dc2131b29819a7f001eda7e59e5641` |
| `ci/project/p06_simulator_parent.py` | `af9da75aa37f22102680aa1f7eba70262916c2b0d39d55ad70a3606b56618bb5` |
| `docs/designs/simulator_completion_v1.md` | `d407a6d57be4806800ba37a60dacbd54c4e160286c5a65b08413a5e08b22b87b` |

## Retained review evidence

All supporting artifacts are under `/workspace/scratch/ea983fdea786/w06-a04-checkpoint-review/`; the source tree remains unchanged by this reviewer. `exact-commit-inventory.json` contains the full changed-path inventory, every source binding, invariant comparisons, clean-state observation and archive/display-copy proof.

The committed `w04-a04-native-review.md.gz` and `w05-a04-cleanup-review.md.gz` decompress exactly to the original scratch reports. Their adjacent `.md` copies equal only trailing-horizontal-whitespace removal from those originals; no technical finding or other content was altered. The original W05-A04 report hash remains `d4eb8cb98eb51432553ec6b899b25a727e32d63884458548b3546e42f66e8f4a`.

| Artifact | SHA-256 |
|---|---|
| `classify.json` | `881f2921f17625cf09870ddc01d1d7343e821aa0029bfe4e076bb4a91feabf58` |
| `explain.txt` | `8ba58e50a9c2943147734a5d97a987c1bb1d9ebbbfc0edda60145135ed3ffdd5` |
| `classify-receipt.json` | `5f09580e8850b9731751cf4bfe31cf9da06de210bf761c56cfa612d90feedce2` |
| `explain-receipt.json` | `4d6f81164492073bfacd3455998bd7148fffa0ff9fa0f8455532bc3b673c232b` |
| `exact-commit-inventory.json` | `1a7363d5c73f48768a6209bce1458427f696c6f5c45f41e5d9a4d077b01fd610` |
| `prior-review-reconciliation.json` | `cca76da2306d256b5962d8cdcb26a6153714bdc342f39147ad6af1194239e109` |
| `ready-check-evidence-review.json` | `0bd6daaa581f22971f5323df1d6b3757ea077cf492d5c479e5a3aed80af80911` |
| `precommit-static-proof.json` | `d785cd34110c829fc6003dc2666857229786596285074fc70671b0b768112571` |
| `diff-check-receipt.json` | `5ab0b86adda3d28542dce32ea77bb8e2c2e4244cca5c18f84e108d4fa86f2aaa` |

## Final verdict

**Validation checkpoint: supportable, explicitly unqualified. Final/master landing: land only after the required native evidence, exact-source parent/host reconciliation, final documentation pass and existing R3 approval process. No new production fix is requested by this scope review.**
