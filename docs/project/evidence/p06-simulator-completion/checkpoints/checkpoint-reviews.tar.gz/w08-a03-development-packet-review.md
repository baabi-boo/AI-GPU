# Wave 8, agent 3 — committed development packet integrity review

## Result

**PASS for the bounded historical development-packet integrity audit. No concrete broken current packet link, missing indexed evidence member, hash mismatch, changed review finding, or unsupported native-qualification claim was found.** This is not a native execution result, acceptance decision, production-code approval, or exact-final-code qualification.

- Reviewed commit: `db5ebb3a16770004423f2456ec6d0caaa0aced6d`.
- Packet: `docs/project/evidence/p06-simulator-completion/`.
- Recorded development base: `42809ff0c1b81384d7c9b079e4ef786be8407600`.
- Assignment: wave 8/10, agent 3, overall review 45/60.
- Review date: 2026-11-22.

All evidence checks read objects from the specified commit. The worktree was clean and HEAD matched that commit at the initial inspection. No repository file was changed. No archived script, test, compiler, native runner, build, or workflow was executed. The only written artifact is this requested review.

## Integrity checks and exact counts

The packet contains **45 committed files totaling 943,735 bytes**. Its root manifest contains 44 entries and covers every packet file except itself, with no duplicate or unlisted file. All 44 declared SHA-256 values and byte lengths match the committed bytes.

The development index describes ten archives. Each archive's SHA-256, compressed byte count, retained-file count, retained-original byte count, omitted-file count, scope, ID, and key paths agree with its sidecar and actual contents. Every embedded `MANIFEST.json` is byte-identical to its adjacent sidecar. All **304 original archive members, totaling 2,683,122 uncompressed bytes**, match their declared SHA-256 values and sizes. The ten embedded manifests are additional members and are not counted among the 304 originals.

| Archive ID | Original members verified | Compressed bytes | Declared omitted files |
|---|---:|---:|---:|
| `w03-a05-runner-review` | 8 | 10,328 | 0 |
| `w04-a01-runner-repair` | 26 | 26,309 | 0 |
| `w04-a02` | 9 | 13,590 | 0 |
| `w04-a03` | 29 | 21,951 | 2 |
| `w04-a04-native-probe` | 5 | 5,909 | 1 |
| `w05-a01` | 18 | 34,225 | 3 |
| `w05-a02` | 54 | 92,235 | 4 |
| `w05-a03` | 35 | 54,256 | 4 |
| `w05-a04-cleanup-probe` | 50 | 140,281 | 4 |
| `source-at-assembly` | 70 | 283,371 | 0 |

Archive inventories are exact: no extra, duplicate, missing, symlink, hardlink, device, or traversal-path member was found. Every tar member is a regular file. Original members had no ELF, PE/MZ, or ar-library magic. The 18 declared omissions are compiled executables and are explicitly described in their sidecars; their omission is not hidden evidence loss.

All **51 relative Markdown links** in the root and development READMEs resolve at the reviewed commit. This includes the two links outside the packet to the completion contract and development audit; those targets were checked for existence only. Every indexed archive key path resolves to an actual member or populated prefix.

In addition to the manifest hashes, I checked the eight log hashes and sizes embedded in the initial parent receipt, the initial runner-failure receipt's log hash, and **53 internal command-log hashes** in the original leak, timing repair, actual-framework, functional repair, and independent lifecycle receipts. No mismatch was found.

## The two original reviews and their display copies

Both compressed review originals match their stored gzip identity. Decompression matches the original byte length and SHA-256 recorded in `development/index.json`. The readable Markdown copies match their own recorded identities and are exactly the decompressed originals with trailing spaces/tabs removed at line ends.

| Review | Decompressed original bytes | Display bytes | Only observed difference |
|---|---:|---:|---|
| `w04-a04-native-review.md` | 15,131 | 15,125 | Six trailing whitespace bytes removed across three lines |
| `w05-a04-cleanup-review.md` | 18,133 | 18,127 | Six trailing whitespace bytes removed across three lines |

Both retain the same line count and all other bytes. No finding, severity, technical statement, source identity, or conclusion was changed by the display transform.

**Native-fixture review identities:**

- Gzip SHA-256: `a271db0a9a8df31a7eda98e4ff1cc8f0799fb91b2eca5e7301e643e601adeeba`.
- Decompressed original SHA-256: `4e218e64cddc3e8c7f7d4a7babc4d006dff4f63cad106dffda71db44d52ecf64`.
- Display SHA-256: `36f013900ee69cd0826d43a609835353ad193a1f1796287d00351f75883fa9a9`.

**Cleanup review identities:**

- Gzip SHA-256: `05da361847aafafc5c7aac2822cbf977870a26a9fd78b95ee72b2829d71b7f29`.
- Decompressed original SHA-256: `d4eb8cb98eb51432553ec6b899b25a727e32d63884458548b3546e42f66e8f4a`.
- Display SHA-256: `54852f5b492eab2c8465827a885db2c10e56cfb2b324940a9b95802605803da1`.

The uncompressed initial R3 review, runner review, and runner proof JSON also match their index and root-manifest identities. Historical findings remain visible, including the initial fixture-brace and missing-native-evidence findings, the ready-check coverage finding, and the native-source review's original abandoned-reservation defect. The later cleanup review continues to require native CI and does not turn its host observations into final native approval.

## Initial host records and failed attempts

All **13 promised `host/initial-*` files** are present and match their root-manifest identities:

- `initial-async-owner-tests.log` retains the earlier seven passing helper groups.
- `initial-backend-tests.log` retains six passing host backend groups.
- `initial-public-runtime-tests.log` retains three passing public-runtime host groups.
- `initial-public-build-failure.log` retains the original setup/build error, including the missing configuration definitions and `Ran 0 tests`; it is correctly distinguished from behavioral sensitivity.
- `initial-parent-report.json` retains eight old-backend exception results.
- The eight `initial-parent-{simx,rtlsim}-{standard_exception,unknown_exception}-{ram,llc}.log` files remain present. Their recorded compile results are `pass`, their runs exit 1, and their bytes match the parent report's independent log hashes and lengths. The raw failures still state that a failed launch was accepted as successful.

The development archives also preserve the unsuccessful observations that explain subsequent repairs:

| Historical evidence | Retained observation checked |
|---|---|
| Initial runner review | Raw log retains 26 tests and `FAILED (failures=10)`; the original failure receipt and preprocessor observations remain present. |
| Assertion preservation | The earlier compiler-selection gap and fixture diff remain alongside the final receipt and `Ran 26 tests` / `OK` log. |
| Ready-check mutation | Mutant build succeeds; all seven older groups pass; `immediate_check` exits 1 with the lost-initial-busy-observation assertion. |
| Original framework leak | The zero-exit reproduction log retains `inflight=1 idle=0` after full destruction and after fresh-context consumption. Its zero exit is correctly described as successful defect reproduction. |
| Timing repair | Old-header compilation succeeds and its recovery run exits 1; repaired release/debug runs succeed. Both complete headers remain archived. |
| Actual framework regression | Four compile commands succeed; eight candidate cells succeed; six parent fault/abandonment cells exit 1 with intended failures; two parent normal controls succeed. Original command outcomes and logs agree with the summary. |
| Functional repair | Before release/debug compilation succeeds and both runs exit 1; after release/debug compilation and runs succeed. Before/after snapshots and raw failure logs remain present. |
| Independent lifecycle probe | Four timing/functional × debug/release runs succeed, with the explicit no-native/no-internal-worker-fault scope retained. |

These are observations of existing receipts and logs, not new executions or independent reproduction of their behavior.

## Source provenance and claim boundaries

The root README, development README, root manifest, development index, source bindings, and ten sidecars consistently describe the retained material as development history. Root/index metadata keep native execution at `not_run`. The packet does not close P06-A02/A03, change the historical `qualified=false` decision, claim native functional or RTL execution, or assert performance or physical-device results.

The `source-at-assembly` archive contains 70 source/build/contract files, including the shared compiler validator and retained local Python helpers. All 11 entries in the actual `w04-a02/runner-tests-final.json` before/after source maps are identical, agree with `source-bindings.json`, and match the corresponding archived bytes. The archived runner for that host receipt has SHA-256 `373ed9ba9141db73e740c87ec812872bb1dc2131b29819a7f001eda7e59e5641`.

The timing and functional before/after header hashes in `source-bindings.json` match their complete archived snapshots. Both after-header hashes also match the later assembly snapshot.

The two missing exact early runner snapshots are explicitly disclosed, with identities that agree with the original receipts:

- Initial runner: `b3b5013f4ab8bf3c5bae44a57cfc534ccd306fa98c23b46283161eaf5b0e2843`.
- Intermediate generated-proof runner: `9326bbc6931e9bcb0713173c41440357514b59fdda0b5e9ec70833cafddb0561`.

The packet does not substitute the later runner for those missing source states. It explicitly states that the assembly snapshot is historical and is not final release source, and that later parent-runner provenance work requires separate final evidence. That distinction is appropriate at this commit.

The host framework and native execution scopes remain separate. The historical directory name `w04-a04-native-probe` is explicitly explained; its contents do not purport to execute a native Processor. The root README clarifies that the lifecycle probe's two executor threads are the coordinator and one persistent worker. Internal-worker exception transport, simultaneous contexts, hung-worker recovery, finalized-object reuse, and direct same-thread exception recovery remain outside the claimed evidence.

## Limitations and disposition

1. This review verifies committed packet consistency and the stated historical scope. In-packet hashes are not independent proof that the recorded commands actually ran in the stated environment. No tests or archived code were executed.
2. Original scratch evidence outside this packet was not re-read or treated as a second authoritative baseline. In particular, the recorded base commit predates the packet: the initial host files are introduced at the reviewed commit, so preservation before assembly cannot be independently established by comparing those files to that base. Presence, manifest identity, retained failure contents, and the parent receipt's eight cross-referenced log hashes were verified.
3. Historical absolute paths and references to the 18 intentionally omitted compiled executables remain as original text. These disclosed archival references are not presented as current navigable packet links. The 51 current README links and all indexed archive entry paths were verified.
4. The missing full initial/intermediate runner snapshots remain a real, disclosed provenance limitation. The successful 11-file match establishes only the named final host receipt's relation to the later snapshot; it does not retroactively establish the earlier executions' source bytes or final released code identity.
5. Later clean host receipts, parent refresh receipts, hosted CI artifacts, exact-final-commit reviews, and final qualification are outside this audit. Their presence, execution status, and source identities were not inferred from separate scratch packets and must be integrated and reviewed separately after CI.
6. The external completion-contract and audit-document links were checked for existence without extending this audit into a whole-repository source or governance review.

**No packet repair is requested by this audit. Preserve the current development record and add later qualification evidence separately with its actual executing source identity and outcomes.**
