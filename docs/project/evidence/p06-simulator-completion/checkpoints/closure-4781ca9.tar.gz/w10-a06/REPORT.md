# Independent publication preflight and source projection

Reviewer: `/root/w10_a06_release_readiness`, unique assignment **60**, Wave 10 assignment 6. Initial checkpoint; the exact audit and remote-capture times appear below.

## Verdict

**PASS for the completed prepublication source/ref checks; publication is still pending.** No source-projection, ancestry, repository-target or authorization blocker was found. This is a frozen preflight checkpoint, not a claim that master has been updated or that the outstanding repaired-code governance run has passed. The later immutable final commit and published remote ref require follow-up checks recorded separately.

This reviewer changed no repository source, documentation, index, branch, workflow, protection, PR metadata or review state. Only this scratch review directory was written. No native build, host test suite, optional full rerun or retained executable was run. The read-only auditor streams Git blobs, checks source identities and reads retained evidence as data.

## Repository, authorization and ancestry

The fresh GitHub read at **2026-11-22T10:18:38.174Z** independently observed:

| Item | Observed value |
| --- | --- |
| Authorized target | `baabi-boo/AI-GPU` |
| Local origin fetch/push URL | `https://github.com/baabi-boo/AI-GPU.git` |
| Remote master | `42809ff0c1b81384d7c9b079e4ef786be8407600` |
| Validation branch | `codex/p06-simulator-completion-20261122` |
| Remote branch / PR head | `4781ca96db15a1d130626edc7a73411a4f6c2e7c` |
| PR | #6, open, draft, base `master` at the audited master |
| Executed native PR merge | `e929c52d05bad80b28dd4085a97838d7fe2de354` |
| Repaired code / executed merge tree | `6dd0d759390cda78ec63ad0caacc00a08f03e2bc` |

`preflight-remote-snapshot.json` retains these direct API reads. `initial-remote-merge.json` independently binds the executed merge to that exact tree and ordered parents `42809ff0c1b81384d7c9b079e4ef786be8407600`, then `4781ca96db15a1d130626edc7a73411a4f6c2e7c`. The merge commit was not present in the local object database, so this review uses the retained GitHub Git-object metadata for that identity instead of pretending a local read succeeded.

Local unreplaced Git objects establish the linear history `42809ff` → `db5ebb3` → `4781ca9`. `git merge-base --is-ancestor` independently accepts the audited master as an ancestor of the repaired checkpoint. All provenance subprocesses set `GIT_NO_REPLACE_OBJECTS=1`.

The PR body explicitly records the user's requested audit, implementation, 60 agents across ten waves and commit/push to master. It states that publication is authorized and that outstanding tests are not waived. The original user request supplies the authorization; the PR records it as required by the repository's externally visible-change policy. An agent review does not manufacture maintainer approval, and no new approval request is required for this already authorized publication. No waiver, protection change or unrelated repository write is proposed.

## Independently verified execution-input projection

`audit_projection.py` reconstructed the repaired tree and independently streamed every historical host source object through `git cat-file --batch`. For **all 5,109 blobs**, totaling **370,676,935 bytes**, it checked path, mode, object kind, object ID, SHA-256, byte length and reconstructed Git blob ID against the clean host source inventory. All five root gitlinks match. The before/after source inventory bytes are identical and name clean checkpoint `4781ca9` with the exact tree above.

The auditor then checked **all 3,339 current blobs outside `README.md` and `docs/project/**`** against those original bytes and modes, and checked their index entries. This includes the complete source, tests, runners, helpers, workflows, configuration, build inputs, hardware, public headers, inherited assets and `docs/designs/simulator_completion_v1.md`; it is broader than checking only the production files touched by the repair. No new untracked or changed path outside the narrow documentation/evidence allowlist was present.

For the native packet, **all 761 retained source bodies** match their before/after report hashes and exact unreplaced `4781ca9` Git blobs. Each retained native input is also in the protected current-source projection. The allowlisted documentation/evidence paths have **zero overlap** with the 761 native-retained inputs. The native report names executed merge `e929c52d` and the same repaired tree, a clean checkout, successful completion of both cells, and false qualification/acceptance flags.

The exact source inventory is retained in `initial-projection.inputs.json`; the result and its hash are in `initial-projection.json`. The initial audit completed at **2026-11-22T10:17:37.289247+00:00**. No source-drift finding was found.

The original native ZIP was independently rehashed here: **2,792,870 bytes**, SHA-256 `461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9`, artifact `14749901531`. This agrees with the independent original-artifact review by assignment #57. The original native report SHA-256 is `c134037768dd8c55fa8eab5e4bc7012967291b5c44d482570bde9fa9761a2239`. Its declared scope remains RV64 `p02-tfr`, timing SimX, PERF1, one simulation worker and direct-RAM CP. Neither the source projection nor the agent count supplies missing native RTL, native public injected-fault, functional SimX, multiworker, counter-lifetime or phase-acceptance evidence.

The clean host report hash is `68e622bd72ef34f4a21c0fdebd03b2317fe488178c9f13912e7da1eb5a67117b`; it records 83 passing focused methods at `4781ca9`, all integrity flags true and no skips. Assignment #54 independently reviewed its original log and the eight intended compiled-parent failures. This release review checks source binding and does not relabel those host fixtures as native execution.

### Final-commit claim boundary

A later commit containing only `README.md` and `docs/project/**` may retain the execution evidence **for byte-identical inputs at tested checkpoint `4781ca9`**. It must not be described as though its entire new tree was the tree executed by earlier CI. Governance tools read project documentation/evidence, so final documentation/evidence structural and manifest validation must also use the assembled final content. A completed repaired-checkpoint governance receipt remains separately bound to its actual executed revision.

Run the retained auditor again against the actual immutable publication commit:

```text
python3 -B /workspace/scratch/ea983fdea786/w10-a06/audit_projection.py --candidate FINAL_COMMIT --output /workspace/scratch/ea983fdea786/w10-a06/final-projection.json
```

The final mode verifies `4781ca9` ancestry, exact candidate-tree identities for every protected blob/gitlink, every native-retained source and the strict changed-path allowlist. It rejects additions, deletions, mode changes or content changes outside that allowlist. It does not silently broaden the allowed area to all of `docs/`.

The source receipts are before/after observations, not a hermetic build proof or a guarantee against transient substitutions restored between observations. Submodule gitlinks identify revisions, not an independent archive of every third-party working file. No such stronger claims are made.

## Actual agent accounting

The coordinator registry contains **60 distinct actual assignments**, six in each of ten logical waves. The provisional ledger prepared by assignment #59 reports its then-current completion states and explicitly states that counts are coordination records, not qualification. This reviewer read its report and provisional ledger. Neither the requested count nor spawning the final assignment is used as a substitute for a test result or final publication observation. Follow-up work remains the same assignment #60.

## Concrete publication procedure

1. Finish the repaired-code governance original-log review and retain its actual completed outcome/count. Retain late native/review/governance evidence and the completed actual-assignment ledger, then obtain the final claim/manifest delta review from assignment #56. Preserve existing archives and all open gates; do not turn historical pending observations into retrospective passes.
2. Freeze the assembled final documentation/evidence content. Validate its structure, links and manifest without changing any execution input. Create the final immutable commit as a descendant of `4781ca9`, compare its tree to the intended local index tree, and run the candidate mode of this auditor against that exact commit.
3. Refresh remote `master`, the validation branch and PR #6 immediately before any publication. Confirm repository identity, final SHA/tree and ancestry. If either head changed unexpectedly, inspect and preserve the new work; do not blindly retry, force-push or bypass protections.
4. Update the validation branch using `force: false` and an `expected_sha` equal to its freshly observed old head. Record the PR's final tested checkpoint, actual final commit/source projection, exact results, limitations and already supplied authorization.
5. Update only `baabi-boo/AI-GPU` branch `master` to the exact reviewed final SHA using the connector's `github_update_ref` with `force: false` and `expected_sha` equal to the freshly read master. At this preflight that expected old SHA is `42809ff0c1b81384d7c9b079e4ef786be8407600`; it is a checkpoint, not permission to ignore a later change. The API schema explicitly rejects mismatched expected heads. A rejected lease triggers a read/review of the new head, never a force retry.
6. Independently read back remote master and its immutable commit/tree/parents. Confirm exact final SHA and both audited-master and repaired-code ancestry. Read PR #6's actual state and report it as observed; do not assume a direct ref advance marked the draft merged. Record new post-publication CI runs as pending until observed completed. Report the published commit link, execution checkpoint, tested scopes and remaining development obligations.

This reviewer performs only the independent read/verification portions when called back. The coordinator owns the authorized ref update; this reviewer does not push, merge, approve, cancel workflows or alter branch protections.

## Remaining evidence before release closure

- The final original-log repaired-code governance review, including the actual final test count.
- Final appended evidence archives, finalized actual ledger and independent final claim/manifest reconciliation.
- The final immutable commit/tree and successful candidate-mode projection result.
- Fresh remote lease observations immediately before the authorized non-force publication.
- Post-publication readback of master SHA/tree/ancestry and PR state.

The first preflight assignment is complete and releases this reviewer slot. These pending publication observations require follow-up records; no master publication or whole-CI-green claim is made by this report.
