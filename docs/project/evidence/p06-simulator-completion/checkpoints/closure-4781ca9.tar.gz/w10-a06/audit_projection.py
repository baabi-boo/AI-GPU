#!/usr/bin/env python3
"""Read-only source projection; never invokes retained scripts or tests."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/ea983fdea786')
REPO = ROOT / 'AI-GPU'
HERE = ROOT / 'w10-a06'
HOST = ROOT / 'w06-a05-host-receipt/attempt-20261122T094824742647Z'
NATIVE = ROOT / 'w10-a03-native-ci/packet/simulator-completion'
CHECKPOINT = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
BASE = '42809ff0c1b81384d7c9b079e4ef786be8407600'
MERGE = 'e929c52d05bad80b28dd4085a97838d7fe2de354'
TREE = '6dd0d759390cda78ec63ad0caacc00a08f03e2bc'
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, env=ENV)


def load(path):
    return json.loads(path.read_bytes())


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def allowed_document(path):
    return path == 'README.md' or path.startswith('docs/project/')


def tree(revision):
    result = {}
    for row in git('ls-tree', '-r', '-z', '--full-tree', revision).split(b'\0'):
        if not row:
            continue
        header, path = row.split(b'\t', 1)
        mode, kind, object_id = header.decode('ascii').split()
        result[path.decode('utf-8')] = {'mode': mode, 'kind': kind, 'git_object': object_id}
    return result


def working_bytes(path, mode):
    target = REPO / path
    if mode == '120000':
        require(target.is_symlink(), 'symlink became regular file: ' + path)
        return os.fsencode(os.readlink(target))
    require(target.is_file() and not target.is_symlink(), 'missing/nonregular source: ' + path)
    actual = '100755' if target.stat().st_mode & stat.S_IXUSR else '100644'
    require(actual == mode, 'worktree mode drift: ' + path)
    return target.read_bytes()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', help='Final immutable Git commit; default audits the present worktree.')
    parser.add_argument('--output', default=str(HERE / 'initial-projection.json'))
    args = parser.parse_args()
    began = datetime.now(timezone.utc).isoformat()
    original = tree(CHECKPOINT)
    candidate = tree(args.candidate) if args.candidate else None
    require(git('rev-parse', CHECKPOINT + '^{tree}').decode().strip() == TREE, 'checkpoint tree drift')
    require(subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, CHECKPOINT], cwd=REPO, env=ENV).returncode == 0, 'base not ancestor')
    if args.candidate:
        require(subprocess.run(['git', 'merge-base', '--is-ancestor', CHECKPOINT, args.candidate], cwd=REPO, env=ENV).returncode == 0, 'checkpoint not candidate ancestor')
        changed = sorted(p for p in set(original) | set(candidate) if original.get(p) != candidate.get(p))
    else:
        changed = sorted(set(git('diff', '--name-only', '-z', CHECKPOINT).decode().split('\0')) - {''})
        untracked = set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
        changed = sorted(set(changed) | untracked)
    require(all(allowed_document(p) for p in changed), 'postcheckpoint change outside README/docs/project: ' + repr([p for p in changed if not allowed_document(p)]))

    host_before_bytes = (HOST / 'source-before.json').read_bytes()
    require(host_before_bytes == (HOST / 'source-after.json').read_bytes(), 'host inventories changed')
    host = json.loads(host_before_bytes)
    require(host['head'] == CHECKPOINT and host['tree'] == TREE and host['status_porcelain'] == '', 'host source checkpoint mismatch')
    require(host['working_blob_mismatches'] == [], 'host recorded working mismatches')
    require(set(host['tracked_files']) == set(original), 'host source inventory not whole original tree')
    native = load(NATIVE / 'report.json')
    require(native['source_before'] == native['source_after'], 'native source changed during execution')
    require(native['source_before']['checkout']['revision'] == MERGE and native['source_before']['checkout']['tree'] == TREE, 'native checkpoint mismatch')
    require(not native['source_before']['checkout']['dirty'], 'native checkout dirty')
    records = native['source_before']['files']
    native_map = {r['path']: r for r in records}
    require(len(native_map) == len(records) == 761, 'native inventory cardinality or duplicates')
    retained = {r['path'].removeprefix('artifacts/source/'): r for r in native['retained_source']}
    require(set(retained) == set(native_map), 'retained native source path set mismatch')
    require(not any(allowed_document(p) for p in native_map), 'allowlisted docs overlap native input closure')

    cat = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=REPO, env=ENV, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    blob_count = blob_bytes = protected_count = native_count = gitlink_count = 0
    identities = []
    try:
        for path, entry in sorted(original.items()):
            record = host['tracked_files'][path]
            require(all(record[k] == entry[k] for k in ('mode', 'kind', 'git_object')), 'host path/mode/object mismatch: ' + path)
            if entry['kind'] == 'commit':
                gitlink_count += 1
                if candidate is not None:
                    require(candidate.get(path) == entry, 'candidate submodule pin changed: ' + path)
                continue
            cat.stdin.write((entry['git_object'] + '\n').encode('ascii'))
            cat.stdin.flush()
            object_id, kind, count = cat.stdout.readline().decode('ascii').strip().split()
            require(kind == 'blob' and object_id == entry['git_object'], 'unexpected cat-file object')
            data = cat.stdout.read(int(count))
            require(cat.stdout.read(1) == b'\n' and len(data) == int(count), 'short cat-file read')
            sha = digest(data)
            require(record['sha256'] == sha and record['size_bytes'] == len(data), 'host source hash/length mismatch: ' + path)
            require(record['working_git_blob'] == entry['git_object'], 'host working Git blob mismatch: ' + path)
            reconstructed = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            require(reconstructed == entry['git_object'], 'Git blob identity mismatch: ' + path)
            blob_count += 1
            blob_bytes += len(data)
            row = {'path': path, **entry, 'sha256': sha, 'size_bytes': len(data), 'protected_from_docs_delta': not allowed_document(path), 'native_retained': path in native_map}
            if not allowed_document(path):
                protected_count += 1
                if candidate is None:
                    require(working_bytes(path, entry['mode']) == data, 'current protected source drift: ' + path)
                else:
                    require(candidate.get(path) == entry, 'candidate protected source drift: ' + path)
            if path in native_map:
                require(native_map[path]['sha256'] == sha and native_map[path]['size_bytes'] == len(data), 'native Git binding mismatch: ' + path)
                r = retained[path]
                retained_bytes = (NATIVE / r['path']).read_bytes()
                require(retained_bytes == data and r['sha256'] == sha and r['size_bytes'] == len(data), 'retained native body mismatch: ' + path)
                native_count += 1
            identities.append(row)
    finally:
        cat.stdin.close()
        cat.stdout.close()
        require(cat.wait() == 0, 'cat-file failed')
    require(native_count == 761, 'native inventory missing from Git tree')
    require(blob_count == 5109 and gitlink_count == 5, 'host historical source cardinality mismatch')
    if candidate is None:
        index = {}
        for row in git('ls-files', '-s', '-z').split(b'\0'):
            if row:
                header, path = row.split(b'\t', 1)
                mode, object_id, stage = header.decode().split()
                path = path.decode()
                require(stage == '0', 'unmerged index: ' + path)
                index[path] = (mode, object_id)
        for path, entry in original.items():
            if not allowed_document(path):
                require(index.get(path) == (entry['mode'], entry['git_object']), 'protected index drift: ' + path)
    host_report = load(HOST / 'report.json')
    require(host_report['expected_head'] == CHECKPOINT and host_report['outcome'] == 'pass' and host_report['unittest_ok_without_skips'], 'host report identity/result mismatch')
    require(all(host_report['integrity'].values()), 'host integrity flag false')
    require(host_report['unittest_summary']['count'] == 83, 'host count changed')
    require(native['outcome'] == 'pass' and native['full_matrix_completed'] and not native['qualified'] and not native['acceptance_claimed'], 'native outcome/scope mismatch')
    identity_path = Path(args.output).with_suffix('.inputs.json')
    identity_path.write_text(json.dumps(identities, indent=2, sort_keys=True) + '\n')
    result = {
        'schema_version': 1, 'outcome': 'pass', 'started_at': began,
        'finished_at': datetime.now(timezone.utc).isoformat(),
        'checked_candidate': args.candidate or 'WORKTREE',
        'checked_candidate_tree': git('rev-parse', args.candidate + '^{tree}').decode().strip() if args.candidate else None,
        'audited_master': BASE, 'tested_code_checkpoint': CHECKPOINT, 'tested_tree': TREE, 'executed_native_merge': MERGE,
        'native_retained_sources_verified': native_count,
        'host_historical_blobs_verified': blob_count,
        'host_historical_blob_bytes': blob_bytes,
        'host_historical_gitlinks_verified': gitlink_count,
        'protected_current_or_candidate_blobs_verified': protected_count,
        'postcheckpoint_allowed_paths': changed,
        'postcheckpoint_allowlist': ['README.md', 'docs/project/**'],
        'native_input_allowlist_overlap': [],
        'input_manifest': {'path': identity_path.name, 'sha256': digest(identity_path.read_bytes()), 'size_bytes': identity_path.stat().st_size},
        'host_report_sha256': digest((HOST / 'report.json').read_bytes()),
        'native_report_sha256': digest((NATIVE / 'report.json').read_bytes()),
        'native_scope': native['source_scope'],
        'host_test_count_at_checkpoint': host_report['unittest_summary']['count'],
        'claim_boundary': 'Byte-identical source projection from tested checkpoint; not a claim that the whole later documentation/evidence commit was executed. Source inventories do not establish hermeticity or catch transient replacements restored between observations.',
        'execution_performed_by_this_auditor': 'none; Git and byte/hash inspection only',
    }
    Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('postcheckpoint_allowed_paths',)}, sort_keys=True))


if __name__ == '__main__':
    main()
