#!/usr/bin/env python3
"""Retain existing evidence bytes; never execute a retained program."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE = Path('/workspace/scratch/ea983fdea786')
REPO = BASE / 'AI-GPU'
HERE = BASE / 'w09-a05'
STAGE = HERE / 'staged'
TARGET = REPO / 'docs/project/evidence/p06-simulator-completion'
CODE = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
HIST = 'db5ebb3a16770004423f2456ec6d0caaa0aced6d'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def pick_dir(name, prefix=None, top_only=False):
    folder = BASE / name
    result, excluded = {}, []
    paths = folder.iterdir() if top_only else folder.rglob('*')
    for path in sorted(paths):
        if not path.is_file() and not path.is_symlink():
            continue
        relative = path.relative_to(folder).as_posix()
        archive_path = (prefix or name) + '/' + relative
        if path.is_symlink():
            excluded.append({'path': archive_path, 'reason': 'symlink or tool binary not copied'})
            continue
        data = path.read_bytes()
        if '__pycache__' in path.parts or path.suffix in ('.pyc', '.o', '.so', '.a') or data.startswith(b'\x7fELF'):
            excluded.append({'path': archive_path, 'reason': 'compiled/cache artifact; original receipt retains declared identities'})
            continue
        result[archive_path] = (path, data)
    return result, excluded

def single(name, prefix=None):
    p = BASE / name
    return {(prefix or name): (p, p.read_bytes())}

def combine(*parts):
    result, excluded = {}, []
    for part in parts:
        files, omitted = part if isinstance(part, tuple) else (part, [])
        assert not set(result) & set(files)
        result.update(files)
        excluded.extend(omitted)
    return result, excluded

def archive(name, files, scope, revision, result, exclusions=None):
    members = []
    for path, (source, data) in sorted(files.items()):
        assert not path.startswith('/') and '..' not in Path(path).parts
        members.append({'path': path, 'original_path': str(source), 'size_bytes': len(data), 'sha256': sha(data)})
    manifest = {'format': 'retained-evidence-archive-v1', 'archive': name + '.tar.gz',
        'scope': scope, 'source_revision_or_context': revision, 'recorded_result': result,
        'files': members, 'exclusions': exclusions or [],
        'manifest_self_exclusion': 'MANIFEST.json is byte-identical to the sidecar and excluded from its own file list.',
        'retained_programs_executed_by_assembly': False,
        'byte_policy': 'Original members copied verbatim; only archive/gzip header metadata normalized.'}
    mbytes = encoded(manifest)
    folder = STAGE / 'checkpoints'
    folder.mkdir(parents=True, exist_ok=True)
    sidecar = folder / (name + '.manifest.json')
    sidecar.write_bytes(mbytes)
    dest = folder / (name + '.tar.gz')
    with dest.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
                items = {path: data for path, (_, data) in files.items()}
                items['MANIFEST.json'] = mbytes
                for path, data in sorted(items.items()):
                    info = tarfile.TarInfo(path)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    tar.addfile(info, io.BytesIO(data))
    with tarfile.open(dest, 'r:gz') as tar:
        observed = {m.name: m for m in tar.getmembers()}
        assert len(observed) == len(members) + 1
        assert tar.extractfile('MANIFEST.json').read() == mbytes
        for row in members:
            member = observed[row['path']]
            assert member.isfile() and not member.issym() and not member.islnk()
            data = tar.extractfile(member).read()
            assert len(data) == row['size_bytes'] and sha(data) == row['sha256']
            assert data == Path(row['original_path']).read_bytes()
    return {'name': name, 'archive': 'checkpoints/' + dest.name,
        'manifest': 'checkpoints/' + sidecar.name, 'scope': scope,
        'source_revision_or_context': revision, 'recorded_result': result,
        'sha256': sha(dest.read_bytes()), 'size_bytes': dest.stat().st_size,
        'manifest_sha256': sha(mbytes), 'original_members': len(members),
        'uncompressed_original_bytes': sum(r['size_bytes'] for r in members),
        'all_original_members_verified': True}

def main():
    HERE.mkdir(parents=True, exist_ok=True)
    STAGE.mkdir(exist_ok=True)
    original_record = HERE / 'original-packet-identities.json'
    if original_record.exists():
        original = json.loads(original_record.read_text())
    else:
        original = {str(p.relative_to(TARGET)): {'sha256': sha(p.read_bytes()), 'size_bytes': p.stat().st_size}
                    for p in TARGET.rglob('*') if p.is_file()}
        original_record.write_bytes(encoded(original))
    frozen_root = HERE / 'original-root'
    frozen_root.mkdir(exist_ok=True)
    for name in ('README.md', 'manifest.json'):
        frozen = frozen_root / name
        if not frozen.exists():
            frozen.write_bytes((TARGET / name).read_bytes())
        assert sha(frozen.read_bytes()) == original[name]['sha256']
    specs = []
    def add(name, parts, scope, revision, result, extra_exclusions=()):
        files, excluded = combine(*parts)
        specs.append((name, files, scope, revision, result, excluded + list(extra_exclusions)))
    # Specifications are added below; all inputs are data, never executable authority.
    old_index = {('root-at-db5/' + n): (frozen_root / n, (frozen_root / n).read_bytes()) for n in ('README.md', 'manifest.json')}
    add('development-index-db5ebb3', [old_index], 'Original development root index before checkpoint reconciliation', HIST, 'Historical index; not a final qualification')
    add('host-db5ebb3', [pick_dir('w06-a05-host-receipt/attempt-20261122T091646248351Z', 'receipt')], 'Clean checkpoint host-only discovery with source/tool identities', HIST, 'PASS: 78 unittest methods; no native execution')
    add('host-4781ca9', [pick_dir('w06-a05-host-receipt/attempt-20261122T094824742647Z', 'receipt')], 'Clean repaired-code host-only discovery with source/tool identities', CODE, 'PASS: 83 unittest methods in 87.502 seconds; no native execution')
    for short, revision in (('db5ebb3', HIST), ('4781ca9', CODE)):
        parts = [pick_dir('p06-parent-' + short + '-report', 'report')]
        if (BASE / ('p06-parent-' + short + '.log')).is_file():
            parts.append(single('p06-parent-' + short + '.log', 'invocation.log'))
        add('parent-' + short, parts, 'Built pinned-parent sensitivity through actual old backends and shared CP', {'candidate': revision, 'parent': '42809ff0c1b81384d7c9b079e4ef786be8407600'}, 'PASS: eight old-backend exception cells fail intended behavioral assertions', [{'path': 'historical work directory', 'reason': 'Generated build copies and compiled executables excluded; report retains declared inputs, generated configuration, logs, commands and identities.'}])
    add('cp-allocation-repair', [single('w08-a04-consumer-error-scope.md'), pick_dir('w08-a05'), pick_dir('w08-a06'), pick_dir('w09-a02')], 'Late compatibility finding, independently authored repair, unchanged lifecycle and negative controls, independent review', {'base': HIST, 'reviewed_files_in': CODE}, 'PASS: 17 existing groups/44 cells; 38 new positive cells; four compiled db5 OOM failures; no unresolved F2/F3 in boundary review')
    add('native-db5ebb3', [pick_dir('w09-a01-native-ci', top_only=True)], 'Original hosted native archive and review; pre-CP-allocation-repair execution', {'head': HIST, 'executed_merge': '782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd'}, 'PASS: real timing SimX RV64 p02-tfr unit and six public successes; separate governance2988 tests', [{'path': 'w09-a01-native-ci/packet/', 'reason': 'Extracted contents retained without duplication inside original ZIP; extract ZIP into packet/ to reconstruct all original members.'}])
    add('warm-db5ebb3', [pick_dir('w07-a06-warm-ci'), single('w07-a06-warm-ci-review.md')], 'Original existing warm-workspace archive/replay; healthy execution control, not performance acceptance', {'head': HIST, 'executed_merge': '782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd'}, 'Replay passes:24 processes,792 launches,25344 words; qualified=false; conditional diagnostics not_satisfied')
    review_names = ['w06-a01-parent-review.md', 'w06-a03-public-review.md', 'w06-a04-checkpoint-review.md', 'w06-a06-ci-intake-review.md', 'w08-a01-host-receipt-review.md', 'w08-a02-parent-packet-review.md', 'w08-a03-development-packet-review.md']
    add('checkpoint-reviews', [*(single(n) for n in review_names), pick_dir('w06-a04-checkpoint-review'), pick_dir('w06-a02')], 'Historical source, workflow, parent-provenance and packet reviews; parent identity repair', HIST, 'Scope-bound reviews; parent-provenance issue closed; later CP finding retained separately')
    audit_names = ['w07-a01-counter-coverage.md', 'w07-a02-counter-lifetime.md', 'w07-a03-warm-contract.md', 'w07-a04-phase-dependencies.md', 'w07-a05-dsp-attribution.md']
    add('next-development-audits', [*(single(n) for n in audit_names)], 'Read-only future-work audits; no counter guard or qualification implemented', HIST, '33-selector coverage/coherence/lifetime work specified; warm block and other phase/DSP/physical obligations preserved')
    add('documentation-reconciliation', [pick_dir('w09-a03'), pick_dir('w09-a04')], 'Initial post-repair current-status and next-development documentation reconciliation, with original/applied bytes and validation', {'code_checkpoint': CODE, 'documentation': 'worktree changes after clean host receipt; fresh native still pending'}, 'Status, limits and next bounded counter work reconciled; no source/runtime/gate changes by these authors')
    add('host-4781ca9-review', [pick_dir('w09-a06')], 'Independent verification of both clean repaired-checkpoint host discovery and compiled-parent packets', CODE, 'PASS: retained83-test host receipt and all eight intended parent failures independently checked; no new tests or native execution by reviewer')
    records = [archive(*spec) for spec in specs]
    index = {'format': 'simulator-completion-checkpoint-index-v1', 'base_revision': '42809ff0c1b81384d7c9b079e4ef786be8407600', 'repaired_code_revision': CODE, 'repaired_code_tree': '6dd0d759390cda78ec63ad0caacc00a08f03e2bc', 'archives': records,
        'fresh_native_verification': {'run_id': 45009314161, 'state_at_assembly': 'pending', 'not_included_yet': True}, 'acceptance_claimed': False,
        'limitations': ['Host controlled-model tests and actual framework checks are separate from native processor execution.', 'Native db5 predates the CP allocation-error repair and is not final repair verification.', 'No native public-runtime injected-fault, native RTL, performance, phase, vendor or physical-device qualification.', 'Original manifests may reference excluded temporary binaries or extracted paths; exclusions and original ZIP retention are explicit.', 'No retained program executed during assembly; matching hashes preserve bytes but do not authenticate the producer.']}
    (STAGE / 'checkpoints/index.json').write_bytes(encoded(index))
    summary = {'archives': len(records), 'original_members': sum(r['original_members'] for r in records), 'archive_bytes': sum(r['size_bytes'] for r in records), 'staged_bytes': sum(p.stat().st_size for p in STAGE.rglob('*') if p.is_file()), 'all_original_members_verified': True, 'original_repository_packet_files': len(original), 'repository_written': False, 'records': records}
    (HERE / 'assembly-summary.json').write_bytes(encoded(summary))
    print(json.dumps({k: summary[k] for k in ('archives', 'original_members', 'staged_bytes')}))

if __name__ == '__main__':
    main()
