#!/usr/bin/env python3
"""Append the coordinator-approved closure evidence; earlier archives stay immutable."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import importlib.util
import io
import json
import re
import shutil
import tarfile
import zipfile

BASE = Path('/workspace/scratch/ea983fdea786')
HERE = BASE / 'w09-a05'
TARGET = BASE / 'AI-GPU/docs/project/evidence/p06-simulator-completion'
OUT = HERE / 'closure-followup'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def run():
    plan = json.loads((HERE / 'closure-plan.json').read_text())
    if not plan['ready_to_publish']:
        print('Prepared only: coordinator ready signal and original governance/final-document receipts are still required.')
        return
    gov = plan['governance']
    assert gov and gov['outcome'] == 'pass'
    assert isinstance(gov['tests'], int) and gov['tests'] > 83
    assert isinstance(gov['duration_seconds'], (int, float)) and gov['duration_seconds'] > 0
    assert len(gov['executions']) == 2
    assert {row['event'] for row in gov['executions']} == {'pull_request', 'push'}
    assert all(row['outcome'] == 'pass' and row['tests'] == 2993 and row['focused_completion_test_count'] == 83 for row in gov['executions'])
    push = next(row for row in gov['executions'] if row['event'] == 'push')
    for name, expected in gov['file_identities'].items():
        assert sha((BASE / name).read_bytes()) == expected, name
    index = json.loads((TARGET / 'checkpoints/index.json').read_text())
    assert len(index['archives']) == plan['frozen_existing_archive_count'] == 14
    OUT.mkdir(exist_ok=True)
    prior = {p.relative_to(TARGET).as_posix(): sha(p.read_bytes()) for p in TARGET.rglob('*') if p.is_file()}
    save(OUT / 'prior-file-identities.json', prior)
    for row in index['archives']:
        assert sha((TARGET / row['archive']).read_bytes()) == row['sha256']
        assert sha((TARGET / row['manifest']).read_bytes()) == row['manifest_sha256']
    for name, expected in plan['ledger_sha256'].items():
        assert sha((TARGET / name).read_bytes()) == expected
    ledger = json.loads((TARGET / 'delivery-ledger.json').read_text())
    assignments = ledger['assignments']
    assert len(assignments) == 60 and len({r['identity'] for r in assignments}) == 60
    assert sorted(r['ordinal'] for r in assignments) == list(range(1, 61))
    assert Counter(r['wave'] for r in assignments) == {i: 6 for i in range(1, 11)}
    assert all(r['assignment_status'] == 'completed' for r in assignments)
    frozen = json.loads((HERE / 'closure-preparation/frozen-input-identities.json').read_text())
    for directory in frozen:
        for row in directory['identities']:
            assert sha((BASE / directory['directory'] / row['path']).read_bytes()) == row['sha256']
    spec = importlib.util.spec_from_file_location('own_archive_helper', HERE / 'assemble.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    directories = plan['frozen_input_directories'] + plan['pending_input_directories'] + plan['additional_final_documentation_or_ledger_directories']
    assert len(directories) == len(set(directories))
    for name in plan['final_input_manifest_directories']:
        original_manifest = json.loads((BASE / name / 'manifest.json').read_text())
        for row in original_manifest['files']:
            original = BASE / name / row['path']
            assert sha(original.read_bytes()) == row['sha256'], str(original)
            assert original.stat().st_size == row.get('size_bytes', row.get('bytes')), str(original)
    parts = [helper.pick_dir(name) for name in directories]
    own_records = ['REPORT.md', 'manifest.json', 'verification.json', 'credential-scan.json',
                   'original-packet-identities.json', 'assemble.py', 'finish.py', 'append_native.py',
                   'close_packet.py', 'closure-plan.json', 'closure-preparation/frozen-input-identities.json',
                   'native-followup/REPORT.md', 'native-followup/manifest.json',
                   'native-followup/verification.json', 'native-followup/credential-scan.json']
    parts.extend(helper.single('w09-a05/' + name) for name in own_records)
    parts.extend({('delivered-ledger/' + name): (TARGET / name, (TARGET / name).read_bytes())}
                 for name in ('delivery-ledger.json', 'delivery-ledger.md'))
    files, exclusions = helper.combine(*parts)
    record = helper.archive(plan['archive_name'], files,
        'Original repaired-code governance result/review, completed actual-assignment accounting, final documentation records, prepublication preflight and preserved assembly/CI observations',
        {'code_checkpoint': plan['code_checkpoint'], 'publication': 'not yet performed; final candidate projection and ref readback are later observations'},
        f"PASS: both original governance executions report {gov['tests']} tests each; 60 actual initial assignments completed; source preflight passes its declared scope. No broad-CI or phase acceptance claim.", exclusions)

    patterns = {
      'temporary_signed_query': re.compile(rb'https?://[^\s"\'<>]+(?:[?&](?:sig|signature|X-Amz-Signature|X-Amz-Credential|token)=)[^\s"\'<>]+', re.I),
      'github_token': re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b|\bgithub_pat_[A-Za-z0-9_]{30,}\b'),
      'private_key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
      'unmasked_bearer': re.compile(rb'Authorization[\"\s:]+Bearer[\s]+[A-Za-z0-9._~+/-]{25,}', re.I),
    }
    findings, counts = [], {'tar_members': 0, 'zip_members': 0, 'bytes_scanned': 0}
    def scan(name, data, kind):
        counts[kind] += 1
        counts['bytes_scanned'] += len(data)
        for label, pattern in patterns.items():
            if pattern.search(data):
                findings.append({'member': name, 'pattern': label})
        if data.startswith(b'PK\x03\x04'):
            with zipfile.ZipFile(io.BytesIO(data)) as zipped:
                for member in zipped.infolist():
                    if not member.is_dir():
                        assert member.file_size <= 32 * 1024 * 1024
                        scan(name + '!' + member.filename, zipped.read(member), 'zip_members')
    with tarfile.open(helper.STAGE / record['archive'], 'r:gz') as archive:
        for member in archive.getmembers():
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            scan(member.name, archive.extractfile(member).read(), 'tar_members')
    assert not findings, 'Credential pattern requires review before copying'
    scan_record = {'patterns': list(patterns), 'counts': counts, 'findings': findings, 'pass': True}
    save(OUT / 'credential-scan.json', scan_record)
    index['archives'].append(record)
    index['current_governance'] = gov
    index['assignment_accounting'] = {'actual_unique_agents': 60, 'completed_initial_assignments': 60,
        'logical_waves': 10, 'assignments_per_wave': 6, 'followups_count_as_new_agents': False,
        'purpose': 'Coordination record; not execution qualification, approval or phase acceptance'}
    index['pending_additions'] = plan['future_records_not_claimed']

    text = (TARGET / 'README.md').read_text()
    old = 'The corresponding full governance result remains pending and is not inferred\nfrom either the earlier full suite or this native pass.'
    new = (f"Both corresponding original governance jobs now pass: the\n"
           f"[PR job](https://github.com/baabi-boo/AI-GPU/actions/runs/{gov['run_id']}) records\n"
           f"**{gov['tests']:,} tests in {gov['duration_seconds']:,.3f} seconds**, and the\n"
           f"[push job](https://github.com/baabi-boo/AI-GPU/actions/runs/{push['run_id']}) records\n"
           f"**{push['tests']:,} tests in {push['duration_seconds']:,.3f} seconds**. Each includes the 83\n"
           f"focused completion tests. Their [original completed logs and independent\n"
           f"review]({record['archive']}) are retained separately.\n"
           "This is evidence at the repaired code checkpoint; it does not imply that\n"
           "the broader CI matrix or later documentation/evidence commit was executed\n"
           "by that earlier job.")
    assert old in text
    text = text.replace(old, new)
    needle = '| [First full governance receipt](checkpoints/native-db5ebb3.tar.gz)'
    assert needle in text
    row = (f"| [Repaired full governance receipts]({record['archive']}) | Original PR and push jobs each pass {gov['tests']:,} tests, in {gov['duration_seconds']:,.3f} and {push['duration_seconds']:,.3f} seconds respectively, at the repaired code checkpoint | Independent original-log verification, including all 83 focused methods; distinct from the local focused run and later documentation-only assembly. |\n")
    text = text.replace(needle, row + needle)
    old_tail = '''The current governance original log, final evidence delta review and completed
release review remain separate additions. The
[assignment ledger](delivery-ledger.md) is currently a provisional record of
actual assignments and their recorded completion state; pending assignments
must be reconciled before claiming completion of all 60. The root manifest
must be refreshed after these additions. A native pass does not imply that the
entire broad CI matrix passed.'''
    new_tail = f'''The [closure archive]({record['archive']}) retains the original completed
governance logs/review, the completed [assignment ledger](delivery-ledger.md)
and its history, final documentation records and #60's independent source/ref
preflight. The ledger verifies **60 distinct actual agents, all 60 initial
assignments completed, ten logical waves and six assignments per wave**.
Follow-ups are not counted again. Agent counts provide coordination evidence;
they do not substitute for tests, source review or phase acceptance.

The later normalized CI API receipt confirms that both superseded own `db5ebb3`
broad CI runs completed/cancelled. Their earlier requested/queued observations
remain unchanged in the preceding archive. Canceled runs are not passes, and
the corresponding current broad CI matrices were still incomplete at that
receipt's capture time.

The final independent evidence delta review, immutable final-commit source
projection and actual publication readback are subsequent scoped observations.
They are not self-certified by this archive. Final documentation/evidence must
pass its own structure/link/manifest checks, and publication must preserve the
tested code inputs and use the already-authorized non-force expected-head
procedure. The root manifest must be refreshed after later additions.'''
    assert old_tail in text
    text = text.replace(old_tail, new_tail)
    text = text.replace('After corresponding native verification and final review close the completion\nprerequisite, the next bounded action is the',
                        'Native completion and repaired-checkpoint governance are now verified. After\nfinal delivery review, the next bounded development action is the')
    table = (TARGET / 'checkpoints/README.md').read_text()
    table = table.replace('\n\n| [Fresh repaired native packet]', '\n| [Fresh repaired native packet]')
    newrow = (f"| [Governance, ledger and closure records]({Path(record['archive']).name}) ([manifest]({Path(record['manifest']).name})) | {record['original_members']} | {record['size_bytes']:,} | Original current governance log/review; completed ledger/history; final documentation; preflight and CI/assembly observations |")
    table = table.replace('\n\n## Source and interpretation', '\n' + newrow + '\n\n## Source and interpretation')
    table = table.replace('Current governance and the final delta/ledger/release records remain separate.\nThe provisional ledger is included in the current root manifest as data, not\nas an assertion that all assignments have completed.',
                          'The closure archive below now supplies completed current governance and all 60\ninitial-assignment records. Earlier pending observations are preserved. Final\nevidence-delta and immutable publication/readback reviews remain separate.')
    table += f'''\n## Closure follow-up\n\nThe [closure archive]({Path(record['archive']).name}) adds the original repaired\ngovernance result and independent review, completed 60-assignment ledger/history,\nfinal documentation records and initial source/ref preflight. Every prior\narchive remains unchanged. Source-time pending statements in original reports\nare historical; the current result is stated in the root README and index.\nNo broad-CI, phase, final-publication or self-review claim is added.\n\nThe assembly receipt is [assembly-closure-4781ca9.json](assembly-closure-4781ca9.json).\n'''
    for key in ('archive', 'manifest'):
        dest = TARGET / record[key]
        assert not dest.exists()
        shutil.copyfile(helper.STAGE / record[key], dest)
    (TARGET / 'README.md').write_text(text)
    (TARGET / 'checkpoints/README.md').write_text(table)
    save(TARGET / 'checkpoints/index.json', index)
    receipt = {'format': 'simulator-completion-closure-assembly-v1', 'code_checkpoint': plan['code_checkpoint'],
        'archive': record, 'prior_archives_preserved': 14, 'original_members_verified': True,
        'credential_scan': scan_record, 'retained_programs_executed': False,
        'completed_initial_assignments': 60, 'qualification_from_agent_count': False,
        'future_records_not_claimed': plan['future_records_not_claimed'], 'publication_claimed': False,
        'producer_sha256': sha(Path(__file__).read_bytes()), 'plan_sha256': sha((HERE / 'closure-plan.json').read_bytes())}
    save(TARGET / 'checkpoints/assembly-closure-4781ca9.json', receipt)
    mutable = {'README.md', 'manifest.json', 'checkpoints/README.md', 'checkpoints/index.json'}
    for name, digest in prior.items():
        if name not in mutable:
            assert sha((TARGET / name).read_bytes()) == digest, name
    manifest = json.loads((TARGET / 'manifest.json').read_text())
    manifest['assembled_utc'] = datetime.now(timezone.utc).isoformat()
    manifest['scope'] = 'Historical development and reviewed repaired-code host/native/governance evidence, completed actual-assignment records and prepublication reviews; later final commit/readback are separate.'
    manifest['verification']['new_archives'] = 15
    manifest['verification']['new_archive_original_members'] = sum(r['original_members'] for r in index['archives'])
    manifest['verification']['closure_preserves_prior_archives'] = True
    manifest['current_governance'] = gov
    manifest['completed_initial_assignments'] = 60
    manifest['publication_claimed'] = False
    manifest['limitations'][0] = 'Native db5 remains historical; separate fresh 4781 native and original repaired governance records bind their exact code/configuration scopes. The later documentation/evidence commit is not relabeled as their executed tree.'
    manifest['limitations'][-1] = 'All 60 initial assignments are recorded complete. Final evidence delta, immutable candidate projection and actual publication readback remain subsequent scoped records; refresh this manifest after additions.'
    manifest['files'] = [{'path': p.relative_to(TARGET).as_posix(), 'size_bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                         for p in sorted(TARGET.rglob('*')) if p.is_file() and p != TARGET / 'manifest.json']
    save(TARGET / 'manifest.json', manifest)
    links = []
    for p in (TARGET / 'README.md', TARGET / 'checkpoints/README.md'):
        for label, link in re.findall(r'\[([^\]]+)\]\(([^)]+)\)', p.read_text()):
            if '://' in link or link.startswith('#'):
                continue
            assert (p.parent / link.split('#', 1)[0]).resolve().exists(), link
            links.append({'document': str(p.relative_to(TARGET)), 'target': link})
    for row in manifest['files']:
        assert sha((TARGET / row['path']).read_bytes()) == row['sha256']
    result = {'pass': True, 'archive': record, 'prior_archives_unchanged': True, 'relative_links_checked': len(links),
        'total_files': len(manifest['files']) + 1, 'total_bytes': sum(p.stat().st_size for p in TARGET.rglob('*') if p.is_file()),
        'root_manifest_sha256': sha((TARGET / 'manifest.json').read_bytes()),
        'index_sha256': sha((TARGET / 'checkpoints/index.json').read_bytes()),
        'root_readme_sha256': sha((TARGET / 'README.md').read_bytes()), 'credential_scan': scan_record}
    save(OUT / 'verification.json', result)
    print(json.dumps({k: result[k] for k in ('pass', 'total_files', 'total_bytes', 'relative_links_checked', 'root_manifest_sha256', 'index_sha256')}))

if __name__ == '__main__':
    run()
