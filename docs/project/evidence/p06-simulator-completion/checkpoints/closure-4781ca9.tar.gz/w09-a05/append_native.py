#!/usr/bin/env python3
"""Append reviewed native data and late reviews without rebuilding prior archives."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import re
import shutil
import tarfile
import zipfile

BASE = Path('/workspace/scratch/ea983fdea786')
HERE = BASE / 'w09-a05'
TARGET = BASE / 'AI-GPU/docs/project/evidence/p06-simulator-completion'
CODE = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
DELTA = HERE / 'native-followup'
DELTA.mkdir(exist_ok=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

index = json.loads((TARGET / 'checkpoints/index.json').read_text())
assert len(index['archives']) == 12
prior_files = {p.relative_to(TARGET).as_posix(): sha(p.read_bytes())
               for p in TARGET.rglob('*') if p.is_file()}
save(DELTA / 'prior-file-identities.json', prior_files)
for row in index['archives']:
    assert sha((TARGET / row['archive']).read_bytes()) == row['sha256']
    assert sha((TARGET / row['manifest']).read_bytes()) == row['manifest_sha256']
for name, expected in {
 'delivery-ledger.json': '0773625273a9f22f1d0d6bca87dd7dd1f2025931f7b01f0046f7678285ab91ac',
 'delivery-ledger.md': 'ca4f4fa48581f6949cbc9cf74a7fca264552116091503a0a568cf309038c4c78',
}.items():
    assert sha((TARGET / name).read_bytes()) == expected

# Import only this agent's own assembly helper; original evidence code is data.
spec = importlib.util.spec_from_file_location('own_assembly_helper', HERE / 'assemble.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
zip_path = BASE / 'w10-a03-native-ci/p06-simulator-completion-run45009314161-artifact14749901531.zip'
assert zip_path.stat().st_size == 2792870
assert sha(zip_path.read_bytes()) == '461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9'
assert sha((BASE / 'w10-a03-native-ci/review.md').read_bytes()) == '88659fdb99a319a61d413338c2bfa01ec0f5b7ef996191b84bde75b220f61b4e'
native_files, native_exclusions = helper.pick_dir('w10-a03-native-ci', top_only=True)
native_exclusions.append({'path': 'w10-a03-native-ci/packet/', 'reason': 'All extracted content is preserved in the original ZIP; extract that ZIP into packet/ to reconstruct the original manifest paths.'})
native = helper.archive('native-4781ca9', native_files,
    'Fresh repaired-code native execution and independent retained-data review; fixed RV64 p02-tfr timing SimX PERF1, one worker, direct-RAM CP',
    {'head': CODE, 'executed_merge': 'e929c52d05bad80b28dd4085a97838d7fe2de354', 'tree': '6dd0d759390cda78ec63ad0caacc00a08f03e2bc'},
    'PASS: actual native checked/legacy/bounded-RAM/fresh-context unit and six successful public-runtime launches; current governance still pending in original review', native_exclusions)
early = ['w01-a01-counter-semantics.md', 'w01-a02-architecture.md', 'w01-a03-native-coverage.md', 'w01-a04-error-path.md', 'w01-a05-failure-tests.md', 'w01-a06-rtl-scope.md', 'w02-a02-harness-report.md']
late_files, late_exclusions = helper.combine(helper.pick_dir('w10-a01'), helper.pick_dir('w10-a02'),
    helper.pick_dir('w10-a04'), helper.pick_dir('ci-management'), *(helper.single(n) for n in early))
late = helper.archive('late-reviews-4781ca9', late_files,
    'Original final production/protected-input reviews, initial 72-file evidence review, seven early reports and explicitly incomplete superseded-CI management records',
    {'code_checkpoint': CODE, 'review_states': 'Each original review retains its own source/evidence observation time'},
    'Source and initial packet reviews support their scoped conclusions; accepted cancellation requests are not broad CI passes; current governance and final delta/ledger/release reviews remain separate', late_exclusions)
records = [native, late]

patterns = {
 'temporary_signed_query': re.compile(rb'https?://[^\s"\'<>]+(?:[?&](?:sig|signature|X-Amz-Signature|X-Amz-Credential|token)=)[^\s"\'<>]+', re.I),
 'github_token': re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b|\bgithub_pat_[A-Za-z0-9_]{30,}\b'),
 'private_key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
 'unmasked_bearer': re.compile(rb'Authorization[\"\s:]+Bearer[\s]+[A-Za-z0-9._~+/-]{25,}', re.I),
}
findings, counts = [], {'tar_members': 0, 'zip_members': 0, 'bytes_scanned': 0}
def scan(name, data, kind):
    counts[kind] += 1
    counts['bytes_scanned'] += len(data)
    for label, pattern in patterns.items():
        matches = list(pattern.finditer(data))
        if matches:
            findings.append({'member': name, 'pattern': label, 'matches': len(matches)})
    if data.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(data)) as zipped:
            for member in zipped.infolist():
                if member.is_dir():
                    continue
                assert member.file_size <= 32 * 1024 * 1024
                assert not Path(member.filename).is_absolute() and '..' not in Path(member.filename).parts
                scan(name + '!' + member.filename, zipped.read(member), 'zip_members')
for row in records:
    with tarfile.open(helper.STAGE / row['archive'], 'r:gz') as archive:
        for member in archive.getmembers():
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            scan(row['archive'] + '!' + member.name, archive.extractfile(member).read(), 'tar_members')
assert not findings, 'Sensitive-material pattern requires review'
credential_scan = {'patterns': list(patterns), 'counts': counts, 'findings': findings, 'pass': True,
    'image_review': 'The CI cancellation screenshot was visually inspected; it shows repository/run state and accepted cancellation banner, with no credential values.'}
save(DELTA / 'credential-scan.json', credential_scan)

index['archives'].extend(records)
index['fresh_native_verification'] = {
    'run_id': 45009314161, 'job_id': 137167865239, 'artifact_id': 14749901531,
    'state_at_assembly': 'pass', 'not_included_yet': False, 'archive': native['archive'],
    'head': CODE, 'executed_merge': 'e929c52d05bad80b28dd4085a97838d7fe2de354',
    'tree': '6dd0d759390cda78ec63ad0caacc00a08f03e2bc',
    'original_zip_sha256': '461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9',
    'review_sha256': '88659fdb99a319a61d413338c2bfa01ec0f5b7ef996191b84bde75b220f61b4e',
    'scope': 'Fixed timing SimX RV64 p02-tfr PERF1 one worker direct-RAM CP; native unit fault and public success cells only',
    'native_public_injected_fault': False, 'native_rtl': False, 'acceptance_claimed': False}
index['pending_additions'] = ['Original completed current governance log and review', 'Final evidence delta review', 'Completed assignment ledger and release review']
index['limitations'][1] = 'Native db5 remains historical; the separate fresh4781 packet supplies the repaired-code native controls within its exact declared scope.'

root_readme = (TARGET / 'README.md').read_text()
old = '''It predates the subsequently discovered CP allocation-error regression and its
repair. Its native result remains historical evidence. **Corresponding fresh
native verification of `4781ca9` is still pending** in
[run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161).
This packet does not substitute the earlier native result for that obligation.'''
new = '''It predates the subsequently discovered CP allocation-error regression and its
repair, so its native result remains historical evidence. **Fresh native
verification of `4781ca9` passed** in
[run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161).
The [new original packet and independent review](checkpoints/native-4781ca9.tar.gz)
bind the repaired code to same-tree merge
`e929c52d05bad80b28dd4085a97838d7fe2de354`; they verify both the actual native
processor fault/success unit and six successful public-runtime launches.
The corresponding full governance result remains pending and is not inferred
from either the earlier full suite or this native pass.'''
assert old in root_readme
root_readme = root_readme.replace(old, new)
needle = '| [First native completion packet](checkpoints/native-db5ebb3.tar.gz)'
assert needle in root_readme
root_readme = root_readme.replace(needle, '| [Fresh repaired native packet](checkpoints/native-4781ca9.tar.gz) | `4781ca9`, executed merge `e929c52d05bad80b28dd4085a97838d7fe2de354`, identical tree; both native cells pass with independent source/command/compiler review | Real timing SimX RV64 `p02-tfr`, `PERF=1`, one worker, direct-RAM CP; actual model fault/success unit and six public successes. |\n' + needle)
root_readme = root_readme.replace('## Original native archive', '''## Native execution archives

The fresh repaired-code packet retains the original ZIP from
[run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161),
artifact `14749901531`: **2,792,870 bytes**, SHA-256
`461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9`.
Its independent review verifies all 812 original ZIP members, 786 retained
input records, 761 checkpoint source bodies, five gitlinks, 18 command/log
records, five compiler/header roles and 87 model-object compile commands.
It explicitly matches the three repaired runtime/helper files and the
completion contract. The actual native unit records nine checked successes,
three legacy successes, one checked `OutOfRange` exception, one legacy error
and fresh-context success; the public cell records six successful serial
launches across two contexts. Original pending-governance API observations
remain historical data inside this frozen packet.

The original ZIP remains unchanged inside `native-4781ca9.tar.gz`. Extract it
beneath `w10-a03-native-ci/packet/` to reconstruct the original review manifest
paths. Its native scope and exclusions are the same narrow categories as the
earlier packet below; it adds no native public injected-fault or RTL result.''')
old_end = '''Fresh native results, the final governance/review receipts and the actual
60-assignment ledger will be added with their own identities when complete.
The root manifest must then be refreshed; an incomplete or requested agent
count is not represented as completed work here.'''
new_end = '''The [late-review archive](checkpoints/late-reviews-4781ca9.tar.gz) retains
the independent final production review, the initial 72-file evidence review,
the protected-input/phase audit and seven original early audit/harness reports.
Their source-time observations remain unchanged. It also retains the two
accepted requests to cancel this task's superseded `db5ebb3` broad CI runs.
Those original management snapshots still report queued overall runs with no
conclusion; they are explicitly incomplete records, not passing CI evidence.
Neither unrelated runs nor verification thresholds were modified by those
recorded actions.

The current governance original log, final evidence delta review and completed
release review remain separate additions. The
[assignment ledger](delivery-ledger.md) is currently a provisional record of
actual assignments and their recorded completion state; pending assignments
must be reconciled before claiming completion of all 60. The root manifest
must be refreshed after these additions. A native pass does not imply that the
entire broad CI matrix passed.'''
assert old_end in root_readme
root_readme = root_readme.replace(old_end, new_end)

checkpoint_readme = (TARGET / 'checkpoints/README.md').read_text()
rows = []
for row, label, principal in [
    (native, 'Fresh repaired native packet', '`w10-a03-native-ci/review.md`, original ZIP, original job/API/audit records'),
    (late, 'Late reviews and early originals', '`w10-a01/`, `w10-a02/`, `w10-a04/`, `ci-management/` and seven original early report basenames')]:
    rows.append(f"| [{label}]({Path(row['archive']).name}) ([manifest]({Path(row['manifest']).name})) | {row['original_members']} | {row['size_bytes']:,} | {principal} |")
checkpoint_readme = checkpoint_readme.replace('\n## Source and interpretation', '\n' + '\n'.join(rows) + '\n\n## Source and interpretation')
checkpoint_readme += '''
## Repaired native follow-up

The added `native-4781ca9` archive is fresh native PASS evidence for the repaired
code, executed through same-tree merge `e929c52d05bad80b28dd4085a97838d7fe2de354`.
All original bytes, including the ZIP and the independent review, are retained.
The initial 12 archives were not rebuilt. `late-reviews-4781ca9` adds the stated
frozen reviews, seven early originals and incomplete CI-management data. The
seven early reports use their original basenames at the archive root.

Current governance and the final delta/ledger/release records remain separate.
The provisional ledger is included in the current root manifest as data, not
as an assertion that all assignments have completed. The follow-up assembly
receipt is [assembly-native-4781ca9.json](assembly-native-4781ca9.json).
'''

for row in records:
    for key in ('archive', 'manifest'):
        dest = TARGET / row[key]
        assert not dest.exists(), 'New append path already exists'
        shutil.copyfile(helper.STAGE / row[key], dest)
(TARGET / 'README.md').write_text(root_readme)
(TARGET / 'checkpoints/README.md').write_text(checkpoint_readme)
save(TARGET / 'checkpoints/index.json', index)
receipt = {'format': 'evidence-assembly-native-followup-v1', 'code_checkpoint': CODE,
    'new_archives': records, 'prior_checkpoint_archives_preserved': 12,
    'new_original_members': sum(r['original_members'] for r in records),
    'new_original_members_verified': True, 'retained_programs_executed': False,
    'credential_scan': credential_scan, 'current_governance': 'pending original completed log/review',
    'ledger': 'provisional, bytes frozen by assignment59 for this manifest refresh',
    'pending_additions': index['pending_additions'], 'producer_sha256': sha(Path(__file__).read_bytes()),
    'acceptance_claimed': False}
save(TARGET / 'checkpoints/assembly-native-4781ca9.json', receipt)
mutable = {'README.md', 'manifest.json', 'checkpoints/README.md', 'checkpoints/index.json'}
for name, digest in prior_files.items():
    if name not in mutable:
        assert sha((TARGET / name).read_bytes()) == digest, 'Existing evidence drift: ' + name
manifest = json.loads((TARGET / 'manifest.json').read_text())
manifest['assembled_utc'] = datetime.now(timezone.utc).isoformat()
manifest['scope'] = 'Historical development, exact repaired-code host/native evidence and original advisory reviews; each receipt retains its own scope.'
manifest['native_execution']['4781ca9'] = 'passed fresh run45009314161; independent retained-data review confirms exact fixed timing SimX scope'
manifest['verification']['new_archives'] = 14
manifest['verification']['new_archive_original_members'] = sum(r['original_members'] for r in index['archives'])
manifest['verification']['native_followup_preserves_prior_archives'] = True
manifest['limitations'][0] = 'Native db5 remains historical; fresh4781 native evidence is separately retained with exact source/configuration scope. Current full governance remains pending.'
manifest['limitations'][-1] = 'The assignment ledger is provisional. Current full governance, final evidence delta review and final release/ledger completion remain separate additions; refresh this manifest afterward.'
manifest['files'] = [{'path': p.relative_to(TARGET).as_posix(), 'size_bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                     for p in sorted(TARGET.rglob('*')) if p.is_file() and p != TARGET / 'manifest.json']
save(TARGET / 'manifest.json', manifest)
links = []
for p in (TARGET / 'README.md', TARGET / 'checkpoints/README.md'):
    for label, link in re.findall(r'\[([^\]]+)\]\(([^)]+)\)', p.read_text()):
        if '://' in link or link.startswith('#'):
            continue
        assert (p.parent / link.split('#', 1)[0]).resolve().exists(), link
        links.append({'document': str(p.relative_to(TARGET)), 'target': link})
for row in manifest['files']:
    assert sha((TARGET / row['path']).read_bytes()) == row['sha256']
verification = {'pass': True, 'new_archives': records, 'previous_archive_digests_unchanged': True,
    'total_files': len(manifest['files']) + 1, 'total_bytes': sum(p.stat().st_size for p in TARGET.rglob('*') if p.is_file()),
    'relative_links_checked': len(links), 'credential_scan': credential_scan,
    'index_sha256': sha((TARGET / 'checkpoints/index.json').read_bytes()),
    'root_manifest_sha256': sha((TARGET / 'manifest.json').read_bytes()),
    'root_readme_sha256': sha((TARGET / 'README.md').read_bytes())}
save(DELTA / 'verification.json', verification)
print(json.dumps({k: verification[k] for k in ('pass', 'total_files', 'total_bytes', 'relative_links_checked', 'index_sha256', 'root_manifest_sha256')}))
