#!/usr/bin/env python3
"""Verify and publish only the assigned evidence directory."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import shutil
import tarfile
import zipfile

BASE = Path('/workspace/scratch/ea983fdea786')
HERE = BASE / 'w09-a05'
STAGE = HERE / 'staged'
TARGET = BASE / 'AI-GPU/docs/project/evidence/p06-simulator-completion'
CODE = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

index = json.loads((STAGE / 'checkpoints/index.json').read_text())
labels = {
 'development-index-db5ebb3': ('Historical root index', '`root-at-db5/README.md`, `root-at-db5/manifest.json`'),
 'host-db5ebb3': ('Initial clean host receipt', '`receipt/report.json`, `receipt/focused-suite.log`'),
 'host-4781ca9': ('Repaired-code clean host receipt', '`receipt/report.json`, `receipt/focused-suite.log`'),
 'parent-db5ebb3': ('Initial compiled-parent replay', '`report/report.json`, `report/logs/`, `report/inputs/`'),
 'parent-4781ca9': ('Repaired-code compiled-parent replay', '`report/report.json`, `report/logs/`, `report/inputs/`'),
 'cp-allocation-repair': ('Recoverable CP allocation repair', '`w08-a04-consumer-error-scope.md`; `w08-a05/REPORT.md`; `w08-a06/README.md`; `w09-a02/REPORT.md`'),
 'native-db5ebb3': ('Original pre-repair native and governance packet', '`w09-a01-native-ci/review.md`; original ZIP, metadata and both original job logs in that directory'),
 'warm-db5ebb3': ('Original existing warm-workspace execution', '`w07-a06-warm-ci-review.md`; original ZIP and `replay.json` beneath `w07-a06-warm-ci/`'),
 'checkpoint-reviews': ('Earlier checkpoint/provenance reviews', 'Original `w06-a01`, `w06-a03`, `w06-a04`, `w06-a06`, `w08-a01`, `w08-a02`, `w08-a03` review files; `w06-a02/` repair records'),
 'next-development-audits': ('Five read-only next-development audits', '`w07-a01-counter-coverage.md` through `w07-a05-dsp-attribution.md`'),
 'documentation-reconciliation': ('Current status and technical handoff reconciliation', '`w09-a03/README.md`, `w09-a03/report.json`, `w09-a04/REPORT.md`, original/applied documents and patches'),
 'host-4781ca9-review': ('Independent repaired host and parent review', '`w09-a06/REPORT.md`, `w09-a06/audit-summary.json`, original audit log and manifest'),
}
lines = ['# Checkpoint archives', '',
 'These archives retain original evidence bytes and their explicit source scope. The root [evidence README](../README.md) is the current result summary; this index is the extraction map. No archive is an acceptance record.', '',
 'Every archive contains an internal `MANIFEST.json`, byte-identical to its adjacent sidecar. That manifest lists every original member and digest, excludes itself to avoid a recursive hash, and records intentional omissions. Archive metadata is normalized; original content is not rewritten. No retained script was executed by assembly.', '',
 '| Archive | Original members | Compressed bytes | Principal original records |',
 '|---|---:|---:|---|']
for row in index['archives']:
    label, members = labels[row['name']]
    lines.append(f"| [{label}]({Path(row['archive']).name}) ([manifest]({Path(row['manifest']).name})) | {row['original_members']} | {row['size_bytes']:,} | {members} |")
lines += ['', '## Source and interpretation', '',
 'The repaired code checkpoint is `4781ca96db15a1d130626edc7a73411a4f6c2e7c`. Its clean host receipt and parent replay are separate from the earlier `db5ebb3a16770004423f2456ec6d0caaa0aced6d` native packet. The CP repair archive retains the later source hashes and an independent review; it does not relabel the earlier native execution.', '',
 'The first native packet includes original ZIP `p06-simulator-completion-run45006726571-artifact14748468420.zip`. Its complete extracted content is inside that ZIP; extract it under `w09-a01-native-ci/packet/` to reconstruct paths in the original manifest. The original warm ZIP is retained similarly. Duplicate extracted trees are omitted without removing any ZIP member.', '',
 'Parent packet archives contain the report, every declared retained candidate/parent input, configuration file and command log. Temporary build copies, tool symlinks and compiled executables are excluded. Each original receipt states its tool and binary identities and limits. The same scope distinction applies to controlled-model host fixtures, actual-framework checks and native processor execution.', '',
 'The documentation archive records the first reconciliation after the clean host receipt; its original text still says repaired native verification is pending. Later documentation changes must receive their own record. The historical development root README and manifest are preserved verbatim in a separate archive.', '',
 'The complete compressed-file digests and source contexts are in [index.json](index.json). The initial assembly/credential-scan receipt is [assembly.json](assembly.json). Later native results, late reviews and the completed assignment ledger are separate additions; these frozen archives must remain unchanged.', '']
(STAGE / 'checkpoints/README.md').write_text('\n'.join(lines))

patterns = {
 'temporary_signed_query': re.compile(rb'https?://[^\s"\'<>]+(?:[?&](?:sig|signature|X-Amz-Signature|X-Amz-Credential|token)=)[^\s"\'<>]+', re.I),
 'github_token': re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b|\bgithub_pat_[A-Za-z0-9_]{30,}\b'),
 'private_key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
 'unmasked_bearer': re.compile(rb'Authorization[\"\s:]+Bearer[\s]+[A-Za-z0-9._~+/-]{25,}', re.I),
}
findings, counts = [], {'tar_members': 0, 'zip_members': 0, 'bytes_scanned': 0}
def scan(name, data, kind):
    counts[kind] += 1
    counts['bytes_scanned'] += len(data)
    for key, pattern in patterns.items():
        matches = list(pattern.finditer(data))
        if matches:
            findings.append({'member': name, 'pattern': key, 'matches': len(matches)})
    if data.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(data)) as zipped:
            for member in zipped.infolist():
                if member.is_dir():
                    continue
                assert member.file_size <= 32 * 1024 * 1024
                scan(name + '!' + member.filename, zipped.read(member), 'zip_members')
for row in index['archives']:
    p = STAGE / row['archive']
    assert sha(p.read_bytes()) == row['sha256']
    assert sha((STAGE / row['manifest']).read_bytes()) == row['manifest_sha256']
    with tarfile.open(p, 'r:gz') as tar:
        for member in tar.getmembers():
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            scan(p.name + '!' + member.name, tar.extractfile(member).read(), 'tar_members')
credential_scan = {'scope': 'Selected original archive members including every nested original native/warm ZIP member',
                   'patterns': list(patterns), 'counts': counts, 'findings': findings, 'pass': not findings}
save(HERE / 'credential-scan.json', credential_scan)
assert not findings, 'Sensitive material scan requires review before publication'

original = json.loads((HERE / 'original-packet-identities.json').read_text())
for name, row in original.items():
    assert sha((TARGET / name).read_bytes()) == row['sha256'], 'Historical input changed before copy: ' + name
assembly = {'format': 'evidence-assembly-receipt-v1', 'code_checkpoint': CODE,
    'archives': len(index['archives']), 'original_members': sum(r['original_members'] for r in index['archives']),
    'archive_bytes': sum(r['size_bytes'] for r in index['archives']),
    'original_members_checked_against_source_bytes': True, 'retained_programs_executed': False,
    'archive_headers_normalized': True, 'original_hosted_zip_bytes_unchanged': True,
    'original_packet_files': len(original), 'historical_files_preserved_except_root_indexes': True,
    'original_root_indexes_retained_in': 'development-index-db5ebb3.tar.gz',
    'credential_scan': credential_scan,
    'assembler_sha256': sha((HERE / 'assemble.py').read_bytes()),
    'finisher_sha256': sha(Path(__file__).read_bytes()),
    'pending': ['Fresh repaired-code native packet and its independent review', 'Current full governance receipt', 'Late final reviews and completed assignment ledger'],
    'acceptance_claimed': False}
save(STAGE / 'checkpoints/assembly.json', assembly)
for path in sorted(STAGE.rglob('*')):
    if not path.is_file():
        continue
    rel = path.relative_to(STAGE)
    dest = TARGET / rel
    if dest.exists() and str(rel) not in ('README.md', 'manifest.json'):
        assert dest.read_bytes() == path.read_bytes(), 'Refusing to rewrite frozen evidence: ' + str(rel)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, dest)
for name, row in original.items():
    if name not in ('README.md', 'manifest.json'):
        assert sha((TARGET / name).read_bytes()) == row['sha256'], 'Historical byte changed after copy: ' + name
files = [{'path': p.relative_to(TARGET).as_posix(), 'size_bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
         for p in sorted(TARGET.rglob('*')) if p.is_file() and p != TARGET / 'manifest.json']
manifest = {'format': 'simulator-completion-packet-manifest-v2', 'assembled_utc': datetime.now(timezone.utc).isoformat(),
    'base_revision': '42809ff0c1b81384d7c9b079e4ef786be8407600', 'repaired_code_revision': CODE,
    'repaired_code_tree': '6dd0d759390cda78ec63ad0caacc00a08f03e2bc', 'files': files,
    'manifest_self_excluded': True, 'scope': 'Historical development, source-bound host checkpoint evidence and original pre-repair native evidence; each receipt retains its own scope.',
    'native_execution': {'db5ebb3': 'passed original fixed timing SimX controls', '4781ca9': 'pending fresh run45009314161'},
    'acceptance_claimed': False,
    'verification': {'all_archive_original_members_verified': True, 'new_archive_original_members': assembly['original_members'],
                     'new_archives': assembly['archives'], 'original_historical_files_unchanged': len(original) - 2,
                     'original_root_metadata_preserved': True, 'credential_scan_pass': True,
                     'new_tests_or_native_builds_run_by_assembly': False},
    'limitations': ['The original native db5 packet predates the CP allocation-error repair; fresh4781 native verification remains separate.',
                    'No native public fault, native functional/RTL execution, concurrency, cancellation, performance, phase or physical-device acceptance.',
                    'Original manifests preserve temporary paths and declared limitations; excluded binaries and duplicate extracted trees are documented.',
                    'Historical source-at-assembly and early missing-runner-source limits remain unchanged in the retained historical root index.',
                    'The completed assignment ledger and later native/review records are pending additions; refresh this manifest after additions.']}
save(TARGET / 'manifest.json', manifest)
problems, links = [], []
for path in (TARGET / 'README.md', TARGET / 'checkpoints/README.md'):
    for label, target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)', path.read_text()):
        if '://' in target or target.startswith('#'):
            continue
        actual = (path.parent / target.split('#', 1)[0]).resolve()
        links.append({'document': str(path.relative_to(TARGET)), 'target': target, 'exists': actual.exists()})
        if not actual.exists():
            problems.append(str(actual))
assert not problems, problems
for row in manifest['files']:
    p = TARGET / row['path']
    assert p.stat().st_size == row['size_bytes'] and sha(p.read_bytes()) == row['sha256']
verification = {'pass': True, 'manifest_files': len(files), 'total_files': len(files) + 1,
    'total_bytes': sum(p.stat().st_size for p in TARGET.rglob('*') if p.is_file()),
    'new_relative_links_checked': len(links), 'links': links, 'credential_scan': credential_scan,
    'frozen_archive_sha256': {r['archive']: r['sha256'] for r in index['archives']},
    'root_manifest_sha256': sha((TARGET / 'manifest.json').read_bytes()),
    'checkpoint_index_sha256': sha((TARGET / 'checkpoints/index.json').read_bytes()),
    'root_readme_sha256': sha((TARGET / 'README.md').read_bytes())}
save(HERE / 'verification.json', verification)
print(json.dumps({k: verification[k] for k in ('pass', 'total_files', 'total_bytes', 'new_relative_links_checked', 'root_manifest_sha256', 'checkpoint_index_sha256')}))
