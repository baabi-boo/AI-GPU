# Repaired native evidence — append-only assembly follow-up

The coordinator reactivated assignment #53 to append the frozen repaired-code native packet and a separate late-review archive. Only the assigned simulator-completion evidence directory was changed. All prior 12 checkpoint archives, their sidecars and other immutable evidence files remain byte-identical. No source, test, acceptance, threshold or unrelated documentation was edited. No retained evidence program was executed.

## Added immutable archives

| Archive | Original members | Bytes | SHA-256 |
|---|---:|---:|---|
| `checkpoints/native-4781ca9.tar.gz` | 17 | 2,938,126 | `1de2f3f852a5b68c6f3acb5c3ae29c9de725f78cf8d844b549392806f5d1c116` |
| `checkpoints/late-reviews-4781ca9.tar.gz` | 65 | 678,093 | `173ef1343cdd4ffe7b4eb62d5df82b4e3f2b1296d6c51ca776450fc990bf37be` |

The sidecar member-manifest digests are respectively `43826c57200aae9f0628112039323e1dbd70b135a0268be69b450a5ee46adc92` and `c433d62b4151944ad02f26641857f348e7a5166f998ada054bd2e98d1271bf1b`. Every archive contains its identical sidecar as internal `MANIFEST.json`, which excludes itself from its own member list. Every original member was reopened and matched to the original source bytes and digest. Only tar/gzip header metadata was normalized.

The repaired native archive retains the exact original ZIP for run `45009314161`, job `137167865239`, artifact `14749901531`, plus original job/API metadata, audit records, manifest and review. The original ZIP is still **2,792,870 bytes**, SHA-256 `461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9`. Its complete extracted tree remains inside the original ZIP rather than being duplicated. Extracting it into `w10-a03-native-ci/packet/` reconstructs the original review-manifest paths.

The late-review archive retains original #55 production review, #56 initial 72-file evidence review and #58 protected-input/phase review, with their supporting files. It also retains the seven original early audit/harness reports at their original basenames, allowing the assignment ledger to point to actual durable originals. Original source-time native-pending statements in these reports are historical observations and were not rewritten.

The CI-management directory is retained as an explicitly incomplete record: two requests to cancel this task's own superseded `db5ebb3` broad CI runs were accepted; the original API snapshots still report queued overall runs and no conclusion. No broad CI pass is inferred. The cancellation screenshot was inspected visually and contains repository/run state and the accepted-request banner without credential values.

## Updated current claims

The root README, checkpoint index and root manifest now report fresh native PASS at code checkpoint `4781ca96db15a1d130626edc7a73411a4f6c2e7c`, executed through same-tree merge `e929c52d05bad80b28dd4085a97838d7fe2de354`, tree `6dd0d759390cda78ec63ad0caacc00a08f03e2bc`.

The scope is fixed RV64 `p02-tfr`, timing SimX, PERF enabled, one worker and direct-RAM CP. The actual native unit covers checked/legacy x3 semantics, the bounded-RAM exception and fresh-context success. The public native cell covers six successful launches. It provides no native public-runtime injected-fault, native RTL/functional SimX, performance, phase or physical-device acceptance. The independent native review's digest is `88659fdb99a319a61d413338c2bfa01ec0f5b7ef996191b84bde75b220f61b4e`.

Current full governance remains pending. The provisional assignment ledger is included as data with its recorded completion state; it is not described as fully complete. Final governance, evidence delta, completed ledger and release review remain separate additions.

## Verification and final snapshot

The package now has **79 files / 16,749,501 bytes**. All **55** relative file links in the current evidence README and checkpoint index resolve. Every file except the root manifest matches that refreshed manifest. `git diff --check` passes for the evidence directory.

The targeted credential scan inspected **84 tar members and 812 nested ZIP members**, totaling **17,903,889 decoded bytes**. There were no matches for temporary signed-query URLs, GitHub tokens, private-key headers or unmasked bearer tokens. This is a targeted disclosure check, not a universal security certification.

| Snapshot identity | SHA-256 |
|---|---|
| Root manifest | `ca1cd5e76a915a91a0eceec61c5b8bb4a4fe242d22ce79ea1b83682747cf4c9e` |
| Checkpoint index | `93c4ef7b70416f8fc4184fda9c72eb11b404d871f779b11a0155ae56688cfa24` |

The coordinator and independent reviewer #56 were notified that the new snapshot is stable. Agent #59 received the actual archive/member paths for the seven early originals, and was told to coordinate subsequent ledger edits with the coordinator and reviewer. No further repository changes are planned before another explicit follow-up. No commit or push was performed.
