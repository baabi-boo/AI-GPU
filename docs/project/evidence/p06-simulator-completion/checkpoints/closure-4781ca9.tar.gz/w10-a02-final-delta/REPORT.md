# Agent 56: closing evidence and claims delta, interim checkpoint

## Verdict and remaining gate

**PASS for the two frozen native/late-review additions, the current scoped documentation, and the 60-initial-assignment ledger. Final packet/release approval remains pending.** The current root manifest still describes the earlier ledger bytes. Its only mismatches are `delivery-ledger.json` and `delivery-ledger.md`, exactly the pending refresh disclosed by the coordinator and assembler. Current repaired full governance, the closing archive, the final manifest, and publication are not certified by this checkpoint.

This is a follow-up under existing agent **#56**, `/root/w10_a02_evidence_claims_review`, not a new assignment. The initial `/workspace/scratch/ea983fdea786/w10-a02` audit remains unchanged. This separate packet records the closing delta under `/workspace/scratch/ea983fdea786/w10-a02-final-delta`.

## Immutable archive and source verification

`audit_delta.py` independently reads archive bytes and JSON, computes digests, checks safe member paths and regular-file types, and compares retained originals to their scratch sources. It does not import or execute a retained script. The audit observed a stable packet throughout its run.

| Addition | Original members | Archive bytes | SHA-256 |
|---|---:|---:|---|
| `native-4781ca9.tar.gz` | 17 | 2,938,126 | `1de2f3f852a5b68c6f3acb5c3ae29c9de725f78cf8d844b549392806f5d1c116` |
| `late-reviews-4781ca9.tar.gz` | 65 | 678,093 | `173ef1343cdd4ffe7b4eb62d5df82b4e3f2b1296d6c51ca776450fc990bf37be` |

All **82 original members** match both sidecar identities and original scratch bytes. Each internal `MANIFEST.json` is byte-identical to its sidecar. Both archives contain exactly the declared originals plus that internal manifest. The original **12 checkpoint archives and their 12 sidecars** remain byte-identical to the initial independent snapshot. All **43 original non-root-index packet files** still match Git checkpoint `4781ca9`; the unchanged historical archive preserves the original root README and manifest. Thus the original failure/probe records are preserved through the earlier verified immutable archives, rather than rewritten after subsequent successes.

The prior auditor packet is itself present in the late-review archive, with original report/script identities verified. The newer additions contain distinct source scopes and keep historical pending observations historical. Compiled binaries and duplicate extracted ZIP trees are not misrepresented as archived originals.

## Repaired native evidence

The original artifact ZIP is **2,792,870 bytes**, SHA-256 `461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9`. I independently read its **812 unique members**, totaling **10,794,058 decoded bytes**, with no absolute/traversal paths or symlinks. Its service artifact record identifies artifact **14749901531**, run **45009314161**, and repaired source **4781ca96db15a1d130626edc7a73411a4f6c2e7c**. The retained job record identifies job **137167865239**, completed successfully at **2026-11-22T10:06:06Z**.

The executed PR merge is `e929c52d05bad80b28dd4085a97838d7fe2de354`; both its retained service metadata and native source record identify tree `6dd0d759390cda78ec63ad0caacc00a08f03e2bc`, independently matched to the repaired Git checkpoint. The native checkout reports no changed or untracked source paths. Before/after source, tool, generated, binary/artifact and dependency records are equal.

All **786 retained source/configuration/compiler/probe records** match their member digests and sizes. Each of the **761 retained source bodies** independently matches its actual Git blob at `4781ca9` and the current working file. All **18 command logs** match recorded digests/sizes and have successful exits with cleanup complete. The five compiler/header role records and explicit RV64/TFR/direct-RAM settings agree with the reviewed route. The separate native reviewer records 87 model-object compile commands; this audit preserves that original detailed review and checks its scope and identity, without claiming to rerun its compiler-provenance parser.

The actual native report and logs support exactly these observations:

- Real Processor/RAM unit: **five contexts**, **nine checked successes**, **three legacy successes**, **one checked `OutOfRange` exception**, and **one legacy caught exception**. The log includes a successful fresh context after the checked fault and valid `gp=-1` control.
- Public-runtime success cell: **two contexts**, **six launches**, six nonzero `gp` observations and the six exact output witnesses.
- Scope: RV64 `p02-tfr`, timing SimX, `PERF=1`, one simulation worker, CP direct RAM. Native public-runtime injected failure and native processor RTL were not tested by this packet.

Both `qualified` and `acceptance_claimed` remain false. This native PASS belongs to repaired `4781ca9`; the older db5 native PASS and 2,988-test governance receipt remain separate historical evidence.

## Documentation and ledger findings

The four current native-PASS documents—README, status, backlog and completion audit—match the author's frozen `w09-a03-final/after` copies and recorded SHA-256 values exactly. The qualification plan and workspace handoff are unchanged from the initial #56 review. Across those documents, both evidence indexes, the delivery ledger and the completion contract, **715 relative Markdown targets** resolve.

The current prose accurately distinguishes the initial db5 host/native/governance results from repaired host **83**, audited-parent **eight** intended failure controls, CP boundary **38 positive plus four negative** executable cells, and the repaired native PASS. The five CP unittest methods remain part of the 83 host methods, avoiding additive test-count inflation. No document grants current governance success while it is still pending at this snapshot.

The prospective next step is still explicit: freeze and review the exact **33 available / 12 unavailable** counter inventory, coherent two-half reads, and enforceable cumulative context-lifetime/no-wrap assumptions before implementing the guard and a versioned evidence route. The prior **5/33 SimX** and **19/33 RTL leaf** coverage limits remain. The missing RTL MEM mapping for class 7 / CSR `0xB06` prevents an all-33 RTL-parity claim. No guard or no-wrap proof is called implemented. Warm v1 remains blocked, `qualified=false`, with an unestablished absolute no-wrap bound. These unchanged plan bytes and the immutable prior source audit preserve the initial inventory verification; this delta does not claim to re-execute it.

The ledger contains exactly **60 unique initial agent identities and ordinals**, **10 waves**, and **six assignments per wave**. Every initial assignment is completed in both the ledger and the coordinator's actual assignment registry. The registry SHA-256 is `57c1521733d8a7e392a605cc844f59a2afdcca3f4ecc5f78a850b6fad08a3ba8`. Follow-ups explicitly do not count as additional agents. I checked **139 structured evidence targets**, including each referenced archive member and repository file.

The ledger's attribution caveat is appropriate: the coordinator registry establishes recorded assignment identities/statuses; content links do not independently prove authorship. Current governance still has `tests_passed: null`; whole-CI-green is false; final evidence commit is null; master publication is not yet verified. Two superseded general CI runs are recorded as cancelled, not passed. The six-per-wave initial completion claim does not imply completed final publication follow-ups.

## Current source and preserved obligations

`source_projection.py` independently computes Git blob identities for all **3,339 existing blobs** outside the README / `docs/project/` delivery allowlist and compares them with `4781ca9`. All match. Current tracked and untracked changes are within that documentation/evidence allowlist. The five root gitlink identities are retained in its result. The completion contract and all 761 native-retained inputs are included among the unchanged protected bytes.

Protected phase/acceptance metadata, hardware sources, profiles, cold baseline evidence, public runtime/kernel/common headers, original lifecycle test and common CP files have no changes against the original audited master in the checked paths. The script verifies that every selected path actually exists. The `AGENTS.md` change predates the repaired checkpoint and is exactly a five-line completion-contract reference addition, with no removed instruction; its current bytes match the tested checkpoint. No accepted gate, threshold, golden, public ABI, arithmetic or RTL change is introduced by this closing documentation delta. The P01 vendor blocker, P05/P06 open acceptance obligations and inherited DSP 267 → 283 versus the unchanged 5% threshold remain.

## Pending final delta

The root manifest at this checkpoint is `ca1cd5e76a915a91a0eceec61c5b8bb4a4fe242d22ce79ea1b83682747cf4c9e`; checkpoint index is `93c4ef7b70416f8fc4184fda9c72eb11b404d871f779b11a0155ae56688cfa24`. All manifest-listed files exist, with no unlisted packet files. Only these two expected ledger identities differ:

| File | Current SHA-256 | Current bytes |
|---|---|---:|
| `delivery-ledger.json` | `b2abad0663e297fc16ec123fd36c1fca73fb0618fe385ac137871fdf7db3a45b` | 70,274 |
| `delivery-ledger.md` | `735e4233a1eecc833a9f1075ab801032b4d1963be6ac55c292e0754660b1c334` | 40,781 |

Final claims/manifest approval requires the actual repaired full-governance receipt and independent review, the assembled closing archive, an explicit stable-ready signal, and a small final check of the resulting manifest/ledger/document deltas. Final immutable commit and remote master publication are separate observations owned by the coordinator and release reviewer. This checkpoint grants neither publication completion nor whole-CI success.

## Method and retained auditor attempts

No repository edits, project scripts, retained programs, tests, native builds, commits or pushes were performed. The audit consists of standard-library data/archive/hash checks, read-only Git commands and prose comparison. `audit_delta.py` passed on its first execution. An extra projection check initially over-constrained `AGENTS.md` to be unchanged from the original master; the retained failure and original script identify the already-documented five-line contract reference addition. The corrected projection explicitly checks that exact additive delta and current equality to the tested checkpoint. Its final revision also replaces guessed nonexistent profile/header/CP selectors with actual repository paths and requires every selector to exist, preventing an empty Git path match from passing unnoticed. All three projection script/log revisions are retained. These auditor adjustments were not production or packaging failures.

Machine-readable details are in `audit-summary.json`, `packet-files.json`, `docs.json`, `native-source-membership.json`, `ledger-evidence-targets.json`, `relative-links.json` and `source-projection.json`. This interim checkpoint is frozen before final assembly; any later closure review will be a separate follow-up record.
