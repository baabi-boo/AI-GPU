#!/usr/bin/env python3
"""Read-only Git/working-tree byte projection, independent of retained scripts."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
OUT = ROOT.parent / 'w10-a02-final-delta'
CODE = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
BASE = '42809ff0c1b81384d7c9b079e4ef786be8407600'
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


records = []
gitlinks = []
for row in git('ls-tree', '-rz', CODE).split(b'\0'):
    if not row:
        continue
    header, path_raw = row.split(b'\t', 1)
    mode, kind, expected = header.decode().split()
    path = path_raw.decode()
    if kind == 'commit':
        gitlinks.append({'path': path, 'revision': expected})
        continue
    if path == 'README.md' or path.startswith('docs/project/'):
        continue
    p = ROOT / path
    content = os.readlink(p).encode() if mode == '120000' else p.read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    assert actual == expected, path
    records.append({'path': path, 'git_blob': actual})
assert len(records) == 3339 and len(gitlinks) == 5
changes = git('diff', '--name-only', CODE).decode().splitlines()
untracked = git('ls-files', '--others', '--exclude-standard').decode().splitlines()
assert all(p == 'README.md' or p.startswith('docs/project/') for p in changes + untracked)
protected_paths = ['docs/project/roadmap.json', 'docs/project/acceptance.md',
                   'docs/project/phases', 'ci/project/profiles', 'ci/project/goldens',
                   'hw', 'sw/include', 'tests/runtime/test_ai_lifecycle.cpp',
                   'sw/runtime/common/command_processor.cpp']
changed_protected = git('diff', '--name-only', BASE, '--', *protected_paths).decode().splitlines()
assert not changed_protected, changed_protected
instructions_diff = git('diff', BASE, CODE, '--', 'AGENTS.md').decode()
assert '+For simulator completion and exceptional full-platform teardown, follow the' in instructions_diff
assert not any(line.startswith('-') and not line.startswith('---')
               for line in instructions_diff.splitlines())
assert sum(line.startswith('+') and not line.startswith('+++')
           for line in instructions_diff.splitlines()) == 5
assert (ROOT / 'AGENTS.md').read_bytes() == git('show', CODE + ':AGENTS.md')
result = {'outcome': 'pass', 'checkpoint': CODE, 'current_protected_existing_blobs': len(records),
          'root_gitlinks': gitlinks, 'tracked_changes': changes,
          'untracked_paths': untracked, 'allowed_current_delta': ['README.md', 'docs/project/'],
          'protected_paths_unchanged_from_audited_parent': protected_paths,
          'changed_protected_paths': changed_protected,
          'agents_md_delta': 'Five-line completion-contract reference addition only; matches tested checkpoint',
          'executed_project_programs': False}
(OUT / 'source-projection.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: result[k] for k in ['outcome', 'current_protected_existing_blobs',
      'changed_protected_paths']}, indent=2))
