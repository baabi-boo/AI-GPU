#!/usr/bin/env python3
"""Independent immutable-additions/claims audit; retained programs are never run."""
from pathlib import Path, PurePosixPath
import collections
import datetime
import hashlib
import io
import json
import os
import re
import stat
import subprocess
import tarfile
import zipfile

WORK = Path('/workspace/scratch/ea983fdea786')
ROOT = WORK / 'AI-GPU'
OUT = WORK / 'w10-a02-final-delta'
PACKET = ROOT / 'docs/project/evidence/p06-simulator-completion'
PREFIX = PACKET.relative_to(ROOT).as_posix() + '/'
CODE = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
TREE = '6dd0d759390cda78ec63ad0caacc00a08f03e2bc'
MERGE = 'e929c52d05bad80b28dd4085a97838d7fe2de354'
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')
DOCS = ['README.md', 'docs/project/status.md', 'docs/project/backlog.md',
        'docs/project/p06-simulator-completion-audit.md',
        'docs/project/p06-mpm-qualification-plan.md',
        'docs/project/p06-workspace-handoff.md']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ident(data):
    return {'sha256': sha(data), 'size_bytes': len(data)}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


def safe(name):
    p = PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name, name


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
packet = {p.relative_to(PACKET).as_posix(): p.read_bytes()
          for p in PACKET.rglob('*') if p.is_file()}
snapshot = {name: ident(body) for name, body in packet.items()}
index = json.loads(packet['checkpoints/index.json'])
manifest = json.loads(packet['manifest.json'])
baseline = json.loads((WORK / 'w10-a02/packet-files.json').read_text())
initial_summary = json.loads((WORK / 'w10-a02/audit-summary.json').read_text())
mutable_indices = {'README.md', 'manifest.json', 'checkpoints/README.md',
                   'checkpoints/index.json', 'checkpoints/assembly.json'}
immutable_prior = {name: body for name, body in baseline.items() if name not in mutable_indices}
assert len(immutable_prior) == 67
for name, identity in immutable_prior.items():
    assert snapshot[name] == identity, ('immutable prior changed', name)
assert sha((WORK / 'w10-a02/REPORT.md').read_bytes()) == '7139b6348e6cc38f4060e287e228973e0cd47fe7b542346af463f9aed64a95d9'
assert sha((WORK / 'w10-a02/audit.py').read_bytes()) == 'df30d81484ded43bad78581c403c97b9ebd98c6c7a27dac3bab953c98993de8b'

# Compare all original packet paths to the tested Git checkpoint. The two old
# root index versions remain protected by the unchanged historical archive.
old_paths = git('ls-tree', '-r', '--name-only', CODE, '--', PREFIX).decode().splitlines()
assert len(old_paths) == 45
for name in old_paths:
    rel = name.removeprefix(PREFIX)
    if rel not in ('README.md', 'manifest.json'):
        assert packet[rel] == git('show', CODE + ':' + name), rel

records = {r['name']: r for r in index['archives']}
assert len(records) == len(index['archives']) == 14
expected_new = {
    'native-4781ca9': ('1de2f3f852a5b68c6f3acb5c3ae29c9de725f78cf8d844b549392806f5d1c116', 17),
    'late-reviews-4781ca9': ('173ef1343cdd4ffe7b4eb62d5df82b4e3f2b1296d6c51ca776450fc990bf37be', 65),
}
archives = {}
archive_results = []
for label, (expected_sha, expected_count) in expected_new.items():
    r = records[label]
    raw = packet[r['archive']]
    sidecar_raw = packet[r['manifest']]
    sidecar = json.loads(sidecar_raw)
    assert sha(raw) == r['sha256'] == expected_sha
    assert len(raw) == r['size_bytes']
    assert sha(sidecar_raw) == r['manifest_sha256']
    assert len(sidecar['files']) == r['original_members'] == expected_count
    assert sidecar['retained_programs_executed_by_assembly'] is False
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as tf:
        members = tf.getmembers()
        assert len(members) == len({m.name for m in members}) == expected_count + 1
        for m in members:
            safe(m.name)
            assert m.isfile(), m.name
        decoded = {m.name: tf.extractfile(m).read() for m in members}
    assert decoded['MANIFEST.json'] == sidecar_raw
    assert set(decoded) == {'MANIFEST.json'} | {r['path'] for r in sidecar['files']}
    for f in sidecar['files']:
        body = decoded[f['path']]
        assert ident(body) == {k: f[k] for k in ('sha256', 'size_bytes')}, f['path']
        assert body == Path(f['original_path']).read_bytes(), f['original_path']
    archives[label] = decoded
    archive_results.append({'name': label, 'original_members': expected_count,
                            **ident(raw), 'all_original_scratch_bytes_identical': True})

native_archive = archives['native-4781ca9']
zip_name = next(n for n in native_archive if n.endswith('.zip'))
zip_raw = native_archive[zip_name]
assert ident(zip_raw) == {'size_bytes': 2792870,
                         'sha256': '461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9'}
with zipfile.ZipFile(io.BytesIO(zip_raw)) as z:
    info = z.infolist()
    assert len(info) == len({i.filename for i in info}) == 812
    assert sum(i.file_size for i in info) == 10794058
    for i in info:
        safe(i.filename)
        assert not stat.S_ISLNK(i.external_attr >> 16), i.filename
        assert not i.is_dir()
    original_zip = {i.filename: z.read(i) for i in info}


def native_json(suffix):
    matches = [b for name, b in native_archive.items() if name.endswith(suffix)]
    assert len(matches) == 1, suffix
    return json.loads(matches[0])


native = json.loads(original_zip['simulator-completion/report.json'])
assert native['outcome'] == 'pass' and native['state'] == 'finished' and native['full_matrix_completed']
assert native['qualified'] is False and native['acceptance_claimed'] is False
assert native['source_scope'] == 'rv64-p02-tfr-timing-simx-perf-on'
for prefix in ['artifacts_', 'dependencies_', 'generated_', 'source_', 'tools_']:
    assert native[prefix + 'before'] == native[prefix + 'after'], prefix
checkout = native['source_before']['checkout']
assert checkout['revision'] == MERGE and checkout['tree'] == TREE
assert checkout['dirty'] is False and checkout['outcome'] == 'pass'
assert checkout['changed_paths'] == checkout['untracked_paths'] == checkout['blockers'] == []
assert git('rev-parse', CODE + '^{tree}').decode().strip() == TREE
meta = native_json('/github-merge-commit.json')
assert meta['sha'] == MERGE and meta['commit']['tree']['sha'] == TREE
assert CODE in {p['sha'] for p in meta['parents']}
jobs = native_json('/github-native-jobs.json')['jobs']
assert len(jobs) == 1
job = jobs[0]
assert job['id'] == 137167865239 and job['run_id'] == 45009314161
assert job['head_sha'] == CODE and job['status'] == 'completed' and job['conclusion'] == 'success'
artifacts = native_json('/github-artifacts.json')['artifacts']
assert len(artifacts) == 1
artifact = artifacts[0]
assert artifact['id'] == 14749901531 and artifact['size_in_bytes'] == len(zip_raw)
assert artifact['digest'] == 'sha256:' + sha(zip_raw)
assert artifact['workflow_run']['head_sha'] == CODE
assert artifact['workflow_run']['id'] == job['run_id']

git_tree = {}
for row in git('ls-tree', '-rz', CODE).split(b'\0'):
    if row:
        head, path = row.split(b'\t', 1)
        mode, typ, digest = head.decode().split()
        git_tree[path.decode()] = {'mode': mode, 'type': typ, 'sha1': digest}
retained = [r for k in ['retained_source', 'retained_configuration',
                       'retained_compiler_records', 'retained_header_probe'] for r in native[k]]
assert len(retained) == 786 and len(native['retained_source']) == 761
for r in retained:
    body = original_zip['simulator-completion/' + r['path']]
    assert ident(body) == {k: r[k] for k in ('sha256', 'size_bytes')}, r['path']
source_members = []
for r in native['retained_source']:
    path = r['path'].removeprefix('artifacts/source/')
    body = original_zip['simulator-completion/' + r['path']]
    blob = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    assert git_tree[path]['type'] == 'blob' and blob == git_tree[path]['sha1'], path
    assert (ROOT / path).read_bytes() == body, ('current native input changed', path)
    source_members.append({'path': path, 'git_blob': blob, **ident(body)})
unit, public = native['cells']
assert unit['outcome'] == public['outcome'] == 'pass'
assert unit['observations'] == dict(checked_exceptions=1, checked_success=9,
                                  contexts=5, legacy_errors=1, legacy_success=3)
assert public['observations']['contexts'] == 2 and public['observations']['launches'] == 6
assert public['observations']['gp_nonzero'] == 6 and len(public['observations']['witnesses']) == 6
assert len(native['commands']) == 18
for c in native['commands']:
    body = original_zip['simulator-completion/' + c['log']]
    assert sha(body) == c['log_sha256'] and len(body) == c['log_size_bytes'], c['id']
    assert c['outcome'] == 'pass' and c['exit_code'] == 0 and c['cleanup_complete']
    if c['id'] == 'unit-run':
        text = body.decode()
        assert 'native_x3 gp=-1 checked_launches=3 legacy_launches=1' in text
        assert 'native_exception type=OutOfRange consumed=1' in text
        assert text.rfind('native_x3 gp=7') > text.find('native_exception type=OutOfRange')
    elif c['id'] == 'public-run':
        assert 'PASSED simx_completion native_success contexts=2 launches=6 gp_nonzero=6' in body.decode()
assert len(native['effective_headers']) == 5
for body in native['effective_headers'].values():
    assert body['VX_CFG_XLEN'] == '64' and body['VX_CFG_TCU_TYPE'] == 'TFR'
assert native['effective_headers']['runtime']['VX_CFG_CP_ON_LLC'] == '0'
independent_native = native_json('/audit-summary.json')
assert independent_native['native_public_injected_failure_tested'] is False
assert independent_native['native_rtlsim_tested'] is False
assert independent_native['archived_code_executed'] is False
assert independent_native['retained_source_count'] == len(source_members)
assert independent_native['model_object_compile_commands_cross_checked'] == 87

# Evidence links establish content and identity, not independent authorship.
ledger = json.loads(packet['delivery-ledger.json'])
registry_raw = (WORK / 'agent-ledger-source.json').read_bytes()
assert sha(registry_raw) == ledger['registry']['sha256']
registry = json.loads(registry_raw)
assignments = ledger['assignments']
assert len(assignments) == len(registry['assignments']) == 60
assert {a['ordinal'] for a in assignments} == set(range(1, 61))
assert len({a['identity'] for a in assignments}) == 60
assert collections.Counter(a['wave'] for a in assignments) == {w: 6 for w in range(1, 11)}
assert all(a['assignment_status'] == 'completed' for a in assignments)
registry_by_ordinal = {a['ordinal']: a for a in registry['assignments']}
for a in assignments:
    r = registry_by_ordinal[a['ordinal']]
    assert a['identity'] == '/root/' + r['name'] and a['wave'] == r['wave']
    assert r['status'] == 'completed'
assert ledger['observed']['unique_agents'] == 60
assert ledger['observed']['follow_up_tasks_count_as_additional_agents'] is False
assert ledger['observed']['all_requested_assignments_complete'] is True
assert ledger['source_checkpoints']['final_evidence_commit'] is None
assert ledger['source_checkpoints']['master_publication'] == 'not_yet_verified'
verification = ledger['verification_at_this_snapshot']
assert verification['whole_ci_green_claim'] is False
assert verification['historical_db5_governance']['tests'] == 2988
assert verification['repaired_governance']['status'] == 'in_progress'
assert verification['repaired_governance']['tests_passed'] is None
assert verification['repaired_native']['original_artifact_review'] == 'pass'
assert verification['repaired_native']['original_zip_sha256'] == sha(zip_raw)
assert verification['repaired_native']['review_report_sha256'] == sha(native_archive['w10-a03-native-ci/review.md'])
assert all(r['conclusion'] == 'cancelled' for r in verification['superseded_general_ci'])
assert verification['repaired_host']['tests'] == 83
assert verification['original_parent_sensitivity']['intended_old_backend_failures'] == 8
assert verification['cp_boundary']['positive_cells'] == 38
assert verification['cp_boundary']['compiled_db5_negative_controls'] == 4
archive_names = {}
evidence_results = []


def check_evidence(value, location):
    if isinstance(value, dict):
        if value.get('kind') in {'repository_file', 'archive', 'archive_member'} and 'path' in value:
            safe(value['path'])
            path = ROOT / value['path']
            assert path.is_file(), (location, value)
            if value['kind'] in {'archive', 'archive_member'}:
                if value['path'] not in archive_names:
                    with tarfile.open(path, mode='r:gz') as tf:
                        archive_names[value['path']] = set(tf.getnames())
                if value['kind'] == 'archive_member':
                    safe(value['member'])
                    assert value['member'] in archive_names[value['path']], (location, value)
            evidence_results.append({'location': location, **value})
        for k, v in value.items():
            check_evidence(v, location + '/' + k)
    elif isinstance(value, list):
        for n, v in enumerate(value):
            check_evidence(v, location + '/' + str(n))


check_evidence(ledger, 'ledger')
docs = {name: (ROOT / name).read_bytes() for name in DOCS}
doc_after = json.loads((WORK / 'w09-a03-final/source-after.json').read_text())
for name in DOCS[:4]:
    assert sha(docs[name]) == doc_after[name]
    assert docs[name] == (WORK / 'w09-a03-final/after' / name).read_bytes()
    text = docs[name].decode().replace('\n', ' ')
    assert '4781ca9' in text and '45009314161' in text
    assert 'pending' in text and 'governance' in text
    assert '2,988' in text and 'db5ebb3' in text
    assert '33' in text and ('No such guard' in text or 'No no-wrap guard' in text or 'No counter guard' in text)
assert sha(docs[DOCS[4]]) == 'd889dc79e7e6c7597852a4ffc033047ee06eb17a47b33e06d5baac2987369ef6'
assert sha(docs[DOCS[5]]) == 'f4927df2b3822845931b430350ec74f12b2ea55baad785cd494c82ee958da78f'
links = []
link_docs = {**docs, **{PREFIX + name: packet[name] for name in
                        ['README.md', 'checkpoints/README.md', 'delivery-ledger.md']},
             'docs/designs/simulator_completion_v1.md':
             (ROOT / 'docs/designs/simulator_completion_v1.md').read_bytes()}
for name, contents in link_docs.items():
    for target in re.findall(r'\]\(([^)]+)\)', contents.decode()):
        target = target.split('#', 1)[0].split(' "', 1)[0]
        if not target or re.match(r'\w+://', target) or target.startswith(('mailto:', 'data:')):
            continue
        assert ((ROOT / name).parent / target).exists(), (name, target)
        links.append({'source': name, 'target': target})

# The coordinator explicitly identified a provisional root manifest. Record
# actual mismatches; never infer final packet approval from frozen additions.
listed = {r['path']: {k: r[k] for k in ('sha256', 'size_bytes')} for r in manifest['files']}
manifest_mismatches = [{'path': p, 'recorded': v, 'actual': snapshot.get(p)}
                       for p, v in listed.items() if snapshot.get(p) != v]
unlisted = sorted(set(snapshot) - set(listed) - {'manifest.json'})
missing = sorted(set(listed) - set(snapshot))
assert set(r['path'] for r in manifest_mismatches) <= {'delivery-ledger.json', 'delivery-ledger.md'}
assert not missing and not unlisted
after = {p.relative_to(PACKET).as_posix(): ident(p.read_bytes())
         for p in PACKET.rglob('*') if p.is_file()}
assert after == snapshot, 'Packet changed during checkpoint audit; rerun against stable snapshot'
assert all((ROOT / name).read_bytes() == data for name, data in docs.items())
summary = {
    'outcome': 'pass_for_immutable_additions_and_current_scoped_claims',
    'stage': 'interim_closing_delta_before_governance_and_final_manifest',
    'agent': '/root/w10_a02_evidence_claims_review', 'ordinal': 56,
    'started_at_utc': started,
    'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'code_checkpoint': CODE, 'executed_merge': MERGE, 'tree': TREE,
    'new_archives': archive_results,
    'new_original_members': sum(a['original_members'] for a in archive_results),
    'unchanged_prior_archives_and_sidecars': 24,
    'unchanged_original_nonroot_packet_files': 43,
    'original_root_metadata_remains_in_unchanged_archive': True,
    'initial_auditor_packet_preserved': True,
    'native_zip': {**ident(zip_raw), 'members': 812, 'decoded_bytes': 10794058},
    'native_cells': native['cells'], 'native_source_bodies_git_and_current_matched': 761,
    'native_retained_records_checked': 786, 'native_commands_and_log_hashes_checked': 18,
    'native_compiler_header_roles_recorded': 5,
    'ledger_unique_initial_agents': 60, 'ledger_waves': 10,
    'ledger_assignments_per_wave': 6, 'ledger_followups_counted_as_agents': False,
    'ledger_registry_sha256': sha(registry_raw),
    'ledger_registry_authorship_limit_preserved': ledger['registry']['limitation'],
    'ledger_evidence_targets_verified': len(evidence_results),
    'relative_document_links_verified': len(links),
    'four_native_pass_doc_copies_match': True, 'two_prospective_plan_docs_unchanged': True,
    'root_manifest_sha256': sha(packet['manifest.json']),
    'checkpoint_index_sha256': sha(packet['checkpoints/index.json']),
    'root_manifest_mismatches': manifest_mismatches,
    'root_manifest_unlisted': unlisted, 'root_manifest_missing': missing,
    'packet_files': len(snapshot), 'packet_bytes': sum(v['size_bytes'] for v in snapshot.values()),
    'packet_unchanged_during_review': True,
    'counter_inventory_reuses_immutable_initial_review': initial_summary['counter_inventory'],
    'retained_programs_executed': False, 'builds_or_tests_run': False,
    'repo_files_modified_by_reviewer': False,
    'final_release_approval': False,
    'pending': ['Current repaired full governance outcome/log and independent review',
                'Closure archive with final documentation, ledger and follow-up reviews',
                'Refreshed final root manifest and checkpoint index',
                'Small final claims/digest delta after stable-ready signal',
                'Final immutable evidence commit and separately verified master publication'],
}
save('packet-files.json', snapshot)
save('docs.json', {name: ident(data) for name, data in docs.items()})
save('native-source-membership.json', source_members)
save('ledger-evidence-targets.json', evidence_results)
save('relative-links.json', links)
save('audit-summary.json', summary)
print(json.dumps({k: summary[k] for k in ['outcome', 'new_original_members',
      'native_source_bodies_git_and_current_matched', 'ledger_unique_initial_agents',
      'ledger_evidence_targets_verified', 'relative_document_links_verified',
      'root_manifest_mismatches', 'final_release_approval', 'pending']}, indent=2))
