#!/usr/bin/env python3
"""Reconcile completed actual assignments and verified retained review records."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import tarfile

ROOT = Path('/workspace/scratch/ea983fdea786')
REPO = ROOT / 'AI-GPU'
OUT = ROOT / 'w10-a05-final'
PACKET = Path('docs/project/evidence/p06-simulator-completion')
REGISTRY = ROOT / 'agent-ledger-source.json'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def retained(name, member, purpose):
    return {'kind': 'archive_member', 'path': str(PACKET / 'checkpoints' / name),
            'member': member, 'purpose': purpose}

def link(ref):
    rel = os.path.relpath(REPO / ref['path'], REPO / PACKET)
    result = f'[{Path(ref["path"]).name}]({rel})'
    if 'member' in ref:
        result += f' — `{ref["member"]}`'
    return result

def validate_reference(ref):
    p = REPO / ref['path']
    assert p.is_file(), ref
    row = {'path': ref['path'], 'sha256': digest(p.read_bytes())}
    if 'member' in ref:
        with tarfile.open(p, 'r:gz') as t:
            member = t.getmember(ref['member'])
            assert member.isfile(), ref
            body = t.extractfile(member).read()
        row.update({'member': ref['member'], 'member_sha256': digest(body)})
    return row

def main():
    OUT.mkdir(exist_ok=True)
    for extension in ['json','md']:
        old = OUT / f'prior-ledger.{extension}'
        if not old.exists():
            old.write_bytes((REPO/PACKET/f'delivery-ledger.{extension}').read_bytes())
    d = json.loads((OUT/'prior-ledger.json').read_text())
    raw = REGISTRY.read_bytes()
    registry = json.loads(raw)
    actual = registry['assignments']
    assert len(actual) == 60
    assert [r['ordinal'] for r in actual] == list(range(1,61))
    assert len({r['name'] for r in actual}) == 60
    assert collections.Counter(r['wave'] for r in actual) == {n:6 for n in range(1,11)}
    assert all(r['status']=='completed' for r in actual)
    assert all(r['wave']==(r['ordinal']-1)//6+1 for r in actual)
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
    d['state'] = 'initial_assignments_complete_verification_and_publication_pending'
    d['generated_at_utc'] = now
    d['registry']['sha256'] = digest(raw)
    d['observed']['assignment_status_counts'] = {'completed':60}
    d['observed']['all_requested_assignments_complete'] = True
    d['observed']['status_scope'] = 'All 60 initial assignments returned actual completion messages; governance and final publication checks remain follow-ups under their existing identities.'
    by_id = {r['ordinal']:r for r in d['assignments']}
    for a in actual:
        r=by_id[a['ordinal']]
        assert r['identity']=='/root/'+a['name'] and r['scope']==a['task']
        r['assignment_status']='completed'
    early={1:'w01-a01-counter-semantics.md',2:'w01-a02-architecture.md',
           3:'w01-a03-native-coverage.md',4:'w01-a04-error-path.md',
           5:'w01-a05-failure-tests.md',6:'w01-a06-rtl-scope.md',8:'w02-a02-harness-report.md'}
    for n,member in early.items():
        by_id[n]['evidence'].insert(0,retained('late-reviews-4781ca9.tar.gz',member,
             'Original development report; proposals and historical hypotheses are not substituted for the final implemented contract'))
    for n,member in [(55,'w10-a01/REPORT.md'),(56,'w10-a02/REPORT.md'),(58,'w10-a04/REPORT.md')]:
        by_id[n]['evidence'].insert(0,retained('late-reviews-4781ca9.tar.gz',member,
             'Original independent review at its recorded checkpoint'))
    native_ref=retained('native-4781ca9.tar.gz','w10-a03-native-ci/review.md',
                        'Independent original repaired native review; its historical governance observation remains pending')
    by_id[57]['evidence'].insert(0,native_ref)
    by_id[53]['outcome']='Assembled 12 immutable checkpoint archives, then appended the frozen repaired native packet and late reviews while preserving original bytes. Governance and delivery closeout use separate follow-up records.'
    by_id[59]['outcome']='Completed the actual 60-agent/10-wave assignment ledger, validated existing source/evidence references and drafted publication wording. This reconciliation is a follow-up under #59; final governance/publication observations are separate.'
    by_id[60]['outcome']='Completed independent prepublication source/ref checks with PASS: all 3,339 current blobs outside the narrow README/project-documentation allowlist and all 761 native retained source bodies match tested 4781ca9. Final immutable-commit projection, fresh remote lease and post-push identity remain follow-up obligations.'
    by_id[60]['review_receipt']={'file_name':'w10-a06/REPORT.md',
        'sha256':'79570be249dc5f6786b2caa7fea704afa6367bebb89f9742445f0ad5f35372aa',
        'manifest_sha256':'d148f5c53178b7e18134861db11afdfd92a1e2475ad93f24f268dade978d3e9f',
        'retention':'Existing frozen scratch original; final delivery archive pending. No nonexistent archive link is supplied.'}
    v=d['verification_at_this_snapshot']
    v['repaired_native']['evidence']=native_ref
    v['repaired_native']['observation_source']='Original independent review retained in checkpoints/native-4781ca9.tar.gz.'
    v['protected_gates']={'status':'pass_for_preservation_scope','reviewer':'/root/w10_a04_gate_preservation_review',
        'unchanged_original_blobs':5018,'original_blobs':5032,'intended_existing_changes':14,
        'inherited_criteria':{'recorded_passes':16,'blocked':1,'unearned':19},
        'lightweight_source_root_checks_passed':3,
        'evidence':retained('late-reviews-4781ca9.tar.gz','w10-a04/REPORT.md','Original gate-preservation review; no phase approval or waiver')}
    v['publication_preflight']={'status':'pass_for_initial_prepublication_source_and_ref_checks',
        'reviewer':'/root/w10_a06_release_readiness',
        'report_sha256':'79570be249dc5f6786b2caa7fea704afa6367bebb89f9742445f0ad5f35372aa',
        'protected_current_blobs':3339,'native_retained_source_bodies':761,
        'original_host_source_blobs':5109,'root_gitlinks':5,
        'remote_observation_utc':'2026-11-22T10:18:38.174Z',
        'observed_master':'42809ff0c1b81384d7c9b079e4ef786be8407600',
        'observed_validation_head':'4781ca96db15a1d130626edc7a73411a4f6c2e7c',
        'limitation':'Final immutable commit, fresh expected-head publication lease and published master identity still require follow-up. This is not a final publication or whole-CI verdict.'}
    v['broader_current_ci']={
        'observation_source':'Coordinator service read at approximately 2026-11-22 10:23 UTC',
        'runs':[
            {'run_id':45009314304,'event':'pull_request','status':'in_progress',
             'observed_jobs':{'success':3,'in_progress':1,'queued':1}},
            {'run_id':45009309933,'event':'push','status':'in_progress',
             'observed_jobs':{'success':3,'in_progress':2}},
        ],
        'scope':'Broader build/test matrices continue asynchronously; these partial job counts are not complete matrix results or a whole-CI-green claim.'}
    api_raw=(ROOT/'ci-management-final/api-observations.json').read_bytes()
    assert digest(api_raw)=='d8af3e2062c6b2eabb01d2b5c64b02d5fdca4cc0d3d06f713520503b76ab7767'
    api=json.loads(api_raw)
    assert api['observed_utc']=='2026-11-22T10:24:20Z'
    by_run={s['data']['id']:s['data'] for s in api['snapshots'] if 'id' in s['data']}
    v['superseded_general_ci_previous_snapshot']=v['superseded_general_ci']
    v['superseded_general_ci']=[]
    for run_id in [45006726449,45006702880]:
        observed=by_run[run_id]
        assert observed['status']=='completed' and observed['conclusion']=='cancelled'
        assert observed['head_sha']==d['source_checkpoints']['first_native_checkpoint']
        v['superseded_general_ci'].append({'run_id':run_id,'checkpoint':'db5ebb3',
            'cancellation':'completed','observed_api_status':'completed','conclusion':'cancelled',
            'observed_at_utc':api['observed_utc']})
    v['cancellation_observation']={'kind':'normalized_service_api_metadata',
        'file_name':'ci-management-final/api-observations.json','sha256':digest(api_raw),
        'scope':'Workflow status only; prior requested/queued snapshots remain historical and no canceled run is counted as passed.'}
    v['cancellation_scope']='Completed cancellation of only the coordinator\'s two superseded db5 general CI runs; original completed artifacts and current workflows preserved. Canceled runs are not passes.'
    current_runs={r['id']:r for s in api['snapshots'] for r in s['data'].get('workflow_runs',[])}
    for r in v['broader_current_ci']['runs']:
        observed=current_runs[r['run_id']]
        r['status']=observed['status']
        r['conclusion']=observed['conclusion']
        r['workflow_status_observed_utc']=api['observed_utc']
    d['pending_finalization']=[
        'Verify the actual repaired governance outcome and count from the original completed log; retain it as a separate follow-up without rewriting the native review\'s historical pending observation.',
        'Retain #59 delivery reconciliation and #60 publication preflight/final projection records; follow-ups remain the same two agents.',
        'Refresh the final packet manifest and independently review final documentation/evidence claims against the assembled content.',
        'Create and verify the immutable documentation/evidence commit as a descendant of tested 4781ca9 with byte-identical protected execution inputs.',
        'Refresh remote heads, preserve concurrent work, perform only the authorized non-force expected-head update, and independently read back master SHA/tree/ancestry and actual PR state.',
    ]
    (REPO/PACKET/'delivery-ledger.json').write_text(json.dumps(d,indent=2)+'\n')
    lines=[
        '# Simulator completion delivery ledger','',
        '**All 60 actual unique agents completed their initial assignments across 10 logical waves, exactly six per wave.** '
        'Follow-up work stays under its original identity and is not counted as another agent. '
        'Governance and final publication checks remain distinct follow-up obligations at this snapshot.','',
        f'Generated at `{now}` from coordinator registry SHA-256 `{digest(raw)}`. '
        'The [machine-readable ledger](delivery-ledger.json) records every identity, scope, outcome and evidence mapping. '
        'Assignment completion is coordination accounting; it does not grant a test pass, phase acceptance, maintainer approval or waiver.','',
        '## Selected development step','',
        'The audit chose simulator completion and exceptional full-platform teardown as the prerequisite to future counter qualification. '
        'Both runtime adapters now consume asynchronous results, preserve the first busy observation and make processor failures terminal. '
        'Legacy SimX `run()` returns architectural gp data, so successful nonzero and -1 values remain successful through the checked void path. '
        'The later consumer audit found and repaired a separate CP scratch allocation regression; recoverable CP OOM behavior remains intact. '
        'See the [audit](../../p06-simulator-completion-audit.md) and [implemented contract](../../../designs/simulator_completion_v1.md).','',
        'Original Wave1 proposals included a nonzero-return-as-error hypothesis that was corrected during development. '
        'Their original reports are now retained in the [late review archive](checkpoints/late-reviews-4781ca9.tar.gz). '
        'Historical proposals and failed attempts remain historical evidence; the final contract and exact-source receipts define delivered behavior.','',
        '## Source and verification snapshot','',
        '| Item | Observed state and scope |','|---|---|',
        '| Audited parent | `42809ff0c1b81384d7c9b079e4ef786be8407600` |',
        '| First native checkpoint | `db5ebb3a16770004423f2456ec6d0caaa0aced6d`: historical native success and 2,988 governance tests, before the CP error-boundary correction |',
        '| Repaired tested implementation | `4781ca96db15a1d130626edc7a73411a4f6c2e7c`, tree `6dd0d759390cda78ec63ad0caacc00a08f03e2bc`; native CI executed merge `e929c52d05bad80b28dd4085a97838d7fe2de354` with that identical tree |',
        '| Clean host receipt | **83 distinct tests passed in 87.502 seconds**, with stable source/tool/driver identities; [receipt](checkpoints/host-4781ca9.tar.gz), member `receipt/report.json` |',
        '| Original-parent sensitivity | **Eight intended failures** after successful compilation of original backends; [packet](checkpoints/parent-4781ca9.tar.gz), member `report/report.json` |',
        '| CP compatibility regression | **38 positive cells and four compiled db5 negative controls**; its five methods are already included in 83; [packet](checkpoints/cp-allocation-repair.tar.gz), member `w08-a06/report.json` |',
        '| Repaired native | **Independent original-artifact PASS** for run [45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161), artifact 14749901531; [original packet/review](checkpoints/native-4781ca9.tar.gz), member `w10-a03-native-ci/review.md` |',
        '| Repaired governance | Run [45009314170](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314170): final original-log review remains pending; no final count or pass is inferred |',
        '| Broader current CI | PR [45009314304](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314304) and push [45009309933](https://github.com/baabi-boo/AI-GPU/actions/runs/45009309933) remain asynchronous and incomplete; partial build/preparation jobs do not establish a complete matrix pass |',
        '| Protected gates | Independent review found no new preservation blocker; 5,018/5,032 original blobs unchanged and 14 intended existing changes, with the inherited 36 criteria retaining 16 accepted/one blocked/19 unearned; [review](checkpoints/late-reviews-4781ca9.tar.gz), member `w10-a04/REPORT.md` |',
        '| Publication preflight | **PASS for initial source/ref checks**: all 3,339 protected current blobs and 761 native source bodies match tested `4781ca9`. Final immutable-commit projection and actual publication remain pending |',
        '| Superseded general CI | db5 runs [45006726449](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726449) and [45006702880](https://github.com/baabi-boo/AI-GPU/actions/runs/45006702880) are **completed/cancelled**, confirmed by service metadata observed at 10:24:20 UTC. Earlier requested/queued observations remain historical; canceled runs are not passes |',
        '| Master publication | Authorized by the user; final evidence commit and actual remote publication are not yet verified |','',
        'The repaired original native ZIP is 2,792,870 bytes with SHA-256 '
        '`461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9`. '
        'Its scope is RV64 p02-tfr timing SimX, PERF1, one simulation worker and direct-RAM CP: actual processor gp 7/-1, '
        'legacy fault, consumed OutOfRange, fresh-context success and six successful public launches. '
        'It does not establish native public injected faults, native RTL, functional SimX, multiworker fault transport, cancellation or failed-context reuse.','',
        'The [checkpoint index](checkpoints/index.json) records original archive identities and source scopes. '
        'Host tests use controlled models where stated. Earlier db5 success does not certify the three runtime files changed afterward. '
        'A final documentation/evidence commit may preserve this execution evidence only for independently verified byte-identical inputs at tested `4781ca9`; '
        'it must not be described as the entire tree executed by those earlier runs. Final assembled documentation/evidence requires its own structural/manifest validation. '
        'No whole-CI-green claim is made.','',
        '## Ten-wave progression','',
        '| Wave | Purpose | Actual completed assignments | Progression |','|---|---|---:|---|',
    ]
    for w in d['waves']:
        lines.append(f'| {w["wave"]} | {w["title"]} | 6/6 | {w["progression"]} |')
    lines += ['','## Actual assignments','',
        'Every identity below exists in the coordinator registry and returned an actual initial completion message. '
        'A completed assignment can precede a later finding or follow-up. Evidence links identify existing source or retained reports; '
        'they do not independently authenticate per-agent authorship. Archive members are named explicitly. '
        'The initial publication preflight and this reconciliation are existing scratch originals awaiting their final append-only delivery archive.','']
    for w in d['waves']:
        lines += [f'### Wave {w["wave"]}: {w["title"]}','','| # / actual identity | Initial assignment | Scope and observed outcome | Existing source or evidence |','|---|---|---|---|']
        for r in d['assignments']:
            if r['wave']==w['wave']:
                lines.append(f'| {r["ordinal"]} — `{r["identity"]}` | `completed` | **{r["scope"]}.** {r["outcome"]} | '+ '; '.join(link(ref) for ref in r['evidence'])+' |')
        lines.append('')
    lines += ['## Preserved gates and next step','',
        'Public ABI, ISA, RTL, accepted goldens, enforcement/acceptance policies and protected assets remain unchanged. '
        'The user explicitly authorized commit and push to `master`; that authorization grants no waiver and supplies no invented human review. '
        'Actual agent completion does not establish test or phase acceptance.','',
        'P06 counter qualification and A02/A03 remain open. Frozen warm v1 remains blocked with `qualified=false` and '
        '`absolute_no_wrap_bound` not established. P05 framework review, P01 vendor integration, the inherited DSP area failure '
        'and physical FPGA/silicon gates retain separate obligations. See [canonical phase gates](../../roadmap.json), '
        '[acceptance policy](../../acceptance.md) and [workspace handoff](../../p06-workspace-handoff.md).','',
        'The next bounded development is to freeze and independently review the exact 33-selector RV64 p02-tfr timing SimX PERF1 route, '
        'coherent reads and an enforceable cumulative context-lifetime no-wrap contract. Reviewed guard implementation and a versioned evidence path '
        'precede a fresh complete warm matrix. The [qualification plan](../../p06-mpm-qualification-plan.md) retains the exact requirements.','',
        '## Remaining verification and publication follow-ups','']
    lines += ['- '+x for x in d['pending_finalization']]
    lines.append('')
    (REPO/PACKET/'delivery-ledger.md').write_text('\n'.join(lines))
    (OUT/'agent-ledger-source.snapshot.json').write_bytes(raw)
    (OUT/'ci-api-observations.snapshot.json').write_bytes(api_raw)
    (OUT/'source-evidence-mapping.json').write_text(json.dumps(d['assignments'],indent=2)+'\n')
    checks=[]
    for r in d['assignments']:
        checks.extend({'assignment':r['ordinal'],**validate_reference(ref)} for ref in r['evidence'])
    for name,vv in v.items():
        if isinstance(vv,dict) and 'evidence' in vv:
            checks.append({'verification':name,**validate_reference(vv['evidence'])})
    md=REPO/PACKET/'delivery-ledger.md'
    local_links=[]
    for m in re.finditer(r'\[[^\]]+\]\(([^)]+)\)',md.read_text()):
        target=m.group(1)
        if not target.startswith(('https://','http://','#')):
            assert (md.parent/target.split('#',1)[0]).is_file(),target
            local_links.append(target)
    validation={'status':'pass','actual_unique_agents':60,'initial_completed_assignments':60,
        'six_per_wave':True,'followup_agents_added':0,'registry_sha256':digest(raw),
        'existing_evidence_references_checked':len(checks),'local_markdown_links_checked':len(local_links),
        'ledger_json_sha256':digest((REPO/PACKET/'delivery-ledger.json').read_bytes()),
        'ledger_markdown_sha256':digest(md.read_bytes()),'reference_checks':checks}
    (OUT/'checks.json').write_text(json.dumps(validation,indent=2)+'\n')
    print(json.dumps({k:v for k,v in validation.items() if k!='reference_checks'},indent=2))

if __name__=='__main__':
    main()
