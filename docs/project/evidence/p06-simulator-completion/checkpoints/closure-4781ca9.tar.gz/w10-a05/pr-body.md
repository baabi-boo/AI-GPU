## Problem and result

The P06 audit found a prerequisite to trustworthy counter qualification: simulator execution faults could be lost between the worker and public waits, and a task that completed before its first busy poll could strand the CP launch handshake. Exceptional platform disposal could also leave abandoned channel accounting that poisoned a fresh context.

This change makes completion observable and processor failures terminal while preserving successful architectural gp values, public runtime ABI and the inherited recoverable CP allocation path. It implements the selected prerequisite; P06 counter/coherence/no-wrap qualification remains the next bounded development step.

## Changes

- Add the internal checked-void SimX entry while preserving legacy `Processor::run()` and its architectural gp return convention. Normal gp values 7 and -1 remain successful.
- Share asynchronous ownership across SimX and processor RTL runtime adapters: consume future exceptions, preserve the first busy observation, reject work after a processor fault and join outstanding work before releasing resources.
- Distinguish processor-owned failures from unrelated CP/host exceptions. The late consumer audit found that broad terminal conversion broke CP scratch allocation recovery; the repaired boundary preserves the existing OOM mapping and same-device recovery. The unchanged public AI lifecycle test exercises that behavior.
- Clear abandoned packet accounting only after full disposal of the timing/functional platform. Ordinary reset, scheduling and counter behavior remain unchanged; a failed live backend is not rehabilitated.
- Add source-sensitive host controls, actual native processor/public success fixtures, an additive native build target, bounded hosted evidence collection and independently reviewed evidence packets.
- Update status, blockers and the exact future selector/coherence/lifetime plan without changing phase acceptances.

## Verification and source binding

Audited parent: `42809ff0c1b81384d7c9b079e4ef786be8407600`.

Repaired implementation: `4781ca96db15a1d130626edc7a73411a4f6c2e7c`, tree `6dd0d759390cda78ec63ad0caacc00a08f03e2bc`. Hosted execution used merge `e929c52d05bad80b28dd4085a97838d7fe2de354` with that exact tree. Subsequent delivery edits are documentation/evidence; final source projection and remote ancestry still require their recorded closeout.

| Check | Actual result |
|---|---|
| Clean focused host receipt | **83 distinct tests passed in 87.502 seconds**, with stable source, tool and driver identities; independently reviewed |
| Pinned original-parent sensitivity | **Eight intended failures** after successful compilation of the original backend bodies; build failures and timeouts were not substituted for behavioral failures |
| CP allocation/fault-origin regression | **38 positive cells and four compiled db5 negative controls**; the five methods are already included in the 83-test total |
| Repaired native completion | **Independent original-artifact PASS**, run [45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161), artifact 14749901531, ZIP SHA-256 `461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9` |
| Protected gates/assets | Independent review found no new preservation blocker; canonical phase criteria, acceptance records, existing hardware, goldens, ABI/ISA and enforcement remain unchanged |
| Repaired full governance | **Pending at this draft checkpoint**, run [45009314170](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314170); no expected or inferred final test count |

The repaired native scope is RV64, `p02-tfr`, timing SimX, PERF enabled, one simulation worker and direct RAM CP. The actual processor unit verifies normal gp 7/-1, legacy error behavior, consumed native `OutOfRange` and fresh-context success after teardown. The public cell verifies six successful native launches across two contexts with exact outputs. It does not establish native public injected faults, native RTL execution, functional SimX, multiworker fault transport, cancellation or failed-context reuse.

Earlier native success and **2,988 governance tests** at `db5ebb3` remain historical evidence. They are not used to certify the three runtime files changed in the repaired checkpoint. Original failures, negative controls and superseded reports are preserved.

Cancellation was requested only for the coordinator's two superseded db5 general CI runs, 45006726449 and 45006702880, to release capacity for current verification. Their last recorded API state was queued with no conclusion; they are not passing results. Completed original artifacts remain retained. There is no whole-CI-green claim.

## Review, delivery and remaining gates

All **60 unique agents have actually been spawned across 10 logical waves, six per wave**. This draft records 58 completed assignments while the ledger and release-readiness assignments are still running. Follow-ups remain attributed to their original agent and are not extra agents. The ledger records identities, scopes, outcomes and existing evidence; neither the count nor any agent report grants phase acceptance, human approval or a waiver.

The user explicitly authorized commit and push to `master`. The final evidence/claims review, actual final governance outcome and non-force remote/ref verification remain to be recorded before publication is claimed.

P06-A02/A03 and counter qualification remain open. Frozen warm v1 remains blocked with `qualified=false` and no established absolute no-wrap bound. The next step is a reviewed exact 33-selector/coherent-read/context-lifetime contract, followed by narrow enforcement and versioned evidence, then a fresh complete warm attempt. P01 vendor integration, P05 framework acceptance, the inherited DSP area failure against the unchanged 5% bound, physical FPGA and silicon obligations remain separate open gates.
