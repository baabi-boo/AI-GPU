#!/usr/bin/env python3
"""Render the coordinator's actual assignments; never synthesize a missing agent."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import tarfile

ROOT = Path('/workspace/scratch/ea983fdea786')
REPO = ROOT / 'AI-GPU'
OUT = ROOT / 'w10-a05'
PACKET = Path('docs/project/evidence/p06-simulator-completion')
REGISTRY = ROOT / 'agent-ledger-source.json'

def source(path, purpose):
    return {'kind': 'repository_file', 'path': path, 'purpose': purpose}

def archive(name, purpose, member=None):
    result = {'kind': 'archive_member' if member else 'archive',
              'path': str(PACKET / name), 'purpose': purpose}
    if member:
        result['member'] = member
    return result

AUDIT = 'docs/project/p06-simulator-completion-audit.md'
CONTRACT = 'docs/designs/simulator_completion_v1.md'
PLAN = 'docs/project/p06-mpm-qualification-plan.md'
HANDOFF = 'docs/project/p06-workspace-handoff.md'
CHECKPOINT_INDEX = str(PACKET / 'checkpoints/index.json')
ASYNC = 'sw/runtime/common/async_run.h'
EXECUTE = 'ci/project/p06_simulator_execute.py'
PARENT = 'ci/project/p06_simulator_parent.py'

# Outcomes describe the assignment's observed contribution. A completed assignment
# does not imply that its original implementation was final or that a gate passed.
MAPPING = {
1: ('Established that wall-clock limits, small observed counters and monotonicity do not establish a cumulative no-wrap bound; identified reliable completion/error propagation as a prerequisite.', [source(AUDIT, 'Consolidated finding and chosen prerequisite'), source(PLAN, 'Current counter-lifetime follow-on plan')]),
2: ('Proposed an additive qualification envelope around the frozen warm replay, with independently bound route, lifetime and provenance obligations; no qualification implementation or acceptance was earned.', [source(PLAN, 'Reconciled future qualification design'), source('docs/designs/warm_workspace_benchmark_v1.md', 'Preserved blocked historical contract')]),
3: ('Counted 33 available and 12 unavailable warm selectors and exposed the narrower historical transport/configuration coverage; directed native coverage remains future work.', [source(PLAN, 'Exact selector inventory and route requirements'), source(AUDIT, 'Audit decision and execution scope')]),
4: ('Traced wait-only asynchronous observation and the CP busy-rise race to public error propagation; initial nonzero-return-as-error hypothesis was superseded by the later gp-register finding.', [source(AUDIT, 'Consolidated error-path audit'), source(CONTRACT, 'Corrected checked-void and legacy-gp contract')]),
5: ('Designed source-sensitive actual-backend/CP host fault tests, deterministic scheduling checks and original-parent negative controls; original nonzero-result hypothesis was corrected before final implementation.', [source('ci/project/test_p06_simulator_completion.py', 'Implemented actual-backend/CP coverage'), source(CONTRACT, 'Final success and failure semantics')]),
6: ('Identified the shared exception/busy-edge problem in both simulation adapters and retained separate processor contracts; proposed integer normalization was superseded by checked void execution.', [source(AUDIT, 'Shared-backend scope finding'), source(CONTRACT, 'Final boundary with legacy run() preserved')]),
7: ('Implemented the shared asynchronous owner and both backend integrations, preserving the launch edge and sticky processor failures; the CP allocation boundary was later narrowed by #47.', [source(ASYNC, 'Final integrated asynchronous owner'), source('sw/runtime/simx/vortex.cpp', 'Integrated SimX adapter')]),
8: ('Added the actual-backend/CP host harness: six groups across both backends and RAM/LLC routes, with controlled Processor/RAM substitutes and compiled parent sensitivity.', [source('ci/project/test_p06_simulator_completion.py', 'Six-group host driver'), archive('host/initial-backend-tests.log', 'Original host execution log')]),
9: ('Added native processor exception/legacy-gp controls and a public runtime serial-success regression; native execution was later retained and independently reviewed at exact checkpoints.', [source('tests/unittest/simx_completion/main.cpp', 'Actual native processor fixture'), source('tests/regression/simx_completion/main.cpp', 'Public native success fixture')]),
10: ('Wired helper dependencies and the additive native build fragment while preserving the accepted SimX Makefile; added a meaningful rebuild-dependency check.', [source('sim/simx/completion.mk', 'Additive native target'), source('ci/project/test_p06_simulator_build.py', 'Build dependency validation')]),
11: ('Documented completion behavior, fault propagation and evidence boundaries; the implemented contract was subsequently reconciled for full teardown and recoverable CP allocation failures.', [source(CONTRACT, 'Current implemented completion contract'), source(AUDIT, 'Scope and audit history')]),
12: ('Implemented the bounded native evidence runner with source/tool/build binding; adversarial reviews later exposed and repaired provenance gaps before the retained native runs.', [source(EXECUTE, 'Final bounded native runner'), archive('development/source-at-assembly.tar.gz', 'Historical development source snapshot, not final proof')]),
13: ('Added deterministic helper-state regressions for already-ready success/failure, preserved launch announcements, sticky errors and safe join semantics.', [source('ci/project/test_p06_simulator_async_run.py', 'Host test driver'), archive('host/initial-async-owner-tests.log', 'Original helper execution log')]),
14: ('Added actual public runtime/event/queue integration against controlled model inputs; retained the initial build failure and successful repair instead of erasing the failure.', [source('ci/project/test_p06_simulator_public.py', 'Public runtime fault-injection driver'), archive('host/initial-public-runtime-tests.log', 'Original public integration test log')]),
15: ('Added the dedicated bounded hosted completion workflow and policy checks; source preparation, resource limits and always-retained artifacts remained explicit.', [source('.github/workflows/p06-simulator-completion.yml', 'Dedicated native workflow'), source('ci/project/test_p06_simulator_ci.py', 'Workflow policy checks')]),
16: ('Added the pinned-parent execution runner and compiled both original adapters against the unchanged CP/fixtures to observe eight intended exception-propagation failures.', [source(PARENT, 'Final pinned-parent runner'), archive('host/initial-parent-report.json', 'Original compiled-parent report')]),
17: ('Adversarially reviewed the native runner and retained source/provenance counterexamples; the discovered compiler/generated-input gaps drove Wave4 repairs.', [archive('development/w03-a05-runner-review.tar.gz', 'Original adversarial records', 'w03-a05-runner-review/initial-runner-failures.json'), source(EXECUTE, 'Repaired current runner')]),
18: ('Performed an independent R3 review of production behavior and the contract, retaining findings and scope instead of treating source presence as native evidence.', [archive('reviews/w03-a06-r3-review.md', 'Original independent production review'), source(CONTRACT, 'Current contract after later reconciliations')]),
19: ('Repaired compiler option/include handling and generated-input/tool binding in the native runner after independent attacks; preserved concrete proof records.', [archive('development/w04-a01-runner-repair.tar.gz', 'Provenance repair evidence', 'w04-a01-runner-repair/generated-proof.json'), source(EXECUTE, 'Current runner with repairs')]),
20: ('Retained independent runner attacks using realistic compile inputs, including negative controls for claims that could otherwise be satisfied by incomplete provenance.', [archive('development/w04-a02.tar.gz', 'Independent provenance regression records'), source('ci/project/test_p06_simulator_runner_failures.py', 'Current adversarial driver')]),
21: ('Closed deterministic immediate check-success coverage and retained a mutation proving that the assertion detects loss of the pending launch announcement.', [archive('development/w04-a03.tar.gz', 'Immediate completion review and mutation proof', 'w04-a03/report.md'), source('ci/project/fixtures/simulator_async_run_test.cpp', 'Current deterministic helper fixture')]),
22: ('Reviewed native fixture/link/build semantics before hosted execution and retained a scoped probe; this static work was not presented as native success.', [archive('reviews/w04-a04-native-review.md', 'Native source/build review'), archive('development/w04-a04-native-probe.tar.gz', 'Original probe evidence')]),
23: ('Updated resumable status and next actions with preserved acceptance boundaries; these development documents were subsequently reconciled to exact checkpoint evidence.', [source(AUDIT, 'Current resumable audit'), archive('development-index-db5ebb3.tar.gz', 'Superseded evidence index retained at first checkpoint')]),
24: ('Independently reviewed the provenance repair and retained source-bound proof, including the limitations of simulated compiler records and hosted preparation.', [archive('reviews/w04-a06-runner-review.md', 'Independent runner review'), archive('reviews/w04-a06-runner-proof.json', 'Retained independent proof')]),
25: ('Repaired abandoned SimChannel inflight accounting at complete timing-platform disposal, after owned workers, events and channels are destroyed; ordinary reset remained unchanged.', [archive('development/w05-a01.tar.gz', 'Timing cleanup implementation and proof', 'w05-a01/report.md'), source('sim/common/simobject.h', 'Final timing framework teardown')]),
26: ('Added actual-framework exceptional/pending cleanup controls for both timing and functional frameworks; compared old headers to show fault sensitivity and preserved healthy cases.', [archive('development/w05-a02.tar.gz', 'Framework regression evidence'), source('ci/project/test_p06_simulator_platform.py', 'Current actual-framework test driver')]),
27: ('Applied the corresponding full-disposal accounting repair to the functional framework, keeping ordinary reset and live-context reuse semantics unchanged.', [archive('development/w05-a03.tar.gz', 'Functional cleanup implementation record', 'w05-a03/report.json'), source('sim/common/simobject_functional.h', 'Final functional framework teardown')]),
28: ('Independently reviewed full-platform teardown accounting and recovery scope; identified whole-platform cleanup as distinct from rehabilitating a failed live backend.', [archive('reviews/w05-a04-cleanup-review.md', 'Independent teardown review'), archive('development/w05-a04-cleanup-probe.tar.gz', 'Original framework probe records')]),
29: ('Reconciled the implemented contract with exceptional full-platform disposal and the limits of fresh-context recovery, without claiming cancellation or arbitrary concurrency.', [source(CONTRACT, 'Final recovery/teardown contract'), archive('development/source-at-assembly.tar.gz', 'Historical contract and source snapshot')]),
30: ('Assembled retained development failures, proofs, source snapshots and reviews with per-member hashes; the historical package remains separate from exact-checkpoint evidence.', [archive('development/index.json', 'Original development archive index'), archive('development/source-bindings.json', 'Historical source-binding inventory')]),
31: ('Independently audited pinned-parent execution and evidence semantics, separating expected assertion failures from compile/time-budget failures.', [archive('checkpoints/checkpoint-reviews.tar.gz', 'Independent parent review', 'w06-a01-parent-review.md'), source(PARENT, 'Final parent runner')]),
32: ('Closed Git replacement-object ambiguity and tested replacement-free pinned-parent identity; replay execution uses the intended historical source rather than a substituted object.', [source(PARENT, 'Replacement-free parent identity handling'), source('ci/project/test_p06_simulator_parent.py', 'Identity and runner policy checks')]),
33: ('Audited actual public-runtime fixture seams, event/error assertions and claimed scope; host substitutions remained explicitly separate from native model execution.', [archive('checkpoints/checkpoint-reviews.tar.gz', 'Public evidence review', 'w06-a03-public-review.md'), source('ci/project/test_p06_simulator_public.py', 'Reviewed public fault driver')]),
34: ('Reviewed the checkpoint production/base classification and protected inputs, retaining the stricter independent review obligation and unchanged enforcement boundaries.', [archive('checkpoints/checkpoint-reviews.tar.gz', 'Checkpoint classification/protection review', 'w06-a04-checkpoint-review.md'), source(CONTRACT, 'Reviewed behavior contract')]),
35: ('Captured clean immutable host receipts: the earlier 78-test checkpoint and, on follow-up, the repaired 83-test checkpoint with stable source/tool/driver identities. Follow-up did not create another agent.', [archive('checkpoints/host-db5ebb3.tar.gz', 'Historical clean 78-test receipt', 'receipt/report.json'), archive('checkpoints/host-4781ca9.tar.gz', 'Repaired clean 83-test receipt', 'receipt/report.json')]),
36: ('Reviewed hosted workflow trust, preparation/resource bounds and CI intake, preserving blocked or pending evidence rather than claiming anticipated results.', [archive('checkpoints/checkpoint-reviews.tar.gz', 'CI intake review', 'w06-a06-ci-intake-review.md'), source('.github/workflows/p06-simulator-completion.yml', 'Actual hosted workflow')]),
37: ('Reconstructed exact selector/configuration gaps for the next qualification step: 33 available rows, 12 unavailable rows and distinct historical SimX/RTL coverage.', [archive('checkpoints/next-development-audits.tar.gz', 'Exact coverage audit', 'w07-a01-counter-coverage.md'), source(PLAN, 'Reconciled route/selector plan')]),
38: ('Audited per-launch clock reset versus cumulative counter lifetimes and the missing enforceable no-wrap proof; future bounded tick/event candidates remain unimplemented.', [archive('checkpoints/next-development-audits.tar.gz', 'Counter lifetime audit', 'w07-a02-counter-lifetime.md'), source(PLAN, 'Current proof obligations')]),
39: ('Reviewed the frozen warm block and a separately versioned future envelope; preserved the complete fixed experiment and unqualified historical decision.', [archive('checkpoints/next-development-audits.tar.gz', 'Warm contract audit', 'w07-a03-warm-contract.md'), source('docs/designs/warm_workspace_benchmark_v1.md', 'Preserved implemented warm v1')]),
40: ('Reconciled phase/vendor/framework dependencies without promoting open P05, P06 or physical gates, and retained the distinct P01 requirement before P07.', [archive('checkpoints/next-development-audits.tar.gz', 'Phase dependency audit', 'w07-a04-phase-dependencies.md'), source('docs/project/roadmap.json', 'Unchanged canonical phase gates')]),
41: ('Audited the inherited DSP area failure and unchanged synthesis inputs; did not guess a causing commit or weaken the 5% threshold.', [archive('checkpoints/next-development-audits.tar.gz', 'DSP attribution audit', 'w07-a05-dsp-attribution.md'), source(HANDOFF, 'Preserved resource blocker')]),
42: ('Audited the original warm CI artifact and replayed its complete 24-process/792-launch/25,344-word matrix; replay integrity passed while qualification and conditional performance remained unsatisfied.', [archive('checkpoints/warm-db5ebb3.tar.gz', 'Original warm review and packet', 'w07-a06-warm-ci-review.md'), source(PLAN, 'Future qualification prerequisites')]),
43: ('Independently reviewed the clean 78-test host receipt and its source/tool identities at db5ebb3; this is historical evidence before the CP boundary correction.', [archive('checkpoints/checkpoint-reviews.tar.gz', 'Original host receipt review', 'w08-a01-host-receipt-review.md'), archive('checkpoints/host-db5ebb3.tar.gz', 'Reviewed historical receipt', 'receipt/report.json')]),
44: ('Independently reviewed the original compiled-parent packet and all eight intended failures, distinguishing source-sensitive failures from setup errors.', [archive('checkpoints/checkpoint-reviews.tar.gz', 'Parent packet review', 'w08-a02-parent-packet-review.md'), archive('checkpoints/parent-db5ebb3.tar.gz', 'Reviewed first-checkpoint parent report', 'report/report.json')]),
45: ('Independently verified the retained development archive integrity and claim limits; historical snapshots and failed probes remained separate from final tested source.', [archive('checkpoints/checkpoint-reviews.tar.gz', 'Development packet review', 'w08-a03-development-packet-review.md'), archive('development/index.json', 'Reviewed historical archive inventory')]),
46: ('Found the late consumer regression: broad backend catches turned recoverable CP scratch bad_alloc into terminal INVALID_VALUE and broke same-device recovery. This blocked the first checkpoint.', [archive('checkpoints/cp-allocation-repair.tar.gz', 'Original consumer finding', 'w08-a04-consumer-error-scope.md'), source('tests/runtime/test_ai_lifecycle.cpp', 'Unchanged original OOM/lifecycle expectation')]),
47: ('Narrowed terminal conversion to processor-owned failures; unrelated CP/host exceptions retain the inherited Queue mapping, preserving allocation OOM and same-device recovery.', [archive('checkpoints/cp-allocation-repair.tar.gz', 'CP error boundary repair', 'w08-a05/REPORT.md'), source(ASYNC, 'Processor-origin tracking'), source('sw/runtime/rtlsim/vortex.cpp', 'Final corresponding adapter boundary')]),
48: ('Added five methods exercising 38 positive CP/model-fault cells and four compiled db5 negative controls, including the entire unchanged public AI lifecycle test.', [archive('checkpoints/cp-allocation-repair.tar.gz', 'Original 38-positive/4-negative regression packet', 'w08-a06/README.md'), source('ci/project/test_p06_simulator_error_boundary.py', 'Current regression driver')]),
49: ('Audited the first original native artifact and its full 2,988-test governance log at db5ebb3; explicitly excluded the later three runtime-file changes from that execution claim.', [archive('checkpoints/native-db5ebb3.tar.gz', 'Original first-checkpoint native review', 'w09-a01-native-ci/review.md'), archive('checkpoints/native-db5ebb3.tar.gz', 'Original governance summary', 'w09-a01-native-ci/governance-summary.json')]),
50: ('Independently reviewed the repaired CP/processor error boundary and source-sensitive regression, found no remaining F2/F3 issue in that scope, and reconciled the implemented contract.', [archive('checkpoints/cp-allocation-repair.tar.gz', 'Independent repair review', 'w09-a02/REPORT.md'), source(CONTRACT, 'Reconciled contract frozen with repaired source')]),
51: ('Reconciled README, current status, backlog and the completion audit to exact tested revisions, preserved blockers and the completed CP correction; later live CI status remains a separate update.', [archive('checkpoints/documentation-reconciliation.tar.gz', 'Documentation reconciliation record', 'w09-a03/README.md'), source(AUDIT, 'Current completion audit')]),
52: ('Updated the counter/coherence/lifetime plan and workspace handoff with exact future selector, guard and complete warm-matrix obligations; implemented no guard and granted no qualification.', [archive('checkpoints/documentation-reconciliation.tar.gz', 'Counter/handoff reconciliation review', 'w09-a04/REPORT.md'), source(PLAN, 'Next bounded development contract'), source(HANDOFF, 'Resumable handoff')]),
53: ('Assembled 12 immutable checkpoint archives, preserving the earlier packet and binding original host, parent, CP, native, warm and independent-review evidence. Late review appendices remain a separate follow-up.', [source(CHECKPOINT_INDEX, 'Current checkpoint archive index'), archive('checkpoints/assembly.json', 'Assembly receipt')]),
54: ('Independently verified the clean repaired 83-test receipt and eight intended original-parent failures, including original logs and source/tool/driver integrity, without rerunning the suite.', [archive('checkpoints/host-4781ca9-review.tar.gz', 'Independent exact-checkpoint review', 'w09-a06/REPORT.md'), archive('checkpoints/parent-4781ca9.tar.gz', 'Repaired-source parent sensitivity', 'report/report.json')]),
55: ('Completed final independent R3 production/build review, checking preserved gp behavior, fault origin, launch edge and teardown scope; no F2/F3 code defect found, with exact-source native verification still tracked separately.', [source(CONTRACT, 'Reviewed final contract'), source(ASYNC, 'Reviewed final production owner'), source(CHECKPOINT_INDEX, 'Retained verification supporting the review')]),
56: ('Completed the initial final-claims audit of 72 retained files, 22 tar archives, original ZIPs and 553 links; final native/governance, this ledger and publication were explicitly outside that snapshot.', [source(CHECKPOINT_INDEX, 'Reviewed checkpoint index'), archive('manifest.json', 'Reviewed packet manifest; final delta needs refresh')]),
57: ('Independently verified the original repaired native packet: both declared RV64 p02-tfr timing SimX cells pass at 4781ca9 via the identical merge tree. Governance remains pending for a follow-up under the same agent identity.', [source(CONTRACT, 'Frozen repaired-source behavior independently verified'), archive('checkpoints/host-4781ca9.tar.gz', 'Already-retained host proof at the same repaired source', 'receipt/report.json')]),
58: ('Completed protected-gate/asset review with no new preservation blocker: 5,018 of 5,032 original blobs unchanged, 14 intended existing changes, 36 criteria retaining 16 accepted/one blocked/19 unearned, and three lightweight checks passing. No acceptance or waiver granted.', [source('docs/project/roadmap.json', 'Preserved canonical phase gates'), source('docs/project/acceptance.md', 'Preserved acceptance policy')]),
59: ('Preparing the actual-assignment ledger, source/evidence mapping and a provisional publication description; final agent count, late review and publication state remain explicit open items.', [source(str(PACKET / 'delivery-ledger.json'), 'Machine-readable coordination ledger'), source(str(PACKET / 'delivery-ledger.md'), 'Human-readable coordination ledger')]),
60: ('Independently reviewing final source projection and non-force publication/ref readiness; actual master identity verification belongs to a post-push follow-up. No verdict or publication is yet claimed.', [source(CHECKPOINT_INDEX, 'Existing evidence/source projection to review'), source('AGENTS.md', 'Preserved remote-ancestry and publication obligations')]),
}

# Archive helper also addresses loose retained files; normalize their kind.
for _, refs in MAPPING.values():
    for ref in refs:
        if ref['kind'] == 'archive' and not ref['path'].endswith('.tar.gz'):
            ref['kind'] = 'repository_file'

# Correct an early short archive spelling to the real retained checkpoint path.
for ref in MAPPING[23][1]:
    if ref['path'].endswith('/development-index-db5ebb3.tar.gz'):
        ref['path'] = str(PACKET / 'checkpoints/development-index-db5ebb3.tar.gz')

WAVES = {
1: ('Audit', 'Trace counter, qualification, native coverage, error-path and processor-contract gaps before choosing the completion prerequisite.'),
2: ('Implementation', 'Implement checked completion, actual adapter/CP fixtures, native controls, build integration and a bounded runner.'),
3: ('Failure controls', 'Exercise immediate completion, public errors, hosted workflow and pinned-parent failures; independently attack and review the first implementation.'),
4: ('Hardening', 'Repair provenance, retain realistic attacks, prove immediate success sensitivity and independently review native/build semantics.'),
5: ('Teardown repair', 'Repair full-platform inflight accounting in both frameworks, establish fault sensitivity and preserve development evidence.'),
6: ('Provenance', 'Independently review parent/public/checkpoint/CI semantics, close replacement-object ambiguity and capture immutable host receipts.'),
7: ('Future counter audit', 'Define exact selector, coherence, lifetime and phase/resource obligations while auditing the original complete warm packet.'),
8: ('Consumer regression', 'Audit original host/parent/development evidence, discover the CP OOM regression, repair fault origin and prove the preserved consumer behavior.'),
9: ('Integration', 'Audit native and CP evidence, reconcile current status and future plans, preserve checkpoint archives and verify repaired host/parent receipts.'),
10: ('Final review', 'Review final production, claims, exact-source native/governance evidence, protected gates and actual delivery accounting before publication.'),
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_reference(ref):
    p = REPO / ref['path']
    if not p.is_file():
        raise ValueError('Missing repository evidence: ' + ref['path'])
    if 'member' in ref:
        with tarfile.open(p, 'r:gz') as t:
            item = t.getmember(ref['member'])
            if not item.isfile():
                raise ValueError('Evidence member is not a file: ' + repr(ref))
            body = t.extractfile(item).read()
        return {'path': ref['path'], 'member': ref['member'], 'member_sha256': hashlib.sha256(body).hexdigest()}
    return {'path': ref['path'], 'sha256': sha(p)}

def link(ref):
    rel = os.path.relpath(REPO / ref['path'], REPO / PACKET)
    label = Path(ref['path']).name
    result = f'[{label}]({rel})'
    if 'member' in ref:
        result += f' — `{ref["member"]}`'
    return result

def main():
    OUT.mkdir(exist_ok=True)
    raw = REGISTRY.read_bytes()
    registry = json.loads(raw)
    assignments = registry['assignments']
    ordinals = [r['ordinal'] for r in assignments]
    names = [r['name'] for r in assignments]
    assert len(set(ordinals)) == len(ordinals)
    assert len(set(names)) == len(names)
    assert ordinals == list(range(1, len(assignments) + 1))
    assert registry['requested_agents'] == 60 and registry['requested_waves'] == 10
    assert len(assignments) <= 60
    missing = set(ordinals) - MAPPING.keys()
    if missing:
        raise ValueError('Need actual outcome/evidence mapping for new assignments: ' + str(sorted(missing)))
    records = []
    for a in assignments:
        assert a['wave'] == (a['ordinal'] - 1) // 6 + 1
        outcome, refs = MAPPING[a['ordinal']]
        records.append({'ordinal': a['ordinal'], 'wave': a['wave'], 'identity': '/root/' + a['name'],
                        'scope': a['task'], 'assignment_status': a['status'],
                        'outcome': outcome, 'evidence': refs})
    status = collections.Counter(a['status'] for a in assignments)
    counts = collections.Counter(a['wave'] for a in assignments)
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
    data = {
        'schema': 'p06-simulator-completion-delivery-ledger-v1',
        'state': 'provisional',
        'generated_at_utc': now,
        'purpose': 'Actual multi-agent assignment accounting and evidence navigation; not a test verdict, phase acceptance, maintainer approval or waiver.',
        'registry': {'kind': 'coordinator_actual_spawn_registry', 'file_name': REGISTRY.name,
                     'sha256': hashlib.sha256(raw).hexdigest(),
                     'limitation': 'Coordinator registry establishes recorded assignment identities/statuses; source links establish work/evidence content, not independent attribution of authorship.'},
        'requested': {'unique_agents': 60, 'logical_waves': 10, 'assignments_per_wave': 6},
        'observed': {'unique_agents': len(records), 'assignment_status_counts': dict(sorted(status.items())),
                     'not_yet_spawned': 60 - len(records),
                     'wave_counts': {str(k): counts[k] for k in range(1,11)},
                     'follow_up_tasks_count_as_additional_agents': False,
                     'all_requested_assignments_complete': len(records) == 60 and status['completed'] == 60},
        'source_checkpoints': {
            'audited_parent': '42809ff0c1b81384d7c9b079e4ef786be8407600',
            'first_native_checkpoint': 'db5ebb3a16770004423f2456ec6d0caaa0aced6d',
            'repaired_implementation': '4781ca96db15a1d130626edc7a73411a4f6c2e7c',
            'repaired_tree': '6dd0d759390cda78ec63ad0caacc00a08f03e2bc',
            'executed_pr_merge': 'e929c52d05bad80b28dd4085a97838d7fe2de354',
            'final_evidence_commit': None,
            'master_publication': 'not_yet_verified',
        },
        'verification_at_this_snapshot': {
            'repaired_host': {'status': 'pass', 'tests': 83, 'seconds': 87.502,
                              'source_tool_driver_integrity': True,
                              'evidence': archive('checkpoints/host-4781ca9.tar.gz', 'Clean repaired host receipt', 'receipt/report.json')},
            'original_parent_sensitivity': {'status': 'pass', 'intended_old_backend_failures': 8,
                                           'evidence': archive('checkpoints/parent-4781ca9.tar.gz', 'Compiled pinned-parent controls', 'report/report.json')},
            'cp_boundary': {'status': 'pass', 'positive_cells': 38, 'compiled_db5_negative_controls': 4,
                            'unit_test_methods_included_in_83': 5,
                            'evidence': archive('checkpoints/cp-allocation-repair.tar.gz', 'Original CP regression report', 'w08-a06/report.json')},
            'historical_db5_native': {'status': 'pass_with_independent_original_artifact_review', 'run_id': 45006726571,
                                      'limitation': 'Does not certify the three runtime files changed in the repaired checkpoint.'},
            'historical_db5_governance': {'status': 'pass', 'tests': 2988, 'run_id': 45006726409},
            'repaired_native': {'run_id': 45009314161, 'job_id': 137167865239,
                                'service_conclusion': 'success', 'job_finished_utc': '2026-11-22T10:06:06Z',
                                'original_artifact_review': 'pass', 'reviewer': '/root/w10_a03_repaired_native_review',
                                'artifact_id': 14749901531, 'original_zip_bytes': 2792870,
                                'original_zip_sha256': '461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9',
                                'review_report_sha256': '88659fdb99a319a61d413338c2bfa01ec0f5b7ef996191b84bde75b220f61b4e',
                                'scope': 'Two cells: native processor controls and six native public-runtime successful launches; RV64 p02-tfr timing SimX PERF1, one simulation worker, CP direct RAM.',
                                'observation_source': 'Original review read at w10-a03-native-ci/review.md; late archive retention pending.'},
            'repaired_governance': {'run_id': 45009314170, 'status': 'in_progress', 'tests_passed': None,
                                    'observation_source': 'coordinator update; exact original log still required'},
            'superseded_general_ci': [
                {'run_id': 45006726449, 'checkpoint': 'db5ebb3', 'cancellation': 'requested', 'observed_api_status': 'queued', 'conclusion': None},
                {'run_id': 45006702880, 'checkpoint': 'db5ebb3', 'cancellation': 'requested', 'observed_api_status': 'queued', 'conclusion': None},
            ],
            'cancellation_scope': 'Only the coordinator\'s two superseded general CI runs; completed original artifacts preserved. Incomplete runs are never counted as passed.',
            'whole_ci_green_claim': False,
        },
        'preserved_boundaries': [
            'The user explicitly authorized commit and push to master; that authorization does not grant a gate waiver or invent human review.',
            'Public ABI, ISA, RTL, accepted goldens, acceptance/enforcement policies and protected assets remain unchanged.',
            'Completion/host/native control evidence does not qualify counters, warm performance, P06-A02/A03, P05-A02/A03, vendor integration, physical FPGA or silicon.',
            'Frozen warm v1 remains blocked with qualified=false and absolute_no_wrap_bound not established.',
            'The inherited DSP area failure remains open under the unchanged threshold.',
            'Original development reports retain superseded hypotheses and failures; current contract and exact-source receipts define the delivered behavior.',
            'Agent count and completed assignments do not grant test success, phase acceptance, independent human approval or any waiver.',
        ],
        'next_development': 'Freeze and independently review the exact 33-selector RV64 p02-tfr timing SimX PERF1 route, coherent reads and an enforceable cumulative context-lifetime no-wrap contract; then implement reviewed guard/versioned evidence and only afterward run a fresh complete warm matrix.',
        'waves': [{'wave': n, 'title': title, 'progression': desc, 'actual_assignments': counts[n]} for n,(title,desc) in WAVES.items()],
        'assignments': records,
        'pending_finalization': [
            'Record actual completion of this #59 checkpoint and the eventual #60 verdict; all 60 identities already exist.',
            'Retain late original native/governance and independent review artifacts, including the seven original Wave1/2 reports.',
            'Retain the completed repaired native original-artifact review and record the exact governance outcome from original completed logs.',
            'Confirm requested superseded-run cancellation status from the service API.',
            'Refresh the final packet manifest and independently review the final claims/evidence delta.',
            'Verify current remote ancestry and the eventual authorized master publication; no final commit hash is guessed here.',
        ],
    }
    (REPO / PACKET / 'delivery-ledger.json').write_text(json.dumps(data, indent=2) + '\n')
    intro = [
        '# Simulator completion delivery ledger', '',
        '**Provisional coordination record.** This snapshot contains '
        f'**{len(records)} actual unique agents**, **{status["completed"]} completed assignments** and '
        f'**{60-len(records)} not yet spawned** against the requested 60 agents across 10 logical waves. '
        'Follow-up work is recorded under the original identity. No missing agent or pending verdict is counted as completed.', '',
        f'Generated at `{now}` from coordinator registry SHA-256 '
        f'`{hashlib.sha256(raw).hexdigest()}`. The [machine-readable ledger](delivery-ledger.json) '
        'records the complete identity, scope, outcome and evidence mapping. This is assignment accounting, '
        'not a test verdict, phase acceptance, maintainer approval or waiver.', '',
        '## Selected development step', '',
        'The audit chose simulator completion and exceptional full-platform teardown as the prerequisite '
        'to future counter qualification. Both runtime adapters must consume asynchronous results, preserve '
        'the first busy observation and make processor failures terminal. Legacy SimX `run()` returns '
        'architectural gp data, so successful nonzero and -1 values remain successful through the checked '
        'void path. The later consumer audit found and repaired a separate CP scratch allocation regression; '
        'recoverable CP OOM behavior remains intact. See the '
        '[audit](../../p06-simulator-completion-audit.md) and '
        '[implemented contract](../../../designs/simulator_completion_v1.md).', '',
        'Original Wave1 proposals included a nonzero-return-as-error hypothesis. That proposal was corrected '
        'during development. Historical reports and failed attempts remain historical evidence, not the '
        'definition of the final implementation.', '',
        '## Source and verification snapshot', '',
        '| Item | Observed state and scope |', '|---|---|',
        '| Audited parent | `42809ff0c1b81384d7c9b079e4ef786be8407600` |',
        '| First native checkpoint | `db5ebb3a16770004423f2456ec6d0caaa0aced6d`; successful historical native controls and 2,988 governance tests, before the CP error-boundary correction |',
        '| Repaired implementation | `4781ca96db15a1d130626edc7a73411a4f6c2e7c`; tree `6dd0d759390cda78ec63ad0caacc00a08f03e2bc` |',
        '| Repaired host receipt | 83 distinct tests passed in 87.502 seconds with stable source/tool/driver identities; [original receipt](checkpoints/host-4781ca9.tar.gz), member `receipt/report.json` |',
        '| Original-parent sensitivity | Eight intended failures after successful compilation of original backends; [original packet](checkpoints/parent-4781ca9.tar.gz), member `report/report.json` |',
        '| CP compatibility regression | 38 positive cells and four compiled db5 negative controls; its five methods are already included in the 83-test total; [packet](checkpoints/cp-allocation-repair.tar.gz), member `w08-a06/report.json` |',
        '| Repaired native | [Run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161), job 137167865239: independent original-artifact **PASS** by #57 for two declared RV64 p02-tfr timing SimX cells at repaired source. Original ZIP SHA-256 `461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9`; late archive retention pending |',
        '| Repaired governance | [Run 45009314170](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314170) remains in progress; no final test count or pass is claimed |',
        '| Superseded general CI | Cancellation requested only for db5 runs [45006726449](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726449) and [45006702880](https://github.com/baabi-boo/AI-GPU/actions/runs/45006702880). Latest coordinator API observation still showed queued, with no conclusion. These incomplete runs are not passes |',
        '| Master publication | Authorized by the user; final evidence commit and actual remote publication are not yet verified |', '',
        'The [checkpoint index](checkpoints/index.json) identifies original archive bytes and source scopes. '
        'Current host checks use controlled models where stated. Historical db5 native success does not '
        'certify the three runtime files changed afterward. No whole-CI-green claim is made.', '',
        '## Ten-wave progression', '',
        '| Wave | Purpose | Actual assignments | Progression |', '|---|---|---:|---|',
    ]
    for n,(title,desc) in WAVES.items():
        intro.append(f'| {n} | {title} | {counts[n]}/6 | {desc} |')
    intro += ['', '## Actual assignments', '',
        'Every identity below is present in the coordinator registry. A completed implementation or review '
        'assignment can precede a later finding or repair. Evidence links identify existing source or retained '
        'reports; they do not independently authenticate per-agent authorship. Archive member names are '
        'shown explicitly instead of linking to nonexistent extracted files. Late Wave10 review reports '
        'await their append-only archival step; existing source/evidence pointers identify the reviewed scope.', '']
    for n,(title,_) in WAVES.items():
        intro += [f'### Wave {n}: {title}', '',
                  '| # / actual identity | Assignment status | Scope and observed outcome | Existing source or evidence |',
                  '|---|---|---|---|']
        for r in records:
            if r['wave'] != n:
                continue
            refs = '; '.join(link(x) for x in r['evidence'])
            intro.append(f'| {r["ordinal"]} — `{r["identity"]}` | `{r["assignment_status"]}` | **{r["scope"]}.** {r["outcome"]} | {refs} |')
        intro.append('')
    intro += ['## Preserved gates and next step', '',
        'Public ABI, ISA, RTL, accepted goldens, enforcement/acceptance policies and protected assets remain '
        'unchanged. The user explicitly authorized commit and push to `master`; that authorization grants '
        'no waiver and supplies no invented human review. Agent counts do not establish test or phase acceptance.', '',
        'P06 counter qualification and A02/A03 remain open. Frozen warm v1 remains blocked with '
        '`qualified=false` and `absolute_no_wrap_bound` not established. P05 framework review, P01 vendor '
        'integration, the inherited DSP area failure and physical FPGA/silicon gates remain separate open '
        'obligations. See [canonical phase gates](../../roadmap.json), '
        '[acceptance policy](../../acceptance.md) and [workspace handoff](../../p06-workspace-handoff.md).', '',
        'The next bounded development is to freeze and independently review the exact 33-selector '
        'RV64 p02-tfr timing SimX PERF1 route, coherent reads and an enforceable cumulative context-lifetime '
        'no-wrap contract. Reviewed guard implementation and a versioned evidence path precede a fresh '
        'complete warm matrix; neither is supplied by this completion repair. The '
        '[qualification plan](../../p06-mpm-qualification-plan.md) retains the exact obligations.', '',
        '## Remaining ledger finalization', '']
    intro += ['- ' + item for item in data['pending_finalization']]
    intro += ['']
    (REPO / PACKET / 'delivery-ledger.md').write_text('\n'.join(intro))
    (OUT / 'agent-ledger-source.snapshot.json').write_bytes(raw)
    (OUT / 'source-evidence-mapping.json').write_text(json.dumps(records, indent=2) + '\n')
    original_names = ['w01-a01-counter-semantics.md','w01-a02-architecture.md','w01-a03-native-coverage.md',
                      'w01-a04-error-path.md','w01-a05-failure-tests.md','w01-a06-rtl-scope.md',
                      'w02-a02-harness-report.md']
    original_records = [{'name': n, 'size_bytes': (ROOT/n).stat().st_size, 'sha256': sha(ROOT/n),
                         'retention': 'Existing scratch original; requested for late append-only review archive, not yet linked as retained.'} for n in original_names]
    (OUT / 'original-report-inventory.json').write_text(json.dumps(original_records, indent=2) + '\n')
    checks = []
    for r in records:
        for ref in r['evidence']:
            checks.append({'assignment': r['ordinal'], **check_reference(ref)})
    for item in data['verification_at_this_snapshot'].values():
        if isinstance(item,dict) and 'evidence' in item:
            checks.append({'verification': True, **check_reference(item['evidence'])})
    for path in [REPO/PACKET/'delivery-ledger.md']:
        text = path.read_text()
        for match in re.finditer(r'\[[^\]]+\]\(([^)]+)\)',text):
            target=match.group(1)
            if target.startswith(('https://','http://','#')):
                continue
            assert (path.parent/target.split('#',1)[0]).is_file(), target
    result = {'status':'pass', 'actual_agents':len(records), 'unique_identities':len(set(names)),
              'requested_agents':60, 'status_counts':dict(status), 'wave_counts':dict(counts),
              'existing_evidence_references_checked':len(checks),
              'no_missing_agent_synthesized':True, 'no_native_build_or_commit_or_push':True,
              'registry_sha256':hashlib.sha256(raw).hexdigest(),
              'ledger_json_sha256':sha(REPO/PACKET/'delivery-ledger.json'),
              'ledger_markdown_sha256':sha(REPO/PACKET/'delivery-ledger.md'),
              'reference_checks':checks}
    (OUT/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='reference_checks'},indent=2))

if __name__ == '__main__':
    main()
