#!/usr/bin/env python3
"""Read-only independent audit of completed governance logs at repaired 4781ca9."""
import argparse
import ast
from collections import Counter
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/ea983fdea786/AI-GPU')
CHECKPOINT = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
MERGE = 'e929c52d05bad80b28dd4085a97838d7fe2de354'
TREE = '6dd0d759390cda78ec63ad0caacc00a08f03e2bc'
COMMAND = "python3 -m unittest discover -s ci/project -p 'test_*.py' -v"
CASES = {
    'pr': (45009314170, 137167865708, 'pull_request', MERGE),
    'push': (45009309941, 137167851515, 'push', CHECKPOINT),
}
TIMESTAMP = re.compile(r'^\ufeff?(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z) (.*)$')
ANSI = re.compile(r'\x1b\[[0-9;]*m')
RESULT = re.compile(r'(test\S+) \(([A-Za-z_]\w*\.[A-Za-z_]\w*\.[A-Za-z_]\w*)\)(?: \.\.\. (.+))?')

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('case', choices=CASES)
args = parser.parse_args()
run_id, job_id, event, executed = CASES[args.case]
run = json.loads((ROOT / (args.case + '-run.json')).read_text())
jobs = json.loads((ROOT / (args.case + '-jobs.json')).read_text())
merge = json.loads((ROOT / 'github-merge-commit.json').read_text())
assert run['id'] == run_id and run['run_attempt'] == 1
assert run['event'] == event and run['head_sha'] == CHECKPOINT
assert run['repository']['full_name'] == 'baabi-boo/AI-GPU'
assert run['path'] == '.github/workflows/project-governance.yml'
assert run['status'] == 'completed' and run['conclusion'] == 'success'
assert jobs['total_count'] == len(jobs['jobs']) == 1
job = jobs['jobs'][0]
assert job['id'] == job_id and job['run_id'] == run_id and job['name'] == 'governance'
assert job['status'] == 'completed' and job['conclusion'] == 'success'
assert job['started_at'] and job['completed_at']
assert all(step['status'] == 'completed' and step['conclusion'] == 'success' for step in job['steps'])
test_steps = [step for step in job['steps'] if step['name'] == 'Test governance tooling']
assert len(test_steps) == 1 and test_steps[0]['started_at'] and test_steps[0]['completed_at']
assert job['steps'][-1]['name'] == 'Complete job'
assert merge['sha'] == MERGE and merge['commit']['tree']['sha'] == TREE
assert [parent['sha'] for parent in merge['parents']] == [
    '42809ff0c1b81384d7c9b079e4ef786be8407600', CHECKPOINT]
assert git('rev-parse', CHECKPOINT + '^{tree}').decode().strip() == TREE
commit_body = git('cat-file', 'commit', CHECKPOINT)
assert hashlib.sha1(b'commit ' + str(len(commit_body)).encode() + b'\0' + commit_body).hexdigest() == CHECKPOINT
(ROOT / 'source-checkpoint.commit').write_bytes(commit_body)
workflow = git('show', CHECKPOINT + ':.github/workflows/project-governance.yml')
assert workflow.decode().count('run: ' + COMMAND) == 1
(ROOT / 'project-governance-4781ca9.yml').write_bytes(workflow)

log_path = ROOT / ('job-' + str(job_id) + '.log')
log_bytes = log_path.read_bytes()
lines = []
for number, raw in enumerate(log_bytes.decode('utf-8').splitlines(), start=1):
    match = TIMESTAMP.fullmatch(raw)
    assert match is not None, ('missing timestamp', number, raw[:80])
    lines.append({'line': number, 'timestamp': match[1], 'text': ANSI.sub('', match[2])})
texts = [line['text'] for line in lines]
commit_markers = [index for index, line in enumerate(texts) if line.endswith('git log -1 --format=%H')]
assert len(commit_markers) == 1 and texts[commit_markers[0] + 1] == executed
assert 'Source: ' + executed + ' (tracked changes: False)' in texts
starts = [index for index, line in enumerate(texts) if line == '##[group]Run ' + COMMAND]
assert len(starts) == 1
start = starts[0]
summaries = [(index, re.fullmatch(r'Ran ([0-9]+) tests in ([0-9]+(?:\.[0-9]+)?)s', row['text']))
             for index, row in enumerate(lines) if index > start]
summaries = [(index, match) for index, match in summaries if match]
assert len(summaries) == 1
summary_index, suite_summary = summaries[0]
total = int(suite_summary[1])
duration = float(suite_summary[2])
assert total > 0 and duration > 0
assert lines[summary_index + 1]['text'] == '' and lines[summary_index + 2]['text'] == 'OK'
assert any('Post job cleanup.' in line for line in texts[summary_index + 3:])
assert not any(re.match(r'FAILED\b|ERROR:|FAIL:|##\[error\]', line) for line in texts[start:])

rows, pending = [], None
source_records = {}
for index in range(start + 1, summary_index):
    row = lines[index]
    match = RESULT.fullmatch(row['text'])
    if match:
        assert pending is None, 'unfinished test result'
        method, identity, status = match.groups()
        module, class_name, actual_method = identity.split('.')
        assert method == actual_method
        source_path = 'ci/project/' + module + '.py'
        if module not in source_records:
            data = git('show', CHECKPOINT + ':' + source_path)
            source_records[module] = {'path': source_path, 'size_bytes': len(data), 'sha256': sha(data),
                                      'git_blob': git('rev-parse', CHECKPOINT + ':' + source_path).decode().strip()}
        result = {'id': identity, 'method': method, 'module': module, 'status': status,
                  'line': row['line'], 'timestamp': row['timestamp']}
        if status is None:
            # unittest may print a method's short docstring on a second line.
            tree = ast.parse(git('show', CHECKPOINT + ':' + source_path).decode())
            classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name]
            assert len(classes) == 1
            methods = [node for node in classes[0].body if isinstance(node, ast.FunctionDef) and node.name == method]
            assert len(methods) == 1
            doc = ast.get_docstring(methods[0])
            assert doc
            pending = (result, doc.splitlines()[0].strip())
        else:
            assert status == 'ok', result
            rows.append(result)
    elif pending is not None:
        result, docstring = pending
        assert row['text'] == docstring + ' ... ok', row
        result.update(status='ok', completion_line=row['line'], completion_timestamp=row['timestamp'],
                      docstring_verified_against_checkpoint=True)
        rows.append(result)
        pending = None
    elif row['text'].startswith('test'):
        raise AssertionError(('unparsed result', row))
assert pending is None
assert len(rows) == total
assert len({row['id'] for row in rows}) == total
assert {row['status'] for row in rows} == {'ok'}
focused = [row for row in rows if row['module'].startswith('test_p06_simulator_')]
step_duration = (datetime.fromisoformat(test_steps[0]['completed_at']) -
                 datetime.fromisoformat(test_steps[0]['started_at'])).total_seconds()
assert duration <= step_duration + 2
summary = {
    'outcome': 'pass', 'scope': 'governance and bounded host tests at repaired 4781ca9; no broad-CI claim',
    'checkpoint': CHECKPOINT, 'executed_commit': executed, 'tree': TREE,
    'run_id': run_id, 'job_id': job_id, 'event': event, 'run_attempt': run['run_attempt'],
    'command': COMMAND, 'tests': total, 'unique_test_results': len({row['id'] for row in rows}),
    'test_statuses': sorted({row['status'] for row in rows}), 'duration_seconds': duration,
    'suite_summary_line': lines[summary_index]['text'], 'suite_summary_timestamp': lines[summary_index]['timestamp'],
    'test_step_duration_seconds': step_duration, 'job_started_at': job['started_at'],
    'job_completed_at': job['completed_at'], 'all_job_steps_successful': True,
    'source_clean_observed': True, 'focused_completion_test_count': len(focused),
    'focused_completion_modules': dict(sorted(Counter(row['module'] for row in focused).items())),
    'test_source_modules_bound_to_checkpoint': len(source_records),
    'docstring_result_lines_verified_against_source': sum(bool(row.get('docstring_verified_against_checkpoint')) for row in rows),
    'log_bytes': len(log_bytes), 'log_sha256': sha(log_bytes), 'workflow_sha256': sha(workflow),
    'native_packet_untouched': True, 'tests_run_locally_by_this_audit': False,
}
save(args.case + '-test-results.json', rows)
save(args.case + '-test-source-identities.json', list(source_records.values()))
save(args.case + '-governance-summary.json', summary)
print(json.dumps(summary, indent=2))
