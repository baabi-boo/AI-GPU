from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
HERE = ROOT.parent / 'w09-a03-final'
NAMES = ('README.md', 'docs/project/status.md', 'docs/project/backlog.md',
         'docs/project/p06-simulator-completion-audit.md')
texts = {name: (ROOT / name).read_text() for name in NAMES}
before = {}
for name in NAMES:
    data = (ROOT / name).read_bytes()
    before[name] = hashlib.sha256(data).hexdigest()
    target = HERE / 'before' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
(HERE / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')

def replace(name, old, new):
    assert texts[name].count(old) == 1, (name, old[:120], texts[name].count(old))
    texts[name] = texts[name].replace(old, new)

replace('README.md',
'''**Current work: P06-T01 — close simulator completion verification, then qualify
the exact counter route (`in_progress`), with [P06-A01 accepted](docs/project/evidence/p06-baseline/acceptance.json).**''',
'''**Current work: P06-T01 — qualify the exact counter route after the reviewed
simulator completion repair (`in_progress`), with [P06-A01 accepted](docs/project/evidence/p06-baseline/acceptance.json).**''')
replace('README.md',
'''At checkpoint `db5ebb3`, the hosted native completion controls passed, including
a real model exception followed by a fresh context and six successful public
launches; all 2,988 governance tests passed. The subsequent allocation-error
repair has independent host regression and review, including the unchanged
lifecycle suite. At repaired checkpoint `4781ca9`, all **83 focused host tests**
and the eight compiled-parent failure controls pass. **Native verification of the repaired checkpoint `4781ca9` and final evidence
reconciliation remain pending.** The [completion evidence packet](docs/project/evidence/p06-simulator-completion/README.md)
separates these revisions, raw failures and verification scopes.''',
'''At repaired checkpoint
[`4781ca9`](https://github.com/baabi-boo/AI-GPU/commit/4781ca96db15a1d130626edc7a73411a4f6c2e7c),
all **83 focused host tests** and the eight compiled-parent failure controls pass.
The unchanged lifecycle suite verifies recoverable allocation errors and
same-device continuation; separate processor-fault controls keep execution
failures terminal. The fresh
[native completion run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161)
also passed independent original-artifact review: a real model exception is
followed by successful fresh-context execution, and six public launches produce
exact outputs with nonzero `gp`. This is RV64 `p02-tfr`, timing SimX, `PERF=1`,
one worker and direct-RAM CP scope. It does not qualify native RTL or a native
public-runtime injected fault.

The [completion evidence packet](docs/project/evidence/p06-simulator-completion/README.md)
retains both checkpoints, original failures, source/tool identities and reviews.
The repaired checkpoint's full governance result is still pending; the earlier
2,988-test `db5ebb3` result remains historical. Subsequent documentation/evidence
additions preserve the tested execution inputs and are checked separately; the
native result remains bound to `4781ca9`.''')

replace('docs/project/status.md',
'''At `db5ebb3`, dedicated native completion controls and 2,988 governance tests
passed. A later repair to that CP error boundary has independent host regression
and review; native verification of repaired checkpoint `4781ca9` and final packet
reconciliation remain pending. The [evidence packet](evidence/p06-simulator-completion/README.md)
records each result's source and scope.''',
'''At repaired checkpoint `4781ca9`, **83 focused host tests**, the eight compiled-parent
failure controls and the fresh dedicated native completion controls pass.
Independent original-artifact review binds native execution to the exact repaired
tree. The full governance result for that checkpoint remains pending; the earlier
`db5ebb3` native and 2,988-test receipts remain historical. The
[evidence packet](evidence/p06-simulator-completion/README.md) records each result's
source and scope, including the later documentation/evidence source projection.''')
replace('docs/project/status.md',
'''| P06 — Memory and performance scaling | `in_progress` | A01 cold acceptance, original workspace correctness and reviewed RV64 transport evidence are preserved; completion/teardown repair has native checkpoint evidence and a later host-reviewed CP-error correction awaiting exact-source native closeout; counter/coherence/no-wrap qualification and A02/A03 remain open |''',
'''| P06 — Memory and performance scaling | `in_progress` | A01 cold acceptance, original workspace correctness and reviewed RV64 transport evidence are preserved; repaired completion/teardown and CP-error behavior have independent host/native review at `4781ca9`; counter/coherence/no-wrap qualification and A02/A03 remain open |''')
replace('docs/project/status.md',
'''The compiled audited-parent replay also passed all eight intended old-backend
failure controls. The checkpoint's queued
[native run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161)
and final evidence reconciliation remain pending. The PR merge
`e929c52d05bad80b28dd4085a97838d7fe2de354` has the same tree as that checkpoint.
The [completion packet](evidence/p06-simulator-completion/README.md)
is the source for exact receipts, original logs, historical failures and review
scope. Host fault injection and actual timing/functional framework tests do not
establish native public-runtime fault injection, native functional SimX,
multiworker exception recovery or processor RTL execution. The local 15 GiB
native disk reserve remains enforced; native execution uses adequately
provisioned hosted CI.''',
'''The compiled audited-parent replay also passed all eight intended old-backend
failure controls. The fresh
[native run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161)
passed both native cells, and independent original-artifact review verified the
actual repaired runtime/helper and contract bytes. The executed PR merge
`e929c52d05bad80b28dd4085a97838d7fe2de354` has the same tree,
`6dd0d759390cda78ec63ad0caacc00a08f03e2bc`, as that checkpoint.
The original ZIP and review are retained in the
[repaired native packet](evidence/p06-simulator-completion/checkpoints/native-4781ca9.tar.gz).

The declared native route is RV64 `p02-tfr`, timing SimX, `PERF=1`, one worker and
direct-RAM CP. It repeats the real-model fault/legacy-success/fresh-context unit
and six public success launches. It does not inject a native public-runtime
fault or establish native functional SimX, multiworker exception recovery or
processor RTL execution. The local 15 GiB native disk reserve remains enforced;
native execution used adequately provisioned hosted CI.

The full governance result for the repaired checkpoint remains pending. The
[completion packet](evidence/p06-simulator-completion/README.md) retains exact
receipts, original logs, historical failures and review scope. The later delivery
adds only README/project documentation and evidence. Independent source
projection checks the unchanged execution inputs against tested `4781ca9`;
earlier CI is not represented as an execution of the later documentation tree.''')
replace('docs/project/status.md',
'''**P06-T01 — close the repaired completion checkpoint, then freeze the exact
counter-qualification contract.** Complete native verification of the narrowed
CP error boundary and reconcile its host/native/review receipts in the
[completion packet](evidence/p06-simulator-completion/README.md). Earlier native
success at `db5ebb3` does not verify subsequent production changes. Preserve all
failed controls and the 15 GiB native disk reserve.

The next implementation is the [versioned qualification route](p06-mpm-qualification-plan.md)''',
'''**P06-T01 — freeze and independently review the exact counter-qualification
contract.** The [completion packet](evidence/p06-simulator-completion/README.md)
now has fresh independently reviewed native evidence for repaired `4781ca9`,
alongside its host and parent controls. Preserve the recorded source scopes,
failed controls and 15 GiB native disk reserve.

The next implementation is the [versioned qualification route](p06-mpm-qualification-plan.md)''')

replace('docs/project/backlog.md',
'''## Start here: P06-T01 completion closeout and exact counter qualification

**Current bounded task: P06-T01 — verify the final completion repair, then freeze
the exact counter-qualification contract.**''',
'''## Start here: P06-T01 exact counter qualification

**Current bounded task: P06-T01 — freeze and independently review the exact
counter-qualification contract after the simulator completion repair.**''')
replace('docs/project/backlog.md',
'''clean focused suite passed **83 tests**, and all eight compiled-parent failure
controls passed. Native verification and final packet reconciliation remain pending; use the
[completion evidence index](evidence/p06-simulator-completion/README.md) for exact
source, command and review scope.''',
'''clean focused suite passed **83 tests**, all eight compiled-parent failure
controls passed, and fresh
[native run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161)
passed independent original-artifact review. That native scope is RV64 `p02-tfr`,
timing SimX, `PERF=1`, one worker and direct-RAM CP; it covers the actual-model
fault/success unit and six public successes. The full governance outcome for this
checkpoint remains pending. Use the
[completion evidence index](evidence/p06-simulator-completion/README.md) for exact
source, command and review scope. Documentation/evidence additions preserve the
tested inputs without relabeling the earlier execution as a run of the later tree.''')
replace('docs/project/backlog.md',
'''[simulator completion prerequisite](p06-simulator-completion-audit.md) has native
checkpoint evidence and a later host-reviewed CP-error correction; close exact-source
native verification and final review before versioned counter qualification and
a fresh complete warm attempt.''',
'''[simulator completion prerequisite](p06-simulator-completion-audit.md) now has
independently reviewed host and fresh native evidence for the repaired CP-error
boundary at `4781ca9`. Freeze the versioned counter contract and prove its exact
scope before implementing qualification and collecting a fresh complete warm attempt.''')
replace('docs/project/backlog.md',
'''| **P06-T01 — Measured optimization — in progress** | Close native verification/review of the final completion and CP-error repair, then freeze and qualify all 33 available counters in the exact configuration, coherent reads and enforceable context-lifetime no-wrap bounds before the unchanged fresh warm matrix; track broader CI/publication separately. |''',
'''| **P06-T01 — Measured optimization — in progress** | Build on the reviewed completion repair: freeze and qualify all 33 available counters in the exact configuration, coherent reads and enforceable context-lifetime no-wrap bounds before the unchanged fresh warm matrix; track broader CI/publication separately. |''')

replace('docs/project/p06-simulator-completion-audit.md',
'''correction has independent host regression and review. Its checkpoint is
`4781ca96db15a1d130626edc7a73411a4f6c2e7c`;
[native run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161)
and final evidence reconciliation remain pending. The queued PR run checks merge
`e929c52d05bad80b28dd4085a97838d7fe2de354`, whose tree equals the checkpoint. The
[evidence packet](evidence/p06-simulator-completion/README.md) records the distinct
revisions and original results. No performance or phase acceptance follows from
either checkpoint.''',
'''correction has independent host regression, source review and fresh native
verification at `4781ca96db15a1d130626edc7a73411a4f6c2e7c`.
[Native run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161)
passed both declared cells, with independent review of the original artifact.
Its executed merge `e929c52d05bad80b28dd4085a97838d7fe2de354` has the identical
tree `6dd0d759390cda78ec63ad0caacc00a08f03e2bc`. The full governance result at
the repaired checkpoint remains pending. The
[evidence packet](evidence/p06-simulator-completion/README.md) records the distinct
revisions and original results. No performance or phase acceptance follows from
either checkpoint.''')
replace('docs/project/p06-simulator-completion-audit.md',
'''| Real linked processor unit | **Five contexts:** nine checked successes, three legacy successes, one checked `OutOfRange`, one legacy caught exception; fresh normal context after the fault | Real Processor/RAM and legacy `gp` values `7`/`-1`; not native public-runtime injected failure |''',
'''| Fresh repaired native run | [Run 45009314161](https://github.com/baabi-boo/AI-GPU/actions/runs/45009314161) passes at `4781ca9`, executed as same-tree merge `e929c52d05bad80b28dd4085a97838d7fe2de354`; independent original-artifact review passes | Exact repaired runtime/helper and contract bytes; RV64 `p02-tfr`, timing SimX, `PERF=1`, one worker, direct-RAM CP |
| Real linked processor unit in both native runs | **Five contexts:** nine checked successes, three legacy successes, one checked `OutOfRange`, one legacy caught exception; fresh normal context after the fault | Real Processor/RAM and legacy `gp` values `7`/`-1`; not native public-runtime injected failure |''')
replace('docs/project/p06-simulator-completion-audit.md',
'''| Native public success | **Two contexts, six launches**, nonzero `gp`, exact global-data/output witnesses and cleanup |''',
'''| Native public success in both native runs | **Two contexts, six launches**, nonzero `gp`, exact global-data/output witnesses and cleanup |''')
replace('docs/project/p06-simulator-completion-audit.md',
'''| Both backend adapters with RAM/LLC as applicable, controlled Processor/RAM; native verification of this later repair remains pending |''',
'''| Both backend adapters with RAM/LLC as applicable, controlled Processor/RAM; the separate repaired native packet establishes only its declared native scope |''')
replace('docs/project/p06-simulator-completion-audit.md',
'''close verification of that repair. The [evidence packet](evidence/p06-simulator-completion/README.md)
is the authority for the final repaired revision and its eventual receipts.''',
'''close verification of that repair. The fresh
[repaired native archive](evidence/p06-simulator-completion/checkpoints/native-4781ca9.tar.gz)
retains artifact `14749901531`, whose original ZIP is 2,792,870 bytes with SHA-256
`461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9`.
Its independent review again checks 761 source bodies, 18 command/log records,
five compiler/header roles and 87 actual model-object compile commands, including
the three repaired runtime/helper files and completion contract.

The execution checkpoint remains `4781ca9`. Later additions are confined to
README/project documentation and evidence; independent source projection checks
all 3,339 existing blobs outside that allowlist, including every one of the 761
native-retained inputs, against the tested bytes. The allowlist has no overlap
with those native inputs. A later documentation/evidence commit is not described
as the entire tree executed by earlier CI. Structural and manifest validation
apply separately to the assembled documents. The
[evidence packet](evidence/p06-simulator-completion/README.md) retains the exact
projection and final publication observations when completed.''')
replace('docs/project/p06-simulator-completion-audit.md',
'''Close native verification and independent evidence review for the exact repaired
completion revision. Then freeze and review the
[versioned counter qualification contract](p06-mpm-qualification-plan.md) before
implementing its enforcement.''',
'''Build on the independently reviewed host and fresh native evidence for repaired
`4781ca9`. Freeze and review the
[versioned counter qualification contract](p06-mpm-qualification-plan.md) before
implementing its enforcement.''')

for name, value in texts.items():
    (ROOT / name).write_text(value)
print('Updated only the four owned documents for repaired native PASS; current full governance remains pending.')
