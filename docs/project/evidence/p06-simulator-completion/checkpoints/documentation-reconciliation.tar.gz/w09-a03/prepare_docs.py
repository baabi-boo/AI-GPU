from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
OUT = Path('/workspace/scratch/ea983fdea786/w09-a03')
NAMES = ('README.md', 'docs/project/status.md', 'docs/project/backlog.md',
         'docs/project/p06-simulator-completion-audit.md')
texts = {name: (ROOT / name).read_text() for name in NAMES}
before = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in NAMES}

def replace(name, old, new):
    assert texts[name].count(old) == 1, (name, old[:100], texts[name].count(old))
    texts[name] = texts[name].replace(old, new)

replace('README.md',
'''**Current work: P06-T01 — simulator completion verification before counter qualification
(`in_progress`), with [P06-A01 accepted](docs/project/evidence/p06-baseline/acceptance.json).**''',
'''**Current work: P06-T01 — close simulator completion verification, then qualify
the exact counter route (`in_progress`), with [P06-A01 accepted](docs/project/evidence/p06-baseline/acceptance.json).**''')
replace('README.md',
'''visible. Broader CI is still in progress at this checkpoint, as separately
tracked in the [transport evidence packet](docs/project/evidence/p06-mpm-transport/README.md).
The [completion audit](docs/project/p06-simulator-completion-audit.md) found a
prerequisite: simulator exceptions could disappear, and an immediately completed
task could miss the command processor's busy edge. The
[completion changes](docs/designs/simulator_completion_v1.md) preserve valid
SimX `gp` values, including `-1`, while consuming asynchronous results, retaining
terminal failure and joining pending work before teardown. Host backend/public
checks and built-parent behavioral failures are available. A further host probe
found an outstanding simulated-channel count surviving exceptional teardown;
that cleanup repair remains in progress. **Native completion execution remains
`not_run` pending hosted CI**, and checkpoint evidence is incomplete. Resolve
and verify that blocker, complete native verification and independent review,
then follow the [versioned counter qualification plan](docs/project/p06-mpm-qualification-plan.md)
for exact configuration/selector coverage, coherent reads and an absolute no-wrap
bound. Only then collect the unchanged fresh warm matrix: 24 processes,
792 launches and 25,344 exact output words. **P06 and P06-T01 remain
`in_progress`; P06-A02/A03 remain open.** Warm v1 stays unconditionally blocked;
these repairs do not qualify historical measurements or establish a speedup.''',
'''visible in the [transport evidence packet](docs/project/evidence/p06-mpm-transport/README.md),
which retains that repair's separate integration and publication history.

The [completion audit](docs/project/p06-simulator-completion-audit.md) found a
prerequisite: simulator exceptions could disappear, an immediately completed
task could miss the command processor's busy edge, and abandoned channel
accounting could survive full teardown. The
[completion implementation](docs/designs/simulator_completion_v1.md) consumes
execution results, preserves valid `gp` values including `-1`, retains processor
failure, joins pending work, and retires abandoned accounting only after complete
platform disposal. The narrowed error boundary also preserves the existing
recoverable command-processor allocation-error path and same-device continuation.

At checkpoint `db5ebb3`, the hosted native completion controls passed, including
a real model exception followed by a fresh context and six successful public
launches; all 2,988 governance tests passed. The subsequent allocation-error
repair has independent host regression and review, including the unchanged
lifecycle suite. **Native verification of that later repair and final evidence
reconciliation remain pending.** The [completion evidence packet](docs/project/evidence/p06-simulator-completion/README.md)
separates these revisions, raw failures and verification scopes.

The next development step is the [versioned counter qualification plan](docs/project/p06-mpm-qualification-plan.md):
cover all **33 available counters** in the exact RV64 tensor configuration,
prove coherent reads and establish an enforceable cumulative no-wrap bound.
No such guard or bound is implemented by this completion repair. Only after
that qualification should the unchanged fresh warm matrix run: 24 processes,
792 launches and 25,344 exact output words. **P06 and P06-T01 remain
`in_progress`; P06-A02/A03 remain open.** Warm v1 stays unconditionally blocked;
these repairs do not qualify historical measurements or establish a speedup.''')
replace('README.md',
'''- Start the next bounded task: [simulator completion audit](docs/project/p06-simulator-completion-audit.md)
  and [completion contract](docs/designs/simulator_completion_v1.md), then the
  [counter qualification plan](docs/project/p06-mpm-qualification-plan.md).''',
'''- Review the [simulator completion audit](docs/project/p06-simulator-completion-audit.md),
  [contract](docs/designs/simulator_completion_v1.md) and
  [source-bound verification packet](docs/project/evidence/p06-simulator-completion/README.md),
  then start the [exact counter qualification plan](docs/project/p06-mpm-qualification-plan.md).''')

replace('docs/project/status.md',
'''raw RV64 area failures remain failures. Broader CI is still running at this
checkpoint, with final integration/publication tracked in the
[handoff](p06-mpm-transport-handoff.md).
The [completion audit](p06-simulator-completion-audit.md) identifies reliable
asynchronous simulator completion as the prerequisite to that qualification.
The [completion implementation](../designs/simulator_completion_v1.md) and host
checks are present. A further production-SimObject host probe exposes an
outstanding-channel count surviving exceptional teardown; its cleanup repair is
in progress. Native completion execution remains `not_run` pending hosted CI,
and checkpoint evidence reconciliation is incomplete. Resolve that blocker and
complete native verification and independent review before the
[versioned qualification plan](p06-mpm-qualification-plan.md), then collect a fresh
complete warm attempt under the [implemented contract](../designs/warm_workspace_benchmark_v1.md).
Its unconditional v1 block, `P06-WARM-RV64-MPM-HIGH-HALF`, remains in force with
`qualified=false`; the repair cannot recover missing historical high bits.
No warm speedup or new P06 gate is accepted.''',
'''raw RV64 area failures remain failures. The
[handoff](p06-mpm-transport-handoff.md) retains that repair's separate integration
and publication history.

The [completion audit](p06-simulator-completion-audit.md) identified a prerequisite:
execution faults must reach public waits before a future counter guard can be
trusted. The [implementation](../designs/simulator_completion_v1.md) now consumes
asynchronous results, preserves the first busy edge, keeps processor failures
terminal and clears abandoned channel accounting at complete platform disposal.
It also preserves the inherited recoverable CP-copy allocation-error path.
At `db5ebb3`, dedicated native completion controls and 2,988 governance tests
passed. A later repair to that CP error boundary has independent host regression
and review; native verification of its exact revision and final packet
reconciliation remain pending. The [evidence packet](evidence/p06-simulator-completion/README.md)
records each result's source and scope.

The next development is the [exact counter qualification contract](p06-mpm-qualification-plan.md):
all 33 available selectors, coherent reads and an enforceable cumulative no-wrap
proof, followed only then by a fresh complete warm attempt. The
[implemented warm v1 contract](../designs/warm_workspace_benchmark_v1.md) remains
unconditionally blocked by `P06-WARM-RV64-MPM-HIGH-HALF`, with `qualified=false`
and no absolute no-wrap bound. No counter guard, warm speedup or new P06 gate is
established by the completion repair.''')
replace('docs/project/status.md',
'''| P06 — Memory and performance scaling | `in_progress` | A01 cold acceptance, original workspace correctness and reviewed RV64 transport evidence are preserved; async completion has host checks, with exceptional channel cleanup, native verification and final evidence review still pending before counter/warm qualification; A02/A03 stay open |''',
'''| P06 — Memory and performance scaling | `in_progress` | A01 cold acceptance, original workspace correctness and reviewed RV64 transport evidence are preserved; completion/teardown repair has native checkpoint evidence and a later host-reviewed CP-error correction awaiting exact-source native closeout; counter/coherence/no-wrap qualification and A02/A03 remain open |''')
start = texts['docs/project/status.md'].index('## Latest continuation — simulator completion prerequisite')
end = texts['docs/project/status.md'].index('## Previous continuation — host counter transport', start)
texts['docs/project/status.md'] = texts['docs/project/status.md'][:start] + '''## Latest continuation — simulator completion prerequisite

The [audit](p06-simulator-completion-audit.md) begins at
`42809ff0c1b81384d7c9b079e4ef786be8407600`. SimX's legacy run swallowed model
exceptions, both host backends discarded asynchronous results, and a task ready
before its first poll could fail to expose the required busy edge. A guard for
future counter qualification cannot rely on a failure path that loses errors.

The [completion contract](../designs/simulator_completion_v1.md) separates
checked SimX execution from the legacy register-derived return; valid `gp`
values, including `-1`, remain successful. Both backends use `AsyncRun` to consume
outcomes, retain processor failure, preserve the launch edge and join outstanding
execution before freeing owned memory or processor state. Full cleanup in both
timing and functional SimObject frameworks disposes of abandoned channel
accounting after workers, scheduled events and inboxes have been removed. Normal
packet flow, reset/launch behavior, arithmetic, public error codes and ABI remain
unchanged.

The first clean checkpoint, `db5ebb3a16770004423f2456ec6d0caaa0aced6d`, passed
78 focused host tests and the hosted
[native completion run 45006726571](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726571).
Its unit exercised real `Processor`/RAM, nine checked normal runs, three legacy
normal runs, one legacy caught exception and one checked `OutOfRange` exception,
with a fresh successful context after the fault. Its separate public-runtime
cell passed six serial launches across two contexts with nonzero `gp` and exact
outputs. Independent review binds the executed merge tree to that checkpoint.
The [governance run](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726409)
passed all 2,988 tests. These receipts precede the CP error-boundary correction
described next; they are not verification of later production bytes.

A late consumer audit caught a compatibility regression in the initial broad
exception catch: CP-copy scratch `std::bad_alloc` became a terminal
`VX_ERR_INVALID_VALUE` instead of the inherited recoverable
`VX_ERR_OUT_OF_HOST_MEMORY`. The repair latches failures at actual processor
operations and leaves unrelated CP/host exceptions on their existing runtime
path. The unchanged lifecycle test now passes all three allocation-failure stages
in SimX/rtlsim × RAM/LLC (**four full lifecycle cells**), including resource
restoration, unchanged seeded data, no replay and same-device continuation.
Another **34 host cells** keep asynchronous and synchronous processor faults
terminal. All four built `db5ebb3` negative controls fail the intended OOM
assertion. Independent review found no remaining F2/F3 defect in this boundary.

Native verification of the repaired production revision and final evidence
reconciliation remain pending. The [completion packet](evidence/p06-simulator-completion/README.md)
is the source for exact receipts, original logs, historical failures and review
scope. Host fault injection and actual timing/functional framework tests do not
establish native public-runtime fault injection, native functional SimX,
multiworker exception recovery or processor RTL execution. The local 15 GiB
native disk reserve remains enforced; native execution uses adequately
provisioned hosted CI.

''' + texts['docs/project/status.md'][end:]
replace('docs/project/status.md',
'''**P06-T01 — complete native simulator completion verification before counter qualification.**
Use the [completion audit](p06-simulator-completion-audit.md) and
[contract](../designs/simulator_completion_v1.md) to resolve the exceptional
channel-accounting blocker, then finish the native checked-model and public-success
controls. Retain all results and reconcile them with the host fault/parent
evidence under independent review. Native execution is still
`not_run`; host fixtures and runner checks cannot replace it. The native disk
reserve remains 15 GiB. The earlier counter transport's broader integration and
publication remain separately tracked in its [handoff](p06-mpm-transport-handoff.md).

Then implement and independently review the
[versioned qualification binding](p06-mpm-qualification-plan.md): prove the exact
warm configuration and required selector coverage, coherent reads and an absolute
cumulative no-wrap bound, and reject historical packets or mismatched source,
configuration or binaries. Keep the existing v1 `qualified=false` block and
`absolute_no_wrap_bound="not_established"` intact; any future no-wrap claim needs
its own evidence.''',
'''**P06-T01 — close the repaired completion checkpoint, then freeze the exact
counter-qualification contract.** Complete native verification of the narrowed
CP error boundary and reconcile its host/native/review receipts in the
[completion packet](evidence/p06-simulator-completion/README.md). Earlier native
success at `db5ebb3` does not verify subsequent production changes. Preserve all
failed controls and the 15 GiB native disk reserve.

The next implementation is the [versioned qualification route](p06-mpm-qualification-plan.md)
for the exact RV64 `p02-tfr`, timing SimX, `PERF=1` configuration. Independently
review a source-bound contract covering all **33 available counter selectors**,
the 12 unavailable L2/L3 rows, coherent two-half reads and an enforceable absolute
bound over the entire cumulative context lifetime. Existing representative
TCU-disabled transport tests cover only five of those 33 SimX sources; the
launch-relative clock cannot bound cumulative counters across resets. No guard
or absolute bound is implemented by the completion repair. Reject historical
packets or mismatched source/configuration/tools/binaries on the future route,
and preserve v1 `qualified=false` and
`absolute_no_wrap_bound="not_established"`.''')

replace('docs/project/backlog.md',
'''## Start here: P06-T01 completion verification before counter qualification

**Current bounded task: P06-T01 — complete native simulator completion verification.**''',
'''## Start here: P06-T01 completion closeout and exact counter qualification

**Current bounded task: P06-T01 — verify the final completion repair, then freeze
the exact counter-qualification contract.**''')
replace('docs/project/backlog.md',
'''raw area failures. Broader CI is still running at this checkpoint; the
[transport handoff](p06-mpm-transport-handoff.md) tracks final integration/publication.

The [completion audit](p06-simulator-completion-audit.md) found that discarded
asynchronous results and a missed immediate-completion busy edge must be repaired
before a counter guard can fail reliably. The
[completion contract](../designs/simulator_completion_v1.md) guides the ongoing
implementation, with host backend/public checks and built-parent behavioral
sensitivity. A production-SimObject host probe found an outstanding-channel count
surviving exceptional teardown and leaving the next context non-idle; repair and
verify that cleanup accounting first. Native completion execution remains
`not_run` pending hosted CI; then finish native verification, exact-source
evidence reconciliation and independent review.
This checkpoint is incomplete and claims no native pass.

Then implement and independently review the [versioned qualification binding](p06-mpm-qualification-plan.md),
covering the exact warm configuration and selectors, coherent reads and an
absolute cumulative no-wrap bound. Reject old packets or mismatched source,
configuration or binaries; bind the actual executing interpreter for standalone receipts.''',
'''raw area failures. The [transport handoff](p06-mpm-transport-handoff.md)
retains that repair's separate integration/publication history.

The [completion audit](p06-simulator-completion-audit.md) found discarded
asynchronous exceptions, a missed immediate-completion busy edge and abandoned
channel accounting surviving full teardown. Those repairs are implemented in
the [completion contract](../designs/simulator_completion_v1.md), with host
backend/public/framework checks and built-parent sensitivity. Dedicated native
controls at `db5ebb3` passed real-model exception/fresh-context and six public
success launches; 2,988 governance tests passed at that checkpoint.

A subsequent compatibility correction preserves recoverable CP-copy allocation
errors while keeping processor failures terminal. The unchanged lifecycle suite
passes four backend/memory cells and all three allocation stages, with 34 further
terminal-model-fault cells and four intended old-backend failures. Independent
review found no remaining F2/F3 defect. Native verification of the corrected
production revision and final packet reconciliation remain pending; use the
[completion evidence index](evidence/p06-simulator-completion/README.md) for exact
source, command and review scope.

The next development is the [versioned qualification binding](p06-mpm-qualification-plan.md):
first freeze and independently review the exact RV64 tensor configuration and
all **33 available selectors**, coherent reads and an enforceable absolute
cumulative no-wrap proof. The existing transport matrix covers five of the 33
required SimX sources in a different, TCU-disabled configuration. Keep the 12
unavailable L2/L3 rows explicit. No no-wrap guard is implemented by the completion
repair. Reject old packets or mismatched source, configuration or binaries;
bind the actual executing interpreter for standalone receipts.''')
replace('docs/project/backlog.md',
'''repair's broader integration/publication status. Complete the
[simulator completion prerequisite](p06-simulator-completion-audit.md), including
the open exceptional channel-cleanup repair and native execution still `not_run`,
before versioned counter qualification and a fresh complete warm attempt.''',
'''repair's separate integration/publication history. The
[simulator completion prerequisite](p06-simulator-completion-audit.md) has native
checkpoint evidence and a later host-reviewed CP-error correction; close exact-source
native verification and final review before versioned counter qualification and
a fresh complete warm attempt.''')
replace('docs/project/backlog.md',
'''| **P06-T01 — Measured optimization — in progress** | Resolve exceptional channel cleanup, complete native simulator completion verification and independent review, then qualify exact counter configuration/selectors, coherent reads and absolute no-wrap bounds before the unchanged fresh warm matrix; track broader CI/publication separately. |''',
'''| **P06-T01 — Measured optimization — in progress** | Close native verification/review of the final completion and CP-error repair, then freeze and qualify all 33 available counters in the exact configuration, coherent reads and enforceable context-lifetime no-wrap bounds before the unchanged fresh warm matrix; track broader CI/publication separately. |''')

texts['docs/project/p06-simulator-completion-audit.md'] = '''# P06 simulator completion audit

## Decision

The audit starts at `42809ff0c1b81384d7c9b079e4ef786be8407600` on `master`.
The selected implementation is reliable simulator completion at the host backend
boundary, a prerequisite discovered while reviewing the
[counter qualification plan](p06-mpm-qualification-plan.md). Execution faults
must reach the caller before a future counter-bound guard can be trusted.

The completion and full-platform accounting repairs are implemented. The first
checkpoint, `db5ebb3a16770004423f2456ec6d0caaa0aced6d`, passed host tests and
dedicated hosted native controls. A later consumer audit found and repaired an
overbroad exception boundary that broke recoverable CP allocation errors. That
correction has independent host regression and review; its exact-source native
verification and final evidence reconciliation remain pending. The
[evidence packet](evidence/p06-simulator-completion/README.md) records the distinct
revisions and original results. No performance or phase acceptance follows from
either checkpoint.

## Findings and disposition

The first four findings concern the audited parent. Cleanup was reproduced
using the actual SimObject/SimChannel framework. The CP allocation finding was
discovered in the initial completion implementation during consumer review.

| Finding | Evidence and consequence | Disposition |
|---|---|---|
| SimX suppresses processor exceptions | Legacy `Processor::run()` catches exceptions and returns `-1`; the runtime's void launch lambda discards that result | Add `run_checked()` to propagate model exceptions while preserving the legacy API and body |
| Legacy return is not a reliable status | `Operands::get_exit_code()` reads x3 (`gp`), a legitimate global-data pointer; even integer `-1` can be valid | Ignore the legacy register-derived result on the checked path; native controls exercise `7` and `-1` |
| Both host backends discard asynchronous exceptions | Future readiness/wait without `get()` can hide a stored exception | `AsyncRun` consumes outcomes and keeps processor failures terminal |
| Immediate completion can lose the busy edge | The CP requires busy to rise before falling; current readiness alone can skip the rise and leave `WaitBusy` stuck | Preserve the unobserved launch edge independently of future completion; deterministic and mutation controls cover it |
| Exceptional teardown can retain channel accounting | A real-framework probe left `inflight_count=1` after finalization; a fresh context consumed its message but remained non-idle | Timing and functional cleanup retire abandoned accounting after disposing all platform work; actual-framework tests and native fresh-context control exercise declared scopes |
| Initial catch-all breaks recoverable CP OOM | CP scratch allocation throws after selecting `EngState::Retire`; blanket catch changed OOM into terminal INVALID_VALUE and prevented safe continuation | Latch only processor-origin failures, preserve inherited CP/host exception mapping, and run the original lifecycle suite unchanged |
| Counter qualification remains incomplete | The old native SimX transport test seeds five of 33 required available sources, under a different TCU-disabled configuration; no absolute cumulative bound exists | Preserve warm v1 rejection and freeze the exact selector/coherence/lifetime contract before new qualification |

Processor RTL's `Processor::run()` returns `void`; no RTL kernel exit-code
reporting is inferred. Its completion repair concerns host exception transport
and ordering. The existing callback adapter maps nonzero HAL results to
`VX_ERR_INVALID_VALUE`; no public error code or ABI mapping is changed.

## Implemented boundaries

The [completion contract](../designs/simulator_completion_v1.md) separates checked
SimX execution from the legacy register result. Both backends use the shared
[AsyncRun owner](../../sw/runtime/common/async_run.h) to consume asynchronous
outcomes, retain an unobserved launch edge, reject work after processor failure,
and join pending execution before freeing memory or destroying the processor.
Synchronous DCR, LLC-memory and applicable drain hooks use the same terminal
processor-failure boundary. Exception type alone does not determine recovery:
a processor `std::bad_alloc` is terminal too.

Unrelated CP/host exceptions keep the inherited common-runtime path. In the
specific CP-copy scratch case, `EngState::Retire` is selected before allocation;
unwinding releases staging, the queue reports `VX_ERR_OUT_OF_HOST_MEMORY`, and
the next CP transaction retires the abandoned descriptor without replaying its
copy. The unchanged [lifecycle test](../../tests/runtime/test_ai_lifecycle.cpp)
requires seeded data to remain unchanged before a fresh same-device transfer
succeeds. Preserving the OOM number alone would not satisfy this contract.

Both timing and functional SimObject cleanup clear abandoned global accounting
only after workers are stopped and platform objects, scheduled events, domains
and inboxes are disposed. Neither ordinary reset nor launch reset is a failed
context recovery entry. External owners surviving finalization are
destruction-only; they do not authorize concurrent live contexts or reuse of old
channels. The normal run loop, packet scheduling and simulated-cycle behavior
remain unchanged.

## Verification by revision and scope

The evidence index retains original logs, exact source/tool identities, review
reports and failed attempts. The initial development logs are historical and
must not be substituted for later clean-source receipts.

| Evidence | Observed result | Scope and limit |
|---|---|---|
| Clean focused host suite at `db5ebb3` | **78 tests passed** in 68.480 seconds, with unchanged tracked source and tool identities | Host backend/common-runtime/framework and runner-policy checks; precedes the CP error-boundary correction |
| Actual backend/CP and public runtime fixtures | **24 backend cells** and **12 public-runtime cells** pass, using controlled Processor/RAM | Real production callback, CP, adapter, queue and event paths; no native arithmetic or RTL fault mechanism |
| Completion owner | **Eight directed groups**, including deterministic completion before first busy and a ready-`check()` mutation failure | Helper-level scheduling and failure semantics; not native model execution |
| Timing and functional frameworks | **Eight actual-framework cells** pass; old-header controls fail six fault cases while two healthy controls pass | Actual channel/event accounting, one worker and a joined asynchronous fault task; no native functional or multiworker recovery claim |
| Pinned audited-parent sensitivity | Both old backends compile; **eight standard/unknown exception cells** fail their intended behavioral assertions | The parent is fixed at `42809ff`; build failures or timeouts are not accepted as sensitivity |
| Native runner policy | **26 focused tests** cover original compiler options/include order, preflight, outputs and failure handling | Tooling checks support the runner but do not replace native execution |
| First dedicated native run | [Run 45006726571](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726571) passes at checkpoint `db5ebb3`, executed as merge `782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd` with the identical tree | RV64 `p02-tfr`, timing SimX, `PERF=1`; independent original-artifact review verifies source/build/log identities |
| Real linked processor unit | **Five contexts:** nine checked successes, three legacy successes, one checked `OutOfRange`, one legacy caught exception; fresh normal context after the fault | Real Processor/RAM and legacy `gp` values `7`/`-1`; not native public-runtime injected failure |
| Native public success | **Two contexts, six launches**, nonzero `gp`, exact global-data/output witnesses and cleanup | Real generated kernel/runtime success; not processor RTL or native fault injection |
| Initial full governance | [Run 45006726409](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726409): **2,988 tests passed** in 1,191.429 seconds | Exact initial checkpoint; not a claim that all broader CI or later production bytes passed |
| CP error-boundary correction | **Four full unchanged lifecycle cells** cover three OOM stages, no replay, released ownership and same-device continuation; **34 further cells** keep processor faults terminal | Both backend adapters with RAM/LLC as applicable, controlled Processor/RAM; native verification of this later repair remains pending |
| CP regression sensitivity | Both `db5ebb3` backends/helper compile against the same lifecycle test; **four controls fail the intended OOM assertion** after allocation stages 0/1 pass | Proves the narrower boundary repairs a reproduced regression; every expected failure is exit 1, not compile failure or timeout |

The native archive for the initial checkpoint has SHA-256
`d5f71cec99321c5f8e6c11fab37875aa93e551270a1a15c29b3fe9af6c766588`.
Review verified 761 retained source bodies against the checkpoint, 18 command/log
records and five compiler/header roles. Its three backend/helper input files
subsequently changed for CP OOM compatibility, so the earlier native pass cannot
close verification of that repair. The [evidence packet](evidence/p06-simulator-completion/README.md)
is the authority for the final repaired revision and its eventual receipts.

The original failed public-fixture build, runner provenance failures, cleanup
probes and compiled-parent failures remain retained. Native binaries are
identified but not archived; tool records do not inventory every host system
header or dynamic library. Before/after hashes detect observed drift and are not
a hermetic-execution claim. The 15 GiB native disk reserve remains mandatory;
local host fixtures and adequately provisioned hosted native execution have
separate resource scopes.

## Next bounded development

Close native verification and independent evidence review for the exact repaired
completion revision. Then freeze and review the
[versioned counter qualification contract](p06-mpm-qualification-plan.md) before
implementing its enforcement. It must bind the exact RV64 tensor configuration,
all **33 available selectors** and 12 unavailable rows, real backing-source
coverage, coherent two-half reads, and an enforceable absolute bound over the
complete cumulative context lifetime. A per-launch clock or host timeout cannot
bound counters that survive launch resets. No such guard is implemented here.

Only after those obligations pass should a fresh matched warm attempt run under
the unchanged sampling and rejection rules: **24 processes, 792 launches and
25,344 exact output words**, including excluded primes and warm-ups. Historical
warm v1 remains unconditionally blocked. A successful workload or replay does
not establish qualified performance.

## Preserved obligations

P06-A02/A03 remain open. Warm v1 keeps `qualified=false` and
`absolute_no_wrap_bound="not_established"`. P01-A03 vendor `hw_emu`, independent
P05-A02/A03 framework qualification, the inherited **267 → 283 DSP-area failure**
against the unchanged **5% threshold**, and physical FPGA/silicon work remain
separate. No pipeline, arithmetic, ISA, public ABI, frozen workload, statistical
predicate, golden, tolerance or phase acceptance is changed by this repair.

The delivery ledger records actual completed assignments and evidence scopes.
An agent count is not a test result, native qualification, human approval or gate
waiver. Existing acceptance records and retained failures preserve their scopes.
'''

for name, value in texts.items():
    path = OUT / 'draft' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value)
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
(OUT / 'draft-hashes.json').write_text(json.dumps({name: hashlib.sha256(value.encode()).hexdigest()
                                                for name, value in texts.items()}, indent=2) + '\n')
print('Prepared four draft files outside the repository; repository content unchanged.')
