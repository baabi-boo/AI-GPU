# Wave 9 / Agent 4 — counter qualification handoff consolidation

## Outcome

Updated only `docs/project/p06-mpm-qualification-plan.md` and
`docs/project/p06-workspace-handoff.md` at parent checkpoint
`4781ca96db15a1d130626edc7a73411a4f6c2e7c`. The two files are frozen for final
integration. This is documentation work, not implementation or acceptance of
a counter guard or qualification path.

The next bounded development action is now explicit: freeze and independently
review the exact 33-selector counter/coherence/lifetime contract for RV64
`p02-tfr`, timing SimX, `PERF=1`, then implement its reviewed narrow guard and
versioned evidence enforcement before a fresh unchanged warm attempt.

## What changed

- Reconciled the implemented completion/whole-platform teardown repair with
  source-specific evidence. The initial `db5ebb3` native result retains its
  scope; the subsequent `4781ca9` CP boundary repair is assessed using its own
  receipts. The evidence README remains the authoritative current record.
- Distinguished processor-origin terminal failure from inherited recoverable
  CP scratch OOM, preserving same-device transfer continuation without
  promising reuse of a failed processor.
- Recorded 33 available and 12 unavailable/no-query counter rows; prior
  TCU-disabled SimX coverage is 5/33 and RTL leaf coverage is 19/33.
  Class 7 / CSR `0xB06` memory-bank stalls have no RTL MEM-decoder mapping,
  preventing an all-33 RTL parity claim.
- Defined the smallest useful additional diagnostics: all actual backing
  selectors and halves in each format-bound backend; four public format/policy
  processes with 132 launches, 4,224 words and 16 snapshots; and future native
  guard-failure controls with normal controls. These are proposed tests.
- Explained why launch-relative cycles cannot bound cumulative counters.
  The `T = E = 2^32 - 1` lifetime-tick/request-cap proposal is explicitly
  unimplemented and unqualified. It requires zero-origin, reset/flush/close,
  request/pending, every updater and aggregate proof. The derived memory
  latency bound is conditional on those enforcement premises.
- Specified separate versioned qualification binding, actual interpreter and
  original source/compiler/config/tool/binary identities, pre-launch binding
  and independent rejection/replay review. Existing `qualification_id` remains
  an execution-binding digest, and frozen warm v1 stays blocked.
- Reconciled the complete 24-process, 792-launch, 25,344-word population into
  640 measured non-prime operations, 24 excluded primes and 128 excluded
  non-prime warm-up operations, avoiding double-counted warm-up primes.

## Preserved boundaries

No production code, fixture, public ABI, ISA, configuration, golden, threshold,
acceptance record or canonical roadmap was edited. The 95% median, no-slower
pair and qualified-cycle predicates remain unchanged, as do all native resource
limits. P06-A02/A03, independent P05-A02/A03 framework review, mandatory vendor
P01-A03 before P07, the inherited 267 → 283 DSP finding against the unchanged
5% threshold, and physical FPGA/silicon evidence remain separate obligations.

The sources consolidated were the existing owned documents, current completion
contract, frozen warm inputs and the read-only Wave 7 coverage, lifetime,
versioning and phase-dependency audits. Those source audits remain historical;
this handoff does not turn their proposals into an implementation.

## Validation and retention

Prepared changes in scratch while the parent ran clean-checkpoint receipts.
Applied them only after the parent's explicit receipt-complete clearance.
`git diff --check` passes for both files. All 54 local Markdown link targets
resolve to existing files. No build, test suite or native execution was run by
this agent. No commit or push was performed.

`before/` and `after/` retain exact document bytes. `handoff.patch` records
the complete two-file change; `validation.json`, `before.json` and `after.json`
record the limited checks and identities. The parent may separately add current
CI/publication receipts without changing the prospective guard claims.

| Final document | SHA-256 |
|---|---|
| `docs/project/p06-mpm-qualification-plan.md` | `d889dc79e7e6c7597852a4ffc033047ee06eb17a47b33e06d5baac2987369ef6` |
| `docs/project/p06-workspace-handoff.md` | `f4927df2b3822845931b430350ec74f12b2ea55baad785cd494c82ee958da78f` |

