# Independent repaired-code native completion review

Reviewer: Wave 10 assignment 3, unique agent 57. Frozen 2026-11-22T10:11:20+00:00.

## Verdict

**PASS for the two recorded native completion prerequisite cells at repaired checkpoint `4781ca96db15a1d130626edc7a73411a4f6c2e7c`.** This is fresh evidence after the recoverable synchronous CP allocation repair. It does not relabel the earlier `db5ebb3` packet, and it does not accept a project phase or qualify counters.

The exact scope is RV64, frozen `p02-tfr` profile, timing SimX, performance counters enabled, `THREADS=1`, direct RAM CP configuration. The unit exercises the actual native processor and bounded RAM. The public cell exercises successful native public-runtime launches. A native public injected fault and native RTL are outside this packet.

## Original GitHub identity

| Item | Verified value |
| --- | --- |
| Repository | `baabi-boo/AI-GPU` |
| Workflow run | `45009314161`, attempt 1, `pull_request` |
| Job | `137167865239`, Native simulator completion prerequisites |
| GitHub job result | Completed, success, 2026-11-22 10:06:06 UTC |
| Code checkpoint | `4781ca96db15a1d130626edc7a73411a4f6c2e7c` |
| Executed merge | `e929c52d05bad80b28dd4085a97838d7fe2de354` |
| Exact shared tree | `6dd0d759390cda78ec63ad0caacc00a08f03e2bc` |
| Merge parents | `42809ff0c1b81384d7c9b079e4ef786be8407600`, then the code checkpoint |
| Artifact | `14749901531` |
| Original ZIP size | 2,792,870 bytes |
| Original ZIP SHA256 | `461ddd226474aff20205b5ae852489fd4e88f21f7065a74efba25e706eb087b9` |
| Original ZIP members | 812; 10,794,058 uncompressed bytes |

The ZIP length and SHA256 match both GitHub artifact metadata and the completed job's upload log. Independent GitHub commit metadata binds the executed merge to the same tree as the repaired checkpoint. The original ZIP and decoded job log remain here alongside the API metadata. No signed download URL was retained.

## Observed native behavior

The full original unit log is:

```text
native_x3 gp=7 checked_launches=3 legacy_launches=1
native_x3 gp=-1 checked_launches=3 legacy_launches=1
Error: exception: out of range memory address
native_legacy_exception result=-1
native_exception type=OutOfRange consumed=1
native_x3 gp=7 checked_launches=3 legacy_launches=1
PASSED simx_completion native_unit contexts=5 checked_success=9 legacy_success=3 checked_exceptions=1 legacy_errors=1
```

The retained unit source constructs a bounded 4,096-byte RAM, launches at its capacity to produce the native `OutOfRange`, and consumes the exception with `std::future::get()`. Its normal program writes architectural x3 directly. Each normal context executes three checked launches and one legacy launch; the checked path verifies the architectural result without converting nonzero x3 into a runtime failure. The ordered final `gp=7` context is constructed after both fault contexts have been destroyed. This proves fresh-context success after teardown, not reuse of a failed processor context.

The full original public log is:

```text
native_success context=0 launch=0 gp=0000000180001870 value=373f373f
native_success context=0 launch=1 gp=0000000180001870 value=373f372e
native_success context=0 launch=2 gp=0000000180001870 value=373f36dd
native_success context=1 launch=0 gp=0000000180001870 value=373f373e
native_success context=1 launch=1 gp=0000000180001870 value=373f372d
native_success context=1 launch=2 gp=0000000180001870 value=373f36dc
PASSED simx_completion native_success contexts=2 launches=6 gp_nonzero=6
```

Both public contexts performed three launches. All six architectural gp low words were nonzero. All six copied output words equal the fixed input formula for their ordered context and launch; no host fault injection was used in this cell.

## Independent verification performed

- Verified the original ZIP identity before safe extraction. Extraction rejects absolute paths, traversal, backslashes, duplicate members, symlinks, special files and oversized entries; it bounds member count and total uncompressed size. Every extracted member was compared again with the original ZIP.
- Reconstructed the required source inventory from the frozen Git tree and runner constants, rather than accepting an arbitrary retained subset. All 761 source bodies match unreplaced Git blob objects at the repaired checkpoint. All five root submodule gitlinks match the checkout report.
- Verified the three changed runtime/helper bodies and changed completion contract by explicit SHA256, so the earlier native run cannot satisfy this review accidentally. The hashes are included in `audit-summary.json`.
- Rechecked all 786 retained input records: 761 source files, 20 generated configuration inputs, four compiler stamps and one header probe. Reconstructed `config.mk` from the retained template and selected tool paths; checked configured copies, `.config.stamp`, Verilator configuration substitution and exact probe bytes.
- Revalidated all five compiler roles, their option and include path policy, macro configurations, raw header outputs and recorded probe commands. Cross-checked 87 actual model object compile commands against the respective recorded flags. Confirmed timing mode, one simulation worker, PERF enabled in both model builds, and direct RAM CP configuration.
- Verified the complete inventory of 18 commands, their log sizes and SHA256 values, successful exits, cleanup completion, bounds, exact configure/build/native-run invocation paths, and tool selection. Both observed cell sequences were independently parsed against the ordered native contract.
- Checked equality of source, tool, dependency, generated-input and binary/stamp snapshots before and after execution. The packet identifies 21 tool records, three reused dependency libraries and eight native binaries plus four stamps. All retained stamp bytes match their corresponding artifact identity records. Native binary and dependency library bytes are not archived, so their SHA256 identities are producer receipts, not locally rehashed binary bodies.
- Checked recorded resource gates: two build jobs, one simulation worker, 15 GiB minimum disk reserve, 4 GiB process RSS ceiling. Recorded maximum sampled RSS was 888,791,040 bytes. Every command stayed within its timeout and log cap. Recorded initial and final disk reserves exceeded the required minimum.
- Verified pinned CPython 3.12.14 and equality of the executing interpreter and `python3` identity.

The auditor uses local validators only after checking all 272 local `ci/project/*.py` source bodies against the fixed unreplaced Git checkpoint. Eleven imported local modules are checked again afterward. Existing bytecode caches cannot substitute for those sources. Archived Python, shell scripts, executables and libraries were treated solely as data. No local native build or native execution occurred.

## Evidence hashes

| Evidence | SHA256 |
| --- | --- |
| Original native report | `c134037768dd8c55fa8eab5e4bc7012967291b5c44d482570bde9fa9761a2239` |
| Original unit output | `72f2fa579ebebc53190bfb20a96ab9b165f68a05d9d5122a6eda087871b3d3f4` |
| Original public output | `21b114c7606216dd3eb0ec347899bc61a0c28357d69d4d4683c58d073f688cdc` |
| Decoded GitHub job log | `3ea7aa88268572e61bbc7d0732e233ee3345aeab9fb1010bd21c803f7d6c93c8` |
| Audit script | `330e37aba6fa05e48b677461d3317bc7dc314396644ddc0e3df08b670c088baf` |
| Audit summary | `998abe89b144abefa25e63cf7904a11d1b693d04d7c5524a7668d33780013ef4` |

`manifest.json` inventories the retained files. Reproduce the read-only review with `python3 -B extract_original.py` and `python3 -B audit_native_packet.py` from this directory while the trusted local validator files match checkpoint `4781ca96`. These commands extract data and validate records; they do not rebuild or run native code.

## Governance checkpoint: pending

At 2026-11-22 10:09:56 UTC, repaired PR governance run `45009314170`, job `137167865708`, and repaired push governance run `45009309941`, job `137167851515`, were both **in progress** in `Test governance tooling`. Earlier setup, structure/evidence validation and baseline-packet consistency steps had succeeded. No completed full-suite log or actual final test count was available at this checkpoint. Neither governance run is claimed as passed here. Their API snapshots are retained separately with `pending` in their names.

The native review is frozen now. A later governance review must use the corresponding original completed job log and record its actual count without changing this pending historical observation.

## Scope that remains open

This packet does not establish a native public-runtime injected-fault result, native RTL behavior, functional SimX execution, multiworker fault transport, failed-backend reuse, fatal abort/cancellation handling, counter lifetime or no-wrap qualification, warm speedup, FPGA or silicon results. The three reused dependency libraries and third-party header bodies are not included as archived bytes; five Git links and producer identity records provide the stated boundary. Before/after hashes detect observed drift, not an adversarial transient replacement restored between checks. No phase acceptance or counter qualification is claimed.

No repository files were edited, no commits were created or pushed, and no workflow run was cancelled by this reviewer.
