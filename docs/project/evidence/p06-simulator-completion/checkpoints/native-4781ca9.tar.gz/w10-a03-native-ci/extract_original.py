#!/usr/bin/env python3
"""Verify GitHub identity and extract original artifact with bounded path checks."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'p06-simulator-completion-run45009314161-artifact14749901531.zip'
TARGET = ROOT / 'packet'
metadata = json.loads((ROOT / 'github-artifacts.json').read_text())['artifacts']
assert len(metadata) == 1
metadata = metadata[0]
assert metadata['id'] == 14749901531 and not metadata['expired']
assert metadata['workflow_run']['id'] == 45009314161
assert metadata['workflow_run']['head_sha'] == '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
data = ARCHIVE.read_bytes()
assert len(data) == metadata['size_in_bytes'] == 2792870
assert 'sha256:' + hashlib.sha256(data).hexdigest() == metadata['digest']
assert hashlib.sha256(data).hexdigest() in (ROOT / 'job-137167865239.log').read_text()
with zipfile.ZipFile(ARCHIVE) as archive:
    members = archive.infolist()
    assert len(members) <= 4096
    assert len({item.filename for item in members}) == len(members)
    assert sum(item.file_size for item in members) <= 64 * 1024**2
    for item in members:
        path = PurePosixPath(item.filename)
        assert not path.is_absolute() and '..' not in path.parts
        assert path.parts and '\\' not in item.filename and '\x00' not in item.filename
        assert item.file_size <= 8 * 1024**2
        mode = item.external_attr >> 16
        assert stat.S_IFMT(mode) in (0, stat.S_IFREG, stat.S_IFDIR)
        target = TARGET / path
        assert target.resolve().is_relative_to(TARGET.resolve())
        assert not target.is_symlink()
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            content = archive.read(item)
            assert len(content) == item.file_size
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                assert target.read_bytes() == content
            else:
                target.write_bytes(content)
    summary = {'outcome': 'pass', 'archive_sha256': hashlib.sha256(data).hexdigest(),
               'archive_bytes': len(data), 'members': len(members),
               'uncompressed_bytes': sum(item.file_size for item in members),
               'archived_scripts_executed': False, 'native_binaries_executed': False}
(ROOT / 'extraction-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
