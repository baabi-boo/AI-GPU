# W09-A06 — repaired-checkpoint host receipt review

**Reviewer:** `/root/w09_a06_final_host_review`, unique assignment 54 of 60, wave 9.

**Verdict: PASS for both declared host evidence scopes. No concrete mismatch or blocking finding was found.** The original clean-checkpoint discovery supports 83 successful focused unittest methods at `4781ca96db15a1d130626edc7a73411a4f6c2e7c`. The separately retained compiled-parent packet supports eight intended behavioral failures of the original backends. These are separate receipts and neither is native processor or RTL execution.

This review read original files and Git objects, recomputed hashes, enumerated the committed test methods, compared exact compiler arguments, and inspected the receipt/runner execution paths. It ran only the independent read-only [audit script](audit.py); it did not run a test, compiler, build, simulator, retained script, or retained executable. No repository file was changed. Documentation and evidence writers were active during this review, so the present whole worktree was not asserted to be clean. Execution inputs were compared to the exact tested commit instead.

## Identity and original artifacts

| Receipt | Original location | SHA-256 |
|---|---|---|
| Clean host discovery report | `w06-a05-host-receipt/attempt-20261122T094824742647Z/report.json` | `68e622bd72ef34f4a21c0fdebd03b2317fe488178c9f13912e7da1eb5a67117b` |
| Host discovery raw transcript | Same directory, `focused-suite.log` | `431a5feeeee82aa756637fdaddaeb275221146449ca6688b0eaa8e25521db880` |
| Actual pinned-parent report | `p06-parent-4781ca9-report/report.json` | `3183ed4fd2be6fbcb64d62f3a4008b13762d144de8ff3f603617a3b36a79c7a5` |
| Independent verification result | [audit-summary.json](audit-summary.json) | `79870595f13cb305e3d974181ff4733e38a991f7e3b7d0104f178c9eab82d740` |

The tested candidate commit is `4781ca96db15a1d130626edc7a73411a4f6c2e7c`, tree `6dd0d759390cda78ec63ad0caacc00a08f03e2bc`. The deliberately failing parent sources are pinned to `42809ff0c1b81384d7c9b079e4ef786be8407600`; that is the audited original baseline, not the candidate's immediate parent. Every Git comparison in this review used both `git --no-replace-objects` and `GIT_NO_REPLACE_OBJECTS=1`. No current replacement refs were present.

## Clean 83-test discovery

The original command is:

```sh
python3 -B -m unittest discover -s ci/project -p 'test_p06_simulator_*.py' -v
```

The transcript contains exactly **83 distinct fully qualified test results**, all `ok`, one `Ran 83 tests in 87.502s` line, and one bare `OK`. There are no failed, erroneous, skipped, expected-failure, or unexpected-success unittest results. Static AST enumeration of the ten test modules from the unreplaced candidate Git blobs produces exactly the same 83 method identities; the five new error-boundary methods are included.

| Test module suffix | Methods | Scope |
|---|---:|---|
| `async_run` | 8 | Actual completion-owner host fixture |
| `completion` | 6 | Actual backends/CP with controlled Processor/RAM |
| `error_boundary` | 5 | Unchanged inherited lifecycle plus terminal model-fault controls |
| `public` | 3 | Actual public runtime/error transport with controlled Processor/RAM |
| `platform` | 4 | Actual timing and functional SimObject frameworks |
| `build` | 1 | Configure/Make dependency checks |
| `ci` | 14 | Workflow, shell and interpreter policies |
| `execute` | 11 | Native-runner input/output and provenance validation |
| `parent` | 16 | Parent-runner policies, including the real Git replacement-ref regression |
| `runner_failures` | 15 | Adversarial native-runner policy records with mocked native commands |
| **Total** | **83** | **Host fixture and governance evidence** |

The new error-boundary driver compiles `tests/runtime/test_ai_lifecycle.cpp` unchanged and runs it for two backends and two memory routes. Its other methods separately exercise asynchronous, DCR, LLC and processor-RTL-drain `bad_alloc`/unknown faults. These five methods derive **38 positive process cells** from the committed loops. The outer discovery receipt retains their successful assertions and source/tool binding; the separate `w08-a06` packet retains the detailed command logs and pre-repair negative controls. This review does not replace that packet's independent review or treat the discovery log as a complete child-command archive.

### Complete source and tool reconciliation

All eight receipt files are accounted for: the report and its seven manifested artifacts. Their hashes and lengths match. Before/after source inventories are byte-identical, as are before/after tool inventories. The recorded HEAD and tree are exact, status is empty, and there are no recorded working-blob mismatches.

I independently streamed and hashed **all 5,109 tracked Git blobs**, comprising **370,676,935 bytes**, and reconstructed each Git blob ID. Their path, mode, kind, object ID, length and SHA-256 agree with the original source inventory. The five gitlinks agree with the commit's tree entries; those identities do not substitute for a full submodule working-tree inventory.

I additionally compared **2,172 current execution-source inputs** under `ci/`, `sw/`, `sim/`, `tests/`, plus the frozen completion contract, with the tested Git bytes. They were unchanged during this audit. Later documentation edits therefore do not silently relabel this receipt as a whole-tree test of a future publication commit.

All **43 recorded tool/compiler-support identities** still match their resolved paths, lengths and SHA-256 values. The tool record contains **27 probes**. The actual interpreter and PATH `python3` resolve to the same Python 3.12.14 executable. The C++ driver resolves to the recorded Debian GCC 14.2.0 executable. The retained receipt driver matches both the original driver identity and its unchanged current bytes; its SHA-256 is `c47f319e96a35f084c7dfa8c0b2f62939fd810d320fe5505ef6063b5c73cc665`.

The invocation record agrees with the final report's argv, working directory, expected revision, environment and budget. The actual bounded process started, exited zero, and completed cleanup. It took 87.745006 seconds including monitor overhead, with sampled outer-group peak RSS 50,450,432 bytes. The budget is 300 seconds, 1 GiB RSS, 1 GiB free disk and 8 MiB log output, sampled every 0.1 seconds. Initial and final resource snapshots are ready. Inner host fixture commands have their own separate bounded process groups; the outer peak does not aggregate those groups.

## Compiled original-backend sensitivity

The original replay report records a clean candidate at `4781ca9`, the exact fixed baseline `42809ff`, and a finished pass with all eight cells completed. I compared all **33 retained candidate inputs** with their exact candidate Git blobs and current execution inputs. I compared all **24 retained parent inputs** with their exact unreplaced baseline Git blobs, recorded parent blob IDs, extracted working copies and raw `git show` logs. All agree. The **eight generated configuration inputs** match both their retained copies and the original build directory. All **20 shared CP/callback/support/configuration inputs** remain byte-identical to the baseline.

All **51 command logs** match their declared byte length and SHA-256. Their actual result records contain successful process start and complete cleanup; all durations remain below their corresponding deadlines. The **43 setup, extraction, probe, configure, compile and dependency commands** succeeded. The remaining eight commands are the required failures, each with exit 1, reason `nonzero_exit`, and raw outcome `fail`.

The compiler arguments were independently reconstructed from the retained source-level argv producer and compared in full. Each build compiles the actual extracted baseline backend, unchanged production `cmd_processor.cpp`, and controlled fixture `main.cpp`. The first include selects the disclosed controlled Processor/RAM headers; generated configuration and production support headers follow in their original order. The configuration is RV64 `p02-tfr`, C++17, `-O1`, warnings as errors, pthreads and UBSan. No backend or CP body is substituted. The adapter implemented using `mock.patch` in the runner only redirects the fixture's command recorder into the real bounded subprocess executor; it does not replace compilation or cell execution with a synthetic result.

Both compiler commands passed and produced retained executable ELF binaries. I checked their ELF magic, executable bit, size and before/after identity:

| Actual baseline backend binary | Bytes | SHA-256 |
|---|---:|---|
| `simx-completion` | 410,176 | `a78c0d5054f4f80265ba64babd665e69a88625415b4d63961fd0770e106f92a0` |
| `rtlsim-completion` | 410,464 | `36e18ad4f2dc50b571e1be96e0fd9e46edc6fff5c0335cad2b65ce521ba45fd6` |

For every combination of SimX/processor-RTL backend, standard/unknown exception, and RAM/LLC selection, the output is exactly:

```text
FAIL simulator-completion GROUP: failed launch was accepted as successful
```

`GROUP` is the correct cell's `standard_exception` or `unknown_exception`; every original log has exactly one final newline. Each cell's result equals the corresponding command result, and each references its successful actual backend build. A compiler failure, timeout or unrelated assertion was not accepted. These cells stop at the expected old exception-transport defect; they do not execute the later sticky-error assertions after that failure.

The runner's explicit child environment contains `GIT_NO_REPLACE_OBJECTS=1`, and its actual `run_bounded` path forwards that environment. The retained parent-ID/blob-ID logs match original Git objects. The **15 host-tool identities**, **12 additional compiler/runtime-library identities**, both binaries, source maps, generated maps and original command logs agree before and after. The configured Python shim resolves to the recorded running interpreter.

The fixed parent replay budget remains one sequential job, 1 GiB RSS/disk reserve, 1 MiB logs, 60-second configure/build deadlines and 10-second probes/cells. The replay ran from `2026-11-22T09:49:22.772856+00:00` to `2026-11-22T09:49:35.988401+00:00`.

## Limits and release handoff

- The clean discovery transcript is not a hermetic binary replay packet. Successful temporary fixture binaries and child logs are cleaned by their owning tests; their assertions and bracketed input identities remain. The separate error-boundary packet supplies its own detailed logs and binary hashes.
- Before/after inventories cannot detect temporary changes restored between observations. All system headers and dynamic dependencies are not captured. `-B` prevents bytecode writes, not reads; ignored Python caches are outside this receipt's original inventory. No execution discrepancy was found, but no historical bytecode-use record is inferred.
- Resource limits are polled budgets, not hard quotas. Reported RSS can miss between-poll peaks, excludes page cache, and does not imply cgroup-wide containment. Detached descendants are outside the stated process-group model.
- Actual original-backend host compilation establishes sensitivity to discarded exceptions. Controlled Processor/RAM, RAM/LLC flags and the processor-RTL adapter are not native processor, cache, RTL datapath, public-runtime fault or physical-device evidence.
- Both receipts correctly leave native execution and qualification/acceptance claims false or `not_run`. Fresh native completion run `45009314161` was pending in the coordinator's handoff and is a separate release obligation; this review did not query or qualify that run. P06 counter coherence/lifetime qualification, warm-v1 rejection and all unrelated phase/hardware gates remain unchanged.

The two original host receipts are internally consistent, bound to their stated sources, and sufficient for their declared claims. No further host rerun is requested by this review. The coordinator should retain them under their actual tested revision and complete the separate native/final publication checks.
