#!/usr/bin/env python3
"""Read-only independent audit of the two original 4781 host receipts."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
OUT = Path(__file__).resolve().parent
HOST = ROOT.parent / 'w06-a05-host-receipt/attempt-20261122T094824742647Z'
PARENT = ROOT.parent / 'p06-parent-4781ca9-report'
COMMIT = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
BASE = '42809ff0c1b81384d7c9b079e4ef786be8407600'
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0')

def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, env=ENV, timeout=30)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def identity(path, expected):
    path = Path(path)
    assert path.is_file(), str(path)
    assert path.stat().st_size == expected['size_bytes'], str(path)
    assert sha(path) == expected['sha256'], str(path)
    if 'resolved_path' in expected:
        assert str(path.resolve()) == expected['resolved_path'], str(path)

def tree(commit):
    rows = {}
    for item in git('ls-tree', '-r', '-z', '--full-tree', commit).split(b'\0'):
        if not item:
            continue
        metadata, name = item.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        rows[os.fsdecode(name)] = dict(mode=mode, kind=kind, git_object=oid)
    return rows

def manifest_directory(directory, records):
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
    assert actual == set(records), (str(directory), sorted(actual ^ set(records)))
    for name, row in records.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        identity(directory / name, row)

def host_audit():
    report = load(HOST / 'report.json')
    assert sha(HOST / 'report.json') == '68e622bd72ef34f4a21c0fdebd03b2317fe488178c9f13912e7da1eb5a67117b'
    assert report['outcome'] == 'pass' and report['expected_head'] == COMMIT
    assert report['unittest_ok_without_skips'] is True and all(report['integrity'].values())
    for name, row in report['artifacts'].items():
        identity(HOST / name, row)
    assert len(report['artifacts']) == 7
    assert {p.name for p in HOST.iterdir() if p.is_file()} == {'report.json', *report['artifacts']}
    source = load(HOST / 'source-before.json')
    tools = load(HOST / 'tools-before.json')
    assert (HOST / 'source-before.json').read_bytes() == (HOST / 'source-after.json').read_bytes()
    assert (HOST / 'tools-before.json').read_bytes() == (HOST / 'tools-after.json').read_bytes()
    assert source['head'] == COMMIT and source['status_porcelain'] == '' and source['working_blob_mismatches'] == []
    assert source['tree'] == git('rev-parse', COMMIT + '^{tree}').decode().strip()
    assert source['object_format'] == 'sha1'
    original = tree(COMMIT)
    assert set(original) == set(source['tracked_files'])
    batch = subprocess.Popen(['git', '--no-replace-objects', 'cat-file', '--batch'], cwd=ROOT, env=ENV,
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    counts = Counter()
    total_bytes = 0
    current_inputs = 0
    for name, record in source['tracked_files'].items():
        row = original[name]
        assert all(record[key] == value for key, value in row.items()), name
        counts[row['kind']] += 1
        if row['kind'] != 'blob':
            continue
        batch.stdin.write((row['git_object'] + '\n').encode())
        batch.stdin.flush()
        oid, kind, length = batch.stdout.readline().decode().strip().split()
        size = int(length)
        assert oid == row['git_object'] and kind == 'blob' and size == record['size_bytes'], name
        digest = hashlib.sha256()
        blob = hashlib.sha1(b'blob ' + str(size).encode() + b'\0')
        left = size
        while left:
            part = batch.stdout.read(min(left, 1024 * 1024))
            assert part
            left -= len(part)
            digest.update(part)
            blob.update(part)
        assert batch.stdout.read(1) == b'\n'
        assert digest.hexdigest() == record['sha256'], name
        assert blob.hexdigest() == row['git_object'] == record['working_git_blob'], name
        total_bytes += size
        if name.startswith(('ci/', 'sw/', 'sim/', 'tests/')) or name == 'docs/designs/simulator_completion_v1.md':
            data = os.fsencode(os.readlink(ROOT / name)) if row['mode'] == '120000' else (ROOT / name).read_bytes()
            assert len(data) == size and hashlib.sha256(data).hexdigest() == record['sha256'], name
            current_inputs += 1
    batch.stdin.close()
    assert batch.wait(timeout=30) == 0
    log = (HOST / 'focused-suite.log').read_text()
    successes = re.findall(r'^(test_\w+) \(([^)]+)\) \.\.\. ok$', log, re.M)
    assert len(successes) == 83 and len({qualified for _, qualified in successes}) == 83
    assert re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', log, re.M) == [('83', '87.502')]
    assert len(re.findall(r'^OK$', log, re.M)) == 1
    assert not re.search(r'\.\.\. (?:FAIL|ERROR|skipped|expected failure|unexpected success)', log)
    modules = Counter(qualified.split('.')[0] for _, qualified in successes)
    static = set()
    for name in report['focused_test_files']:
        module = Path(name).stem
        syntax = ast.parse(git('show', COMMIT + ':' + name))
        for cls in syntax.body:
            if isinstance(cls, ast.ClassDef):
                for method in cls.body:
                    if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'):
                        static.add(module + '.' + cls.name + '.' + method.name)
    assert static == {qualified for _, qualified in successes}
    assert modules['test_p06_simulator_error_boundary'] == 5
    for row in tools['files'].values():
        identity(row['path'], row)
    assert len(tools['files']) == 43 and len(tools['probes']) == 27
    assert report['driver_before'] == report['driver_after']
    identity(report['driver_before']['path'], report['driver_before'])
    assert sha(HOST / 'receipt-driver.py') == report['driver_before']['sha256']
    invocation = load(HOST / 'invocation.json')
    for key in ('argv', 'budget', 'command', 'cwd', 'environment_allowlist', 'expected_head'):
        assert invocation[key] == report[key], key
    assert report['argv'] == ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'ci/project', '-p', 'test_p06_simulator_*.py', '-v']
    assert report['budget'] == dict(timeout_seconds=300, min_free_bytes=1024**3,
                                   max_log_bytes=8*1024**2, max_rss_bytes=1024**3, poll_seconds=0.1)
    process = report['process']
    assert process['process_started'] and process['cleanup_complete'] and process['exit_code'] == 0
    assert process['outcome'] == 'pass' and process['reason'] is None
    assert process['log_sha256'] == sha(HOST / 'focused-suite.log') == '431a5feeeee82aa756637fdaddaeb275221146449ca6688b0eaa8e25521db880'
    assert report['resources_before']['ready'] and report['resources_after']['ready']
    assert report['native_execution'] == 'not_run' and report['native_policy_process_calls'] == 'mocked'
    assert tools['files']['sys.executable']['resolved_path'] == tools['files']['suite:python3']['resolved_path']
    return dict(report_sha256=sha(HOST / 'report.json'), log_sha256=sha(HOST / 'focused-suite.log'),
                artifact_files=8, revision=COMMIT, tree=source['tree'], source_counts=dict(counts),
                source_blob_bytes=total_bytes, current_execution_inputs_checked=current_inputs,
                test_modules=dict(modules), tests=83, tool_files=43, tool_probes=27,
                process=process, budget=report['budget'], limitations=report['limitations'])

def parent_audit():
    report = load(PARENT / 'report.json')
    assert sha(PARENT / 'report.json') == '3183ed4fd2be6fbcb64d62f3a4008b13762d144de8ff3f603617a3b36a79c7a5'
    assert report['candidate_revision'] == COMMIT and report['parent_revision'] == BASE
    assert report['candidate_status'] == '' and report['state'] == 'finished'
    assert report['outcome'] == 'pass' and report['full_matrix_completed'] and report['reason'] is None
    assert report['qualified'] is False and report['acceptance_claimed'] is False and report['native_execution'] is False
    assert report['environment']['GIT_NO_REPLACE_OBJECTS'] == '1'
    work = Path(report['paths']['work'])
    for prefix in ('source', 'parent', 'generated', 'tools', 'extra_tools'):
        assert report[prefix + '_before'] == report[prefix + '_after'], prefix
    for location, field, commit in (('inputs/candidate', 'source_before', COMMIT), ('inputs/parent', 'parent_before', BASE)):
        records = report[field]
        manifest_directory(PARENT / location, records)
        for name, record in records.items():
            data = git('show', commit + ':' + name)
            assert len(data) == record['size_bytes'] and hashlib.sha256(data).hexdigest() == record['sha256'], name
            assert (PARENT / location / name).read_bytes() == data, name
            if field == 'parent_before':
                assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == report['parent_git_blobs'][name]
                assert (work / 'parent-sources' / name).read_bytes() == data
            else:
                assert (ROOT / name).read_bytes() == data, name
    manifest_directory(PARENT / 'configuration', report['generated_before'])
    for name, record in report['generated_before'].items():
        identity(work / 'rv64-p02-tfr' / name, record)
    for name, equal in report['shared_parent_candidate_equal'].items():
        assert equal and report['source_before'][name] == report['parent_before'][name], name
    commands = {row['id']: row for row in report['commands']}
    assert len(commands) == len(report['commands']) == 51
    failed = 0
    for name, entry in commands.items():
        result = entry['result']
        raw = (PARENT / entry['log']).read_bytes()
        assert len(raw) == result['log_size_bytes'] and hashlib.sha256(raw).hexdigest() == result['log_sha256']
        assert result['process_started'] and result['cleanup_complete']
        assert result['duration_seconds'] < entry['timeout_seconds']
        if name.startswith('run-'):
            failed += 1
            assert result['outcome'] == 'fail' and result['exit_code'] == 1 and result['reason'] == 'nonzero_exit'
        else:
            assert result['outcome'] == 'pass' and result['exit_code'] == 0 and result['reason'] is None
        if name.startswith('parent-source-'):
            name_ = entry['argv'][-1].split(':', 1)[1]
            assert raw == (PARENT / 'inputs/parent' / name_).read_bytes()
    assert failed == 8
    assert (PARENT / commands['candidate-status']['log']).read_bytes() == b''
    assert (PARENT / commands['candidate-revision']['log']).read_text().strip() == COMMIT
    assert (PARENT / commands['parent-revision']['log']).read_text().strip() == BASE
    assert (PARENT / commands['parent-blob-identities']['log']).read_text().splitlines() == [report['parent_git_blobs'][a.split(':',1)[1]] for a in commands['parent-blob-identities']['argv'][4:]]
    cells = set()
    for cell in report['cells']:
        key = (cell['backend'], cell['group'], cell['memory'])
        assert key not in cells
        cells.add(key)
        expected = 'FAIL simulator-completion ' + cell['group'] + ': failed launch was accepted as successful\n'
        assert cell['outcome'] == 'expected_failure'
        entry = commands[cell['run_command']]
        assert entry['result'] == cell['result']
        assert (PARENT / entry['log']).read_text() == expected == cell['observations']['exact_output']
        assert commands[cell['build_command']]['result']['outcome'] == 'pass'
    assert cells == {(b,g,m) for b in ('simx','rtlsim') for g in ('standard_exception','unknown_exception') for m in ('ram','llc')}
    binaries = {}
    for backend, row in report['builds'].items():
        assert row['binary_before'] == row['binary_after']
        identity(row['binary_before']['path'], row['binary_before'])
        binary = Path(row['binary_before']['path'])
        with binary.open('rb') as stream:
            assert stream.read(4) == b'\x7fELF'
        assert os.access(binary, os.X_OK)
        argv = commands['build-' + backend]['argv']
        expected = [report['tools_before']['compiler']['path'], '-std=c++17', '-O1', '-g0', '-Wall', '-Wextra', '-Werror', '-DNDEBUG', '-DVX_CFG_XLEN=64', '-DVX_CFG_XLEN_64', '-fsanitize=undefined', '-fno-sanitize-recover=undefined', '-pthread']
        if backend == 'simx':
            expected += ['-DCOMPLETION_SIMX']
        for include in (ROOT/'ci/project/fixtures/simulator_completion', work/'rv64-p02-tfr/sw', ROOT/'sw/runtime/common', ROOT/'sw/runtime/include', ROOT/'sw/common', ROOT/'sim/simx', ROOT/'sim/common'):
            expected += ['-I', str(include)]
        expected += [str(work/'parent-sources/sw/runtime'/backend/'vortex.cpp'), str(ROOT/'sim/common/cmd_processor.cpp'), str(ROOT/'ci/project/fixtures/simulator_completion/main.cpp'), '-Wl,--wrap=free', '-o', str(binary)]
        assert argv == expected, backend
        binaries[backend] = row['binary_before']
    for label in ('tools_before', 'extra_tools_before'):
        for row in report[label].values():
            identity(row['path'], row)
    assert report['tools_before']['configure-python3']['resolved_path'] == report['tools_before']['sys.executable']['resolved_path']
    for snapshot in ('resources_before', 'resources_after'):
        assert all(size >= 1024**3 for size in report[snapshot]['free_disk_bytes'].values())
    assert report['budget'] == dict(jobs=1, max_log_bytes=1024**2, max_rss_bytes=1024**3, min_free_bytes=1024**3, timeouts_seconds=dict(build=60, configure=60, probe=10, run=10))
    source = (PARENT / 'inputs/candidate/ci/project/p06_simulator_parent.py').read_text()
    assert '"GIT_NO_REPLACE_OBJECTS": "1"' in source
    assert 'run_bounded(entry["argv"], Path(entry["cwd"]), environment,' in source
    return dict(report_sha256=sha(PARENT/'report.json'), candidate=COMMIT, parent=BASE,
                candidate_inputs=len(report['source_before']), parent_inputs=len(report['parent_before']),
                generated_inputs=len(report['generated_before']), shared_equal=len(report['shared_parent_candidate_equal']),
                command_logs=51, successful_commands=43, expected_failure_cells=8,
                tool_files=len(report['tools_before']), extra_tool_files=len(report['extra_tools_before']),
                binaries=binaries, budget=report['budget'], limitations=report['limitations'],
                started_at=report['started_at'], finished_at=report['finished_at'])

def main():
    result = dict(reviewed_at=datetime.now(timezone.utc).isoformat(), reviewer='/root/w09_a06_final_host_review',
                  scope='read-only original host receipt verification', native_execution='not_run',
                  git_replacements_disabled=True, replacement_refs=git('for-each-ref','--format=%(refname)','refs/replace/').decode().splitlines(),
                  host=host_audit(), parent=parent_audit(), outcome='pass')
    (OUT / 'audit-summary.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
