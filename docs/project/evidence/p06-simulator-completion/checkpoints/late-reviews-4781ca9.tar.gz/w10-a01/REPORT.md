# Final independent production and build review

## Verdict and exact scope

**No unresolved F2/F3 production defect was found in the final reviewed implementation. Treat the change as R3 and land only after the corresponding repaired-checkpoint native evidence and final delivery review are complete.** This report does not supply that native evidence or waive it.

Reviewed range: audited master `42809ff0c1b81384d7c9b079e4ef786be8407600` to frozen implementation `4781ca96db15a1d130626edc7a73411a4f6c2e7c`. The review is author-disjoint: I wrote no production, tests, contracts or repository documents. I inspected every hunk in the ten production/build files and relevant unchanged consumers. Later working-tree edits were confined to documentation/evidence; the ten reviewed files matched the frozen Git blobs before and after this review.

I applied the repository `code-review` and `simx-review` skills, AGENTS, C++/Verilog guidelines, bug-fix discipline, review policy, SimObject design and simulator architecture. The **base revision's** classifier and policy were extracted into this packet and executed with Git replacements disabled. Both `classify` and `explain` returned **R2** across the 91-file checkpoint diff, with the SimX/RTL lockstep and configure-copied evidence notices. The externally visible completion/error behavior warrants **R3** despite that advisory result. No golden, threshold, ABI, ISA, configuration or new workflow-trust detector fired.

## Hunk-by-hunk conclusions

| Changed file or boundary | Review conclusion |
|---|---|
| `sim/simx/processor.cpp` and `.h` | The only implementation addition is a void checked entry calling the existing `impl_->run()`. It propagates exceptions and deliberately discards the legacy register-derived integer. Removing the exact new entry restores the original `.cpp` byte-for-byte; removing its declaration/comment restores the original header. The old direct `run()` catch/log/`-1` behavior, model loop, launch/reset, DCR, memory, arithmetic and cycle paths are unchanged. Legitimate x3/gp values, including `-1`, cannot be mistaken for execution status. |
| `AsyncRun::start`, `check`, `collect` | Exactly one owned `future<void>` is started with explicit asynchronous policy. Observed completion is consumed with `get()`. Task creation, overlapping launches and exceptional futures latch terminal failure. A second start cannot overwrite a pending future or an unobserved launch edge. The worker task does not concurrently mutate the plain host-owned flags. |
| `AsyncRun::busy`, `wait`, `wait_for` | The launch edge is separate from future validity. A normal completion consumed by any supported path still produces the first busy observation, then idle. Failure is checked before the edge is exposed. This matches the unchanged CP `PulseStart → WaitBusy → WaitDrain → Idle` protocol and avoids successful retirement of an exceptional launch. |
| `AsyncRun::invoke`, `failed` | Synchronous processor calls first consume pending execution, then call the hook in the same host frame. Every thrown type latches failure and is rethrown. No lambda is retained, so reference captures stay valid. Classification follows operation origin, not exception type. `fail()` remains an explicit internal test seam for pending-owner teardown. |
| `AsyncRun::join` and both backend destructors | Join consumes outstanding execution without calling the healthy-state guard, including an already-poisoned owner with a live task. It records exceptions without letting them escape destruction. Both backend destructor bodies join before freeing registered host memory; member destruction subsequently releases CP, completion owner, processor and RAM. No task detachment, forced cancellation or timeout-based reclamation was added. |
| Both CP register callbacks | Each callback checks owner completion before CP work and again before returning success. Once owner failure is latched, catches return the existing nonzero HAL error and later callbacks fail before touching CP state. A failed read does not publish its output as a successful response. An unrelated CP/host exception is rethrown while the owner is healthy. SimX's existing bounded 50 µs host poll remains bounded and performs no wait when there is no future. |
| Processor-facing hooks in both backends | Every changed DCR read/write and LLC read/write, including DMA/no-allocation write, uses `invoke`; processor RTL drain does too. These actual processor paths can advance model/cache state, so a thrown exception is terminal. Host-region memcpy, direct RAM reads/writes and constant capability queries retain their inherited route. Successful hook call order and synchronization are preserved. |
| Recoverable CP scratch allocation | The unchanged copy branch selects `EngState::Retire` before allocating scratch. Its bad allocation occurs outside `invoke`, so the callback rethrows through unchanged forwarding/adapter code to the queue's existing OOM catch. Staging is released during unwind. A later tick retires the abandoned descriptor without replay, and queue finish can consume the queue-local error. This specific recovery does not rehabilitate a failed processor or promise rollback after partially completed writes. |
| Timing and functional framework cleanup | Each header has exactly the same three added lines at full cleanup. Workers are stopped/joined first, then reset registrations, object ownership, scheduled/immediate events, domains and cross-domain inboxes are disposed; abandoned global channel accounting is then set to zero. No reset, launch-reset, send, pop, event or scheduler code changed. Late channel destruction only unregisters the channel and does not decrement the global count, so it cannot subtract old occupancy from a fresh context. External finalized objects remain destruction-only. |
| Both runtime Makefiles | The sole edit adds `async_run.h` as a prerequisite of the backend shared library. Compilation still passes `$(SRCS)`, not `$^`, so the header is not treated as a translation unit. Removing that dependency restores each original Makefile exactly. The existing dependency regression uses fresh configure output and checks unchanged/unrelated/helper-changed cases for both backends. |
| `sim/simx/completion.mk` | An additive test fragment includes the unchanged accepted Makefile, uses its model objects and flags, and adds separately named checked/legacy test objects and binaries. It introduces no production configuration override, pipeline option, install rule or changed accepted target. The optional legacy variant is not treated as executed native evidence. |

## Protected behavior and byte proofs

`invariants.json` records six exact-addition proofs and **35 unchanged Git object identities**, including whole trees for hardware, kernel, shared software headers, installed runtime headers, goldens, test catalogs and profiles. It also covers the accepted SimX Makefile; configuration/ISA files; toolchain pin; configure/config generation; actual CP, adapter, queue, event and device consumers; the original lifecycle test; all six matched gate/threshold scripts; frozen warm contract/analyzer/replay; roadmap, acceptance and review policy; and framework SVG.

Thus the processor timing loop, full framework scheduler/reset code, instruction implementation, counter layout, arithmetic, public ABI and RTL are unchanged. The added checked wrapper and teardown-only reset alter host failure/completion semantics and disposal of an abandoned context. They make no claim about host wall-time improvement or equality of host-driven CP polling iterations. No cycle tolerance or performance/area baseline was changed. A new model-parity experiment is not substituted for this byte proof, and no native parity run was performed by this reviewer.

The following source checks ran successfully and have original output retained:

- Base classifier `classify` and `explain`, using the immutable base policy, with `GIT_NO_REPLACE_OBJECTS=1`.
- `bash ci/check_sw_sim_boundary.sh` — boundary check OK.
- `bash ci/check_simx_mt_boundary.sh` — threading-boundary check passed.
- `git diff --check 42809ff0c1b81384d7c9b079e4ef786be8407600 4781ca96db15a1d130626edc7a73411a4f6c2e7c` — clean.

## Evidence inspected and limits

The clean repaired-checkpoint receipt records **83 successful focused tests in 87.502 seconds**, with all full-source/tool/driver integrity flags true. The audited-parent replay at the same candidate records 51 commands and all eight intended exception failures against fixed parent `42809ff`. The new error-boundary packet records five methods, 38 positive execution cells and four compiled `db5ebb3` negative controls. I inspected the real inherited lifecycle assertions, the new hook fixture/driver, these original reports, and the prior independent boundary review. The original receipt identities are recorded in `evidence-observed.json`; the dedicated final host-packet audit is separately owned by agent #54. I did not rerun those host suites or reproduce the full archive audit here.

The initial native review supports checkpoint `db5ebb3` only. Its retained runtime owner and both backend source files differ from the repaired checkpoint. **Fresh native evidence for the repaired bytes has not been inspected in this source review; it remains a release obligation handled separately.** The required actual bounded-RAM exception/fresh-context native unit and real public-success kernel must remain intact. A ready workflow or prior native success cannot close this obligation.

Supported host ownership remains serial. This change does not add thread-safe simultaneous control of one owner, concurrent managed contexts, recovery of a poisoned processor, same-thread direct tick-exception TLS restoration, multiworker exception transport, forced cancellation, signal/fatal-abort recovery or bounded destruction of a hung worker. Native public-runtime injected-fault behavior, native RTL/functional-SimX fault execution, performance qualification, vendor integration and physical results require separate evidence.

## Findings and disposition

- **F0, high confidence, static-proof:** the advisory classifier reports R2, but the externally visible completion and error-origin contract is reviewed as R3. The classifier and policy were not modified.
- **F0, high confidence, static-proof plus observed regression records:** the intermediate CP OOM regression is repaired by the final origin-based boundary. The original lifecycle assertions and CP retirement implementation remain unchanged.
- **No unresolved F1/F2/F3 production finding in the ten-file scope.** Earlier reviews' broader runner, workflow, archive and consumer scopes are separate; this report is not a replacement for them.
- **Open release evidence obligation (F2, high confidence, missing-test evidence in this review packet):** obtain and independently review native execution bound to repaired checkpoint `4781ca9`, then reconcile final source/evidence identities and publication status. This is not a new code defect or waiver. Close it with the corresponding original native packet, not with the pre-repair native result.

**Class: R3. Verdict: land after the listed native-evidence and final-delivery obligations are closed.** No performance, P06 gate, vendor, framework or physical acceptance is granted here.

## Exact reviewed production identities

| File | SHA-256 |
|---|---|
| `sim/common/simobject.h` | `0e0369f5ea1ba85f5e461e03b85e9723bb47f0e118499ba2b21a7923594f7004` |
| `sim/common/simobject_functional.h` | `0a62df63e18f340096bda900ccb858e00a3c2d54d7688c92737c5cca06210984` |
| `sim/simx/completion.mk` | `371f1cc7ad00e00094cb80e03074e114bf38134c59e03a617f34ec9fe209f235` |
| `sim/simx/processor.cpp` | `569cf629d1e25ec9a295b20bfadfabbe21cd0989127f2b825fceee99a8062b78` |
| `sim/simx/processor.h` | `588db10c3997e91dd471771cd12bb0329dacbc3902248b84353beebd19bc0438` |
| `sw/runtime/common/async_run.h` | `a9f63b2a896c5e512f7c592c758618ea88b774c9dac4bca29e847e2e3719a24e` |
| `sw/runtime/rtlsim/Makefile` | `1a2e731e8a676d3f57a891dfa380c4992d42ed066c81256a82ea278e78602ab4` |
| `sw/runtime/rtlsim/vortex.cpp` | `e6e049d41ccb3315fd464387a4006745a82160849795af50411edcef6095ac93` |
| `sw/runtime/simx/Makefile` | `a904a327b54481567d5efd205da7cba3fed0f7ecb6410ab641753d789c8ee975` |
| `sw/runtime/simx/vortex.cpp` | `0d890c95fecb67da26d23ea4a0af10ac328dddf110cd2575baff3aa5d4c905cb` |
