#!/usr/bin/env python3
"""Independent retained-data and documentation audit; executes no packet code."""
from pathlib import Path, PurePosixPath
import collections
import hashlib
import io
import json
import os
import re
import stat
import subprocess
import tarfile
import zipfile

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
WORK = ROOT.parent
OUT = WORK / 'w10-a02'
PACKET = ROOT / 'docs/project/evidence/p06-simulator-completion'
PREFIX = PACKET.relative_to(ROOT).as_posix() + '/'
BASE = '42809ff0c1b81384d7c9b079e4ef786be8407600'
CODE = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
INITIAL = 'db5ebb3a16770004423f2456ec6d0caaa0aced6d'
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')
DOCS = ['README.md', 'docs/project/status.md', 'docs/project/backlog.md',
        'docs/project/p06-simulator-completion-audit.md',
        'docs/project/p06-mpm-qualification-plan.md',
        'docs/project/p06-workspace-handoff.md']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ident(path):
    data = path.read_bytes()
    return dict(size_bytes=len(data), sha256=sha(data))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


def safe(name):
    p = PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name, name


def verified_zip(data, label):
    members = {}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert sum(i.file_size for i in z.infolist()) < 128 * 1024**2
        assert len(z.namelist()) == len(set(z.namelist()))
        for i in z.infolist():
            safe(i.filename)
            mode = i.external_attr >> 16
            assert not stat.S_ISLNK(mode), i.filename
            if i.is_dir():
                continue
            payload = z.read(i)
            assert len(payload) == i.file_size
            members[i.filename] = payload
    return members


manifest_bytes = (PACKET / 'manifest.json').read_bytes()
index_bytes = (PACKET / 'checkpoints/index.json').read_bytes()
assert sha(manifest_bytes) == '2c36552dddc7fd5e762ef490b6a70ad4cbbba82ee73976664bf11f2705fe2496'
assert sha(index_bytes) == '9efce087f6c7cc5958919f88dd2d6cf56e17faafad969a860c7806fe18a040d6'
manifest = json.loads(manifest_bytes)
index = json.loads(index_bytes)
before = {p.relative_to(PACKET).as_posix(): ident(p) for p in PACKET.rglob('*') if p.is_file()}
listed = {r['path'] for r in manifest['files']}
assert listed == set(before) - {'manifest.json'}
for row in manifest['files']:
    assert before[row['path']] == {k: row[k] for k in ('size_bytes', 'sha256')}, row['path']

old_paths = git('ls-tree', '-r', '--name-only', CODE, '--', PREFIX).decode().splitlines()
assert len(old_paths) == 45
old_root = {}
for path in old_paths:
    relative = path.removeprefix(PREFIX)
    original = git('show', CODE + ':' + path)
    if relative in ('README.md', 'manifest.json'):
        old_root[relative] = original
    else:
        assert (PACKET / relative).read_bytes() == original, relative

archive_results = []
selected = {}
zip_results = []
development = json.loads((PACKET / 'development/index.json').read_text())
for phase, records in [('development', development['artifacts']), ('checkpoints', index['archives'])]:
    for row in records:
        archive = PACKET / row['archive']
        sidecar = PACKET / row['manifest']
        raw_sidecar = sidecar.read_bytes()
        description = json.loads(raw_sidecar)
        raw_archive = archive.read_bytes()
        assert sha(raw_archive) == row['sha256'] and len(raw_archive) == row['size_bytes']
        if 'manifest_sha256' in row:
            assert sha(raw_sidecar) == row['manifest_sha256']
        files = {r['path']: r for r in description['files']}
        assert len(files) == len(description['files'])
        with tarfile.open(fileobj=io.BytesIO(raw_archive), mode='r:gz') as t:
            names = t.getnames()
            assert len(names) == len(set(names))
            assert set(names) == set(files) | {'MANIFEST.json'}
            total = 0
            for m in t:
                safe(m.name)
                assert m.isfile() and not m.issym() and not m.islnk(), m.name
                total += m.size
                assert total < 256 * 1024**2
                data = t.extractfile(m).read()
                assert len(data) == m.size
                if m.name == 'MANIFEST.json':
                    assert data == raw_sidecar
                    continue
                f = files[m.name]
                assert len(data) == f['size_bytes'] and sha(data) == f['sha256'], m.name
                if phase == 'checkpoints':
                    original = Path(f['original_path'])
                    assert original.is_file() and original.read_bytes() == data, str(original)
                    selected[(row['name'], m.name)] = data
                if m.name.endswith('.zip'):
                    zipped = verified_zip(data, m.name)
                    zip_results.append(dict(name=m.name, size_bytes=len(data), sha256=sha(data),
                                            members=len(zipped), uncompressed_bytes=sum(map(len, zipped.values()))))
                    selected[(row.get('name', row.get('id')), 'ZIP_CONTENTS')] = zipped
        archive_results.append(dict(phase=phase, archive=row['archive'], originals=len(files),
                                    uncompressed_bytes=sum(r['size_bytes'] for r in files.values()),
                                    archive_sha256=sha(raw_archive)))

for name, data in old_root.items():
    assert selected[('development-index-db5ebb3', 'root-at-db5/' + name)] == data


def one(name, suffix):
    matches = [v for (a, p), v in selected.items() if a == name and p.endswith(suffix)]
    assert len(matches) == 1, (name, suffix, len(matches))
    return matches[0]


host = json.loads(one('host-4781ca9', '/report.json'))
host_log = one('host-4781ca9', '/focused-suite.log').decode()
assert host['expected_head'] == CODE and host['outcome'] == 'pass'
assert host['unittest_summary'] == {'count': 83, 'duration_seconds': 87.502}
assert all(host['integrity'].values()) and host['unittest_ok_without_skips']
methods = re.findall(r'^([^\n]+) \.\.\. ok$', host_log, re.M)
assert len(methods) == len(set(methods)) == 83
assert sum('test_p06_simulator_error_boundary.' in s for s in methods) == 5
assert sha(host_log.encode()) == '431a5feeeee82aa756637fdaddaeb275221146449ca6688b0eaa8e25521db880'
assert host['native_execution'] == 'not_run'

parent = json.loads(one('parent-4781ca9', '/report.json'))
assert parent['candidate_revision'] == CODE and parent['parent_revision'] == BASE
assert parent['outcome'] == 'pass' and parent['full_matrix_completed']
assert parent['qualified'] is False and parent['acceptance_claimed'] is False
assert len(parent['commands']) == 51 and len(parent['cells']) == 8
for c in parent['cells']:
    r = c['result']
    assert c['outcome'] == 'expected_failure'
    assert r['exit_code'] == 1 and r['reason'] == 'nonzero_exit'
    assert r['process_started'] and r['cleanup_complete']
assert all(r['result']['exit_code'] == 0 for r in parent['commands'] if not r['id'].startswith('run-'))

cp = json.loads(one('cp-allocation-repair', '/w08-a06/report.json'))
assert cp['pass'] and cp['source_stable'] and len(cp['tests']) == 5
assert all(t['outcome'] == 'pass' for t in cp['tests'])
assert len(cp['negative_controls']) == 4
for c in cp['negative_controls']:
    assert c['outcome'] == 'expected_failure'
    assert 'test_ai_lifecycle.cpp:415: result == VX_ERR_OUT_OF_HOST_MEMORY' in c['detail']
cp_commands = json.loads(one('cp-allocation-repair', '/w08-a06/commands.json'))
assert len(cp_commands) == 51
outcomes = collections.Counter(r['result']['outcome'] for r in cp_commands)
assert outcomes == {'pass': 47, 'fail': 4}

native_zip = selected[('native-db5ebb3', 'ZIP_CONTENTS')]
native = json.loads(native_zip['simulator-completion/report.json'])
assert native['outcome'] == 'pass' and native['full_matrix_completed']
assert native['qualified'] is False and native['acceptance_claimed'] is False
assert native['source_scope'] == 'rv64-p02-tfr-timing-simx-perf-on'
unit, public = native['cells']
assert unit['observations'] == dict(checked_exceptions=1, checked_success=9, contexts=5,
                                  legacy_errors=1, legacy_success=3)
assert public['observations']['contexts'] == 2 and public['observations']['launches'] == 6
assert public['observations']['gp_nonzero'] == 6 and len(public['observations']['witnesses']) == 6
for record in native['commands']:
    r = record['result']
    assert r['outcome'] == 'pass' and r['exit_code'] == 0 and r['cleanup_complete']
    data = native_zip['simulator-completion/' + record['log']]
    assert sha(data) == r['log_sha256'] and len(data) == r['log_size_bytes']
    if record['id'] == 'unit-run':
        text = data.decode()
        assert 'native_x3 gp=-1 checked_launches=3 legacy_launches=1' in text
        assert 'native_exception type=OutOfRange consumed=1' in text
        assert text.rfind('native_x3 gp=7') > text.find('native_exception type=OutOfRange')
    if record['id'] == 'public-run':
        assert 'PASSED simx_completion native_success contexts=2 launches=6 gp_nonzero=6' in data.decode()
assert native['source_before'] == native['source_after']

warm = json.loads(one('warm-db5ebb3', '/replay.json'))
assert warm['outcome'] == 'pass' and warm['full_matrix_completed']
assert warm['hypothesis_evaluation'] == 'blocked'
assert warm['full_hypothesis_qualification']['qualified'] is False
assert warm['full_hypothesis_qualification']['absolute_no_wrap_bound'] == 'not_established'
assert warm['conditional_evaluation'] == 'not_satisfied'

docs = {name: (ROOT / name).read_text() for name in DOCS}
links = []
for name, contents in docs.items():
    for target in re.findall(r'\]\(([^)]+)\)', contents):
        target = target.split('#', 1)[0]
        if not target or re.match(r'\w+://', target) or target.startswith(('mailto:', 'data:')):
            continue
        target = target.split(' "', 1)[0]
        path = (ROOT / name).parent / target
        assert path.exists(), (name, target)
        links.append(dict(source=name, target=target))
for name in DOCS[:4]:
    assert '4781ca9' in docs[name] and 'pending' in docs[name]
for name in DOCS[4:]:
    assert 'not implemented' in docs[name] or 'not implemented' in docs[name].replace('\n', ' ')
assert 'P06-WARM-RV64-MPM-HIGH-HALF' in docs[DOCS[4]]

contract = json.loads((ROOT / 'ci/project/p06_warm_contract.json').read_text())
isa = contract['capability_values']['isa_flags']
available = [r for r in contract['counters'] if not r['required_isa'] or r['required_isa'] & isa == r['required_isa']]
assert len(available) == 33 and len(contract['counters']) == 45
simx_seeds = {(0, 0), (0, 2), (1, 3), (1, 4), (1, 30)}
rtl_text = (ROOT / 'hw/unittest/mpm_transport/main.cpp').read_text()
array = rtl_text.split('PerfCase perf_cases[] = {', 1)[1].split('#ifdef VX_CFG_EXT_TCU_ENABLE', 1)[0]
rtl_seeds = {(0, 0), (0, 2)} | {(int(a), int(b)) for a, b in re.findall(r'&tb\.sim->\w+,\s*(\d+),\s*(\d+),', array)}
required = {(r['mpm_class'], r['csr'] - 0xb00) for r in available}
assert len(required & simx_seeds) == 5 and len(required & rtl_seeds) == 19
assert 'VX_CSR_MPM_MEM_BANK_ST' in (ROOT / 'sim/simx/csr_unit.cpp').read_text()
assert 'VX_CSR_MPM_MEM_BANK_ST' not in (ROOT / 'hw/rtl/core/VX_csr_mpm.sv').read_text()
assert (2**32 - 1)**2 == 2**64 - 2**33 + 1 < 2**64
assert 2 * 6 * 2 * 33 == 792 and 792 * 32 == 25344
assert 640 + 20 + 128 + 4 == 792

changed = git('diff', '--name-only', BASE).decode().splitlines()
protected = [p for p in changed if p.startswith(('hw/', 'ci/baselines/', 'ci/testcases/', 'profiles/',
              'sw/runtime/include/', 'sw/kernel/include/')) or p in ('docs/project/roadmap.json',
              'VERSION', 'VX_config.toml', 'VX_types.toml', 'ci/project/p06_warm_contract.json',
              'ci/project/p06_warm_analyze.py', 'ci/project/p06_warm_replay.py') or 'acceptance' in Path(p).name]
assert not protected, protected
assert git('show', BASE + ':tests/runtime/test_ai_lifecycle.cpp') == (ROOT / 'tests/runtime/test_ai_lifecycle.cpp').read_bytes()
assert before == {p.relative_to(PACKET).as_posix(): ident(p) for p in PACKET.rglob('*') if p.is_file()}

summary = dict(outcome='pass', stage='initial-evidence-assembly-before-final-native-and-ledger',
    code_revision=CODE, root_manifest_sha256=sha(manifest_bytes), checkpoint_index_sha256=sha(index_bytes),
    packet_files=len(before), packet_bytes=sum(r['size_bytes'] for r in before.values()),
    original_files_preserved=43, original_root_metadata_archived=2, archives=archive_results,
    zip_archives=zip_results, checkpoint_original_members=sum(r['originals'] for r in archive_results if r['phase']=='checkpoints'),
    development_original_members=sum(r['originals'] for r in archive_results if r['phase']=='development'),
    host_methods=len(methods), parent_cells=len(parent['cells']), cp_positive_cells=38, cp_negative_cells=4,
    initial_native_unit=unit['observations'], initial_native_public={k:v for k,v in public['observations'].items() if k!='witnesses'},
    warm_qualification=warm['full_hypothesis_qualification'], warm_conditional_evaluation=warm['conditional_evaluation'],
    docs={name: ident(ROOT/name) for name in DOCS}, relative_links_checked=len(links),
    counter_inventory=dict(available=len(available),unavailable=12,simx_old_seed_coverage=5,rtl_old_seed_coverage=19),
    protected_paths_changed=protected, packet_unchanged_during_audit=True,
    retained_programs_executed=False, builds_or_tests_run=False,
    pending=['Fresh repaired-checkpoint native packet and independent review', 'Repaired-checkpoint full governance receipt',
             'Late independent reviews', 'Actual 60-assignment delivery ledger', 'Final publication and source projection'])
(OUT/'audit-summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
(OUT/'packet-files.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
(OUT/'links.json').write_text(json.dumps(links,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:summary[k] for k in ('outcome','packet_files','packet_bytes','checkpoint_original_members','development_original_members','relative_links_checked')}))
