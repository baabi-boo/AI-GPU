# Wave 10, assignment 2 — evidence and documentation review

## Disposition

**The initial reconciled package passes this independent retained-data and
claim-scope audit. No new F2/F3 defect was found in its packaging or the reviewed
documentation. This is not approval of an unverified final release.**

The reviewed code checkpoint is `4781ca96db15a1d130626edc7a73411a4f6c2e7c`.
The documentation and evidence assembly are subsequent, uncommitted worktree
changes. The exact reviewed file hashes are in `audit-summary.json` and
`packet-files.json`. The root packet manifest was
`2c36552dddc7fd5e762ef490b6a70ad4cbbba82ee73976664bf11f2705fe2496`; its checkpoint
index was `9efce087f6c7cc5958919f88dd2d6cf56e17faafad969a860c7806fe18a040d6`.

The package explicitly retains the remaining obligations: the corresponding
repaired-checkpoint native packet and independent review, current full
governance receipt, late review records, the actual 60-assignment ledger, and
final publication/source projection. Those were **not included in this audit
snapshot**. Neither the old native pass nor this packaging review closes them.
The coordinator should request a final delta review after those additions.

I wrote only this scratch review packet. I edited no repository source,
documentation, test, accepted evidence, baseline or threshold. No build, test,
simulator, retained program or retained binary was executed. My newly authored
`audit.py` reads files and archive members, performs arithmetic/hash checks,
and uses read-only Git commands with `GIT_NO_REPLACE_OBJECTS=1`.

## Independently verified package integrity

The assembler supplied a stable-ready signal before inspection. The package
remained byte-identical throughout the audit.

| Item | Independent result |
|---|---|
| Root delivered inventory | All **72 files / 12,998,100 bytes** agree with the root manifest; its file set is exact, excluding only the manifest itself. |
| New checkpoint archives | All **12 archives / 615 original members** match their archive digest, sidecar member manifest and original scratch-file bytes. |
| Preserved development archives | All **10 archives / 304 original members** match their recorded archive and member digests. |
| Internal manifests | Every archive's `MANIFEST.json` is byte-identical to its sidecar and properly omitted from its own member list. |
| Historical preservation | All **43 non-root-index historical files** equal their exact unreplaced Git blobs at `4781ca9`. The previous README and root manifest are preserved verbatim inside the historical-index archive. |
| Archive path/type checks | Every tar member is an ordinary file with a unique safe relative path; no links, traversal or absolute paths. Both nested ZIPs also have unique safe paths, no symbolic links and bounded decoded size. |
| Original native ZIP | **2,791,612 bytes**, SHA-256 `d5f71cec99321c5f8e6c11fab37875aa93e551270a1a15c29b3fe9af6c766588`; all **812** members read successfully. Its digest, size and `db5ebb3` head agree with retained GitHub artifact metadata. |
| Original warm ZIP | **5,870,951 bytes**, SHA-256 `9abac0ec3611c111528968460121db19e3449ad7184e7b8c433e0ad20b54e744`; all **1,256** members read successfully. |
| Source and scope exclusions | Duplicate extracted native/warm trees remain completely available inside their unchanged ZIPs. Parent workdir executables, compiler caches and separately excluded binaries are not represented as archived. Original records preserve their declared binary/tool identities and omissions. |

The total is **919 original tar members** plus their 22 internal manifests.
Both nested original ZIPs contain **2,068 files**. No retained script was
imported or executed to obtain these integrity results.

## Verification claims checked against original records

The current six development documents, implemented completion contract and
two evidence indexes consistently distinguish the following source states:

| Claim | What I checked directly | Interpretation |
|---|---|---|
| Clean repaired host discovery | The archived `4781ca9` report and raw log contain **83 distinct successful methods**, including all five error-boundary methods; **87.502 seconds**; all source/tool/driver integrity flags true; host-only scope. | This is actual normal unittest discovery, separate from the earlier development driver's method invocation. |
| Audited-parent sensitivity | Candidate `4781ca9`, pinned parent `42809ff`; **51 commands**, successful setup/build/probe commands and **eight expected failures**, each exit 1, `nonzero_exit`, started and completely cleaned up. | Build failure or timeout is not counted as sensitivity. The eight stored assertions concern accepted-as-success execution failures. |
| CP allocation correction | Original five-method report is successful with stable source hashes; all **51 command records** contain 47 passes and four intended old-backend failures. Each negative control names the inherited lifecycle OOM assertion after stages 0 and 1 passed. | The four full unchanged lifecycle processes and 34 terminal-model-fault processes are 38 positive execution cells, not 38 separate unittest methods. Actual Processor/RAM behavior remains controlled. |
| Initial native completion | Original `db5ebb3` ZIP report has both native cells successful. The unit records **five contexts, nine checked successes, three legacy successes, one checked exception and one legacy error**. The public cell has **two contexts and six nonzero-gp successes**. | Fixed timing SimX, RV64 `p02-tfr`, PERF enabled. This predates the CP correction and is not evidence for its later bytes. |
| Native original logs | All **18 native command logs** match report digests and sizes and have successful bounded outcomes/cleanup. Actual unit text includes legitimate `gp=-1`, checked `OutOfRange` consumption, and a later fresh successful context. Public text carries the exact six-launch success banner. | These are native unit/fresh-context and public-success controls; no native public-runtime fault injection or native RTL execution is inferred. |
| Initial full governance | Original job log independently yields **2,988 unique successful method results**, plus `Ran 2988 tests in 1191.429s` and `OK`. | One test prints its docstring on a second line before `... ok`; the audit handles that legitimate unittest output. This is the old checkpoint's full suite. |
| Existing native warm control | Archived replay is successful/full-matrix, but full hypothesis remains **blocked**, `qualified=false`, absolute no-wrap bound **not_established**, and conditional evaluation **not_satisfied**. | A healthy 24-process execution/replay is not a speedup or performance acceptance. |

The separately archived native review states its deeper source/compiler checks
(761 Git-bound source bodies, five roles and 87 model compile commands). This
audit verifies that review's original bytes and checks the native results/logs
above; it does not pretend to have repeated every compiler-analysis step.
Similarly, the final host review's wider Git/tool inventory is retained with
its own scope. Original development failures, negative controls and prior
review findings were not rewritten to conceal the discovered CP regression.

## Current documentation and next-development claims

I reviewed the complete six updated current documents and their diffs, the
completion contract, root evidence README and checkpoint extraction index.
All **553 relative Markdown file targets** across those nine files resolve.
The review checks file existence, not every HTML fragment or external web URL.

The next-development claims are appropriately prospective. The plan says that
the guard, qualification record and new evidence format are **not implemented**.
It requires independent contract/updater review before guard implementation,
native/public qualification, and only then a fresh unchanged warm experiment.

I independently recomputed **33 available / 12 unavailable** counter rows from
the frozen warm manifest and its ISA mask: BASE 2, CORE 11, ICACHE 3, DCACHE 6,
MEM 8 and TCU 3. The unavailable rows are six each for L2/L3. The original
SimX harness actually seeds cycles, instructions, scheduler idle, active warps
and stores: **5/33**. Intersecting the original RTL fixture's non-TCU seed table
plus base counters with the required rows gives **19/33**. The old native runner
uses empty profile/CONFIGS; TCU-conditional table entries are not silently
counted as executed coverage.

`VX_CSR_MPM_MEM_BANK_ST` is present in SimX's MEM readout and absent from RTL's
MPM decoder. The documentation therefore correctly refuses an all-33 RTL
parity claim. It also keeps coherent two-half read proof separate from selector
coverage and the cumulative no-wrap proof. Source inspection confirms the
platform clock reset and the distinct persistent memory accounting that make
a launch-relative clock insufficient.

The proposed bound is explicitly conditional. I recomputed
`(2^32 - 1)^2 = 2^64 - 2^33 + 1 < 2^64`; that arithmetic does not prove all
updaters are bounded or that such a guard exists. The plan correctly requires
those missing proofs and their executable assumptions. The four-process
diagnostic population is separate from the complete experiment. The full
warm count is `2 formats × 6 pairs × 2 policies × 33 launches = 792`, with
`792 × 32 = 25,344` exact words. Its disjoint launch populations
`640 + 20 + 128 + 4` sum to 792 without double-counting warm-up primes.

## Preserved gates and limits

Against audited master `42809ff`, there are no changed RTL files, public runtime
or kernel headers, profiles, type/configuration definitions, toolchain pin,
test catalogs, goldens, warm contract/analyzer/replay, canonical roadmap, or
acceptance-named records. The inherited lifecycle source is byte-identical.
The canonical phase states remain P00/P02/P03/P04 complete, P01 blocked,
P05/P06 in progress, and P07–P11 not started.

The current docs preserve vendor P01-A03, P05-A02/A03 review, P06-A02/A03,
the inherited DSP finding and physical-device obligations. They do not infer
a completed phase, performance improvement, native functional/RTL failure
qualification, concurrent contexts, forced cancellation, or reuse of a failed
processor. Specific CP allocation recovery remains distinct from processor
failure. The future no-wrap proposal is not presented as current qualification.

The reviewed initial snapshot has no completed 60-agent ledger and explicitly
does not claim one. The final ledger and later native/governance/review data
must be added under fresh identities and the root manifest refreshed. A final
delta audit should verify those additions and the corresponding current prose
without altering these frozen historical archives.

## Audit execution and limitations

The retained commands are `python3 -B audit.py` from the repository root, with
output in `audit-attempt-1.log`, `audit-attempt-2.log` and `audit-attempt-3.log`.
The first attempt completed archive validation but stopped at an auditor path
selector that incorrectly included a leading slash. That selector was corrected
without modifying evidence. Attempts 2 and 3 passed; attempt 3 adds original
governance result parsing and all three additional documentation link sets.
Earlier auditor script versions are retained. This was a review-script
adaptation, not a test or project failure.

Hash and before/after equality checks establish the observed bytes, not
producer honesty, protection against transient replacement, or a hermetic
rebuild. Native public fault execution and the later repaired checkpoint's
native result were not supplied by this initial snapshot. No outside CI
status was fetched or inferred by this reviewer.
