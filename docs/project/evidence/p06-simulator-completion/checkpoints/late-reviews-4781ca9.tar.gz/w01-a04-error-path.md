# Wave 1 agent 4 — asynchronous simulator failure path audit

Audited source: `42809ff0c1b81384d7c9b079e4ef786be8407600` in `/workspace/scratch/ea983fdea786/AI-GPU`.
Scope: source review only; no native execution, production edits or publication.

## Confirmed defects

1. **F3/high/static-proof: SimX launch result is discarded.** `sw/runtime/simx/vortex.cpp::make_cp_hooks` launches `processor_.run()` in a void lambda and stores `std::future<void>`. `sim/simx/processor.cpp::Processor::run` returns nonzero processor exit codes and returns `-1` after caught exceptions. The backend never obtains the result. Its `vortex_busy` returns false when the future becomes ready, allowing normal command retirement after a failed run.
2. **F3/high/static-proof: exceptions carried by the future are not observed.** All current synchronization uses `wait`/`wait_for`; neither rethrows a stored worker exception. Destruction also waits without examining the result. A future budget guard must not rely on an exception reaching the caller through this path.
3. **F2/high/static-proof: completion before the first busy poll can hang.** `sim/common/cmd_processor.cpp::tick_launch` requires `WaitBusy` to see true before entering `WaitDrain`. A future already ready when the first busy hook executes returns false forever. The problem affects successful rapid completion as well as failure. Tests must deterministically force completion before the first busy poll.
4. The same readiness-only `future<void>` structure exists in `sw/runtime/rtlsim/vortex.cpp`; its drain hook also uses wait-only synchronization. Its `Processor::run` is genuinely `void`, so its matching issues are lost asynchronous exceptions and the busy-rise race, not a discarded integer result. This counterpart needs either matching host-transport handling or an explicitly retained limitation. No RTL pipeline timing modification follows from fixing host completion bookkeeping alone.

## Existing propagation route

| Layer | Relevant behavior |
|---|---|
| Backend `cp_reg_read/write` | C callback currently returns zero unconditionally after CP work. This is the narrow place to convert a latched simulator failure into a nonzero HAL result. |
| `CallbacksAdapter::r` in `sw/runtime/common/vortex2_internal.h` | Maps zero to `VX_SUCCESS`, any nonzero HAL result to `VX_ERR_INVALID_VALUE`. Do not claim `VX_ERR_DEVICE_LOST` without a separate adapter change. |
| `Device::cp_poll_seqnum_` | Checks the register-call result before interpreting the sequence number. A nonzero HAL result therefore prevents successful completion even if output storage happens to contain a sufficient seqnum. |
| `Device::cp_submit_cl_`, `cp_batch_end` | Propagate doorbell and poll errors; plain launch, QMD launch and draw routes flow through these paths. |
| `Queue::worker_loop` | Records the first work error, skips later queued work, and completes the command's event with that error. Caught unexpected work exceptions become `VX_ERR_INTERNAL`. |
| `Event::complete` / `wait_value` | Retain the first error and return it on later waits. |
| `Queue::finish` | Reports then clears queue-local `async_error_`. Backend failure must therefore be device-sticky if a failed simulator context is unsafe for reuse. |

## Minimal production repair proposal

Keep all public ABI declarations, CP command encodings, RTL and modeled cycle behavior unchanged.

- Retain the asynchronous result with `std::future<int>` (or an equally small host-only completion owner). Obtain it exactly once with `get`, converting a nonzero return or thrown exception into a terminal backend failure.
- Ensure every accepted launch has an observable busy phase even when its task completes immediately. A per-launch busy-announcement flag can satisfy the existing CP handshake; it must be distinct from future validity, which changes after `get`.
- Detect failure before the launch hook permits the CP FSM to transition to completed/retired. Simply inspecting the future after an entire 256-tick burst is too late: a draw or batched command could already execute subsequent work inside that burst.
- Catch the completion failure at the CP MMIO boundary and return a nonzero callback result. Keep the error latched across every later CP read/write and reject new launches. Do not let register reset commands, a replacement future, a later success or queue `finish` clear it.
- Any DCR/DMA/drain hook that blocks on the active future should use the same completion observer before touching simulator state. A direct wait-only path must not bypass the error latch and execute effects after failure.
- Keep cleanup available: `host_mem_free` and destruction must remain usable after failure. Destruction waits for the worker without throwing across the C callback. A new device instance owns a new clean state; an existing failed context does not recover merely because its queue error was consumed.
- Catch asynchronous launch creation failure too: no C callback should leak `std::system_error` or another exception to callers.

Prefer a backend-local helper or a shared host-transport helper if both SimX and processor RTL are repaired. Do not add a new on-wire CP status, public error enum, model tick guard, or sampling protocol as part of this bounded change.

## Required regression cases

1. Delayed success, immediate success before first busy poll, and repeated serial success.
2. Positive and negative nonzero `Processor::run` results; standard and nonstandard worker exceptions.
3. Failure cannot publish the failing launch's successful completion, execute a later draw stage, or start another queued launch.
4. Both MMIO read and write return failure after the latch is set; output values are not mistaken for successful observations.
5. Plain launch, QMD launch, draw, and batched common-runtime propagation; repeated event waits retain failure.
6. Calling queue finish cannot rehabilitate the backend; independent new device creation can succeed.
7. Direct DCR/memory/drain paths cannot ignore a ready failed future; clean shutdown still frees retained host regions and joins a delayed worker.
8. A parent-revision sensitivity check should compile successfully and fail the nonzero-return/immediate-completion assertions. Host fakes exercise production adapter code but must not be described as native model execution.

## Qualification boundary

This repair is a prerequisite for enforceable future counter bounds. It establishes neither an absolute no-wrap bound nor warm performance qualification. Historical v1 blocked behavior, acceptance records, sampling thresholds, FPGA/vendor blockers and inherited DSP area failures remain unchanged.
