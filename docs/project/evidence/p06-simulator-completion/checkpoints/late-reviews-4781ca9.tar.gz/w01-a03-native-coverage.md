# Wave 1 / agent 3 — native coverage audit

Audited source: `42809ff0c1b81384d7c9b079e4ef786be8407600` in the requested checkout. Read-only source inspection plus a small JSON inventory; no download, configure, compilation or native execution occurred. This is an implementation recommendation, not qualification evidence.

## Finding

The existing eight-cell transport evidence is a good high-half regression prerequisite, but it does not cover the actual warm experiment. `ci/project/p06_mpm_execute.py` deliberately configures `--profile=` and empty `CONFIGS`; the linked harness seeds only cycles, instructions, and three CORE fields. The TCU-enabled classes array merely causes cycles/instructions to be read with class 11; it does not test class-11 user counter selectors.

The warm experiment requires RV64, timing SimX, `p02-tfr`, `PERF=1`, one cluster/core/socket, four warps of four threads and issue width one. Its contract forbids `SIMX_FUNCTIONAL` and `SIMX_MT`. Profile flags alone are insufficient: check effective macros for runtime, backend, kernel and host, using the existing separate compiler-record validation.

## Exact counter inventory

The frozen warm manifest has 45 rows. Applying its declared ISA flags (`2420223512872`) yields **33 available** and **12 unavailable** rows. Every row targets core 0.

| Class | Available rows | Required selectors |
|---|---:|---|
| BASE 0 | 2 | `0xb00`, `0xb02` |
| CORE 1 | 11 | `0xb03`, `0xb04`, `0xb05`, `0xb06`, `0xb07`, `0xb0a`, `0xb0e`, `0xb10`, `0xb17`, `0xb1c`, `0xb1e` |
| ICACHE 3 | 3 | `0xb03`, `0xb04`, `0xb05` |
| DCACHE 4 | 6 | `0xb03`, `0xb04`, `0xb05`, `0xb06`, `0xb07`, `0xb09` |
| MEM 7 | 8 | `0xb03` through `0xb0a` |
| TCU 11 | 3 | `0xb03`, `0xb04`, `0xb05` |

The 12 L2/L3 rows must remain explicitly unavailable with null status/value; zero is not an available measurement. The `p02-tfr` route disables WGMMA, so ordinary measured TCU tile-buffer rows may be zero. A zero observation does not exercise high-half transport for that row.

## Concrete native changes

1. Add a separate qualification harness/target rather than changing the previously reviewed `tests/unittest/mpm_transport/main.cpp` acceptance scope. Use the established additive Make fragment pattern: `include Makefile`, a disjoint test object and executable, and ordinary actual SimX objects. Leave `sim/simx/Makefile` byte-identical to its accepted source pin. `configure` must copy the new fragment through an existing matching rule or a reviewed additive rule.
2. Compile under the **same backend effective flags** as the warm run, including TCU and PERF. Assert the actual topology, feature macros and counter width in the harness. Retain the compiler/link command and effective preprocessed macros, rather than trusting its printed configuration banner.
3. Seed each required selector with independent frozen low/high expectations. Exercise `0`, `0xffffffff`, `0x100000000`, `0x100000001`, a nontrivial value above 44 bits, and `0xffffffffffffffff`. Alternate unequal selectors/classes, read low-first/high-first/repeated, and verify original MPM class restoration. Report per-selector coverage; a total assertion count cannot establish a complete inventory.
4. Keep the actual `Processor::dcr_read → Cluster → Socket → Core → CsrUnit` route. Public reconstruction (`sw/runtime/common/perf.cpp`) is currently qualified separately against a controlled DCR responder; do not relabel it as actual public-runtime-to-SimX end-to-end execution.
5. Add independent **lifetime** checks: seed nonzero counters, invoke the real launch-reset boundary, and verify intended persistence; construct a genuinely new Processor/device context and verify initial zero. Keep reset-preservation evidence separate from transport tests. Existing `Core::Impl::reset()` deliberately preserves `perf_stats_`, and `ProcessorImpl::reset()` deliberately preserves `perf_mem_*` counters.

### Feasible seed access and its boundary

`Core::perf_stats()` provides a mutable reference, so all 13 BASE+CORE rows can be seeded without modifying production. `TcuUnit`, `LocalMem` and `MemCoalescer` expose `const PerfStats&` backed by nonconst owned statistics. A narrowly scoped test can use a documented `const_cast` on those actual nonconst objects to seed their 7 rows without altering production behavior. This still must be reviewed and must not become a general production state access path.

**The remaining 13 cache/global-memory rows are not writable through the exposed interfaces.** `Socket::perf_stats()`, `ProcessorImpl::perf_stats()` and `Cache::perf_stats()` return aggregate values, so modifying the returned object will not seed the model. Qualifying those rows needs either reviewed test-only access to the actual owned fields, or a separately reviewed instrumented harness with an explicit narrower scope. Do not silently inject replacement values in the DCR decoder or treat the current zero-cache reads as high-half coverage. Adding test access must leave installed runtime/public ABI and production compilation unchanged; source instrumentation cannot claim byte-identical tested binary identity to an uninstrumented runtime.

## Provenance repair

`p06_mpm_execute.py::tools_snapshot` hashes PATH `python3` but not the running `sys.executable`. The parent runner reuses this inventory; the synthesis runner already adds `executing_python`. Add an `executing_python` file identity directly from `sys.executable`, retain its version independently, and include it in all before/after stability checks. Test differing PATH/interpreter binaries, disappearing executable, changed bytes and equal-path resolution. The existing hosted job checks their resolved paths are equal, but standalone absolute-interpreter invocation does not.

The new qualification path also needs the actual interpreter separately: `p06_warm_execute.py` uses `p02_matrix.py::tool_inventory`, which only inventories PATH `python3`. Avoid changing old historical contract pins merely to add this field; use a versioned new wrapper or reviewed additive inventory for the new format.

The existing warm runner already retains the actual host, kernel and runtime binaries in `artifacts()`, then binds them to each format and checks stability before/after every policy process. Reuse this machinery. The directed MPM runner identifies native binaries but does not archive them; future offline qualification must retain those binaries or explicitly remain unable to rehash them offline.

## Quiescence and no-wrap limits

`sw/runtime/simx/vortex.cpp` waits for the background `processor_.run()` future before each DCR read. `ProcessorImpl::run()` exits only when cores are done and `SimPlatform::idle()`. Serial warm ownership plus this path supports a source-derived stable-read argument, provided there is no concurrent caller or later tick-producing operation between halves. A runtime witness should bind those assumptions to the executed backend and process.

Neither native boundary vectors nor bounded process wall time establishes an absolute cumulative no-wrap bound. The qualifying path needs a proved/event-enforced bound over the whole counter lifetime. Keep `qualified=false` when that obligation is absent, even if all native transports pass.

## Test and delivery route

Local free disk was approximately 6 GiB in the parent's inventory, below the unchanged 15 GiB native reserve. Do not lower the reserve or delete unrelated data. Host Python and C++ fault tests remain feasible; native execution belongs on the existing GitHub-hosted route after source/contract review.

Use the existing pinned CPython 3.12.14, restore-only tool/dependency caches, clean source preparation, two-job/4 GiB/15 GiB/16 MiB budgets and retained `always()` artifact upload. A dedicated additive workflow can run the new p02-tfr directed harness before a complete warm matrix. Historical v1 always-blocked analysis and prior native eight-cell workflow must remain intact. Missing cache/native prerequisites must produce blocked retained receipts.

Recommended disjoint owners: native harness/Make fragment; qualification schema/analyzer/replay; interpreter/provenance runner changes; workflow plus independent tests; docs/evidence; author-disjoint enforcement and coverage review. No native pass, no-wrap proof or performance qualification was earned by this audit.
