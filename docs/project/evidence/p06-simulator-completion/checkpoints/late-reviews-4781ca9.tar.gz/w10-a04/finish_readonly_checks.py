#!/usr/bin/env python3
"""Retain the immutable-base classifier and warm-plan consistency checks."""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspace/scratch/ea983fdea786/AI-GPU')
out = Path('/workspace/scratch/ea983fdea786/w10-a04')
base = '42809ff0c1b81384d7c9b079e4ef786be8407600'
code = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
env = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0',
           PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', PYTHONPATH='')
def digest(data):
    return hashlib.sha256(data).hexdigest()
def write(name, value):
    (out / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

policy_dir = out / 'immutable-base'
policy_dir.mkdir(exist_ok=True)
copies = {}
for path in ('ci/change_impact.py', 'docs/review/change-impact.yaml'):
    result = subprocess.run(['git', '--no-replace-objects', 'show', base + ':' + path],
                            cwd=root, env=env, capture_output=True, timeout=30, check=True)
    destination = policy_dir / Path(path).name
    destination.write_bytes(result.stdout)
    copies[path] = {'retained_as': str(destination.relative_to(out)),
                    'base_sha256': digest(result.stdout),
                    'current_sha256': digest((root / path).read_bytes())}
    assert copies[path]['base_sha256'] == copies[path]['current_sha256']
argv = [sys.executable, '-I', str(policy_dir / 'change_impact.py'), '--repo', str(root),
        '--policy', str(policy_dir / 'change-impact.yaml'), 'explain',
        '--base', base, '--head', code]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
result = subprocess.run(argv, cwd=root, env=env, capture_output=True, timeout=60)
(out / 'base-classifier.stdout').write_bytes(result.stdout)
(out / 'base-classifier.stderr').write_bytes(result.stderr)
write('base-classifier-receipt.json', {'argv': argv, 'cwd': str(root), 'exit_code': result.returncode,
      'started_utc': started, 'elapsed_seconds': time.monotonic() - start,
      'copies': copies, 'stdout_sha256': digest(result.stdout), 'stderr_sha256': digest(result.stderr),
      'python_executable': sys.executable, 'python_version': sys.version,
      'python_sha256': digest(Path(sys.executable).resolve().read_bytes()),
      'manual_classification': 'R3: public completion and error behavior changes',
      'maintainer_approval_granted': False, 'waiver_granted': False})
assert result.returncode == 0, result.stderr.decode()

contract_path = root / 'ci/project/p06_warm_contract.json'
contract = json.loads(contract_path.read_text())
isa = contract['capability_values']['isa_flags']
classes = {}
rows = []
for row in contract['counters']:
    enabled = (isa & row['required_isa']) == row['required_isa']
    group = classes.setdefault(row['class_macro'], {'available': 0, 'unavailable': 0})
    group['available' if enabled else 'unavailable'] += 1
    rows.append(dict(row, available_in_frozen_capabilities=enabled))
assert sum(c['available'] for c in classes.values()) == 33
assert sum(c['unavailable'] for c in classes.values()) == 12
assert contract['complete_matrix']['processes'] == 24
assert contract['complete_matrix']['launches'] == 792
assert contract['complete_matrix']['checked_words'] == 25344
assert contract['budget']['min_free_bytes'] == 15 * 1024**3
assert contract['budget']['max_rss_bytes'] == 4 * 1024**3
assert contract['budget']['jobs_max'] == 2
assert contract['analysis']['candidate_median_percent_of_reference_max'] == 95
assert contract['analysis']['decision_is_phase_acceptance'] is False
plan = (root / 'docs/project/p06-mpm-qualification-plan.md').read_text()
assert 'are not implemented, and no absolute no-wrap bound is established by this document.' in plan
assert '**Design candidate for review, not implemented limits:**' in plan
analyzer = (root / 'ci/project/p06_warm_analyze.py').read_text()
assert '"status": "blocked", "qualified": False' in analyzer
assert '"finding_id": "P06-WARM-RV64-MPM-HIGH-HALF"' in analyzer
assert '"absolute_no_wrap_bound": "not_established"' in analyzer
paths = ['ci/project/p06_warm_contract.json', 'ci/project/p06_warm_analyze.py',
         'ci/project/p06_warm_replay.py', 'docs/designs/warm_workspace_benchmark_v1.md',
         'docs/project/p06-mpm-qualification-plan.md', 'docs/project/status.md',
         'docs/project/backlog.md', 'docs/project/p06-workspace-handoff.md',
         'docs/project/p06-simulator-completion-audit.md', 'README.md',
         '.github/workflows/p06-simulator-completion.yml']
write('warm-plan-consistency.json', {'contract_sha256': digest(contract_path.read_bytes()),
      'capability_isa_flags': isa, 'class_counts': classes, 'rows': rows,
      'complete_matrix': contract['complete_matrix'], 'budget': contract['budget'],
      'analysis': contract['analysis'], 'sampling': contract['sampling'],
      'reviewed_document_hashes': {p: digest((root / p).read_bytes()) for p in paths},
      'warm_v1_retains_unconditional_block': True, 'new_guard_implemented': False,
      'new_no_wrap_bound_established': False, 'new_qualification_established': False,
      'new_phase_acceptance': False})
print(result.stdout.decode())
print(json.dumps({'warm_counters_available': 33, 'warm_counters_unavailable': 12,
                  'frozen_budget_and_statistics_unchanged': True}))
