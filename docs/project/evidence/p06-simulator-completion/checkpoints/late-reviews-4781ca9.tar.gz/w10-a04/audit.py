#!/usr/bin/env python3
"""Read-only project-gate preservation audit, agent 58 / wave 10 assignment 4."""
import collections
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
OUT = Path('/workspace/scratch/ea983fdea786/w10-a04')
BASE = '42809ff0c1b81384d7c9b079e4ef786be8407600'
CODE = '4781ca96db15a1d130626edc7a73411a4f6c2e7c'
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0',
           PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', PYTHONPATH='')
PRODUCTION = {
    'sim/common/simobject.h', 'sim/common/simobject_functional.h',
    'sim/simx/completion.mk', 'sim/simx/processor.cpp', 'sim/simx/processor.h',
    'sw/runtime/common/async_run.h', 'sw/runtime/rtlsim/Makefile',
    'sw/runtime/rtlsim/vortex.cpp', 'sw/runtime/simx/Makefile',
    'sw/runtime/simx/vortex.cpp',
}
BASE_DOCUMENT_CHANGES = {
    'AGENTS.md', 'README.md', 'docs/project/backlog.md',
    'docs/project/p06-mpm-qualification-plan.md',
    'docs/project/p06-workspace-handoff.md', 'docs/project/status.md',
}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def git(*args):
    result = subprocess.run(['git', '--no-replace-objects', '--no-optional-locks',
                             '-c', 'core.fsmonitor=false', *args],
                            cwd=ROOT, env=ENV, capture_output=True, timeout=60)
    if result.returncode:
        raise RuntimeError(f'Git read failed: {args!r}: {result.stderr.decode()}')
    return result.stdout


def tree(revision):
    answer = {}
    for line in git('ls-tree', '-rz', revision).split(b'\0'):
        if not line:
            continue
        meta, path = line.split(b'\t', 1)
        mode, kind, oid = meta.decode().split(' ')
        answer[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return answer


def working_blob(relative, mode):
    path = ROOT / relative
    try:
        if mode == '120000':
            data = os.fsencode(os.readlink(path))
            actual_mode = '120000'
        else:
            data = path.read_bytes()
            actual_mode = '100755' if path.stat().st_mode & stat.S_IXUSR else '100644'
        identity = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        return {'oid': identity, 'mode': actual_mode, 'sha256': sha256(data), 'bytes': len(data)}
    except (OSError, ValueError) as exc:
        return {'error': type(exc).__name__}


def doc_snapshot():
    paths = [p.decode() for p in git('diff', '--name-only', '-z', CODE).split(b'\0') if p]
    paths += [p.decode() for p in git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0') if p]
    return {p: working_blob(p, '100644') for p in sorted(set(paths))}


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
head = git('rev-parse', 'HEAD').decode().strip()
assert head == CODE, (head, CODE)
before = doc_snapshot()
base = tree(BASE)
code = tree(CODE)
base_changes = sorted(p for p in base if base[p] != code.get(p))
new_paths = sorted(set(code) - set(base))
assert set(base_changes) == (BASE_DOCUMENT_CHANGES | (PRODUCTION & set(base))), base_changes
assert not (set(base) - set(code)), 'Existing source removed'
working = {p: working_blob(p, meta['mode']) for p, meta in code.items() if meta['kind'] == 'blob'}
working_changes = sorted(p for p, value in working.items()
                         if value.get('oid') != code[p]['oid'] or value.get('mode') != code[p]['mode'])
allowed_worktree = lambda p: p == 'README.md' or p.startswith('docs/')
assert all(allowed_worktree(p) for p in working_changes), working_changes
assert all(allowed_worktree(p) for p in before), sorted(before)

preserved = sorted(p for p in base if p not in base_changes and base[p]['kind'] == 'blob')
preservation_failures = []
manifest = []
for path in preserved:
    observation = working[path]
    okay = observation.get('oid') == base[path]['oid'] and observation.get('mode') == base[path]['mode']
    if not okay:
        preservation_failures.append(path)
    manifest.append(dict(path=path, base_git_blob=base[path]['oid'], code_git_blob=code[path]['oid'],
                         current=observation, preserved=okay))
assert not preservation_failures, preservation_failures
write_json('preserved-existing-files.json', manifest)

group_predicates = {
    'all_existing_hardware': lambda p: p.startswith('hw/'),
    'all_existing_ci': lambda p: p.startswith('ci/'),
    'existing_test_workloads': lambda p: p.startswith('tests/'),
    'configuration_profiles': lambda p: p.startswith('profiles/'),
    'existing_github_configuration': lambda p: p.startswith('.github/'),
    'python_binding': lambda p: p.startswith('python/'),
    'existing_evidence_json': lambda p: p.startswith('docs/project/evidence/') and p.endswith('.json'),
    'all_existing_acceptance_named_json': lambda p: p.endswith('.json') and 'acceptance' in Path(p).name,
    'phase_definitions': lambda p: p.startswith('docs/project/phases/'),
    'review_policy': lambda p: p.startswith('docs/review/'),
    'sw_kernel': lambda p: p.startswith('sw/kernel/'),
    'sw_common': lambda p: p.startswith('sw/common/'),
    'public_runtime_headers': lambda p: p.startswith('sw/runtime/include/'),
    'existing_runtime_common': lambda p: p.startswith('sw/runtime/common/'),
    'synthesis_and_performance_baselines': lambda p: p.startswith('ci/baselines/'),
}
groups = {}
for name, predicate in group_predicates.items():
    selected = sorted(p for p in base if base[p]['kind'] == 'blob' and predicate(p))
    groups[name] = {'count': len(selected), 'all_preserved': all(p in preserved for p in selected),
                    'paths': selected}
    assert groups[name]['all_preserved'], name

protected_roots = ['hw', 'hw/rtl', 'profiles', 'ci/baselines', 'ci/testcases',
                   'sw/kernel', 'sw/common', 'sw/runtime/include', 'docs/project/phases',
                   'docs/review', 'docs/project/roadmap.json', 'docs/project/acceptance.md',
                   'ROADMAP.md', 'VERSION', '.gitmodules', 'Makefile.in', 'config.mk.in',
                   'configure', 'VX_config.toml', 'VX_types.toml', 'sim/simx/Makefile',
                   'docs/assets/img/vortex_framework_stack.svg', 'ci/toolchain_rev.sh',
                   'ci/synth_gate.py', 'ci/baselines/synthesis/beacon/tensor.json',
                   'ci/project/p01_toolchain.lock.json', 'ci/project/p05_torch_requirements.lock',
                   'ci/project/p06_warm_contract.json', 'ci/project/p06_warm_contract.py',
                   'ci/project/p06_warm_analyze.py', 'ci/project/p06_warm_replay.py',
                   'ci/project/p06_benchmark_contract.json', 'ci/project/p06_contract.py',
                   'tests/regression/ai_bench_common/counters.h',
                   'tests/regression/ai_warm_workspace/observer.cpp']
objects = {}
for path in protected_roots:
    b = git('rev-parse', BASE + ':' + path).decode().strip()
    c = git('rev-parse', CODE + ':' + path).decode().strip()
    assert b == c, path
    objects[path] = {'base_oid': b, 'code_oid': c}
    if path in working:
        objects[path]['current'] = working[path]

gitlinks = {p: {'base': meta, 'code': code.get(p)} for p, meta in base.items() if meta['kind'] == 'commit'}
assert all(value['base'] == value['code'] for value in gitlinks.values())
(OUT / 'submodule-status.txt').write_bytes(git('submodule', 'status', '--recursive'))
(OUT / 'base-to-code-scope.tsv').write_bytes(git('diff', '--name-status', BASE, CODE))
(OUT / 'production.patch').write_bytes(git('diff', '--no-ext-diff', BASE, CODE, '--', *sorted(PRODUCTION)))
(OUT / 'instructions.patch').write_bytes(git('diff', '--no-ext-diff', BASE, CODE, '--', 'AGENTS.md'))
(OUT / 'worktree-status-before.txt').write_bytes(git('status', '--short'))

roadmap_path = 'docs/project/roadmap.json'
roadmap = json.loads((ROOT / roadmap_path).read_text())
gate_rows = []
phase_rows = []
for phase in roadmap['phases']:
    evidence = {entry['acceptance_id']: entry['record'] for entry in phase['evidence']}
    counts = collections.Counter()
    for criterion in phase['acceptance']:
        record_path = evidence.get(criterion['id'])
        record = json.loads((ROOT / record_path).read_text()) if record_path else None
        if record is not None:
            assert criterion['id'] in record['acceptance_ids']
        outcome = record['outcome'] if record else 'unearned'
        counts[outcome] += 1
        gate_rows.append({'id': criterion['id'], 'phase_status': phase['status'],
                          'criterion_evidence_level': criterion['evidence_level'],
                          'outcome': outcome, 'record': record_path,
                          'record_evidence_level': record.get('evidence_level') if record else None,
                          'record_sha256': sha256((ROOT / record_path).read_bytes()) if record else None})
    phase_rows.append({'id': phase['id'], 'status': phase['status'],
                       'depends_on': phase['depends_on'],
                       'entry_acceptances': phase.get('entry_acceptances', []),
                       'counts': dict(counts)})
gate_counts = dict(collections.Counter(row['outcome'] for row in gate_rows))
assert gate_counts == {'pass': 16, 'blocked': 1, 'unearned': 19}, gate_counts
assert len(gate_rows) == 36
write_json('phase-and-gate-state.json', {'phases': phase_rows, 'criteria': gate_rows,
                                       'counts': gate_counts, 'new_acceptance_claimed': False})
asset = roadmap['protected_assets'][0]
assert asset['path'] == 'docs/assets/img/vortex_framework_stack.svg'
assert working[asset['path']]['sha256'] == asset['sha256']
readme = (ROOT / 'README.md').read_text()
asset_embedded = bool(re.search(r'<img[^>]+src=[\"\']docs/assets/img/vortex_framework_stack\.svg[\"\']', readme))
assert asset_embedded, 'Protected SVG embed missing'

prior_dir = ROOT / 'docs/project/evidence/p06-mpm-transport/hosted'
dsp = {}
for key, filename in [('prior', 'broader-logic-gate-prior'), ('transport', 'broader-logic-gate')]:
    index_bytes = (prior_dir / (filename + '.json')).read_bytes()
    index = json.loads(index_bytes)
    archive = (prior_dir / index['raw_log']['path']).read_bytes()
    raw = gzip.decompress(archive)
    assert sha256(archive) == index['raw_log']['gzip_sha256']
    assert len(archive) == index['raw_log']['gzip_bytes']
    assert sha256(raw) == index['raw_log']['uncompressed_sha256']
    assert len(raw) == index['raw_log']['uncompressed_bytes']
    lines = raw.decode('utf-8').splitlines()
    stripped = [re.sub(r'^\d{4}-\d\d-\d\dT\S+Z\s+', '', line) for line in lines]
    table_rows = [line for line in stripped if re.fullmatch(r'[a-z_]+\s+[a-z_]+\s+.*\d+m\s+(?:PASS|FAIL)', line)]
    assert len(table_rows) == 14, (key, len(table_rows))
    assert table_rows == index['gate_rows']
    normalized = [re.sub(r'\s+\d+m\s+(PASS|FAIL)$', r' \1', line) for line in table_rows]
    failed = [line for line in table_rows if line.endswith('FAIL')]
    assert len(failed) == 1 and failed[0].startswith('tensor ')
    assert any('dsp: 267 -> 283 (+6.0%, tolerance 5%) -- REGRESSION' in line for line in lines)
    assert any('Process completed with exit code 1.' in line for line in lines)
    assert any(index['executed_checkout'] == line for line in stripped)
    patterns = [r'git log -1 --format=%H', index['executed_checkout'],
                r'Cache restored from key: Linux-toolchain-', r'foldsim.tar.bz2.*4804521',
                r'ci/logic_gate.py -j', r'schedule \(', r'^.*tensor\s+tensor\s+',
                r'dsp: 267 -> 283', r'Process completed with exit code 1', r'configuring build tree']
    selected = [{'line': i + 1, 'text': line} for i, line in enumerate(lines)
                if any(re.search(pattern, line) for pattern in patterns)]
    dsp[key] = {'run_id': index['run_id'], 'job_id': index['job_id'],
               'executed_checkout': index['executed_checkout'],
               'index_sha256': sha256(index_bytes), 'gzip_sha256': sha256(archive),
               'uncompressed_sha256': sha256(raw), 'uncompressed_bytes': len(raw),
               'normalized_displayed_rows': normalized, 'selected_original_lines': selected,
               'passing_builds': 13, 'failing_builds': 1, 'exit_code': 1,
               'raw_logs_retrieved_now': False, 'raw_log_index_hashes_verified': True}
assert dsp['prior']['normalized_displayed_rows'] == dsp['transport']['normalized_displayed_rows']
baseline_tensor = json.loads((ROOT / 'ci/baselines/synthesis/beacon/tensor.json').read_text())['tensor']
assert baseline_tensor['result']['dsp'] == 267
assert baseline_tensor['clock_mhz'] == 250
assert baseline_tensor['configs'] == '-DVX_CFG_NUM_THREADS=16 -DVX_CFG_NUM_WARPS=16'
synth_text = (ROOT / 'ci/synth_gate.py').read_text()
assert re.search(r'^TOLERANCE = 0\.05$', synth_text, re.M)
assert 'metric_tolerance = dict.fromkeys(area_metrics, 0.05)' in synth_text
dsp.update({'baseline': 267, 'observed': 283, 'relative_increase_percent': (283 - 267) / 267 * 100,
            'unchanged_tolerance_percent': 5, 'hardware_and_synthesis_inputs_base_to_code_identical': True,
            'tensor_clock_mhz': 250, 'tensor_configs': baseline_tensor['configs'],
            'tensor_baseline_tool_environment': baseline_tensor['result']['env'],
            'historical_rows_equal_except_elapsed_time': True, 'new_synthesis_run': False,
            'root_cause_established': False, 'tool_binaries_byte_identity_established': False,
            'gate_outcome': 'fail', 'waiver_granted': False, 'new_phase_acceptance': False})
write_json('dsp-inherited-finding.json', dsp)

commands = []
for label, arguments in [
    ('preflight', ['ci/project/preflight.py', '--tier', 'governance', '--json']),
    ('project-structure', ['ci/project/check_project.py']),
    ('baseline-packets', ['ci/project/check_baseline_packets.py']),
]:
    argv = [sys.executable, '-B', *arguments]
    start = time.monotonic()
    completed = subprocess.run(argv, cwd=ROOT, env=ENV, capture_output=True, timeout=60)
    elapsed = time.monotonic() - start
    stdout_path = OUT / (label + '.stdout')
    stderr_path = OUT / (label + '.stderr')
    stdout_path.write_bytes(completed.stdout)
    stderr_path.write_bytes(completed.stderr)
    entry = {'label': label, 'argv': argv, 'cwd': str(ROOT), 'exit_code': completed.returncode,
             'elapsed_seconds': round(elapsed, 6), 'python_version': sys.version,
             'python_executable_sha256': sha256(Path(sys.executable).resolve().read_bytes()),
             'entry_sha256': sha256((ROOT / arguments[0]).read_bytes()),
             'stdout': stdout_path.name, 'stdout_sha256': sha256(completed.stdout),
             'stderr': stderr_path.name, 'stderr_sha256': sha256(completed.stderr),
             'environment_overrides': {key: ENV[key] for key in ['GIT_NO_REPLACE_OBJECTS',
                 'GIT_OPTIONAL_LOCKS', 'PYTHONDONTWRITEBYTECODE', 'PYTHONNOUSERSITE', 'PYTHONPATH']}}
    commands.append(entry)
write_json('commands.json', commands)
assert all(command['exit_code'] == 0 for command in commands), commands
after = doc_snapshot()
assert before == after, 'Documentation/evidence changed during read-only audit; repeat against stable snapshot'
assert git('rev-parse', 'HEAD').decode().strip() == CODE
write_json('current-document-snapshot.json', after)
(OUT / 'worktree-status-after.txt').write_bytes(git('status', '--short'))

result = {'schema_version': 1, 'agent': '/root/w10_a04_gate_preservation_review',
          'assignment': 58, 'wave': 10, 'started_utc': started,
          'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'base': BASE, 'code': CODE, 'code_tree': git('rev-parse', CODE + '^{tree}').decode().strip(),
          'existing_base_entries': len(base), 'existing_base_blob_count': sum(v['kind'] == 'blob' for v in base.values()),
          'preserved_existing_blob_count': len(preserved), 'changed_existing_base_paths': base_changes,
          'added_code_paths': new_paths, 'deleted_existing_base_paths': [],
          'current_worktree_changed_tracked_paths': working_changes,
          'current_worktree_document_only': True, 'production_paths': sorted(PRODUCTION),
          'production_tracked_bytes_match_frozen_code': all(working[p]['oid'] == code[p]['oid'] for p in PRODUCTION),
          'protected_groups': groups, 'protected_objects': objects, 'gitlinks': gitlinks,
          'protected_svg': dict(asset, current_sha256=working[asset['path']]['sha256'], readme_embedded=asset_embedded),
          'simx_makefile_sha256': working['sim/simx/Makefile']['sha256'],
          'gate_counts': gate_counts, 'lightweight_checks': commands,
          'document_snapshot_unchanged_during_review': before == after,
          'new_gate_acceptance': False, 'waiver_granted': False, 'maintainer_approval': False,
          'full_tests_run': False, 'native_build_run': False, 'new_synthesis_run': False,
          'native_repaired_checkpoint_verification': 'separate obligation; pending at review snapshot',
          'preservation_outcome': 'pass',
          'limitations': ['Read-only source and retained historical-log review, not fresh native/RTL/physical execution.',
                          'Gate counts describe existing recorded outcomes; this audit does not re-accept their evidence.',
                          'Published baseline checker explicitly does not verify raw-log bytes or redaction relationship.',
                          'No causal bisect or historical synthesis executable identity was established.',
                          'All artifacts were written only outside the repository in the review directory.']}
write_json('audit-result.json', result)
print(json.dumps({k: result[k] for k in ['base', 'code', 'existing_base_blob_count',
    'preserved_existing_blob_count', 'gate_counts', 'preservation_outcome']}, indent=2))
print(json.dumps({'groups': {k: v['count'] for k,v in groups.items()},
                  'lightweight_checks': {v['label']: v['exit_code'] for v in commands},
                  'current_document_snapshot_count': len(after)}))
