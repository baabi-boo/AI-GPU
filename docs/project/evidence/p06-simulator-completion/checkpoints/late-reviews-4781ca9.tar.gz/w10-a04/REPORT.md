# Wave 10 assignment 4: preserved gates and publication scope

**Reviewer:** `/root/w10_a04_gate_preservation_review`, actual assignment 58.

**Disposition:** No new gate-preservation or publication-scope blocker found in the reviewed snapshot. Existing gates, acceptance records, baselines, workloads, ABI/ISA definitions, configuration/toolchain pins and protected assets are preserved. This is a read-only advisory review; it grants no acceptance, waiver or maintainer approval. Repaired-checkpoint native verification is a separate pending obligation at this snapshot.

## Reviewed identities and method

- Audited master: `42809ff0c1b81384d7c9b079e4ef786be8407600`.
- Repaired implementation: `4781ca96db15a1d130626edc7a73411a4f6c2e7c`.
- Implementation tree: `6dd0d759390cda78ec63ad0caacc00a08f03e2bc`.
- Repository: `/workspace/scratch/ea983fdea786/AI-GPU`.
- Primary preservation/checker snapshot: `2026-11-22T10:08:13.462593+00:00` through `2026-11-22T10:08:17.343029+00:00`.

I read the project instructions, acceptance policy, phase metadata, review policy, status/backlog, completion audit and counter-qualification plan. I compared the immutable base and repaired commit with Git replacement objects disabled, and independently hashed the actual working files using Git's blob framing and SHA-256. The snapshot separately records documentation/evidence edits after the repaired checkpoint. The primary audit confirmed that its 35 changed/new documentation/evidence files did not change during that observation.

`audit.py`, `audit-result.json`, `preserved-existing-files.json`, `current-document-snapshot.json` and `base-to-code-scope.tsv` retain the procedure, exact object identities, per-file hashes and scope. `finish_readonly_checks.py` adds the immutable-base classifier and a data-only comparison of the prospective plan to the frozen warm contract. No repository file was edited by this reviewer. No installer, native build, full test suite, synthesis run, artifact mutation, commit or push was performed.

## Preservation findings

The audited base contains **5,032 blobs plus five gitlinks**. Of those blobs, **5,018 are byte-identical** at the repaired commit and in the reviewed worktree. The other **14** are exactly eight intended existing production/build files and six instruction/documentation files. There are no removed base paths.

The eight existing production/build changes are the timing/functional framework cleanup headers, SimX processor source/header, and the two backend source/Makefile pairs. The six existing prose changes are `AGENTS.md`, `README.md`, backlog, status, workspace handoff and qualification plan. The two new production/build files are `sw/runtime/common/async_run.h` and `sim/simx/completion.mk`. Thus the frozen production/build scope is ten files, **250 insertions and 84 deletions**. `production.patch` retains that scope independently from documentation and new validation fixtures. Current post-checkpoint modifications are confined to README and documentation/evidence; all production and test bytes match the repaired code checkpoint.

The following counts are overlapping views of preserved base files, not an additive total:

| Preserved group | Existing files | Result |
|---|---:|---|
| Hardware, including RTL, test wrappers, synthesis inputs and scripts | 882 | Unchanged |
| CI scripts, contracts, fixture data and existing tests | 410 | Unchanged |
| Existing test/workload files | 1,395 | Unchanged |
| Configuration profiles | 23 | Unchanged |
| Existing GitHub configuration and workflows | 19 | Unchanged |
| Python binding files | 9 | Unchanged |
| Existing evidence JSON files | 601 | Unchanged |
| Existing JSON filenames containing `acceptance` | 17 | Unchanged |
| Phase definition documents | 12 | Unchanged |
| Review policy files | 2 | Unchanged |
| Kernel library files | 25 | Unchanged |
| Common software files | 41 | Unchanged |
| Public runtime headers | 7 | Unchanged |
| Existing runtime-common files | 23 | Unchanged |
| Synthesis/performance baselines | 25 | Unchanged |

All roadmap-referenced acceptance records are also included in the preservation inventory, including records whose filenames do not contain `acceptance`. `docs/project/roadmap.json`, `ROADMAP.md`, `docs/project/acceptance.md`, every phase definition and the original design/review files retain their bytes. No phase dependencies, criteria, evidence levels, acceptance evidence references or thresholds were changed.

`VERSION`, `.gitmodules`, root configure/build configuration, `VX_config.toml`, `VX_types.toml`, public runtime/kernel/common headers, toolchain locks and all five gitlink revisions remain unchanged. The public C ABI, installed headers, ISA/CSR definitions, error-number definitions and existing common error mapping are untouched. This does not mean externally observable completion behavior is unchanged: surfacing formerly lost processor failures is precisely the repaired behavior and requires R3 treatment.

The `AGENTS.md` delta only adds a five-line link/explanation for the new completion contract. It does not remove a rule, add a waiver or grant approval. Its exact delta is retained in `instructions.patch`.

### Protected original files

The original `sim/simx/Makefile` has SHA-256:

`c719966647f32fef5421dd798a89d3eeddccd692e7c61046e5744b7a8e722403`.

The completion test uses a separate additive `completion.mk` that includes this Makefile; the frozen Makefile itself was not rewritten.

The framework SVG retains the roadmap's required SHA-256:

`db123c71024f85f379c2504c7465c03ee9df8959a5d17fc3d3e94a94a1cd3aa4`.

README still embeds `docs/assets/img/vortex_framework_stack.svg`. Both byte identity and the actual embed were checked.

## Phase state independently derived

I read each criterion in `docs/project/roadmap.json`, followed its existing evidence reference where present, checked that the criterion ID appears in the record's `acceptance_ids`, and classified the record's `outcome`. A criterion with no evidence reference was counted as unearned. This derives **36 criteria: 16 recorded passes, one blocked, and 19 unearned**. It reports the inherited acceptance ledger; it does not independently re-accept every historical execution.

| Phase | Recorded phase status | Passed criteria | Blocked | Unearned |
|---|---|---:|---:|---:|
| P00 | complete | 3 | 0 | 0 |
| P01 | blocked | 2 | 1 | 0 |
| P02 | complete | 3 | 0 | 0 |
| P03 | complete | 3 | 0 | 0 |
| P04 | complete | 3 | 0 | 0 |
| P05 | in_progress | 1 | 0 | 2 |
| P06 | in_progress | 1 | 0 | 2 |
| P07 | not_started | 0 | 0 | 3 |
| P08 | not_started | 0 | 0 | 3 |
| P09 | not_started | 0 | 0 | 3 |
| P10 | not_started | 0 | 0 | 3 |
| P11 | not_started | 0 | 0 | 3 |
| **Total** | | **16** | **1** | **19** |

The blocked criterion remains vendor integration P01-A03. P06-A01 retains its accepted cold-baseline scope; P06-A02/A03 remain open. P05-A02/A03 still require their separate qualification/review. Physical FPGA and silicon phases have no acceptance evidence added. The existing staged-entry conditions and P07 dependence on P01/P04/P06 are preserved. See `phase-and-gate-state.json` for every criterion, record hash, evidence level and dependency.

The reviewed README, status, backlog, completion audit and plan agree with these states. They distinguish the initial `db5ebb3` evidence from repaired code `4781ca9`. They do not reuse the earlier native pass or earlier 2,988-test governance result as a repaired-checkpoint result. Claims about those prior executions were not rerun by this reviewer; exact artifact review belongs to the separate evidence/native assignments.

## Lightweight source-root checks

I executed the documented metadata/checker entry points from the source root under CPython **3.12.14**, with bytecode disabled. Every command exited zero and had empty stderr:

| Command | Result | Scope |
|---|---|---|
| `python3 -B ci/project/preflight.py --tier governance --json` | Pass | Offline governance prerequisites only |
| `python3 -B ci/project/check_project.py` | Pass | Structure, links and metadata only |
| `python3 -B ci/project/check_baseline_packets.py` | Pass | Published baseline packet consistency only |

`commands.json` records actual executable/entry hashes, argv, cwd, timestamps/durations and output hashes; each output is retained separately. Preflight correctly warns about tracked documentation edits and five uninitialized submodules. The gitlink **pins** were verified; this is not a claim that local submodule contents or target tools were initialized. The observed free disk was 2,320,916,480 bytes and available RAM 3,840,000,000 bytes. No native execution was attempted on this host or budget bypassed.

The baseline packet checker verifies both the clean-build and native packet's published integrity and retained run outcome. Its native packet reports consistent native matrix records. Its clean-build packet does not require native matrix records. The checker explicitly returns `phase_complete=false`, `raw_log_bytes_verified=false` and `redaction_relationship_verified=false`; those limits remain part of this review. This checker pass is not a fresh native result or a phase pass.

Because the change adds a workflow, I also extracted the classifier and impact policy from **immutable audited base `42809ff`**, checked their SHA-256 equality against the retained copies, and ran the base classifier using `python3 -I`. The read-only result is **R2 for 91 frozen-commit paths**, with SimX/RTL lockstep and configure-copy advisories. Receipt and full output are retained in `base-classifier-receipt.json` and `base-classifier.stdout`. I retain **manual R3** because public completion/error behavior changes; the classifier's R2 does not waive independent review or maintainer requirements. Production review owns the per-hunk implementation assessment. No CI summary was used to grant approval.

## Inherited tensor DSP failure

I independently decompressed the two original retained job logs under `docs/project/evidence/p06-mpm-transport/hosted/`, verified both gzip and decompressed byte counts/SHA-256 against their indexes, and parsed the original table rows. I did not execute retained audit helper code, fetch a new measurement or run synthesis.

| Retained run/job | Actual checkout in original log | Decompressed log SHA-256 |
|---|---|---|
| 44705486919 / 136199969543 | `10ace66193686e3862c3c218760b66c044f1d4ae` | `94a77aaf385709cc0d0b442da0e02eba4498ed1a849b7a8759b72d79ccbd1573` |
| 44983573278 / 137094134318 | `6e6426a0bf761baab11e932a4c86b49a5de81217` | `b26ba3a4e0846202863b42bae26f925a8cb78a63eab2cfd8192c44511218be6e` |

Both logs show `ci/logic_gate.py -j 2`, XLEN32, 14 builds, **13 pass / one tensor failure**, and exit 1. All 14 displayed metric/verdict rows match after removing only timestamps and the final elapsed-minute column. Both show **DSP 267 → 283**, an increase of 16 or **5.9925093633%**, reported as 6.0%, against the same **5%** limit. The tensor row also retains LUT 259,593, FF 161,523, BRAM 114.5, depth 25 and predicted Fmax 253.4 MHz. `dsp-inherited-finding.json` retains selected original lines, normalized tables and all verified hashes.

The frozen tensor baseline still contains 267 DSPs; `ci/synth_gate.py` still defines `TOLERANCE = 0.05` and the Beacon area metric tolerance at 0.05. The existing tensor configuration remains 16 threads, 16 warps, 250 MHz, targeting `VX_tensor_top` and `xcu55c-fsvh2892-2L-e`. This is a Beacon estimate using the Xilinx DUT route. It is not generic Yosys, placed/routed sign-off, a physical FPGA measurement or whole-GPU fit.

For this completion repair, the **entire hardware tree**, RTL tree, synthesis/performance baselines, test catalog, profiles, root configuration, toolchain pins and existing CI scripts are unchanged from audited master. Representative equal Git objects are:

| Input | Same base and repaired object |
|---|---|
| `hw` | `6c3ce08581ee8528278de2173b52a005d449a524` |
| `hw/rtl` | `97dcaa93fefae711ec60621f3f91f7ee154adb2e` |
| `profiles` | `423aa86f244918888341f759dd5bc88b74fa2737` |
| `ci/baselines` | `5654a345f7eba410f0e9ea968041eef72fd2d46e` |
| `ci/testcases` | `683f41f8ac73dea493f438a6a5bf9e97a3001174` |
| `ci/synth_gate.py` | `b986ac225e604552555bc3273d592cb5d7080179` |
| Beacon tensor baseline | `36d6b1775224175a70a66068d0ae7dd351cdb134` |

This establishes preservation and that the documented failure predates the completion change. It does **not** establish the introducing cause. The old logs agree on toolchain tag `v3.0.2` resolving to `6cff3efdc1b721e4fec9165801ecd405be34dd11` and the FoldSim download byte count; their cache profiles differ (`full` and `lite`), and historical synthesis executable hashes are not available. I make no claim of byte-identical installed tools or a causal bisect. The retained failure stays open with its threshold intact. It is neither fixed nor waived by unchanged inputs.

## Counter/no-wrap boundary and next work

The implemented code does not add a lifetime ledger, tick/request ceiling, counter-growth proof, versioned qualification reader or warm qualification. The two new full-teardown assignments reset abandoned **channel packet accounting** after disposal; they are not MPM cumulative-counter guards. The ordinary run loop, counter updater/decoder source and existing warm readers remain unchanged.

I independently derived **33 available and 12 unavailable** counter rows from the frozen warm contract's actual `isa_flags` and each row's `required_isa`. The classes yield BASE 2, CORE 11, ICACHE 3, DCACHE 6, MEM 8 and TCU 3 available; the six L2 and six L3 rows are unavailable. `warm-plan-consistency.json` retains every row, the source digest, budgets, sampling and rejection predicates.

The plan explicitly calls its `T = E = 2^32 - 1` limits a **design candidate, not implemented limits**. The product bound for memory latency is conditional on proving all accumulation sites and checked pending-request accounting. The document also requires full updater/aggregation proofs and rejects launch-only reset clocks as a lifetime proof. These are future obligations; they do not create acceptance evidence.

The unchanged analyzer still emits the unconditional `P06-WARM-RV64-MPM-HIGH-HALF` block, `qualified=false`, and `absolute_no_wrap_bound="not_established"`. The original contract/analyzer/replay bytes are preserved. The plan retains the frozen 24-process / 792-launch / 25,344-word complete matrix, five measured batch means per format/policy, 95% median predicate, no slower measured host pair, no increased paired active-cycle delta, and all original sample rejection rules. It also retains the two-job, 4 GiB RSS, 15 GiB free-disk, 16 MiB log, 1,800-second build, 180-second invocation and 90-minute hosted-job budgets.

At this review snapshot, the concrete next development sequence remains: complete source-bound native verification and independent evidence review for repaired `4781ca9`; then freeze and review the exact selector/coherence/context-lifetime contract before implementing its narrow enforcement and collecting a fresh matched warm attempt. P01-A03, P05-A02/A03, P06-A02/A03, the inherited DSP failure and physical hardware obligations retain their own evidence requirements.

## Handoff and limits

This assignment is complete and can release its slot. The separate native reviewer must decide the final repaired-run artifact, and later evidence/ledger edits must be reconciled against their own exact final tree. Any later native completion changes its own verification status, not the preserved phase ledger. This report is scoped to the recorded read-only snapshot and does not pre-approve an unseen final publication commit.

The retained review files are data/provenance. Their presence is not authority to execute archived helper code. `artifact-manifest.json` binds this report, the independent procedures, command receipts, exact outputs and preservation inventories; it excludes itself to avoid a circular digest.
