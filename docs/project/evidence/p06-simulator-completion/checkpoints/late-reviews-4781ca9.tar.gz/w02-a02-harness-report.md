# Simulator completion host harness

Owned files added:

- `ci/project/test_p06_simulator_completion.py`
- `ci/project/fixtures/simulator_completion/control.h`
- `ci/project/fixtures/simulator_completion/mem.h`
- `ci/project/fixtures/simulator_completion/processor.h`
- `ci/project/fixtures/simulator_completion/main.cpp`

The test compiles both complete production runtime backends, actual callback
installation and actual CommandProcessor with generated RV64 p02-tfr headers.
Only the processor and device RAM are controlled substitutes. The explicit
`ubuntu/focal` configure target generates headers on this Debian host; no
prebuilt toolchain installation or OS support qualification is implied.

Six unittest groups execute 24 cells: both backends and RAM/LLC routes for
serial pending/success, standard exceptions, unknown exceptions, transfer/drain,
pending-success destruction and pending-exception destruction. The SimX double
preserves the legacy gp-return convention and has the new checked void entry;
the success case sets legacy gp to seven. Failed callbacks are checked before
retirement, preserve output sentinels, prevent queued DCR commands and reject
subsequent reset/submission attempts. Link wrapping observes premature frees of
registered host memory. Condition variables control workers; there are no sleeps.

Final command:

```sh
python3 -m unittest discover -s ci/project -p test_p06_simulator_completion.py -v
```

Result: all 6 tests passed in 9.180 seconds. Raw log is
`/workspace/scratch/ea983fdea786/simulator-completion-host.log`.

Parent sensitivity compiled both historical backend bodies from
`42809ff0c1b81384d7c9b079e4ef786be8407600` against the identical fixture and
verified unchanged parent/current CP and callbacks bodies. All eight historical
exception cells exited 1 with `failed launch was accepted as successful` after
successful compilation. They were not build failures or timeouts. The original
raw logs and source/binary hash records are in
`/workspace/scratch/ea983fdea786/simulator-parent-sensitivity/`.

Limitations: these are host fault-injection tests, not native arithmetic or RTL
datapath execution. The real-CP scheduling guarantees a held pending phase;
deterministic already-ready-before-first-busy coverage needs a separate reviewed
scheduling seam or helper-state test. Destruction tests observe joined state and
no early frees in the exercised schedule, not arbitrary concurrent API safety.

No production changes, commits or pushes were made by this agent.
