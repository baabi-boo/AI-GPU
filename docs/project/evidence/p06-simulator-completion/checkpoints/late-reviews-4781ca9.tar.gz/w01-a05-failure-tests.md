# Wave 1 / agent 5: SimX async-failure regression design

## Scope and inspected revision

Read-only audit of `/workspace/scratch/ea983fdea786/AI-GPU` at inherited master `42809ff0c1b81384d7c9b079e4ef786be8407600`. No production edits, builds, commits or publication. This report proposes host fault tests; none would constitute real SimX arithmetic, RTL, counter qualification or phase acceptance.

## Concrete defect and observable assertions

`sw/runtime/simx/vortex.cpp` constructs `std::future<void>` from a lambda that drops the integer returned by `Processor::run()`. The `vortex_busy` callback observes readiness only. DCR and memory hooks call `wait()` rather than obtaining the asynchronous result. `sim/simx/processor.cpp::Processor::run()` returns `-1` after caught exceptions. Consequently a returned failure and an exception stored in the future can be treated as successful completion.

There is a second edge that a regression must cover: `sim/common/cmd_processor.cpp::tick_launch()` requires the busy indication to rise in `WaitBusy` and later fall in `WaitDrain`. A future already ready at its first poll produces no rising edge under the current backend callback, so the launch can remain in `WaitBusy`. This is a source-proven reachable scheduling case, not an observed execution in this audit.

Tests should assert public/transport behavior: a successful launch retires once; a pending launch does not retire; a failed launch never yields a successful completion, never allows later work to overwrite its failure, and still allows safe destruction/host-buffer release. Tests should not inspect the implementation's future type or newly introduced private flags.

## Recommended primary harness

Compile **the entire unmodified production backend source** `sw/runtime/simx/vortex.cpp`, its real `callbacks.inc`, and the real `sim/common/cmd_processor.cpp`. Supply only small include-path test doubles for `processor.h` and `mem.h`. Keep real `common.h`, `constants.h`, `callbacks.h`, `vm_types.h`, `util.h` and generated `VX_config.h`/`VX_types.h`. The backend uses angle-bracket includes, so this requires no source extraction, private-access macro, production test hook or changed public ABI.

Generate headers through the normal out-of-tree `configure` route, using the same harmless host-test pattern as `ci/project/test_p06_warm_caller.py`. No RISC-V compiler, model libraries or initialized submodules are needed to compile the host-only backend/CP harness. The real `constants.h` depends on generated configuration and `bitmanip.h`; use the existing `sw/common`, `sim/common`, `sim/simx`, `sw/runtime/common`, and `sw/runtime/include` include directories after the stub directory.

Suggested files (subject to integration owner's ownership allocation):

- `ci/project/fixtures/p06_simx_failure/processor.h`: declared Processor test double and externally controlled outcome/state.
- `ci/project/fixtures/p06_simx_failure/mem.h`: bounded RAM storage sufficient for the declared test address ranges.
- `ci/project/fixtures/p06_simx_failure/main.cpp`: call real `vx_dev_init`, then the returned `callbacks_t`; build ring commands in allocated host memory and drive MMIO.
- `ci/project/test_p06_simx_failure.py`: bounded compile/run orchestration, source stability and parent sensitivity.

The Processor double needs only the methods consumed by the backend: constructor/destructor, `attach_ram`, `run`, `cp_llc_client`, `cp_llc_size`, `cp_mem_read`, `cp_mem_write`, `dcr_read`, and `dcr_write`. Give each fresh process an explicit mode; keep Processor outcomes independent of expected callback results.

Use a mutex/condition variable or promise gate in the fake `run()` to hold execution pending. The harness submits a launch while the worker is held, observes that no completion was published, releases it with a chosen result, and polls for the terminal outcome. Avoid arbitrary sleeps as synchronization.

The real CP can be driven entirely through the production callbacks:

1. `vx_dev_init(&callbacks)` and `dev_open`.
2. Allocate a 64-byte-aligned ring, head slot and completion slot through `host_mem_alloc`.
3. Write queue ring/head/completion addresses through offsets `0x100..0x114`, ring log2 at `0x118`, queue enable at `0x11c`, and global enable at `0x000`.
4. Put an `OP_LAUNCH` command (`0x06`, 12-byte record) at the start of a 64-byte line; commit a 64-byte tail via `0x120/0x124`.
5. Read `Q_SEQNUM` at `0x128` and completion memory. Failed callbacks must leave caller output sentinels unchanged if that becomes the frozen contract.
6. Attempt DCR/read/write and another launch after failure. The error should be sticky and no new processor execution should occur.
7. Free registered host regions and close. Repeat with a fresh device/process to distinguish per-device failure from unintended global poisoning.

Exercise both unified-RAM and `cp_llc_client` branches, because existing memory hooks synchronize with the same future and can otherwise bypass error observation.

## Required behavioral groups

| Group | Controlled event | Required external result |
|---|---|---|
| Success | `run()` returns 0 after held pending phase | one retirement; later launches/DCR/DMA remain usable |
| Returned negative error | `run()` returns -1 | callback/public completion reports failure; no success retirement |
| Returned positive error | `run()` returns 7 | nonzero exit is treated as failure, not only negative values |
| Standard exception | `run()` throws `std::runtime_error` | exception does not escape C callback; failure is retained |
| Unknown exception | `run()` throws non-standard object | same terminal failure behavior |
| Pending | worker gate remains closed | no premature completion; no blocking poll beyond declared budget |
| Failed retry | first launch fails, later submission attempted | failure cannot be overwritten by another future |
| Successful serial reuse | several zero-return launches | no stale failure and no invalid-future errors |
| Error at DCR/memory synchronization | failure becomes ready immediately before relevant operation | no successful DCR value or transfer after known failure |
| Destructor with pending work | destroy while controlled worker is outstanding | waits safely; no use after free; exception cannot terminate process |
| Fresh recovery | close failed context, start fresh context | independent success works, if recovery is scoped to device lifetime |

## Deterministic ready-before-first-poll test

A genuinely asynchronous worker cannot be guaranteed to finish before the first real CP busy poll using a sleep alone. For this one scheduling boundary, compile a second tiny harness with a **scripted CommandProcessor test double** that invokes the actual backend hooks, waits for the controlled worker to finish, then invokes `vortex_busy`. This still compiles the whole production backend and real callback adapter; it does not test the real CP implementation. Keep its narrower scope explicit. Alternatively, a carefully reviewed host scheduling seam can be introduced solely in a test translation unit; do not add a production bypass switch or alter `std::async` through undefined additions to namespace `std`.

Pair that deterministic hook test with real-CP pending-to-ready runs. Include both immediately ready success and failure, because a fix that reports errors but strands immediately completed success is incomplete.

## Public-runtime layer

For a stronger second-stage integration, compile the real common runtime/stub source list from `sw/runtime/stub/Makefile` and dynamically load the above backend test library. The existing `CallbacksAdapter::r` in `sw/runtime/common/vortex2_internal.h` maps any nonzero backend return to `VX_ERR_INVALID_VALUE`; `Device::cp_poll_seqnum_` in `device.cpp` immediately returns that error before accepting a sequence number. Preserve and test that existing mapping rather than inventing an ABI error code.

Exercise queue/event wait and legacy ready-wait using the fake processor backend, with no CPU matmul reference pretending to be device execution. This is more build work than the minimal callback harness; it should remain separately scoped and bounded.

## Orchestration and parent sensitivity

Reuse `tensor_host_tools.run_host_command`, which already imposes a 1 GiB process-group RSS budget, 1 GiB free-storage reserve, bounded logs and process-tree cleanup. Follow `test_p06_workspace_runtime.py` for `-std=c++17 -O1 -g0 -Wall -Wextra -Werror -fsanitize=undefined -fno-sanitize-recover=undefined -pthread`, isolated temporary directories under the source parent, and input SHA-256 checks before and after each scenario. Compile once per actual configuration; run each sticky-failure scenario in its own process under a short timeout.

The parent regression should copy the exact historical backend bytes from pinned `42809ff0c1b81384d7c9b079e4ef786be8407600` into a temporary source location and compile them against the **same** harness, generated configuration and real CP bytes. The parent must compile successfully and fail numeric/behavior assertions on the injected error scenario. A compilation failure, timeout or missing dependency does not demonstrate parent sensitivity. Preserve candidate and parent command/log/binary hashes separately.

No full toolchain download is justified for this host regression. The parent/candidate harness can establish reliable host error transport while the actual native SimX workload, warm no-wrap proof, original v1 block, inherited DSP gate and physical hardware obligations remain separate.
