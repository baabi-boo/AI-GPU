# Wave 1 agent 2 — qualification architecture audit

Audited source: `42809ff0c1b81384d7c9b079e4ef786be8407600` in `/workspace/scratch/ea983fdea786/AI-GPU`. Read AGENTS and the prospective qualification plan; no production edits or native execution.

## Recommendation

Implement an additive `p06_counter_qualification_v1` envelope and explicit qualification CLI around the existing complete warm replay. Keep `p06_warm_analyze.py`, `p06_warm_replay.py`, and the frozen warm manifest's unconditional historical block behavior intact. Do not duplicate the 550-line replay or turn its return code into performance acceptance. The new route may report qualification only after independently validated transport/route/lifetime evidence matches the fresh warm packet.

The warm v1 workload, raw record schema, sample order, and arithmetic can remain unchanged. A second archive/envelope binds the warm archive's externally checked SHA-256, source revision/tree, source-snapshot digest and both reconstructed build IDs. Separate archives avoid changing the existing replay's exact member inventory and hosted outer inventory. A sidecar wrapper should invoke the v1 executor as a separate subprocess rather than importing it and incidentally changing its dynamically collected `LOADED_HELPERS` inventory.

## Existing functionality to reuse

* `p06_warm_replay._Replay.run` verifies the exact 24-process/792-launch/25,344-word matrix, all 53 command records and their order, complete archive membership, original raw-log reconciliation and supervised resources. It rebuilds every binding from independently parsed retained data.
* `provenance` checks clean revision/tree, submodules, source/helper/body identities, source-before/after equality, frozen corpus bytes and contract hashes. `generated` checks all four retained build stages, generated and copied input identities, `.config.stamp`, configured RV64/profile/tool/source paths and stable binaries.
* `compiler_commands` revalidates separate runtime/backend/kernel/host compiler records and effective headers, `PERF=1`, profile and disabled banks. `build_binding` reconstructs two common format builds; `processes` binds both allocation policies to those same artifacts.
* `stability` requires 52 ordered source/tool/dependency observations. `hosted_identity` checks workflow/job identity, CPython provision and PATH/executable equality, preparation cache/dependency identities and resource observations. Standalone replay lacks that last executing-interpreter guarantee.
* `p06_warm_analyze.analyze_processes` already performs fixed exact integer arithmetic. Its conditional criteria can be copied into an outer *qualified* decision only after every new prerequisite passes; the inner result must remain historically blocked.
* The bounded `ArchiveReader` from `p06_workspace_replay`/`p06_replay` supplies archive traversal/size/duplicate/strict-JSON protections; use it for the envelope. Retained commands and source bodies remain data and are never imported or executed on replay.

## Gaps the envelope must close

1. **Transport scope:** current `p06_mpm_execute.py` has `PROFILE=""`, TCU disabled, seeded stable counters, and no complete warm-selector mapping. Its passing matrix cannot alone certify RV64 p02-tfr PERF/tensor-enabled warm binaries. Require matched new evidence or deliberately stay blocked.
2. **Producer trust:** SHA-256 and `qualification_id(binding)` only demonstrate internal consistency. `qualified:true`, a review ID, arbitrary source revision, or a caller-supplied proof record must not establish scientific qualification. Trusted, reviewed contract/proof bytes must be pinned independently in the verifier; all source premises must match original retained bodies and the fresh build.
3. **Counter lifetime/coherence:** monotonic low or full values, process timeout and small observed counts cannot prove no wrap. Qualifying evidence must enforce a reviewed absolute bound for every available selector across initialization, prime, measured operations and final reads. It must establish quiescence throughout both halves of each snapshot. Missing/unsupported proof stays blocked even if timing improves.
4. **Interpreter provenance:** `p06_mpm_execute.tools_snapshot` currently records PATH `python3`, not `sys.executable`; capture separate resolved executable/path/hash/size identities before and after execution, record the Python implementation/version, and bind to packet execution. A read of `sys.executable` is actual identity; a recorded PATH command is not.
5. **Binary correspondence:** retain original host/runtime/backend/kernel artifact identities, original compiler/linker records and generated config; check before/after every process and cross-policy reuse. Qualification sidecars must match these exact identities, not only a new revision/tree.

## Proposed interface and states

Suggested CLI: `p06_counter_qualify.py --warm-archive ... --warm-sha256 ... --source-revision ... --qualification-archive ... --qualification-sha256 ... --output ...`.

The qualification archive contains a strict versioned `qualification.json`, retained reviewed proof/route-test evidence and actual interpreter receipts, all hashed and referenced without extras. Expected minimum binding categories: warm archive/report identity; source revision/tree/source snapshot; both format build IDs; critical source bodies; exact route/config selectors; original proof premises; matched native route evidence; actual interpreter before/after; independently reviewed enforcement identity. Proof acceptance must be verified by code against a reviewed/pinned contract, not a free-form `reviewed` field.

Return three distinguishable states: invalid evidence (error/nonzero); internally valid evidence with missing prerequisites (blocked, `qualified:false`); complete verified qualification (qualified) followed by positive or negative unchanged statistical predicates. A negative performance result is valid evidence and must not induce resampling. No state grants P06-A02/A03 automatically.

If the no-wrap proof needs production instrumentation or a new environment setting, do not shoehorn it through v1's exact command schema. Add an explicitly versioned execution/replay path with shared low-level validators and independently reviewed changes, or deliver the prerequisite implementation as blocked pending that proof. Copying a large frozen runner and verifier wholesale will increase the review surface unnecessarily.

## Required adversarial tests

* V1 stays blocked for favorable and unfavorable records, including patched revision labels.
* Missing, old-version, unknown-route, partial-selector, unreviewed or self-asserted certificates never qualify.
* Every source/config/tool/interpreter/binary mismatch rejects, including one-policy binary mutation and different format bindings.
* Proof boundaries reject zero/negative/bool/float/wrapped/over-limit values and unsupported assumptions; favorable statistics never bypass prerequisites.
* Stable low/high values are distinguished from coherent read evidence; stale snapshots, resets, ongoing writes and absent final lifetime coverage reject.
* Rehashed tampering is tested, not only stale digests: recompute internally consistent bindings while changing a trusted premise and ensure rejection.
* Relocated offline replay succeeds without recorded build/source paths existing; malicious retained Python is never executed. Existing archive limits and complete-member accounting remain enforced.

## Practical scope

The codebase already supplies robust numeric and provenance replay. This milestone should spend its effort on route coverage, mathematical lifetime/coherence enforcement and the separately versioned trust boundary. A large rewrite of the existing measurement harness would not itself solve the qualification problem.
