# Wave 1 agent 6 — simulation-backend completion scope

Audit source: `/workspace/scratch/ea983fdea786/AI-GPU`, inherited master `42809ff0c1b81384d7c9b079e4ef786be8407600`. Read-only source audit; no production edits, builds, native executions, commits or pushes.

## Decision

Cover both simulation transport backends with the same small host-only asynchronous completion helper. Preserve the different processor contracts: SimX returns an integer execution result, while processor RTL simulation returns `void`. The shared guarantee is reliable asynchronous completion/exception handling and an observable launch handshake. It must not claim newly implemented RTL kernel exit-code reporting.

## Source findings

- `sim/simx/processor.cpp::Processor::run()` returns the model exit code, or `-1` after catching an exception. The SimX runtime currently discards that result in a `std::future<void>` lambda.
- `sim/rtlsim/processor.h::Processor::run(HostMonitor*, CoutDrainer*)` returns `void`; `sim/rtlsim/processor.cpp` forwards directly to its implementation. There is no integer result to preserve on this path.
- `sw/runtime/rtlsim/vortex.cpp::make_cp_hooks()` starts `processor_.run()` asynchronously, stores `future<void>`, tests only readiness in `vortex_busy`, and uses `wait()` for DCR, last-level-cache memory access, drain and destruction. No `get()` observes an exceptional future.
- `sim/common/cmd_processor.cpp::tick_launch()` requires a busy rise in `WaitBusy` before observing its fall in `WaitDrain`. A task already ready on its first busy poll leaves the existing hook returning false forever. This affects a successful immediate completion as well as an exceptional one.
- RTLSim's own `Impl::run()` has a separate bounded 100,000-cycle no-work wait before waiting for device busy to fall. That behavior is unrelated to the host CP missed-rise bug and should remain unchanged.
- `sim/rtlsim/main.cpp` handles standalone program exit status separately, using an optional HTIF monitor or the RAM exit-code word. The runtime's `run()` call supplies neither monitor nor an integer result.

## Exact helper placement and semantics

Recommended location: `sw/runtime/common/async_run.h`, used only by `sw/runtime/simx/vortex.cpp` and `sw/runtime/rtlsim/vortex.cpp`. This is runtime-internal host code, not an installed API. Neither simulator implementation nor RTL should include it. If it is later shared directly with simulator code, move it to `sw/common/` under the repository isolation rule rather than introducing a cross-layer include.

Normalize tasks to an internal integer result: SimX's task returns `processor_.run()`; RTLSim's task calls `processor_.run()` and returns zero only after normal completion. `std::future<int>::get()` then observes both a nonzero SimX status and an exceptional future. Any such failure becomes sticky for the backend device lifetime.

Keep launch handshake state independent of `future.valid()`. A successful task completed before the first poll must still produce one busy observation, then idle. A completed failed task must stop the CP through a backend error before retirement. Consuming a successful future must not erase an unobserved launch handshake.

All CP MMIO entry/exit paths must check the sticky failure state and catch asynchronous/launch exceptions. Subsequent register reads/writes and starts cannot erase the error. Under the existing `CallbacksAdapter::r` contract, a backend nonzero result becomes `VX_ERR_INVALID_VALUE`; do not describe it as `VX_ERR_DEVICE_LOST` without an explicit separate mapping change.

Blocking hooks must join and check the result before touching processor state: DCR reads/writes, LLC memory transfers, and the RTLSim drain hook. The destructor must join outstanding execution before freeing host-visible memory, RAM or processor state, and must not throw. Memory-release cleanup should remain callable after a terminal execution failure. A hung worker remains a separate timeout/cancellation obligation; this helper cannot safely detach it or reclaim memory it might still access.

`std::async` creation can itself throw. Treat that as a failed launch at the CP callback boundary. Protect against overwriting an unfinished task or an unobserved failure with another launch. Existing common-runtime serialization of CP callbacks is the relevant host ownership model; a new unrestricted concurrent-caller guarantee is out of scope.

## Scope and validation

This is a host completion-protocol repair. It does not require an RTL datapath, simulator pipeline, ISA, on-wire DCR, public callback ABI, memory map, counter width or installed-header change. Native XRT/OPAE hardware paths can remain byte-identical. Normal processor model work and cycle counting can remain unchanged; the successful host handshake becomes reliable for tasks that completed before their first poll.

Meaningful host regression coverage can compile each actual backend and the actual functional CommandProcessor against a controlled processor substitute. Test immediate success, controlled pending-to-ready success, SimX positive and negative results, standard and nonstandard exceptions, sticky post-failure register/start behavior, DCR/LLC/drain propagation, and destructor join before memory release. Run the identical harness against the parent backend to establish sensitivity. A helper-only test is useful for boundary state transitions but cannot replace actual backend/CP tests.

Native smoke runs remain separately required to verify the real simulator linkage and ordinary successful workloads. Host failure injection proves the transport response to controlled failures, not native processor arithmetic or an RTL fault mechanism. Verilator fatal assertions and process aborts cannot in general be converted by a C++ future exception handler and must remain outside the caught-exception claim.

The counter lifetime/no-wrap and actual warm-selector qualification obligations remain blocked and unchanged. Reliable execution failure propagation is a necessary prerequisite, not their acceptance.
