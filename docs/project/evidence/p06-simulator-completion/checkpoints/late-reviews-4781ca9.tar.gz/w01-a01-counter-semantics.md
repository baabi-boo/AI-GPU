# Wave 1 / Agent 1 — warm counter semantics audit

Source audited: `42809ff0c1b81384d7c9b079e4ef786be8407600` in
`/workspace/scratch/ea983fdea786/AI-GPU`. Read-only inspection; no builds,
production edits, commits, pushes, or acceptance decisions.

## Decision

The repaired transport is a necessary prerequisite, but the current source
does not establish an absolute no-wrap bound for warm-workspace measurements.
A new qualification path must reject packets without independently reviewed
counter-lifetime evidence. Current wall-clock limits and observed monotonicity
cannot supply that evidence.

The fixed serial SimX path has a credible source proof of stable low/high reads.
That proof is limited to the single-owner warm harness, its exact compiled
configuration, and no concurrent raw-runtime caller. The public query API is
not itself an atomic snapshot interface.

## Exact supported route

`profiles/p02-tfr.json` and `ci/project/p06_warm_contract.json` specify RV64 timing
SimX, `PERF_ENABLE`, one cluster/core, four warps of four threads, issue width one,
TFR dense ordinary FP16/BF16 WMMA, STD scalar arithmetic, and local memory.
WGMMA, DSM, sparse tensor paths, other tensor-format banks, matrix loads/stores,
`SIMX_FUNCTIONAL`, and `SIMX_MT` are excluded. L1 instruction/data and local
memory are 16 KiB each; L2/L3 are disabled. The two allocation policies use the
same executable for each format.

The table contains 45 selectors: 33 available and 12 unavailable L2/L3 rows.
Every selector requests representative core 0, so no multi-core summation is
required. Available groups are:

| Group | Available observations | Meaning/source |
|---|---|---|
| Base | cycles, instructions | Active core cycles and retired macroinstructions; `Core::Impl::tick/commit` |
| Core | sched_idle, active_warps, stalled_warps, issued_warps, issued_threads, stall_scrb, stall_lsu, stall_tcu, instr_tcu, loads, stores | Scheduler/dispatch/retire counters; loads/stores count issued lane requests, not bytes |
| I-cache | reads, miss_r, mshr_st | Socket cache request/miss/stall aggregate |
| D-cache | reads, writes, miss_r, miss_w, evicts, mshr_st | Socket cache request/miss/eviction/stall aggregate |
| Local/memory | lmem_reads, lmem_writes, lmem_bank_st, coalescer_miss, memory_reads, memory_writes, memory_lt, memory_bank_st | Local banks, coalescing rounds, memory request arrivals and pending-request cycle accumulation |
| TCU | tbuf_stalls, tbuf_cache_hits, lmem_reads | TCU buffer statistics; availability follows TCU ISA capability even where ordinary WMMA leaves a buffer path unused |

Definitions and mappings live in `tests/regression/ai_bench_common/counters.h`,
`sim/simx/csr_unit.cpp::CsrUnit::get_csr`, `sim/simx/core.h::PerfStats`,
`sim/simx/mem/{cache,local_mem,memory,mem_coalescer}.h`,
`sim/simx/tcu/tcu_unit.h::PerfStats`, and `sim/simx/processor_impl.h`.
The backing fields and aggregates are `uint64_t`.

## Reset, lifetime, and read coherence

- `sw/runtime/common/perf.cpp::vx_device_mpm_query` issues a low DCR read, then a
  high DCR read, and combines `(uint64_t(hi) << 32) | lo`. There is no retry,
  high/low/high protocol, or pair-wide snapshot primitive.
- `sim/simx/core.cpp::Impl::dcr_read` temporarily selects the requested MPM
  class, reads the RV64 low-address full-width CSR, selects the requested half,
  and restores the old class. Architectural RV64 high aliases are unchanged.
- `sw/runtime/simx/vortex.cpp::make_cp_hooks` waits for `future_` before each
  DCR read. The async future owns `processor_.run()`. The MPM read then traverses
  processor/cluster/socket/core without ticking the model.
- `sim/simx/processor.cpp::ProcessorImpl::run` stops only when cores are done
  and `SimPlatform::idle()` reports no undelivered work (with additional VM
  walker checks where compiled). DCR MPM reads do not flush caches.
- `tests/regression/ai_warm_workspace/main.cpp` waits and explicitly closes
  every operation before the prime/batch snapshots. It destroys the completed
  operation and sets the observer phase to idle before the reads. The
  before-release snapshot is collected on the managed owner's release path.
- `tests/regression/ai_warm_workspace/observer.cpp::snapshot` serially queries
  capabilities and enabled counters on the sole observed device. Combined with
  the future wait and absence of another caller, this supports stable half
  reads and stable values across the snapshot.
- Core, processor memory, local memory, coalescer, cache and TCU counters retain
  their values across ordinary launch resets. Sources explicitly preserve
  these counters. New model objects initialize them to zero. CSR writes do not
  provide a supported counter-reset path (`CsrUnit::set_csr`).
- `SimPlatform::reset` resets `cycles_` to zero, while the MPM values remain
  cumulative. With L2/L3 disabled, `ProcessorImpl::launch_reset` takes the full
  reset path. Therefore `SimPlatform::cycles()` is not a process-lifetime bound
  for this warm experiment. `reset_launch` has different kept-memory semantics
  and must not be silently substituted.

The counter meanings should remain narrow: active core cycles omit idle host
work. Memory latency is accumulated from pending reads in `ProcessorImpl::run`
and `cycle`; a generic "all elapsed memory time" interpretation is unjustified.

## Missing absolute bound

The inspected counters use unchecked unsigned `++` and `+=`; no lifetime tick
limit or sticky overflow flag is present. Several grow by more than one per
tick (active warps, issued threads, local banks, aggregated caches, pending-read
latency), so even a bound on active cycles would not automatically bound every
selector. Fresh values below `2^64`, nondecreasing snapshots, 33 finite launches,
and a 180-second timeout do not prove that an unseen wrap never happened.

Two technically sound approaches are possible, each needing separate source
review and native tests:

1. Add a monotonic lifetime tick ledger that survives all launch resets, with a
   fail-closed explicit ceiling. Prove maximum per-tick contributions and
   initial values for each supported selector, including aggregate banks and
   pending memory reads. The packet must bind the compiled limits and expose
   the ledger at every relevant snapshot. Reject any bound violation or
   unsupported configuration. Counting just kernel `run` ticks is insufficient:
   cache flushing/initialization and any CP-memory paths must be included.
2. Add checked accumulation for every underlying required counter and every
   aggregation operation, with a sticky overflow diagnostic that cannot reset
   during the context. This establishes no wrap by execution rather than by
   guessed rates, but is broader and potentially changes instrumentation cost.

Either option changes the measured implementation and therefore requires new
matched observations and an explicit new qualification contract. Historical v1
measurements must remain blocked.

### Failure propagation footgun

`Processor::run` catches exceptions and returns `-1`; the SimX backend starts it
as `std::async(... [&] { processor_.run(); })`, discarding the return value.
Throwing on a lifetime limit therefore is not sufficient by itself to fail
qualification. A limit must produce an unambiguous retained failure and prevent
an analyzer from accepting partial/stale outputs. A hard nonzero process exit
or sticky checked diagnostic must have dedicated adversarial tests.

## Recommended implementation sequence

1. Implement the versioned evidence validator and additive CLI with explicit
   blockers for missing route, lifetime, and bound obligations. Keep v1 bytes
   and rejection semantics intact.
2. Extend real linked native tests to the exact TCU-enabled profile and all 33
   selectors, including boundary seeds across `2^32` and counter maximums.
3. Freeze and independently review a concrete lifetime bound mechanism before
   allowing the new validator to return qualified.
4. Bind source/build/interpreter/configuration/binary identities before and
   after the complete fixed attempt. A string qualification ID is not proof.
5. Only then collect the original fixed 24-process / 792-launch population and
   preserve favorable and negative outcomes under unchanged statistical rules.

No native execution evidence was produced by this audit.
