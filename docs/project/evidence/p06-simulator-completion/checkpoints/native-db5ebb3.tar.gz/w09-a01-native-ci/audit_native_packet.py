#!/usr/bin/env python3
"""Read-only verification of the original hosted completion packet."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PACKET = ROOT / 'packet/simulator-completion'
SOURCE = PACKET / 'artifacts/source'
BUILD = PACKET / 'artifacts/build'
COMPILER = PACKET / 'artifacts/compiler'
REPO = Path('/workspace/scratch/ea983fdea786/AI-GPU')
CHECKPOINT = 'db5ebb3a16770004423f2456ec6d0caaa0aced6d'
MERGE = '782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd'
TREE = '1536393fef63bd4a4639505ce797c27303db1cc7'
sys.path.insert(0, str(SOURCE / 'ci/project'))
import p06_simulator_execute as runner

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    env = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')
    return subprocess.check_output(['git', *args], cwd=REPO, env=env)

report = json.loads((PACKET / 'report.json').read_text())
archive = ROOT / 'p06-simulator-completion-run45006726571-artifact14748468420.zip'
archive_bytes = archive.read_bytes()
metadata = json.loads((ROOT / 'github-artifacts.json').read_text())['artifacts'][0]
assert metadata['id'] == 14748468420
assert len(archive_bytes) == metadata['size_in_bytes'] == 2791612
assert 'sha256:' + digest(archive_bytes) == metadata['digest']
assert digest(archive_bytes) in (ROOT / 'job-137159859409.log').read_text()
with zipfile.ZipFile(archive) as z:
    archive_members = len(z.infolist())
    archive_uncompressed = sum(x.file_size for x in z.infolist())
    for item in z.infolist():
        if not item.is_dir():
            assert z.read(item) == (ROOT / 'packet' / item.filename).read_bytes(), item.filename
job = json.loads((ROOT / 'packet/job.json').read_text())
preparation = json.loads((ROOT / 'packet/preparation.json').read_text())
assert report['outcome'] == 'pass'
assert report['reason'] is None
assert report['state'] == 'finished'
assert report['full_matrix_completed'] is True
assert report['acceptance_claimed'] is False and report['qualified'] is False
assert job['GITHUB_SHA'] == MERGE
assert job['GITHUB_RUN_ID'] == '45006726571'
assert job['GITHUB_RUN_ATTEMPT'] == '1'
assert job['GITHUB_EVENT_NAME'] == 'pull_request'
assert preparation['outcome'] == 'pass'
assert preparation['expected_revision'] == MERGE
assert git('rev-parse', CHECKPOINT + '^{tree}').decode().strip() == TREE

for group in ['source', 'tools', 'dependencies', 'generated', 'artifacts']:
    assert report[group + '_before'] == report[group + '_after'], group
checkout = report['source_before']['checkout']
assert checkout['revision'] == MERGE and checkout['tree'] == TREE
assert checkout['dirty'] is False and not checkout['blockers']
assert not checkout['changed_paths'] and not checkout['untracked_paths']
assert [x['label'] for x in report['stability_checks']] == [
    'before-configure', 'before-unit', 'after-unit', 'before-public', 'after-public']

retained_count = 0
for group in ['retained_source', 'retained_configuration', 'retained_compiler_records', 'retained_header_probe']:
    for item in report[group]:
        path = PACKET / item['path']
        assert path.resolve().is_relative_to(PACKET.resolve()), item['path']
        data = path.read_bytes()
        assert len(data) == item['size_bytes'], item['path']
        assert digest(data) == item['sha256'], item['path']
        retained_count += 1
for source_group, retained_group, prefix in [
    ('source_before', 'retained_source', 'artifacts/source/'),
    ('generated_before', 'retained_configuration', 'artifacts/build/'),
]:
    originals = report[source_group]['files'] if source_group == 'source_before' else report[source_group]
    retained = [{**x, 'path': x['path'].removeprefix(prefix)} for x in report[retained_group]]
    assert originals == retained

git_entries = {}
for entry in git('ls-tree', '-rz', CHECKPOINT).split(b'\0'):
    if not entry:
        continue
    meta, path = entry.split(b'\t', 1)
    mode, kind, sha = meta.decode().split()
    git_entries[path.decode()] = (mode, kind, sha)
membership = []
for item in report['source_before']['files']:
    path = item['path']
    data = (SOURCE / path).read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    row = dict(item, actual_git_blob=blob)
    if path in git_entries:
        assert git_entries[path][1] == 'blob'
        assert git_entries[path][2] == blob, path
        row['membership'] = 'checkpoint_blob_match'
    else:
        enclosing = [name for name, (mode, kind, sha) in git_entries.items()
                     if kind == 'commit' and path.startswith(name + '/')]
        assert len(enclosing) == 1, path
        row['membership'] = 'retained_submodule_body_only'
        row['enclosing_gitlink'] = enclosing[0]
    membership.append(row)
gitlinks = {path: sha for path, (mode, kind, sha) in git_entries.items() if kind == 'commit'}
for path, sha in gitlinks.items():
    entries = [x for x in checkout['submodules']['entries'] if x['path'] == path]
    assert len(entries) == 1 and entries[0]['revision'] == sha

commands = {x['id']: x for x in report['commands']}
assert len(commands) == len(report['commands']) == 18
for command in commands.values():
    assert command['outcome'] == 'pass' and command['exit_code'] == 0
    assert command['process_started'] and command['cleanup_complete']
    assert command['reason'] is None
    data = (PACKET / command['log']).read_bytes()
    assert len(data) == command['log_size_bytes']
    assert digest(data) == command['log_sha256']
    assert command['peak_rss_bytes'] <= report['budget']['max_rss_bytes']
    assert command['duration_seconds'] <= command['timeout_seconds']
    assert len(data) <= report['budget']['max_log_bytes']
for cell in report['cells']:
    observed = runner.verify_output((PACKET / commands[cell['command']]['log']).read_text(), cell['id'])
    assert observed == cell['observations']

original_source = Path(report['paths']['source'])
original_build = Path(report['build_dir'])
original_tools = Path(report['paths']['tools'])
versions = dict(re.findall(r'^([A-Z][A-Z0-9_]*)=([A-Za-z0-9_.+-]+)$',
                          (SOURCE / 'VERSION').read_text(), re.MULTILINE))
substitutions = dict(versions, XLEN='64', PROFILE='p02-tfr', VORTEX_HOME=str(original_source),
                     TOOLDIR=str(original_tools), OSVERSION='ubuntu/focal',
                     INSTALLDIR=str(original_build / 'install'), BUILDDIR=str(original_build))
expected_config = (SOURCE / 'config.mk.in').read_text()
assert set(re.findall(r'@([A-Z][A-Z0-9_]*)@', expected_config)) <= substitutions.keys()
for key, value in substitutions.items():
    expected_config = expected_config.replace('@' + key + '@', value)
assert (BUILD / 'config.mk').read_text() == expected_config
for name in runner.base.COPIED + ('sim/simx/completion.mk', runner.APP + '/Makefile'):
    assert (BUILD / name).read_bytes() == (SOURCE / name).read_bytes(), name
assert (BUILD / 'sim/rtlsim/verilator.vlt').read_text() == (
    SOURCE / 'sim/rtlsim/verilator.vlt.in').read_text().replace('@VORTEX_HOME@', str(original_source))
fields = dict(x.split('=', 1) for x in (BUILD / '.config.stamp').read_text().split())
assert len(fields) == len((BUILD / '.config.stamp').read_text().split())
for key, expected in [('XLEN','64'), ('PROFILE','p02-tfr'), ('SOURCE_DIR',str(original_source)),
                      ('BUILDDIR',str(original_build)), ('TOOLDIR',str(original_tools))]:
    assert fields[key] == expected

configs = runner._stamp_flags((PACKET / 'logs/profile-flags.log').read_text(), 'profile')
stamps = {name:(COMPILER / name).read_text() for name in runner.STAMPS}
runner.compiler.validate_records(stamps['sw/runtime/simx_rt_config.stamp'],
    stamps[runner.APP + '/config.stamp'], str(original_build), configs)
roles = ['unit_model','runtime_model','runtime','kernel','host']
assert [x['role'] for x in report['compiler_records']] == roles
model_compile_commands = 0
for row in report['compiler_records']:
    role = row['role']
    lines = runner.timed_compiler._bounded_records(stamps[row['path']], row['path'])
    line = lines[1] if role == 'host' else lines[0]
    assert digest(line.encode()) == row['sha256']
    words = runner._stamp_words(line, role)
    flags = runner._stamp_flags(line, role)
    assert words == row['compiler_flags'] and flags == row['macro_flags']
    runner.compiler._compile_flags(line, role, configs, kernel=role == 'kernel')
    defines = runner._stamp_defines(line, role)
    runner.timed_compiler._configuration(defines, role, performance=role.endswith('_model'),
                                       raw=True, expanded=not role.endswith('_model'))
    includes, probe = runner._compiler_options(words, role, original_source, original_build)
    assert includes == row['include_paths'] and probe == row['probe_flags']
    argv, cwd = runner.effective_header_command(report['tools_before'], original_build, original_tools, row)
    command = commands['header-' + role]
    assert [str(x) for x in argv] == command['argv'] and str(cwd) == command['cwd']
    macros = runner.validate_header_macros((PACKET / command['log']).read_text(),
                                         performance=role.endswith('_model'))
    assert macros == report['effective_headers'][role]
    assert macros['VX_CFG_XLEN'] == '64' and macros['VX_CFG_TCU_TYPE'] == 'TFR'
    assert macros['VX_CFG_TCU_FP16_ENABLED'] == '1'
    log_id = {'unit_model':'unit-build', 'runtime_model':'runtime-build',
              'runtime':'runtime-build', 'kernel':'application-build',
              'host':'application-build'}[role]
    build_log = (PACKET / 'logs' / (log_id + '.log')).read_text()
    if not role.endswith('_model'):
        assert line in build_log, role
    else:
        expected = list(words)
        dep_index = expected.index('-MF')
        del expected[dep_index:dep_index+2]
        matches = []
        for log_line in build_log.splitlines():
            argv = shlex.split(log_line)
            if argv[:2] != ['ccache', 'g++'] or '-c' not in argv or '-MF' not in argv:
                continue
            options = argv[2:argv.index('-c')]
            dep_index = options.index('-MF')
            dep = options[dep_index+1]
            del options[dep_index:dep_index+2]
            assert options == expected, role + ': recorded build flags differ'
            assert dep.startswith(str(original_build / ('sim/simx/obj' if role == 'unit_model' else 'sw/runtime/obj')) + '/')
            assert dep.endswith('.d')
            matches.append(argv)
        assert matches
        model_compile_commands += len(matches)

assert job['workflow_sha256'] == digest((SOURCE / '.github/workflows/p06-simulator-completion.yml').read_bytes())
assert report['tools_before']['executing_python'] == report['tools_before']['python3']
assert report['budget']['jobs'] == 2 and report['budget']['threads'] == 1
assert report['budget']['min_free_bytes'] == 15*1024**3
assert report['budget']['max_rss_bytes'] == 4*1024**3
for command_id in ['unit-build','runtime-build','application-build']:
    environment = commands[command_id]['environment']
    assert environment['PERF'] == '1' and environment['THREADS'] == '1'
    assert environment['CCACHE_DISABLE'] == '1' and environment['MAKEFLAGS'] == '-j2'
for command_id in ['unit-run','public-run']:
    environment = commands[command_id]['environment']
    assert environment['VORTEX_DRIVER'] == 'simx'
    assert environment['LD_LIBRARY_PATH'] == str(original_build / 'sw/runtime')

summary = {
    'outcome':'pass', 'scope':'retained-data audit; historical pre-CP-allocation-repair checkpoint',
    'checkpoint':CHECKPOINT, 'executed_merge':MERGE, 'tree':TREE,
    'archive_sha256':digest(archive_bytes), 'archive_bytes':len(archive_bytes),
    'archive_members_verified_unchanged':archive_members, 'archive_uncompressed_bytes':archive_uncompressed,
    'retained_records_verified':retained_count,
    'retained_source_count':len(membership),
    'source_checkpoint_blobs_verified':sum(x['membership']=='checkpoint_blob_match' for x in membership),
    'retained_submodule_bodies_only':sum(x['membership']=='retained_submodule_body_only' for x in membership),
    'root_gitlinks_verified':len(gitlinks), 'commands_and_log_hashes_verified':len(commands),
    'compiler_roles_revalidated':roles, 'effective_headers_revalidated':len(roles),
    'model_object_compile_commands_cross_checked':model_compile_commands,
    'generated_records_verified':len(report['generated_before']),
    'tools_before_after_identical':len(report['tools_before']),
    'dependency_library_identities_before_after':len(report['dependencies_before']),
    'binary_and_stamp_identities_before_after':len(report['artifacts_before']),
    'maximum_sampled_rss_bytes':max(x['peak_rss_bytes'] for x in commands.values()),
    'native_observations':report['cells'],
    'acceptance_claimed':False, 'qualified':False,
    'native_public_injected_failure_tested':False, 'native_rtlsim_tested':False,
    'report_sha256':digest((PACKET/'report.json').read_bytes()),
    'unit_log_sha256':digest((PACKET/'logs/unit-run.log').read_bytes()),
    'public_log_sha256':digest((PACKET/'logs/public-run.log').read_bytes()),
    'limitations':report['limitations'] + [
        'All 761 retained source bodies match root checkpoint blobs. Five root gitlinks are bound; third-party submodule source/header bodies and dependency library bytes are not archived by this packet.',
        'The three backend/helper source files subsequently changed for recoverable synchronous CP OOM handling; this is not release-final evidence.',
        'No native binaries were rebuilt or executed locally by this review.'],
}
(ROOT/'source-git-membership.json').write_text(json.dumps(membership,indent=2)+'\n')
(ROOT/'audit-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['native_observations','limitations']},indent=2))
