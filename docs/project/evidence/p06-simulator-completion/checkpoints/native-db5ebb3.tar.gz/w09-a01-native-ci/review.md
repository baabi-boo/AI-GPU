# Wave 9, assignment 1: original native completion packet review

## Verdict and scope

**Accept this as historical native completion evidence for checkpoint
`db5ebb3a16770004423f2456ec6d0caaa0aced6d`. It is not release-final evidence
for the subsequent CP allocation-error repair.** No new blocking defect was
found in the artifact integrity, recorded execution, or the narrowly stated
native claims reviewed here. The separate recoverable CP OOM regression found
by Wave 8 is outside the two native controls, and its repair must receive its
own regression proof and a fresh native run.

This is an author-disjoint evidence review using the repository's code-review
and SimX review discipline. It is not a second review of every implementation
hunk, a waiver, or project-phase acceptance. The overall externally visible
completion change remains R3; this review closes only the historical native
packet inspection assigned to this reviewer.

No repository source files were edited, no native build was started, and no
local native test binary was executed. The local command
`python3 -B audit_native_packet.py` verified retained data and replayed pure
parsers. It returned zero. The original downloaded ZIP and every extracted
member remain unchanged.

## Original artifact and tested identity

| Field | Observed value |
|---|---|
| GitHub workflow | [P06 Simulator Completion, run 45006726571](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726571) |
| Native job | `137159859409`, successful |
| Artifact | `14748468420`, attempt 1 |
| ZIP bytes | 2,791,612 |
| ZIP SHA-256 | `d5f71cec99321c5f8e6c11fab37875aa93e551270a1a15c29b3fe9af6c766588` |
| ZIP members | 812, totaling 10,790,462 uncompressed bytes |
| Executed checkout | `782552fdbb5a216fe7907dde84d8f3f0dc6eb6dd`, PR 6 merge |
| Branch checkpoint | `db5ebb3a16770004423f2456ec6d0caaa0aced6d` |
| Shared source tree | `1536393fef63bd4a4639505ce797c27303db1cc7` |
| Merge parents | `42809ff0c1b81384d7c9b079e4ef786be8407600`, then `db5ebb3a16770004423f2456ec6d0caaa0aced6d` |

The archive digest matches both GitHub artifact metadata and the original job's
upload message. The merge metadata was fetched independently from GitHub and
saved in `github-merge-commit.json`; the branch checkpoint tree was resolved
from local Git with `GIT_NO_REPLACE_OBJECTS=1`. The recorded checkout is clean
both before and after execution. Preparation records correctly say that
preparation alone had not run native tests; the final execution report carries
the two completed native cells.

Safe extraction rejected absolute paths, traversal, backslash paths and
symlinks, and imposed a 64 MiB uncompressed cap. The later audit compared all
812 archive members against their extracted bytes, in addition to the report's
individual retained-file hashes.

## Source, configuration and command verification

The audit checked all **786 retained input records**: 761 source bodies,
20 generated configuration files, four compiler-stamp files, and one header
probe source. Every retained source body matches its exact Git blob in the
checkpoint tree. All five root submodule gitlinks match the recorded checkout
inventory. The packet does not retain third-party submodule source/header
bodies or the dependency library bytes; their checkout/library identities are
recorded separately. This is not a fully hermetic rebuild bundle.

All **18 command records and their original log sizes and SHA-256 values**
agree. Every command started, returned zero, and completed process-group
cleanup. Before/after records agree for source, 21 tool identities, three
dependency libraries, 20 generated files, and 12 binary/stamp identities. Five
stability checkpoints cover before configuration and before/after each native
cell.

The fixed configuration is RV64, `p02-tfr`, timing SimX, FP16 enabled,
`PERF=1`, build jobs 2, and one host simulation worker. The modeled GPU uses
the profile's four threads per warp. This completion workload does not test
tensor arithmetic merely because it builds under a tensor-enabled profile.
The exercised CP path is direct RAM (`VX_CFG_CP_ON_LLC=0` in the expanded
runtime/kernel/host records); native LLC-mode execution is not inferred.

The generated `config.mk` exactly matches the retained template with the
recorded source/build/tool paths and version substitutions. The configure stamp,
13 copied Makefile/helper inputs, and generated Verilator configuration agree
with their retained source inputs. The four generated configuration/type
headers are hash-bound and stable. Five effective-header outputs were parsed
again from their raw compiler output, yielding exactly the report's macro maps.

The original compiler records were parsed again for `unit_model`,
`runtime_model`, `runtime`, `kernel`, and `host`. The shared configuration and
flag checks, strict compiler options, include search order, and header-probe
argv/cwd checks pass. The runtime, kernel and host records appear verbatim in
the build logs. For **87 model-object compile commands**, the observed compiler
options match the respective stamp in order; their `-MF` operand selects the
per-object dependency file instead of the stamp's own target, exactly as the
retained Makefile prescribes. The build logs invoke `ccache g++` with
`CCACHE_DISABLE=1`; this review does not claim that a cache wrapper was absent.

The actual interpreter and `python3` path resolve to the same hash, and the
provisioning/version logs identify CPython 3.12.14. Compiler version evidence
identifies GCC 11 and the pinned Vortex LLVM toolchain. Tool hashes do not bind
every host header, compiler support file, wrapper or dynamic library.

The runner preserves its 15 GiB disk reserve, 4 GiB sampled process-group RSS
budget, 16 MiB per-command log cap and 180-second native execution timeout.
The highest recorded RSS sample is 871,755,776 bytes. These are polled budgets,
not kernel-enforced quotas or a guarantee that every between-sample peak was
observed.

## What the actual native output proves

The processor-unit raw log contains this ordered sequence:

```text
native_x3 gp=7 checked_launches=3 legacy_launches=1
native_x3 gp=-1 checked_launches=3 legacy_launches=1
Error: exception: out of range memory address
native_legacy_exception result=-1
native_exception type=OutOfRange consumed=1
native_x3 gp=7 checked_launches=3 legacy_launches=1
PASSED simx_completion native_unit contexts=5 checked_success=9 legacy_success=3 checked_exceptions=1 legacy_errors=1
```

Inspection of the retained unit source confirms actual `Processor` and bounded
`RAM` objects, not the controlled host fixtures. The normal program writes
architectural x3 with 7 or -1, and three asynchronous checked launches plus a
legacy launch inspect the resulting x3 value. The legacy exception cell calls
`run()` and retains its -1 result. The checked exception cell starts at the
RAM capacity boundary and obtains `OutOfRange` through `future.get()`. A fresh
normal context then completes after the faulted objects have been destroyed.
The stderr exception line is expected output from the legacy control, not a
test failure.

Thus this run establishes checked-versus-legacy semantics and fresh-context
completion for the tested native, single-worker timing configuration. It does
not establish continued use of the failed `Processor`, direct same-thread TLS
recovery, or internal multi-worker exception transport.

The public-runtime raw log contains six ordered successful witnesses:

| Context | Launch | Global pointer | Result |
|---|---:|---|---|
| 0 | 0 | `0000000180001870` | `373f373f` |
| 0 | 1 | `0000000180001870` | `373f372e` |
| 0 | 2 | `0000000180001870` | `373f36dd` |
| 1 | 0 | `0000000180001870` | `373f373e` |
| 1 | 1 | `0000000180001870` | `373f372d` |
| 1 | 2 | `0000000180001870` | `373f36dc` |

Its final banner is
`PASSED simx_completion native_success contexts=2 launches=6 gp_nonzero=6`.
The retained source checks actual output/global data/sequence, dependent reads,
repeated waits on completed events, and explicit release calls. Each witness
matches the fixed input formula, and every low global-pointer word is nonzero.
The native command used `VORTEX_DRIVER=simx` and only the just-built runtime
directory in `LD_LIBRARY_PATH`.

This public control does **not** inject a native backend fault. Host-controlled
public errors, deterministic first-poll scheduling, inherited-parent
sensitivity, and recoverable CP OOM continuation are different evidence.

## Source boundary for the forthcoming repair

All three production files being repaired after this checkpoint are retained
at `packet/simulator-completion/artifacts/source/` and bound by both source
snapshots:

| Relative source path | Bytes | SHA-256 in this original run |
|---|---:|---|
| `sw/runtime/common/async_run.h` | 1,988 | `17e229eb116c6d50d273780bb969630d0e0141a8aec39f22c0ab0fb62b74d2ed` |
| `sw/runtime/simx/vortex.cpp` | 7,310 | `61a14d8c29f9c2e9bef292d4ef8bbc5892ff6b13ad62110a80915f788917edd4` |
| `sw/runtime/rtlsim/vortex.cpp` | 7,287 | `048f7e96625243024a7f4952fb7e616b4f28c47744e1670e346917b554b6fce4` |

Retention of the rtlsim source is provenance, not proof that native RTL
executed. This immutable packet must not be relabeled as exercising the later
repair. Its runner source is SHA-256
`373ed9ba9141db73e740c87ec812872bb1dc2131b29819a7f001eda7e59e5641`.

## Separate governance result

[Project Governance run 45006726409](https://github.com/baabi-boo/AI-GPU/actions/runs/45006726409),
job `137159859008`, completed successfully on the same PR merge checkout.
Its original log contains:

```text
python3 -m unittest discover -s ci/project -p 'test_*.py' -v
Ran 2988 tests in 1191.429s
OK
```

The log independently contains 2,988 unique test results, all `ok`, including
the 78 focused completion tests. One test's docstring puts its `... ok` on
the following line; this was accounted for rather than silently dropping it.
The project structure/metadata validator and published baseline consistency
check also passed. Their own output keeps their scope separate from GPU
execution and phase acceptance.

This governance result predates the new CP OOM tests and repair. It does not
show that the later final revision's full suite has already passed.

## Retained review outputs and limitations

The directory contains the original ZIP, GitHub artifact/merge metadata, both
original job logs, the untouched extraction, `audit_native_packet.py`,
`audit-summary.json`, `source-git-membership.json`, and
`governance-summary.json`.

Key original hashes:

| Record | SHA-256 |
|---|---|
| Native report | `645197e5a4fea26973aa603e4e162bea9ba773ce4f61494945c9906c63bed578` |
| Unit raw log | `72f2fa579ebebc53190bfb20a96ab9b165f68a05d9d5122a6eda087871b3d3f4` |
| Public raw log | `21b114c7606216dd3eb0ec347899bc61a0c28357d69d4d4683c58d073f688cdc` |
| Governance job log | `182eca77ac0db01c0283fa47fc9361296f45521c6334a7af680e1141a110b22b` |

No native binaries or dependency libraries are archived by this runner; their
before/after hashes are records, not a local binary re-execution. Before/after
hashes do not detect malicious replacement restored between observations.
The packet correctly keeps `qualified=false` and `acceptance_claimed=false`.
It does not qualify counter lifetime/no-wrap, warm speedup, RTL/full-AFU,
vendor hardware emulation, physical FPGA, silicon, or any project phase gate.

The release obligations still open at this review's completion are the
recoverable CP OOM fix, its independent actual-CP regression and review, a fresh
native checkpoint covering the repaired source, and final integration evidence.
