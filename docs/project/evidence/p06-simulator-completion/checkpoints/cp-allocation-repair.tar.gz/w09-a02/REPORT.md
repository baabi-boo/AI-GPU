# Independent review: processor failures and recoverable CP errors

## Verdict and reviewed state

**No unresolved F2/F3 defect was found in the narrow production repair or its new host regression.** The repair restores the inherited CP-copy allocation-failure contract while retaining terminal failure for asynchronous and synchronous processor execution. Land this repair after the coordinator completes the clean final-checkpoint and corresponding native verification obligations. The earlier native run of `db5ebb3` cannot certify later production bytes.

This is an author-disjoint review of the three production files changed after `db5ebb3a16770004423f2456ec6d0caaa0aced6d` and the four new error-boundary regression files. I did not write or modify those production/tests. I separately reconciled only `docs/designs/simulator_completion_v1.md`, as assigned, after the code review. Its final wording was also read by the coordinator. No commit, push, native build, acceptance change or waiver was performed.

The review applies the repository's code-review and simx-review skills, AGENTS, C++/Verilog guidelines, bug-fix discipline, SimObject contract and simulator architecture. It treats the observable error-boundary behavior as **R3**, even if a path-only classifier reports R2. This working-tree review is not a substitute for the coordinator's final immutable-base classifier and full delivery review.

Exact copies and SHA-256 identities are retained in `reviewed-source/` and `source-review-final.json`. Production bytes remained unchanged throughout the review:

| File | SHA-256 |
|---|---|
| `sw/runtime/common/async_run.h` | `a9f63b2a896c5e512f7c592c758618ea88b774c9dac4bca29e847e2e3719a24e` |
| `sw/runtime/simx/vortex.cpp` | `0d890c95fecb67da26d23ea4a0af10ac328dddf110cd2575baff3aa5d4c905cb` |
| `sw/runtime/rtlsim/vortex.cpp` | `e6e049d41ccb3315fd464387a4006745a82160849795af50411edcef6095ac93` |

## Production hunk review

`AsyncRun::invoke()` synchronously calls `wait()` before the processor hook. That consumes any pending future before processor state is touched. The enclosing catch latches and rethrows every exception, including `std::bad_alloc` and non-standard thrown values. The helper does not dispatch a second task or retain a lambda; the references captured by each call remain valid until it returns. `failed()` is a const, nonthrowing observation of host-owned state.

Both CP callback catches now inspect that terminal flag. An exceptional future, task-creation failure, overlapping launch, or synchronous processor-hook exception has already latched it and therefore returns the inherited nonzero HAL status. `CallbacksAdapter::r()` maps that status to `VX_ERR_INVALID_VALUE`. Repeated reads/writes fail at the initial completion check, so they cannot retire the failed model launch, expose a successful read value, or execute later processor work. A queue-local error being consumed does not clear the owner flag.

An unrelated CP exception leaves the owner healthy and is rethrown. This matters for the actual copy-scratch allocation in `CommandProcessor::tick_engine()`: the copy branch sets `EngState::Retire` before allocating its vector. The exception unwinds through the unchanged callback forwarding and adapter to `Queue::worker_loop`, whose existing bad-allocation catch reports `VX_ERR_OUT_OF_HOST_MEMORY`. Staging ownership unwinds, failed dependencies preserve the error, and queue finish consumes only its local error. The next CP tick retires the abandoned descriptor instead of replaying a copy through freed staging. Keeping the original OOM result while retaining the terminal owner flag would still be wrong; both mapping and same-device continuation are required.

Every newly wrapped synchronous call was checked in both backends: LLC read, ordinary write, DMA/no-allocation write, DCR read/write, and processor RTL drain. Real processor implementations can advance cache/model state or tick the simulator on these routes, so exceptions must be terminal. Direct host RAM accesses remain on the inherited CP/host route; they can allocate host pages without running the processor. The capability queries `cp_llc_client()`/`cp_llc_size()` remain constant/configuration queries. There is no exception-type shortcut that accidentally makes a processor allocation failure recoverable.

The patch leaves the successful call order and waits intact; `invoke()` adds classification around the same wait and hook call. It changes no model pipeline, arithmetic, scheduling, simulated cycles, normal channel accounting, public ABI, ISA, counter selector or threshold. It leaves the first busy edge untouched because `wait()` and `collect()` do not clear `start_pending_`. Async results still use `get()`. Legacy architectural `gp` interpretation, serial host control and nonthrowing destruction joining remain unchanged. The worker does not mutate the plain host-owned failure flag concurrently. Existing tests still use `fail()` for the explicit failed-owner/destruction seam, so retaining that method is justified.

## Independent regression and evidence verification

I inspected all four new test/fixture files and independently checked the original retained records under `../w08-a06/`. I did not rerun a native processor or duplicate the new host suite during this review. The separate driver executes the actual five TestCase methods via `debug()` after their real class setup; the coordinator will obtain normal discovery on the clean checkpoint.

The test compiles the actual dispatcher, common runtime, callbacks, backends, CP, and **unchanged** `tests/runtime/test_ai_lifecycle.cpp`. Only Processor/RAM are controlled. I independently compared the lifecycle bytes to audited base `42809ff0c1b81384d7c9b079e4ef786be8407600`; SHA-256 remains `0e6efb5275c6e25f3991d7da789fa1a02b4eb204da7da37d7b4b3bb4491df7ae`. The allocation injection and original assertions were not weakened or copied into a substitute test.

| Executed host group | Cells | Evidence checked |
|---|---:|---|
| Entire inherited lifecycle | 4 | SimX/rtlsim × direct RAM/LLC; all three transfer allocation stages; original/dependent OOM; resource restoration; seeded data read before overwrite; same-device write/read recovery |
| Asynchronous model fault | 8 | Two exception kinds × two backends × two memory routes |
| Synchronous DCR read/write fault | 16 | Both DCR hooks, both exception kinds, both backends and memory routes |
| Synchronous LLC read/write fault | 8 | Both memory hooks, both exception kinds and both backends |
| Synchronous processor RTL drain fault | 2 | Both exception kinds through the supported direct-RAM flush/drain path |
| **Fixed positive cells** | **38** | All passed; five TestCase methods |
| Built `db5ebb3` negative lifecycle controls | 4 | Both backends and memory routes; each fails the intended OOM assertion after stages 0/1 pass |

Each terminal-model cell proves exactly one armed fault occurred, original and dependent events retain `VX_ERR_INVALID_VALUE`, repeated waits retain it, and the event timeline reaches one. It consumes the queue error, enqueues fresh work, then requires the backend to reject it without additional processor operations, including during cleanup. That is a meaningful distinction from merely checking a failure code.

The negative controls compile original `db5ebb3` backend and owner bytes against the same actual common runtime/CP, same shims and same lifecycle executable. I independently retrieved those Git objects with replacements disabled and compared all three retained old source files. All four negative logs show `test_ai_lifecycle.cpp:415: result == VX_ERR_OUT_OF_HOST_MEMORY`, exit 1, bounded-process reason `nonzero_exit`, complete cleanup, stage 0/1 success, and no stage 2 success. A timeout or compile failure was not accepted as sensitivity.

I verified all **83** bound source bodies against retained snapshots, current files and before/after hashes; all **51** original command-log hashes and process outcomes; four lifecycle and 34 distinct model cells; and the original manifests of both the repair and regression packets. There were 47 passing commands and four intended failing controls. `regression-evidence-audit.json` and `author-manifests-audit.json` retain the independent checks.

The author repair's existing 17-test receipt was also read: eight owner groups, six actual backend/CP groups (24 cells), and three public runtime groups (12 cells), totaling 44 executable cells. Its log reports 17 tests in 36.272 seconds, `OK`; its source and manifest entries were verified. Those existing cases preserve standard/unknown errors, immediate completion, nonzero legacy gp, pending execution, serial success and destructor joins.

## Contract reconciliation

The contract now explicitly defines processor-origin failure, includes synchronous guarded hooks and allocation exceptions, and describes the inherited CP/host propagation route. The separate CP allocation subsection requires OOM propagation, cleanup, no replay and same-device continuation only for the established recoverable path. It does not promise arbitrary CP recovery or rollback of already-written bytes.

The prohibition on successful retirement is explicitly scoped to processor-origin failure, so it does not contradict the later Retire handling of an abandoned CP-copy descriptor. The evidence table links the new regression. Native requirements are timeless and point to the evidence README for exact retained revision/configuration receipts; no temporary `not_run` or current-run outcome is embedded in the native-bound contract. All local contract links resolve, and `git diff --check` passes.

Final contract SHA-256: `5c93b2be36d7f00a677ea681662cfe0ae0788451c6fa538f59dd895bdf6157c6`.

## Findings and remaining obligations

- **Closed F3, high confidence, static-proof plus executable sensitivity:** the intermediate catch-all made a supported recoverable CP copy allocation failure terminal and misclassified its event. The origin-based boundary and unchanged lifecycle positive/negative matrix close the concrete compatibility defect.
- **Closed F1, high confidence, static-proof:** the contract described every CP-transaction exception as terminal and therefore contradicted inherited lifecycle behavior. The reconciled wording matches the implementation and tested distinction.
- **No unresolved F2/F3 code or host-regression finding in this review scope.** The final clean-checkpoint host discovery, corresponding native evidence, immutable-base full-diff review and delivery packet reconciliation remain coordinator obligations. The prior native run is pre-repair evidence.

The host packet identifies temporary binaries but does not retain their bytes or a hermetic system-header/toolchain image. Before/after source hashes cannot disprove transient changes restored between samples. Native public-runtime fault injection, native processor RTL or functional-SimX failure execution, multiworker exception transport, same-thread TLS restoration, cancellation, failed-processor reuse and concurrent contexts remain outside these tests. No performance or phase gate is accepted by this review.
