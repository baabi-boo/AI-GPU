# Wave 8, agent 5 — CP exception compatibility repair

## Outcome and source identity

Implemented the narrow production repair in exactly these repository files:

- `sw/runtime/common/async_run.h`
- `sw/runtime/simx/vortex.cpp`
- `sw/runtime/rtlsim/vortex.cpp`

The reviewed starting checkout was clean at `db5ebb3a16770004423f2456ec6d0caaa0aced6d`.
This working-tree repair is **subsequent to that revision**. Native execution of
`db5ebb3` cannot establish execution of these new bytes. No native build,
download, commit, push, public ABI change, CP change, common queue/runtime
change, test edit, validator edit, or repository documentation edit was made by
this agent.

The retained `repair.patch`, `before/`, `after/`, `before.json`, and `after.json`
identify the exact production change. The diff is 44 inserted and 26 removed
lines across the three owned files.

| File | Repaired SHA-256 |
|---|---|
| `sw/runtime/common/async_run.h` | `a9f63b2a896c5e512f7c592c758618ea88b774c9dac4bca29e847e2e3719a24e` |
| `sw/runtime/simx/vortex.cpp` | `0d890c95fecb67da26d23ea4a0af10ac328dddf110cd2575baff3aa5d4c905cb` |
| `sw/runtime/rtlsim/vortex.cpp` | `e6e049d41ccb3315fd464387a4006745a82160849795af50411edcef6095ac93` |

## Fault origin determines the error boundary

The consumer audit `../w08-a04-consumer-error-scope.md` identified a real
compatibility conflict. The inherited lifecycle test injects `std::bad_alloc`
at CP scratch allocation and requires the original
`VX_ERR_OUT_OF_HOST_MEMORY`, followed by same-device continuation after queue
finish (`tests/runtime/test_ai_lifecycle.cpp:390–445,517–518`). The CP has
already selected `EngState::Retire` before allocating its copy scratch, so the
next transaction disposes of the failed transfer without replaying released
staging (`sim/common/cmd_processor.cpp:537–567,618–623`).

The blanket callback catch introduced by the completion work intercepted that
exception, latched the backend, and returned `-1`, which the adapter mapped to
`VX_ERR_INVALID_VALUE`. That removed both the original classification and the
required recovery path. The existing common runtime already handles a
propagating allocation exception correctly: callback forwarding and the adapter
allow it to reach `Queue::worker_loop`, whose `std::bad_alloc` catch maps it to
`VX_ERR_OUT_OF_HOST_MEMORY` (`sw/runtime/common/callbacks.inc:60–73`,
`sw/runtime/common/vortex2_internal.h:206–214`, and
`sw/runtime/common/queue.cpp:131–145`). No replacement mapping was needed.

The repair distinguishes these origins without classifying by exception type:

1. `AsyncRun::invoke` waits for outstanding execution, invokes a synchronous
   processor operation, and latches/rethrows every exception. Both backends use
   it for processor DCR reads/writes and LLC memory accesses; processor RTL also
   uses it for drain. These operations can advance or mutate processor state,
   so an exception remains terminal.
2. `AsyncRun::failed()` exposes the existing host-owned terminal flag without
   changing state. Each CP callback returns the existing nonzero HAL error only
   when that flag has been set. Otherwise the callback rethrows the CP/host
   exception through the existing common runtime handling.
3. Async execution and task-creation exceptions already set the flag in
   `AsyncRun`; this remains unchanged. Therefore an asynchronous model
   `std::bad_alloc` or unknown exception stays terminal. A CP scratch
   `std::bad_alloc` occurs outside processor invocation and does not set it.

Direct host-backed `RAM::read`/`RAM::write` retain their inherited CP/host
exception behavior. They do byte access and lazy host-page allocation, whereas
the guarded `Processor::cp_mem_read`/`cp_mem_write` routes execute cache/model
work. Constant-return `cp_llc_client`/`cp_llc_size` capability queries remain
unchanged. No new wait was added to direct RAM access.

The launch state machine, first busy edge, asynchronous result collection,
nonthrowing destruction join, and legacy `gp` return interpretation are
unchanged. `AsyncRun::fail()` remains because the existing deterministic helper
fixture uses it at `ci/project/fixtures/simulator_async_run_test.cpp:288` to
exercise failed-owner destruction with an outstanding throwing task.

## Verification performed

Ran the existing three host suites with the external instrumentation script
`run_existing_host_tests.py`. The script records each original tool invocation
and output, runs the existing unittest cases without altering them, and copies
the tests' hash-bound source inputs after verifying they still match.

Command, from the repository root:

```sh
python3 /workspace/scratch/ea983fdea786/w08-a05/run_existing_host_tests.py \
  > /workspace/scratch/ea983fdea786/w08-a05/existing-host-tests.log 2>&1
```

| Existing suite | Groups | Executable test cases | Result |
|---|---:|---:|---|
| `test_p06_simulator_async_run.py` | 8 | 8 | Pass |
| `test_p06_simulator_completion.py` | 6 | 24: two backends × two memory paths × six groups | Pass |
| `test_p06_simulator_public.py` | 3 | 12: two backends × two memory paths × three groups | Pass |
| Total | 17 | 44 | No failures, errors, or skips |

All 54 underlying configure, host compile, and execution commands passed.
Unittest elapsed time was 36.272 seconds. The host builds use C++17, warnings as
errors, and UBSan. Source inputs remained stable: all 86 recorded input hashes
matched after execution. `git diff --check` also passed.

Evidence:

- `existing-host-tests.log`: unchanged suites' unittest outcomes.
- `commands.json`: exact underlying command arguments, working directories,
  time bounds, elapsed durations, raw output, and outcome.
- `test-result.json`: aggregate execution result.
- `test-source-hashes.json` and `tested-source/`: 86 exact tested inputs.
- `run_existing_host_tests.py`: the external instrumentation used for this run.

These are host-only checks. They exercise actual backend/CP/common runtime
source with controlled Processor/RAM implementations; they do not execute native
SimX or processor RTL. Existing tests preserve immediate completion, pending
work, sticky standard/unknown model faults, suppression of later work, queue
and event behavior, cleanup joining, serial success, and nonzero legacy `gp`.
They do not newly prove the CP allocation-failure reproduction or synchronous
processor-hook fault injections. Agent `w08_a06_cp_oom_regression` owns those
independent regressions and the pre-repair negative control in separate files.

## Remaining integration work owned by the coordinator

The completion contract currently describes the CP catch boundary too broadly.
Its wording must distinguish terminal processor-origin failures from inherited
CP/host exceptions, without changing either the model-failure requirements or
the lifecycle test. This agent did not change that document.

The coordinator should combine this source repair with agent 6's independent
fault-origin regression, obtain independent review of the final bytes, and keep
any native `db5ebb3` result identified as pre-repair evidence. No phase gate,
native qualification, Python fault-transport qualification, or physical recovery
claim is made here.
