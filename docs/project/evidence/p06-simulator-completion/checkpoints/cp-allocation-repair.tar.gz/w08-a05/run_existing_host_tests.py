from pathlib import Path
import hashlib
import importlib
import json
import shutil
import sys
import time
import unittest

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
OUT = Path('/workspace/scratch/ea983fdea786/w08-a05')
sys.path.insert(0, str(ROOT / 'ci/project'))
modules = [
    importlib.import_module(name) for name in (
        'test_p06_simulator_async_run',
        'test_p06_simulator_completion',
        'test_p06_simulator_public',
    )
]
commands = []

def traced(original):
    def invoke(argv, **kwargs):
        number = len(commands) + 1
        record = {'number': number, 'argv': list(map(str, argv)),
                  'cwd': str(kwargs.get('cwd', '')), 'timeout': kwargs.get('timeout')}
        commands.append(record)
        started = time.monotonic()
        try:
            output = original(argv, **kwargs)
            record['outcome'] = 'pass'
            record['output'] = output
            return output
        except BaseException as error:
            record['outcome'] = 'fail'
            record['error_type'] = type(error).__name__
            record['output'] = str(error)
            raise
        finally:
            record['elapsed_seconds'] = round(time.monotonic() - started, 3)
            (OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    return invoke

for module in modules:
    module.run_host_command = traced(module.run_host_command)

suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(module)
                           for module in modules)
result = unittest.TextTestRunner(verbosity=2).run(suite)
identities = {}
for module in modules:
    for obj in vars(module).values():
        if not isinstance(obj, type) or not issubclass(obj, unittest.TestCase):
            continue
        for path, expected in getattr(obj, 'identities', {}).items():
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            relative = str(path.relative_to(ROOT))
            identities[relative] = {'expected_sha256': expected, 'actual_sha256': actual}
            destination = OUT / 'tested-source' / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
            if actual != expected:
                raise RuntimeError('Test input changed: ' + relative)
(OUT / 'test-source-hashes.json').write_text(json.dumps(identities, indent=2) + '\n')
(OUT / 'test-result.json').write_text(json.dumps({
    'tests_run': result.testsRun,
    'failures': len(result.failures),
    'errors': len(result.errors),
    'skipped': result.skipped,
    'successful': result.wasSuccessful(),
    'command_count': len(commands),
    'scope': 'Host-only C++17/UBSan fixtures; controlled Processor/RAM, actual CP and common runtime. No native processor execution.',
}, indent=2) + '\n')
sys.exit(0 if result.wasSuccessful() else 1)
