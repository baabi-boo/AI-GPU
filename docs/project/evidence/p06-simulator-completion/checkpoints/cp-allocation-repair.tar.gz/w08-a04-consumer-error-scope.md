# Wave 8, agent 4 — consumer error-scope audit

## Result and review boundary

**The managed matmul/workspace and copying Python paths are source-compatible with a terminal event reporting `VX_ERR_INVALID_VALUE`: they retain the primary error, suppress output, and allow completed work to release its ownership. One concrete adjacent lifecycle-test incompatibility needs coordinator disposition.** The existing CP-copy allocation-failure test expects the original out-of-memory code and same-device recovery; the new guarded callback makes that particular fault terminal and returns `VX_ERR_INVALID_VALUE` instead.

- Reviewed checkout: `/workspace/scratch/ea983fdea786/AI-GPU` at `db5ebb3a16770004423f2456ec6d0caaa0aced6d`.
- Scope: read-only source/contract integration audit. All source citations below refer to that revision and use repository-relative paths and line numbers.
- Read the repository guidance, current status/roadmap/acceptance material, completion contract, serial-workspace contract, copying-binding contract, actual managed owners, native/Python bindings, and adjacent queue-finish consumers.
- No builds, native execution, broad tests, fault injection, or acceptance/gate changes were performed. `git status --short` and `git diff --stat` were empty at the initial and final source checks.
- The coordinator was notified immediately when the lifecycle incompatibility was identified. This report does not authorize changing that test, relaxing terminal-error behavior, or revising accepted contracts.

## 1. Open integration finding: CP-copy OOM and the inherited recovery expectation

### Concrete source conflict

`tests/runtime/test_ai_lifecycle.cpp:390–445` deliberately injects allocation failures into three real DMA stages. Its comment explicitly identifies backend host-region registration, common-runtime host registration, and the software CP's copy scratch (`407–410`). The background allocator throws `std::bad_alloc` when the selected budget reaches zero (`21–36`), and `main` selects all three budgets, including `2` (`510–518`).

For **each** stage, the test requires:

1. `VX_ERR_OUT_OF_HOST_MEMORY` from the failed event, dependent event, and `vx_queue_finish` (`415–417`).
2. A subsequent same-device read to succeed without replaying the failed transfer (`425–430`).
3. A subsequent same-device write/read sequence and finish to succeed (`433–437`).

The third allocation is the `std::vector<uint8_t>` scratch inside the CP copy implementation (`sim/common/cmd_processor.cpp:534–568`). That allocation runs inside the backend's guarded `cp_.tick()` call. Both backend register callbacks now catch **all** exceptions, call `run_.fail()`, and return `-1`:

- SimX: `sw/runtime/simx/vortex.cpp:74–104`.
- Processor RTL: `sw/runtime/rtlsim/vortex.cpp:73–99`.

`CallbacksAdapter::r` maps the nonzero return to `VX_ERR_INVALID_VALUE` (`sw/runtime/common/vortex2_internal.h:206–214`). The queue's `std::bad_alloc` handler cannot preserve the OOM classification in this case because the backend has already caught the exception and returned a status (`sw/runtime/common/queue.cpp:131–145`). `AsyncRun::fail()` leaves its terminal flag set, and every later `check()` rejects it through `require_healthy()` (`sw/runtime/common/async_run.h:38–43,70–88`). Queue finish only clears the queue-local error (`sw/runtime/common/queue.cpp:213–233`).

**Source-derived consequence:** if the fixture reaches its declared CP-scratch allocation, the existing assertions cannot all hold: the failure becomes `VX_ERR_INVALID_VALUE` and later device transactions stay failed. The CP already sets `eng_state_ = Retire` before the allocation specifically to avoid replaying a released staging transfer (`sim/common/cmd_processor.cpp:537–540`); this older replay protection does not clear the new backend latch.

This is a reachable, concrete integration scenario, not a claimed observed native failure. It merits at least an F2 disposition under the rule for a likely bug with a concrete reachable scenario (`docs/review/code-review-policy.md:54–62`). The coordinator should decide the accepted-scope implication and any narrowly scoped reproduction/remediation. No test or contract was changed by this audit.

### Original exception mapping and safe transfer-retirement sequence

The following comparison was read directly with `git show` at the original completion baseline, **`42809ff0c1b81384d7c9b079e4ef786be8407600`**. The common queue, callback forwarding, common device, adapter, and CP source files cited in this sequence have no diff between that baseline and the reviewed `db5ebb3` revision.

1. Original SimX `cp_reg_write/read` ran `cp_.tick()` without a catch (`sw/runtime/simx/vortex.cpp:75–92` at `42809ff`); original processor RTL did the same (`sw/runtime/rtlsim/vortex.cpp:75–84` at `42809ff`). The callback lambdas directly forwarded the call (`sw/runtime/common/callbacks.inc:60–73`).
2. A CP-copy scratch `std::bad_alloc` therefore propagated through the callback and adapter. In `return r(cb_.cp_reg_write(...))`, argument evaluation threw before `r` could map an integer return (`sw/runtime/common/vortex2_internal.h:206–214`). It reached `Queue::worker_loop`'s `catch (const std::bad_alloc&)`, which produced `VX_ERR_OUT_OF_HOST_MEMORY` (`sw/runtime/common/queue.cpp:131–145`).
3. Before allocation, the CP copy branch had already selected `EngState::Retire` (`sim/common/cmd_processor.cpp:537–540,567–568`). Common runtime had already advanced the ring tail and expected sequence number and rung the doorbell (`sw/runtime/common/device.cpp:660–661,738–754`). Stack unwinding ran the staging `ScopeExit`, freeing the old registered host staging (`1072–1088`).
4. The queue completed the original event with OOM, skipped dependent work, and retained the queue-local error (`sw/runtime/common/queue.cpp:112–153`). Finish's sentinel is a host no-op with no CP access (`933–944`); finish reported and cleared only that queue error (`213–233`).
5. On the next CP transaction, `tick()` resumed the old descriptor in `Retire`: it incremented `q0_.seqnum`, published completion, incremented `cl_cmd_slot_`, and returned to `Idle` (`sim/common/cmd_processor.cpp:618–623`). That path never reread the freed transfer staging. Fresh work could then proceed. The inherited test's seeded-output read specifically checks that the abandoned transfer was not replayed (`tests/runtime/test_ai_lifecycle.cpp:425–430`).

Thus the original behavior was recoverable synchronous **transfer-allocation failure**, with retirement needed only to dispose of its descriptor safely. It was not recovery of a failed asynchronous processor run. The new catch-all conflates these two fault origins by setting `AsyncRun::failed_` for both. Simply preserving the OOM numeric code while still setting that latch would not restore the required same-device continuation, and treating every `std::bad_alloc` as recoverable would also be unsafe if it originated from the asynchronous processor future. This report makes no production-repair choice.

### Why this matters beyond a dormant test

The lifecycle executable is in the regular runtime test list and `run-simx` entry point (`tests/runtime/Makefile:25,46–62`). The P03 native runner explicitly builds it, runs it, and requires `P03_LIFECYCLE PASSED` (`ci/project/p03_execute.py:225–232`). The current completion workflow instead invokes the completion runner (`.github/workflows/p06-simulator-completion.yml:178–184`); the completion contract defines that native workload as the linked model unit plus public success regression (`docs/designs/simulator_completion_v1.md:160–170`). A future pass in that narrow completion workflow would not by itself resolve this lifecycle incompatibility.

### Do not conflate other queue-local failures with this conflict

The lifecycle test's null-unmap case also gets `VX_ERR_INVALID_VALUE`, consumes it with finish, and then expects a later write to succeed (`tests/runtime/test_ai_lifecycle.cpp:235–254`). That failure originates in a queue command before a terminal backend fault. Its recovery expectation is different from the CP-scratch exception above. The error number alone does not identify whether the backend's terminal latch has been set.

## 2. Failed events reach managed matmul without losing the error

The completion contract requires the existing adapter mapping, error-aware polling, retained event errors, and no backend recovery from queue finish (`docs/designs/simulator_completion_v1.md:75–89`). The serial contract independently requires recording the first non-timeout wait error before querying completion and retaining it after successful draining (`docs/designs/serial_matmul_workspace_v1.md:99–120`).

The inspected source follows that path:

| Boundary | Source behavior and citation |
|---|---|
| Backend → adapter → device | Nonzero HAL status maps to `VX_ERR_INVALID_VALUE`; device polling returns that error before trusting the sequence number. `sw/runtime/common/vortex2_internal.h:206–214`; `sw/runtime/common/device.cpp:776–787`. |
| Queue command → event | The worker carries a dependency or queue-local error forward, discards the command's captured work, retains the first queue error, then completes the event with that error. `sw/runtime/common/queue.cpp:112–153`. |
| Failed event | `Event::complete(error)` retains the error **and advances the counter to 1**. Repeated waits return the retained error. `get_value()` still supplies the counter through a successful API query. `sw/runtime/common/event.cpp:31–68,114–126`. |
| Matmul terminal observation | `wait()` records the non-timeout event result before `vx_event_get_value`, requires the final event's counter to reach 1, polls the accepted event prefix, then sets `complete = true`. `sw/runtime/ai/runtime.cpp:623–658`. |
| First-error retention | `remember` only changes a successful primary field. An earlier submit error therefore takes precedence over a later event error; an earlier event error survives later query/drain outcomes. `sw/runtime/ai/runtime.cpp:21–25,545–565,628–647`. |
| Output | Output becomes valid only after all work was submitted and the execution result is successful. Failed results return an empty output vector. `sw/runtime/ai/runtime.cpp:658–680`. |

For an otherwise successfully submitted matmul whose launch fails, the dependent read is skipped and receives the same error. The managed owner can therefore observe `primary = VX_ERR_INVALID_VALUE`, `cleanup = VX_SUCCESS`, and `complete = true` without claiming successful execution. The dependency chain is explicit for each upload, launch, and download (`sw/runtime/ai/runtime.cpp:335–345,387–424`). The same wait/close implementation serves both workspace policies; policy selection changes buffer ownership, not error observation (`sw/runtime/ai/runtime.cpp:359–375`).

A failed or below-target completion query still leaves completion false and retains ownership (`sw/runtime/ai/runtime.cpp:630–640`). A timeout does not cancel work or authorize release. This is the required conservative behavior, not a new recovery promise (`docs/designs/serial_matmul_workspace_v1.md:109–137`).

## 3. Cleanup remains reachable after a completed execution failure

`MatmulOperation::close()` calls `wait()` and releases resources when `complete` is true; it does **not** require `ok()` (`sw/runtime/ai/runtime.cpp:668–675`). Its release order is all events, the queue, then any per-operation buffers, followed by context detachment; the first cleanup error is retained and every later cleanup step is still attempted (`181–212`). A cleanup error also invalidates output and poisons the managed context reservation (`116–118,171–178`).

For the resident policy, operations borrow the context's buffers (`361–364`), and final context release frees resident buffers before kernel, module, and device (`121–144`). An operation that has become the final context owner performs that teardown during its own close (`204–205`). A separately retained owner can close once operations detach (`579–593`). Owner close while an operation still holds the context returns incomplete timeout rather than reclaiming live resources (`583–588`).

The queue releases command captures before signalling completion (`sw/runtime/common/queue.cpp:140–152`), and queue destruction joins its FIFO worker (`63–76`). Backend host-memory free does not consult the terminal execution latch (`sw/runtime/simx/vortex.cpp:127–136`; `sw/runtime/rtlsim/vortex.cpp:122–131`). Backend destruction joins the asynchronous execution before freeing remaining registered host regions (`sw/runtime/simx/vortex.cpp:56–62`; `sw/runtime/rtlsim/vortex.cpp:54–60`). Common device teardown continues to host-region release after its best-effort CP quiesce attempt (`sw/runtime/common/device.cpp:176–190,533–553`).

These are source-level ownership properties. They do not prove every underlying free succeeded: `Buffer::~Buffer` deliberately ignores `mem_free` errors (`sw/runtime/common/buffer.cpp:20–30`), `vx_buffer_release` reports success after refcount release (`178–181`), and common `host_free` ignores the backend free result (`sw/runtime/common/device.cpp:1142–1148`). The frozen serial contract explicitly limits poisoning to **observed** cleanup errors (`docs/designs/serial_matmul_workspace_v1.md:148–150`).

Healthy cleanup can return the operation lease even when the operation's primary execution result failed (`sw/runtime/ai/runtime.cpp:198–212`). A later managed submission may consequently reach the same device. That does not clear or certify the backend: every later guarded device transaction still fails once `AsyncRun` is terminal. The managed reservation's poison is for cleanup failure, not a duplicate of the backend execution latch (`sw/runtime/ai/runtime.cpp:53–69,515–523`).

## 4. Python and fixed-model consumers preserve error and ownership separately

The native binding serializes `validation`, `primary`, `cleanup`, and `complete` without replacing the native code (`python/native/module.cpp:283–292`). Native operation wait stores the managed result (`709–733`). Native operation close marks the owner closed and releases its lease based on `complete`, while retaining the failed status (`736–763`).

The Python wrapper then:

- Returns the failed `ExecutionStatus` from `wait()`; it does not automatically turn every native status into an exception (`python/vortex_ai/_api.py:617–631`).
- Makes `.ok` false for a nonzero primary, and `.raise_for_status(operation)` raises `BindingError(kind="native")` for `VX_ERR_INVALID_VALUE` (`74–81,114–125`). The public numeric code is `3`, distinct from timeout `7` (`sw/runtime/include/vortex2.h:142–146`).
- Keeps the terminal status across repeated close/wait calls and removes the operation from the pending registry when close is complete, even when unsuccessful (`python/vortex_ai/_api.py:622–646`; registry removal `571–574`).
- Rejects failed output before requesting native bytes, with the native layer independently checking complete/successful status and extent (`python/vortex_ai/_api.py:649–657`; `python/native/module.cpp:776–783`).
- Makes context-manager exit raise on failed close status while retaining the operation/session references on the error (`python/vortex_ai/_api.py:362–383`).

Session closure is a separate owner-cleanup result, not a replacement for the failed operation's status (`python/native/module.cpp:606–627`). Calling session close while a matmul still owns the context remains incomplete; closing the operation first makes context cleanup possible. The binding permanently poisons subsequent acquisition only for an observed cleanup error (`python/native/module.cpp:39–60,391–400`), in agreement with `docs/designs/python_binding_v1.md:149–161`.

The fixed-model consumer also merges the first primary/cleanup errors (`sw/runtime/ai/mlp_runtime.cpp:35–45`), terminates graph advancement when a matmul fails, avoids comparing or advancing failed output, and still releases a completed failed operation (`244–266,342–381`). Explicit model close continues to owner teardown after that release (`397–422`). Native/Python model-close paths again use completion to release the lease and unregister the owner (`python/native/module.cpp:934–964`; `python/vortex_ai/_api.py:719–739`).

The adjacent PyTorch adapter raises on any completed failed status or non-timeout error (`python/vortex_ai/torch_ops.py:142–148`). A wait failure occurs before its normal close step, but the exception path retains the operation/session and the pending registry prevents new calls until explicit closure (`123–135,243–245,306–313`). This is retained ownership, not silent success or automatic cancellation.

## 5. Queue finish is not backend recovery

No `vx_queue_finish` call exists in the inspected managed matmul/model code or copying Python implementation. They use operation events and explicit close. The common queue's finish sentinel consumes its own `async_error_` (`sw/runtime/common/queue.cpp:213–233`); it has no access to the backend `AsyncRun` latch.

The completion public host fixture explicitly checks the correct distinction: the first finish reports the error, a second sentinel can succeed, the old event still fails, a new same-queue command fails, and a launch on a new queue also fails before device destruction (`ci/project/fixtures/simulator_public_completion.cpp:216–250`). Its fresh context runs only after explicit closure of the old one (`248–251`). The native public-success regression's finish call is a success-path cleanup assertion, while its destructor continues releasing owned resources (`tests/regression/simx_completion/main.cpp:49–81`). Neither source establishes recovery of a failed live backend.

The CP-copy OOM lifecycle expectation in section 1 is the identified exception: that existing consumer assumes recovery for a fault now caught by the terminal backend guard. Other queue-local errors need not have that terminal provenance.

## 6. Evidence limits and coordinator next step

This audit establishes source compatibility of terminal failed-event cleanup in the managed and copying-binding owners. It does not establish native public-runtime fault qualification, installed Python fault qualification, successful native context recreation, physical recovery, or any new phase acceptance.

The public integration fixture builds the actual common runtime and backend sources against controlled `Processor`/memory headers (`ci/project/test_p06_simulator_public.py:133–178`), not the native processor. The compiled binding fault suite labels its DSOs host-only and states that it executes no SimX backend (`ci/project/test_p05_native_binding.py:2–9`). Its retained-primary/cleanup tests (`380–443`) and the workspace fake-backend edge checks (`ci/project/fixtures/p06_workspace_edge_test.cpp:417–485`) cannot be relabelled as one combined native simulator-to-Python failure result.

The completion contract and packet still record native execution as `not_run` pending hosted CI (`docs/designs/simulator_completion_v1.md:163–170`; `docs/project/evidence/p06-simulator-completion/README.md:12–24`). The task initially reported that workflow as queued; during this review the coordinator reported that it had started. This audit did not independently query or promote its live status. The coordinator stated that its first result will be retained as pre-repair evidence if necessary.

**Coordinator disposition:** the coordinator accepted the CP-copy OOM/lifecycle conflict as a release blocker to resolve without weakening the test, and will assign separate production-repair and host-regression agents. The original exception mapping and CP retirement sequence above were sent directly to the coordinator. This read-only review is complete; any repair needs separate review and evidence. A narrow completion-workflow pass would not erase this source conflict or qualify Python fault transport.
