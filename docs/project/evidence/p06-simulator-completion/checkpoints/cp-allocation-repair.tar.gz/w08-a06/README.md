# Independent CP error-boundary regression

## Result

PASS at `db5ebb3a16770004423f2456ec6d0caaa0aced6d` plus the production repair by agent w08_a05 and four new regression files by agent w08_a06. This is host integration with a controlled Processor and RAM; it is not native SimX or RTL execution and does not qualify a performance or phase gate.

The original `tests/runtime/test_ai_lifecycle.cpp` was compiled without edits. Its SHA-256 is `0e6efb5275c6e25f3991d7da789fa1a02b4eb204da7da37d7b4b3bb4491df7ae`. Four complete lifecycle executions passed: SimX and processor RTL adapters, each with direct RAM and LLC transfer routes. Each execution covered all three allocation stages (backend staging registration, Device staging registration, and actual CP copy-scratch allocation), original/dependent-event OOM, queue-finish error consumption, retained references and memory restoration, seeded destination inspection before recovery, and successful same-device write/read after failure. The inherited suite also exercised bounds, invalid waits, timeout ownership, failed dependencies, host/module OOM, scratch-pool OOM and 32 transfer/release cycles.

The terminal model-failure fixture passed 34 independent process cells: eight asynchronous run cells; 16 synchronous DCR read/write cells; eight synchronous LLC memory read/write cells; and two RTL drain cells. Each relevant backend/memory route was checked with both `std::bad_alloc` and a non-standard thrown value. These cases require INVALID_VALUE completion, repeated failed waits, event timeline completion, failed dependencies, queue-local error consumption without backend revival, and no further processor operations during later work or cleanup. RTL drain is exercised through a successful launch followed by the full flush required by the direct-RAM transfer route.

Five new unittest methods contain the 38 positive executable cells. The independently retained driver invoked those actual TestCase methods using `debug()` after their actual class setup; it also ran the historical negative controls. A later normal discovery run should include the same five methods.

## Negative control

Both backend source files and `async_run.h` were read directly from fixed commit `db5ebb3a16770004423f2456ec6d0caaa0aced6d` with `GIT_NO_REPLACE_OBJECTS=1`, retained under `db5-sources/`, and compiled against the exact same common runtime, actual command processor, shims and lifecycle executable. All four old-backend lifecycle cells failed at the expected `test_ai_lifecycle.cpp:415` OOM assertion after allocation stages 0 and 1 had already passed. Each was exit 1 with bounded-process reason `nonzero_exit` and complete process cleanup. No compiler error, timeout or unrelated assertion counts as the expected failure.

Positive lifecycle raw logs: `command-016.log` to `command-019.log`. Negative raw logs: `command-047.log`, `command-048.log`, `command-050.log`, `command-051.log`.

## Provenance and command

Executed from the repository root:

```sh
python3 -B /workspace/scratch/ea983fdea786/w08-a06/run.py > /workspace/scratch/ea983fdea786/w08-a06/run.log 2>&1
```

The driver retained all 51 bounded command records and logs: 47 passes and the four intended historical failures. End-to-end duration was 27.136 seconds. Every child used the existing host helper's 1 GiB RSS and free-disk limits; configure, compile and execution timeouts remained bounded. Build products were temporary and were removed by their owning TemporaryDirectory cleanup only after their hashes were retained. No native build or download was performed.

`report.json` binds 83 source files before and after and reports all hashes unchanged; full snapshots are under `sources/`. It records hashes of the fixed shared libraries and executables. `commands.json` records exact argv, restricted child environments, bounded-process outcomes and raw-log hashes. This is a reproducibility packet, not a fully hermetic toolchain image: compiler/system-header bodies and generated binary bytes are not retained. The parent clean-host receipt will provide the broader final-source/tool binding.

## Scope and file ownership

Only these four repository files were added:

- `ci/project/test_p06_simulator_error_boundary.py`
- `ci/project/fixtures/simulator_error_boundary.cpp`
- `ci/project/fixtures/simulator_error_boundary_control.h`
- `ci/project/fixtures/simulator_error_boundary_processor.h`

The new Python test reuses the existing public-fixture source list and RAM shim. It compiles the actual public dispatcher, common runtime, callbacks, backend and command processor. The inherited lifecycle source, production files, public ABI, acceptance metadata, baselines and thresholds were not changed by this agent. The production repair is independently owned and reviewed.

## Key digests

| File | SHA-256 |
| --- | --- |
| `run.py` | `4f128deb752d21cf719166d82f60c55beefd43ba5acba59ac3c1474ed8fe8b14` |
| `run.log` | `8801ca501e809ea7b0c9f25a3991178ecb926d13ab04796d40b41b7e0545e992` |
| `report.json` | `a616968af7432c10ed294c7a5569f7a2547120af7dc4e1d97b260c635a93ec84` |
| `commands.json` | `4b9edaab2f341ab3302e4f1235da4cd2d76914c683a75467e634d2b7fd51e2ab` |

## Remaining limits

Native processor success/fault qualification belongs to the dedicated native runner. These injected host tests do not establish native public-runtime fault qualification, RTL datapath correctness, safe reuse of a failed processor, concurrent contexts, cancellation, or Python fault execution. They establish the intended exception-origin boundary and preserve the existing recoverable CP OOM behavior.
