import hashlib,json,os,shutil,subprocess,sys,time,traceback,unittest
from pathlib import Path
ROOT=Path('/workspace/scratch/ea983fdea786/AI-GPU')
EVIDENCE=Path('/workspace/scratch/ea983fdea786/w08-a06')
sys.path.insert(0,str(ROOT/'ci/project'))
import tensor_host_tools
original=tensor_host_tools.run_bounded
commands=[]
def recorded(*args,**kwargs):
    result=original(*args,**kwargs)
    path=Path(args[3])
    name='command-%03d.log' % (len(commands)+1)
    target=EVIDENCE/name
    if path.exists(): shutil.copyfile(path,target)
    commands.append({'argv':args[0],'cwd':str(args[1]),'env':args[2],'result':result,'log':name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest() if target.exists() else None})
    (EVIDENCE/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    return result
tensor_host_tools.run_bounded=recorded
import test_p06_simulator_error_boundary as module
cls=module.SimulatorErrorBoundaryTests
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'scope':'host-controlled-model; actual unchanged lifecycle and common runtime/CP/backends','tests':[],'negative_controls':[]}
started=time.monotonic()
try:
    cls.setUpClass()
    report['sources']={str(p.relative_to(ROOT)):d for p,d in cls.identities.items()}
    for path in cls.identities:
        dest=EVIDENCE/'sources'/path.relative_to(ROOT)
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(path.read_bytes())
    for name in unittest.defaultTestLoader.getTestCaseNames(cls):
        print(name,flush=True)
        try:
            cls(name).debug()
            report['tests'].append({'name':name,'outcome':'pass'})
        except BaseException as error:
            report['tests'].append({'name':name,'outcome':'fail','reason':str(error),'traceback':traceback.format_exc()})
            traceback.print_exc()
    negative=cls.build/'db5-negative'
    negative.mkdir()
    original_sha='db5ebb3a16770004423f2456ec6d0caaa0aced6d'
    for relative in ('sw/runtime/common/async_run.h','sw/runtime/simx/vortex.cpp','sw/runtime/rtlsim/vortex.cpp'):
        data=subprocess.check_output(['git','show',original_sha+':'+relative],cwd=ROOT,env={**os.environ,'GIT_NO_REPLACE_OBJECTS':'1'})
        dest=negative/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
        archived=EVIDENCE/'db5-sources'/relative
        archived.parent.mkdir(parents=True,exist_ok=True)
        archived.write_bytes(data)
    fixed_commands=list(commands)
    for backend in ('simx','rtlsim'):
        source=str(ROOT/'sw/runtime'/backend/'vortex.cpp')
        command=next(c['argv'] for c in fixed_commands if source in c['argv'])
        replaced=[str(negative/'sw/runtime'/backend/'vortex.cpp') if item==source else str(negative/('libvortex-'+backend+'.so')) if item==str(cls.build/('libvortex-'+backend+'.so')) else item for item in command]
        replaced[1:1]=['-I',str(negative/'sw/runtime/common')]
        tensor_host_tools.run_host_command(replaced,cwd=cls.build,env=cls.environment,timeout=60)
        for memory in ('ram','llc'):
            before=len(commands)
            try:
                output=tensor_host_tools.run_host_command([str(cls.lifecycle)],cwd=cls.build,env={**cls.environment,'LD_LIBRARY_PATH':str(negative)+':'+str(cls.build),'VORTEX_DRIVER':backend,'SIMULATOR_ERROR_MEMORY':memory},timeout=30)
                report['negative_controls'].append({'backend':backend,'memory':memory,'outcome':'unexpected_pass','output':output})
            except AssertionError as error:
                command_record=commands[-1]
                output=(EVIDENCE/command_record['log']).read_text()
                correct=(len(commands)==before+1 and command_record['result']['outcome']=='fail' and command_record['result']['reason']=='nonzero_exit' and command_record['result']['exit_code']==1 and command_record['result']['cleanup_complete'] and 'result == VX_ERR_OUT_OF_HOST_MEMORY' in output and '[OK] real DMA allocation stage 0' in output and '[OK] real DMA allocation stage 1' in output and '[OK] real DMA allocation stage 2' not in output)
                report['negative_controls'].append({'backend':backend,'memory':memory,'outcome':'expected_failure' if correct else 'wrong_failure','log':command_record['log'],'detail':str(error)})
    report['sources_after']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in cls.identities}
    report['source_stable']=report['sources']==report['sources_after']
    report['binary_sha256']={str(p.relative_to(cls.build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in cls.build.glob('*.so')}
    report['binary_sha256'].update({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (cls.lifecycle,cls.binary)})
except BaseException as error:
    report['setup_error']=str(error)
    report['traceback']=traceback.format_exc()
    traceback.print_exc()
finally:
    report['seconds']=time.monotonic()-started
    report['command_count']=len(commands)
    report['pass']=('setup_error' not in report and len(report['tests'])==5 and all(t['outcome']=='pass' for t in report['tests']) and len(report['negative_controls'])==4 and all(c['outcome']=='expected_failure' for c in report['negative_controls']) and report.get('source_stable',False))
    (EVIDENCE/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('sources','sources_after','traceback','binary_sha256')},indent=2),flush=True)
    cls.doClassCleanups()
sys.exit(0 if report['pass'] else 1)
