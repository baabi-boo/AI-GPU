"""Tiny host-preprocessor reproduction; no GPU compilation or execution."""

import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess

import p06_simulator_execute as runner
from test_p06_simulator_runner_failures import HostFixture


evidence = Path(__file__).resolve().parent
cpp = shutil.which("g++")
assert cpp, "host g++ is required for this reproduction"
observations = []
for issue in ("fast_math", "include_shadow"):
    with HostFixture() as fixture:
        fixture.build.mkdir(parents=True)
        fixture.configure()
        (fixture.build / "sw/VX_config.h").write_text("#define VX_CFG_NUM_THREADS 4\n")
        probe = fixture.build / "probe.cpp"
        probe.write_text("#include <VX_config.h>\n")
        if issue == "fast_math":
            fixture.alter_role(0, 0, lambda text: text.replace("-O2", "-Ofast"))
        else:
            shadow = fixture.paths["source"].parent / "unretained-headers"
            shadow.mkdir()
            (shadow / "VX_config.h").write_text("#define VX_CFG_NUM_THREADS 8\n")
            fixture.alter_role(0, 0, lambda text: "-I" + str(shadow) + " " + text)
        fixture.compile()
        role = runner.validate_compiler_records(fixture.build, fixture.configs)[0]
        suffix = ["-I" + str(fixture.build / "sw"), "-E", "-dM", "-x", "c++", str(probe)]
        row = {"issue": issue, "compiler_record_accepted": True, "original_record": fixture.stamps[0],
               "record_macro_flags": role["macro_flags"], "commands": {}}
        for mode, flags in (("original", shlex.split(fixture.stamps[0])), ("runner_probe", role["macro_flags"])):
            argv = [cpp, *flags, *suffix]
            result = subprocess.run(argv, text=True, capture_output=True, timeout=10)
            assert result.returncode == 0, result.stderr
            logfile = evidence / (issue + "-" + mode + ".macros.log")
            logfile.write_text(result.stdout)
            row["commands"][mode] = {"argv": argv, "exit_code": result.returncode, "log": str(logfile),
                                      "sha256": hashlib.sha256(result.stdout.encode()).hexdigest(),
                                      "stderr": result.stderr}
            row[mode] = [line for line in result.stdout.splitlines() if line.startswith(
                ("#define __FAST_MATH__ ", "#define VX_CFG_NUM_THREADS "))]
        observations.append(row)
        print(json.dumps({key: row[key] for key in ("issue", "compiler_record_accepted", "original", "runner_probe")}))

result = {"scope": "Host preprocessor only; no GPU compilation or execution",
          "runner_sha256": hashlib.sha256(Path(runner.__file__).read_bytes()).hexdigest(),
          "host_compiler": runner.base._file_identity(cpp), "observations": observations}
(evidence / "preprocessor-probe.json").write_text(json.dumps(result, indent=2) + "\n")
