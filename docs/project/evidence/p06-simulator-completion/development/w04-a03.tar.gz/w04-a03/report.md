# Wave 4 agent 3: successful ready check before first busy observation

## Result

The F1 helper-fixture coverage gap is closed. The added Linux case reaches the
real `AsyncRun::check()` success-consumption branch before the first `busy()`
observation. It then requires `busy()` to return true, false, false.

Only these repository files were edited:

- `ci/project/fixtures/simulator_async_run_test.cpp`
- `ci/project/test_p06_simulator_async_run.py`

Production code and APIs were unchanged. No commit, push, download, GPU build,
native processor execution, or acceptance-gate change was performed.

## Deterministic readiness witness

The new `immediate_check` group starts its controlled task through the production
owner, which uses real `std::async(std::launch::async, ...)`. The task publishes
its Linux worker TID through a separate promise and waits on the existing gate.
The fixture verifies that the TID differs from the observing thread and that
`/proc/self/task/<tid>` exists while the task is held. A nonblocking `check()`
while the gate remains closed exercises the pending path without observing busy.

After releasing the gate, the fixture uses a five-second deadline and
`std::this_thread::yield()` to wait for that exact task entry to disappear. It
requires `ENOENT`, rechecks that the parent procfs task directory still exists,
and requires the controlled task's completion flag. User-space task execution
and the async shared-state completion have finished before the Linux worker
exits. Therefore the next production `check()` sees the successfully ready
future, rather than racing an early task-return signal. No `AsyncRun::wait()`,
`wait_for()`, `join()`, or `busy()` occurs between start and that consuming check.
The separate promise's `get()` retrieves only the worker ID and cannot consume
the owner's future.

A task-body promise or a task-complete atomic alone would be insufficient: it
can become visible before the async implementation finishes making its future
ready. The explicit worker-exit observation avoids that boundary without a
production seam, a fake future, sleeps, or repeated lucky scheduling.

The case is compiled under `__linux__`; the Python test explicitly skips it on
non-Linux platforms. On Linux, missing or inaccessible procfs is a test failure,
not a skip or fallback. This evidence is scoped to the Linux host fixture.

## Verification

Source root:
`/workspace/scratch/ea983fdea786/AI-GPU`

Base HEAD: `42809ff0c1b81384d7c9b079e4ef786be8407600` with the existing shared
worktree changes. The complete status is retained in `status.log`.

Compiler: `/usr/bin/c++`, Debian GCC 14.2.0-19. Both production-header and
mutant-header fixture builds used C++17, `-O1 -g0 -Wall -Wextra -Werror`, UBSan
with recovery disabled, and `-pthread`.

| Check | Result | Raw record |
|---|---|---|
| `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s ci/project -p test_p06_simulator_async_run.py -v` | 8 tests passed, zero failures/errors/skips, 4.109 seconds | `helper-tests.log` |
| Production-header `immediate_check` | PASS, exit 0 | `current-immediate_check.log` |
| Targeted mutant compile | PASS, exit 0 | `compile-mutant.log` |
| All seven pre-existing groups against the targeted mutant | All PASS, exit 0 | `mutant-immediate_wait.log`, `mutant-immediate_bounded.log`, `mutant-pending.log`, `mutant-exceptions.log`, `mutant-overlap_pending.log`, `mutant-overlap_edge.log`, `mutant-failed_cleanup.log` |
| New `immediate_check` against the targeted mutant | Expected behavioral assertion failure, exit 1 | `mutant-immediate_check.log` |

The scratch mutation adds exactly `start_pending_ = false;` immediately after
`collect()` returns successfully inside `check()`. It does not affect the
pending branch or exception path. The new group's observed failure was:

```text
FAIL simulator-async-run immediate_check: completed task lost its initial busy observation
```

This is an assertion failure from a successfully compiled and executed fixture,
not a compile failure or timeout. All seven older groups still passing against
the same mutant demonstrates that the added group distinguishes the previously
uncovered successful ready-check path.

The retained `mutation_probe.py` reproduces the scratch comparison without
editing any repository source. `probe.json` records every invocation, timeout,
exit code, environment, source hash, and raw-log filename. Original source
snapshots are under `source/`; the mutated header is under `mutant/`; both tested
binaries and `successful-check-mutation.diff` are retained beside this report.
The probe verifies that all recorded repository source hashes remain unchanged
through its runs.

## Source identities

| Source | SHA-256 |
|---|---|
| C++ fixture | `cde9dcbb005cef22f0f7a239f70645ea0fa94527fe155aa15a332ccec05a0f2c` |
| Python test wrapper | `08ccaf6821ca73fd51fa24e7f319d0467921c96d19c6a331bba88d0140867295` |
| Production AsyncRun header | `17e229eb116c6d50d273780bb969630d0e0141a8aec39f22c0ab0fb62b74d2ed` |
| Scratch mutated AsyncRun header | `21697cb0f1d7df67e1e33cdf5bfec548bab35cfdd4cda61833f9b330096237bf` |

This closes the bounded F1 helper test gap. It supplies no native GPU, public
runtime, physical hardware, or performance qualification. The two owned files
are released for the parent's checkpoint and independent review.
