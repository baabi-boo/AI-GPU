#!/usr/bin/env python3
"""Retain a focused host-only mutation probe without editing production sources."""

import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


ROOT = Path("/workspace/scratch/ea983fdea786/AI-GPU")
OUT = Path(__file__).resolve().parent
SOURCE = OUT / "source"
MUTANT = OUT / "mutant"
SOURCE.mkdir(exist_ok=True)
MUTANT.mkdir(exist_ok=True)

paths = (
    "ci/project/fixtures/simulator_async_run_test.cpp",
    "ci/project/test_p06_simulator_async_run.py",
    "sw/runtime/common/async_run.h",
    "ci/project/tensor_host_tools.py",
    "ci/project/baseline_process.py",
    "docs/designs/simulator_completion_v1.md",
)
identities = {}
for relative in paths:
    origin = ROOT / relative
    destination = SOURCE / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(origin, destination)
    identities[relative] = hashlib.sha256(origin.read_bytes()).hexdigest()

environment = {
    "PATH": os.environ.get("PATH", os.defpath),
    "LC_ALL": "C",
    "TMPDIR": str(OUT),
    "UBSAN_OPTIONS": "halt_on_error=1:print_stacktrace=1",
    "PYTHONDONTWRITEBYTECODE": "1",
}
records = []


def run(name, argv, expected_code=0, expected_output=None, timeout=15):
    result = subprocess.run(argv, cwd=OUT, env=environment, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=timeout, check=False)
    (OUT / (name + ".log")).write_text(result.stdout)
    records.append({"name": name, "argv": [str(arg) for arg in argv],
                    "cwd": str(OUT), "timeout_seconds": timeout,
                    "exit_code": result.returncode, "expected_code": expected_code,
                    "log": name + ".log"})
    assert result.returncode == expected_code, (name, result.returncode, result.stdout)
    if expected_output is not None:
        assert expected_output in result.stdout, (name, result.stdout)
    return result.stdout


compiler = shutil.which("c++") or shutil.which("g++") or shutil.which("clang++")
assert compiler is not None
run("compiler", [compiler, "--version"])
run("host", ["uname", "-a"])
head = run("head", ["git", "-C", str(ROOT), "rev-parse", "HEAD"]).strip()
run("status", ["git", "-C", str(ROOT), "status", "--short"])
run("resources", ["df", "-B1", str(OUT)])

header = SOURCE / "sw/runtime/common/async_run.h"
original = header.read_text()
before = """  void check() {
    require_healthy();
    if (future_.valid()
     && future_.wait_for(std::chrono::seconds(0)) == std::future_status::ready) {
      collect();
    }
  }
"""
after = before.replace("      collect();\n", "      collect();\n      start_pending_ = false;\n")
assert original.count(before) == 1
mutated = original.replace(before, after)
(MUTANT / "async_run.h").write_text(mutated)
(OUT / "successful-check-mutation.diff").write_text("".join(difflib.unified_diff(
    original.splitlines(keepends=True), mutated.splitlines(keepends=True),
    fromfile="production/async_run.h", tofile="mutant/async_run.h")))

flags = [compiler, "-std=c++17", "-O1", "-g0", "-Wall", "-Wextra", "-Werror",
         "-fsanitize=undefined", "-fno-sanitize-recover=undefined", "-pthread"]
fixture = SOURCE / "ci/project/fixtures/simulator_async_run_test.cpp"
for variant, include in (("current", header.parent), ("mutant", MUTANT)):
    binary = OUT / ("simulator-async-run-" + variant)
    run("compile-" + variant,
        flags + ["-I", str(include), str(fixture), "-o", str(binary)], timeout=60)
    if variant == "current":
        run("current-immediate_check", [str(binary), "immediate_check"],
            expected_output="PASS simulator-async-run immediate_check checks=")
    else:
        for group in ("immediate_wait", "immediate_bounded", "pending", "exceptions",
                      "overlap_pending", "overlap_edge", "failed_cleanup"):
            run("mutant-" + group, [str(binary), group],
                expected_output="PASS simulator-async-run " + group + " checks=")
        run("mutant-immediate_check", [str(binary), "immediate_check"], expected_code=1,
            expected_output="FAIL simulator-async-run immediate_check: "
                            "completed task lost its initial busy observation\n")

for relative, digest in identities.items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == digest, relative

(OUT / "probe.json").write_text(json.dumps({
    "head": head,
    "scope": "host C++ AsyncRun fixture; Linux procfs readiness witness; no native GPU execution",
    "environment": environment,
    "source_sha256": identities,
    "mutant_sha256": hashlib.sha256((MUTANT / "async_run.h").read_bytes()).hexdigest(),
    "commands": records,
    "outcome": "pass; current ready-check case succeeds and targeted mutation fails its busy-edge assertion",
}, indent=2) + "\n")
print("Current ready-check case: PASS")
print("Mutation controls: all seven pre-existing groups PASS")
print("Mutation ready-check case: expected assertion failure, exit 1")
print("Production sources unchanged during probe")
