# Simulator completion contract v1

## Scope and execution routes

This contract defines host completion for the [SimX backend](../../sw/runtime/simx/vortex.cpp)
and [processor RTL simulation backend](../../sw/runtime/rtlsim/vortex.cpp).
Both use the runtime-internal [AsyncRun owner](../../sw/runtime/common/async_run.h)
with the existing functional [CommandProcessor](../../sim/common/cmd_processor.cpp).
The [development audit](../project/p06-simulator-completion-audit.md) records why
this prerequisite precedes counter qualification. This document specifies
behavior and evidence obligations; it does not certify that a test ran.

| Route | Normal completion | Execution failure |
|---|---|---|
| SimX runtime | `Processor::run_checked()` finishes the existing model run and ignores its legacy register-derived return | A model exception propagates into the asynchronous future |
| Processor RTL runtime | Its existing `void Processor::run()` returns normally | A C++ exception propagates into the asynchronous future |
| Legacy direct SimX caller | Existing `Processor::run()` behavior is retained | Its existing catch/log/`-1` behavior is retained |

SimX's legacy integer result reads architectural x3 (`gp`) through
[Operands::get_exit_code](../../sim/simx/operands.cpp). Kernel startup can use
that register as a legitimate global-data pointer. A nonzero value, including
the integer value `-1`, is therefore not an asynchronous execution error by
itself. The [checked entry](../../sim/simx/processor.cpp) separates exception
propagation from that legacy result without changing the model's run loop.
Processor RTL's void return does not add kernel exit-code reporting.

## Ownership and launch ordering

Host control of one completion owner is serial. The existing common runtime
serializes its CP register callbacks; the worker executes the processor task
asynchronously. `AsyncRun` adds no lock for concurrent callers, no independent
device-context scheduling, and no permission to overlap managed operations.
The [serial workspace ownership contract](serial_matmul_workspace_v1.md) and
SimX's process-wide state restrictions remain applicable.

The future, the unobserved launch edge and terminal failure are separate state.

| Observation or action | Required behavior |
|---|---|
| Start while healthy and idle | Own one asynchronous task and retain an unobserved launch edge |
| Start while a future or launch edge is still pending | Reject the overlapping launch and retain terminal failure |
| First busy observation after a successful start | Return busy once, even if normal completion was already consumed |
| Later busy observation while the task is pending | Return busy |
| Later observation after normal completion | Consume the future with `get()` before returning idle |
| Observation of an exceptional future | Consume it, retain terminal failure and propagate the exception to the guarded callback |
| Operation after terminal failure | Reject further execution; no reset of the completion owner is provided |

The command processor requires busy to rise before falling. A successful task
that finishes before its first poll must still satisfy that sequence. A
nonblocking check, a blocking wait or SimX's bounded polling wait may consume a
normal future without erasing the unobserved launch edge. A task exception must
be observed before the busy hook permits successful launch completion.

## Failure visibility and retained state

Each backend checks completion around CP register transactions. DCR and
last-level-cache memory hooks wait for and consume pending execution before
touching processor state; processor RTL's drain hook does the same. Both CP
register callbacks catch exceptions from their guarded transaction, latch
terminal failure, and return the existing nonzero HAL error. Async task creation
failure takes this path too.

The failing launch must not retire successfully or permit later work in the
same serial CP burst. Later CP reads and writes remain rejected for that backend
device's lifetime. A failed read must not publish its output as a successful
register observation. This provides no rollback of commands or memory writes
that completed before the failure.

The existing [CallbacksAdapter](../../sw/runtime/common/vortex2_internal.h)
maps a nonzero HAL result to `VX_ERR_INVALID_VALUE`.
[Device::cp_poll_seqnum_](../../sw/runtime/common/device.cpp) checks that result
before accepting the completion sequence number. The existing
[queue](../../sw/runtime/common/queue.cpp) and
[event](../../sw/runtime/common/event.cpp) error paths must carry the failure to
public waits and retain the event's error on repeated observations. This
contract adds no public error code, callback member or on-wire status.

Consuming a queue-local error with `vx_queue_finish` does not clear the backend
failure. A subsequent command using that device must still fail at the backend
boundary. Successful cleanup or a completed future does not authorize reuse of
the failed simulator state. A new device instance owns a new completion owner;
any claim that recreation succeeds must be demonstrated within the separately
declared simulator/context scope.

## Destruction and limits

Destruction joins outstanding execution before freeing registered host memory
or destroying the processor and RAM. The cleanup join consumes the future
without allowing an exception to escape destruction. Host-memory release remains
available after terminal failure; a successful release is a cleanup result, not
evidence that the earlier task succeeded.

A host wait timeout does not cancel, detach or safely reclaim an executing
worker. A worker that never finishes can still block destruction. Safe forced
cancellation, recovery of a failed context, simultaneous callers, signals,
process termination and Verilator fatal aborts are outside this contract.
Only C++ exceptions reaching the future can be consumed by this mechanism.

## Required verification

Independent review must check each production hunk and the evidence scope under
the [review policy](../review/code-review-policy.md). Retain exact source/build
identities, commands, raw outcomes and failed attempts. A built parent that fails
the intended behavioral assertion establishes sensitivity; a compile failure or
timeout does not substitute for it.

| Evidence | Required observations | Scope limit |
|---|---|---|
| [Actual backend and CP host fixture](../../ci/project/test_p06_simulator_completion.py) | Both backends; pending and serial success; standard and unknown exceptions; failure before retirement; suppressed later work; sticky reads/writes; RAM/LLC and drain synchronization; join before release | Controlled Processor/RAM faults establish host transport behavior, not native processor arithmetic or an RTL fault mechanism |
| Deterministic immediate-completion fixture | Complete the task before the first busy observation; preserve busy then idle after each supported success-consumption path; reject exceptions and overlapping starts without losing failure | A helper or scripted-CP test must disclose its seam; sleeps or repeated lucky scheduling do not prove the boundary |
| Public runtime failure integration | Actual callback adapter, device polling, queue worker and event paths; repeated waits retain failure; consuming queue error does not rehabilitate the backend; cleanup stays usable | Source inspection and direct HAL tests alone do not establish the whole public error path |
| [Linked native SimX unit](../../tests/unittest/simx_completion/main.cpp) | Real `Processor`/RAM; normal x3 values `7` and `-1`; unchanged legacy behavior; a bounded-RAM `OutOfRange` exception reaches asynchronous `get()`; a fresh normal context follows | Directed native model evidence does not establish a native public-runtime failure or physical-device recovery |
| [Native public success regression](../../tests/regression/simx_completion/main.cpp) | Real generated kernel and runtime; global-data access with nonzero low `gp`; exact output checks; repeated serial launches, event waits, cleanup and context recreation | Positive native execution does not replace fault-path evidence |

Native tests run from fresh configured build trees with identified tools and
unchanged resource limits. The additive [completion build fragment](../../sim/simx/completion.mk)
keeps the accepted SimX Makefile intact. Changed helper bytes must cause both
backend shared libraries to rebuild. Unsupported or unexecuted configurations
remain explicitly unqualified.

## Preserved qualification boundaries

This contract changes host completion bookkeeping and failure visibility. It
does not change the processor run loop, pipeline, arithmetic, ISA, counter
widths, public ABI, sampling rules or performance thresholds. Host wall-time
effects are not a simulated-cycle or performance improvement claim.

The [warm v1 contract](warm_workspace_benchmark_v1.md) remains blocked with
`qualified=false` and no established absolute cumulative no-wrap bound.
The [counter qualification plan](../project/p06-mpm-qualification-plan.md) still
requires exact route/selector coverage, coherent reads and independently
reviewed lifetime bounds before a fresh performance qualification. P06-A02/A03,
vendor P01-A03, framework acceptance, inherited DSP-area failures and physical
FPGA/silicon obligations are not closed by this completion repair.
