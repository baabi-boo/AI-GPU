# Timed platform teardown accounting

## Result and ownership

Changed only `AI-GPU/sim/common/simobject.h` in the shared repository. The change adds a relaxed atomic store of zero to `SimChannelBase::inflight_count()` at the end of `SimPlatform::cleanup()`, immediately after cross-domain inbox disposal and `cross_pending_ = 0`. The comment explains why retained shared owners do not defer the context-wide accounting release.

No send/pop operation, reset, launch reset, tick, event delivery, cycle advancement, queue depth, or packet flow changed. No test was weakened. No commit, push, native GPU build, or download occurred. The complete before/after headers and the three-line patch are retained beside this report.

## Lifecycle audit and root cause

`create_object()` registers a shared owner in the singleton platform; the `ProcessorImpl` also retains shared owners for its topology. Channels are value members of simulation objects. Their base constructor registers a raw pointer for topology validation, while the base destructor only unregisters that pointer.

A local send recursively reserves the terminal endpoint, increasing its pending count and the process-global in-flight count. It then schedules a channel event. Delivery decreases the endpoint pending count and constructs the queued packet; the global count remains until normal `SimChannel::queue_pop()`. Cross-domain sends have a separate cross-inbox count until they are reissued at their endpoint. `idle()` tests both counts.

A model exception before consuming a queued request leaves the global count nonzero. Destruction of a channel's `RingQueue` destroys packet values through `RingQueue::pop()`; it does not call `SimChannel::queue_pop()` and therefore does not decrement the framework count. Destruction of an un-fired channel event similarly does not unwind its reservation. The count consequently survived destruction of the entire prior context, and a new context could never become idle even after consuming all of its own work.

Cleanup already establishes the whole-context boundary: it joins parked workers, clears active-reset registrations and platform object ownership, destroys every scheduled and immediate event, clears domains and cross-domain inboxes, and resets the executor's topology state. The added store occurs only after those steps. It retires abandoned accounting for the finalized singleton context; it does not report the failed live context as successfully drained.

`ProcessorImpl::~ProcessorImpl()` calls `finalize()` in its destructor body, before shared-pointer members are destroyed. Some channels therefore remain physically alive after platform cleanup. The existing teardown already makes those objects unusable: their platform scan lists, events, execution domains, and potentially bound peers have been removed. Retained owners are destruction-only after finalization. A new supported context is created after prior destruction finishes, under the existing one-live-context contract. This repair does not authorize old-channel pop/send, reuse of a failed context, or simultaneous contexts.

Per-channel destruction subtraction was deliberately avoided. A late channel destructor must not subtract an old context's occupancy from the newly cleared global total. The existing destructor continues to unregister and destroy storage only, so releasing retained shared owners cannot double-decrement. A global cleanup boundary also covers exceptional sends/deliveries that can leave reservation accounting without a fully materialized queue item. No per-channel accounting or per-packet runtime cost was added.

`reset()` and `reset_launch()` are unchanged. Full reset retains its existing quiescence requirement, and launch reset continues to preserve the designated memory-side in-flight work. Neither reset becomes an escape hatch from an active or failed context.

## Behavioral proof

The probe is the actual-header reproduction from `w04-a04-native-probe/abandoned_channel.cpp`, with its final expected count changed from one (confirm the defect) to zero (require recovery). It creates an actual `SimObject` with an actual `SimChannel`, sends a packet, throws from the model tick before pop, finalizes before releasing the external shared owner, then creates a new context that consumes another packet. There is no stubbed simulator header, manual global-count write, timeout-as-success, or post-finalize old-channel operation.

The unmodified timed header at repository HEAD compiled successfully. That binary failed the intended recovery assertion with exit 1:

```
after_exception inflight=1 idle=0 queued=1
after_full_destruction inflight=1 idle=0
fresh_context_after_consumption inflight=1 idle=0 queued=0
```

The patched timed header compiled with `-Wall -Wextra -Wfatal-errors -Werror` in both release (`-O2 -DNDEBUG`) and debug (`-O0 -g`) modes. Both binaries passed with exit 0:

```
after_exception inflight=1 idle=0 queued=1
after_full_destruction inflight=0 idle=1
fresh_context_after_consumption inflight=0 idle=1 queued=0
```

The failing live context still reports outstanding work, as required. Only finalization retires its abandoned state. The late owner release and fresh-context pop produce neither underflow nor residual count.

Both repository boundary guards passed: `ci/check_simx_mt_boundary.sh` and `ci/check_sw_sim_boundary.sh`. The scoped `git diff --check -- sim/common/simobject.h` also passed. Exact argument vectors, working directories, controlled environment, exit codes, and log hashes are in `commands.json`. `report.json` binds the before/after headers, fixture, patch, tool version, and available transitive header hashes.

## Evidence scope and remaining work

This is actual timed-framework C++ host evidence, not native `Processor`/RAM execution or public-runtime fault evidence. Builds ran in the owned `w05-a01/build` scratch directory and include only framework/shared headers; no generated GPU build tree was reused. The linked native bounded-RAM completion unit and model-parity/performance workloads were not run here. The source change has no normal run-loop or event-scheduling hunk, and makes no cycle or performance improvement claim.

Independent actual-framework regression coverage and review are assigned separately. The analogous functional-kernel cleanup is also assigned separately and is outside this file ownership.

Adjacent exception behavior is unchanged: a serial tick exception can leave its executing thread's `tl_exec_domain_` and `tl_cycles_` at the fault location, while exceptions on parallel workers require their own coordinated transport. The asynchronous backend's throwing task uses a worker whose thread-local state ends with that task, and teardown/fresh-context creation occur after joining it. This scoped counter repair does not qualify same-thread direct multi-domain recreation or parallel-worker exceptions. Such paths need separate evidence and, if required, a separately reviewed lifecycle change.

Next bounded investigation: create an actual domain-1 tick exception on a direct caller thread, fully destroy that context, then create a domain-0 context and inspect host cycle/send behavior on the same thread. Preserve that independent reproduction before considering an exception-safe execution-context guard. Coordinated MT worker failure transport remains a separate problem. Neither investigation changes the scope of the present teardown-count proof.
