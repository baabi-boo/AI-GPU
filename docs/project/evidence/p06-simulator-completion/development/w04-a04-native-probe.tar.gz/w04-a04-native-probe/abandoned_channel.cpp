#include "simobject.h"
#include <cstdio>
#include <stdexcept>

class Node : public vortex::SimObject<Node> {
public:
  vortex::SimChannel<int> input;
  bool should_throw;
  Node(const vortex::SimContext& context, const char* name, bool fault)
      : vortex::SimObject<Node>(context, name), input(this), should_throw(fault) {}
protected:
  void on_tick() {
    if (input.empty()) return;
    if (should_throw) throw std::runtime_error("fault before memory-request pop");
    input.pop();
  }
  friend class vortex::SimObject<Node>;
};

int main() {
  auto& platform = vortex::SimPlatform::instance();
  platform.initialize();
  platform.set_num_workers(1);
  auto failed = Node::Create("failed", true);
  platform.reset();
  failed->input.send(1, 0);
  try {
    platform.tick();
    return 2;
  } catch (const std::runtime_error&) {}
  std::printf("after_exception inflight=%llu idle=%d queued=%u\n",
      (unsigned long long)vortex::SimChannelBase::inflight_count().load(),
      platform.idle(), failed->input.size());
  // Match ProcessorImpl::~ProcessorImpl: finalize precedes member destruction.
  platform.finalize();
  failed.reset();
  std::printf("after_full_destruction inflight=%llu idle=%d\n",
      (unsigned long long)vortex::SimChannelBase::inflight_count().load(), platform.idle());
  platform.initialize();
  platform.set_num_workers(1);
  auto fresh = Node::Create("fresh", false);
  platform.reset();
  fresh->input.send(2, 0);
  for (int i = 0; i != 4; ++i) platform.tick();
  auto remaining = vortex::SimChannelBase::inflight_count().load();
  std::printf("fresh_context_after_consumption inflight=%llu idle=%d queued=%u\n",
      (unsigned long long)remaining, platform.idle(), fresh->input.size());
  platform.finalize();
  fresh.reset();
  return remaining == 1 ? 0 : 1;
}
