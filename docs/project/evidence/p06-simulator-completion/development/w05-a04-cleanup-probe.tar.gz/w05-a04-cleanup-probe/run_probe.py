import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/ea983fdea786/AI-GPU')
OUT = Path(__file__).resolve().parent
SOURCE = OUT / 'source'

files = ['sim/common/simobject.h', 'sim/common/simobject_functional.h']
files += [f'sw/common/{name}' for name in (
    'util.h', 'bitmanip.h', 'smallfunc.h', 'linked_list.h', 'ringqueue.h', 'mempool.h')]
hashes = {}
for name in files:
    destination = SOURCE / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, destination)
    hashes[name] = hashlib.sha256(destination.read_bytes()).hexdigest()

compiler = shutil.which('g++')
if not compiler:
    raise RuntimeError('g++ is required')
environment = {'PATH': os.environ.get('PATH', os.defpath), 'LC_ALL': 'C',
               'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}
commands = []

def run(name, argv, timeout):
    started = time.monotonic()
    result = subprocess.run(argv, cwd=OUT, env=environment, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=timeout)
    log = OUT / f'{name}.log'
    log.write_text(result.stdout)
    commands.append({'name': name, 'argv': argv, 'cwd': str(OUT),
                     'environment': environment, 'timeout_seconds': timeout,
                     'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started,
                     'log': log.name, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    (OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print(f'{name}: exit={result.returncode}', flush=True)
    if result.returncode:
        print(result.stdout, flush=True)
        raise RuntimeError(f'{name} failed')
    return result.stdout

run('compiler', [compiler, '--version'], 10)
for kernel in ('timing', 'functional'):
    for mode, flags in (('debug', ['-O1', '-g0', '-fsanitize=undefined', '-fno-sanitize-recover=undefined']),
                        ('release', ['-O2', '-DNDEBUG'])):
        label = f'{kernel}-{mode}'
        binary = OUT / label
        args = [compiler, '-std=c++17', '-Wall', '-Wextra', '-Werror', '-pthread', *flags]
        if kernel == 'functional':
            args.append('-DSIMX_FUNCTIONAL')
        args += ['-I', str(SOURCE / 'sim/common'), '-I', str(SOURCE / 'sw/common'),
                 str(OUT / 'lifecycle_probe.cpp'), '-o', str(binary)]
        run(f'{label}-compile', args, 45)
        output = run(f'{label}-run', [str(binary)], 15)
        if output != 'PASS lifecycle internal_workers=2 discarded_payloads=4 late_owners=2 fresh_consumed=1 fresh_idle=1\n':
            raise RuntimeError(f'{label} unexpected result')

current = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files}
if current != hashes:
    raise RuntimeError('reviewed source changed during probe')
summary = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_hashes': hashes, 'source_stable': True,
    'fixture_sha256': hashlib.sha256((OUT / 'lifecycle_probe.cpp').read_bytes()).hexdigest(),
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'commands_sha256': hashlib.sha256((OUT / 'commands.json').read_bytes()).hexdigest(),
    'scope': 'Host-only actual SimObject frameworks; healthy two-worker shutdown; abandoned events/inbox; no native Processor or GPU build; no internal-worker fault transport.',
    'cells_passed': 4,
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
