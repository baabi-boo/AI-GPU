#ifdef SIMX_FUNCTIONAL
#include <simobject_functional.h>
#else
#include <simobject.h>
#endif

#include <array>
#include <cstdio>
#include <future>
#include <memory>
#include <stdexcept>
#include <thread>

namespace {

void expect(bool condition, const char* message) {
  if (!condition) {
    throw std::runtime_error(message);
  }
}

struct Payload {};
using Packet = std::shared_ptr<Payload>;

struct Stats {
  unsigned ticks = 0;
  unsigned consumed = 0;
  unsigned messages = 0;
  unsigned destroyed = 0;
  std::thread::id tick_thread;
};

class Node : public vortex::SimObject<Node> {
public:
  vortex::SimChannel<Packet> input;
  vortex::SimEventLink<Packet> control;

  Node(const vortex::SimContext& context, const char* name, Stats& stats)
      : vortex::SimObject<Node>(context, name)
      , input(this, 4)
      , control(this)
      , stats_(stats) {
    control.bind(this, &Node::message);
  }

  ~Node() override {
    ++stats_.destroyed;
  }

protected:
  void on_tick() {
    ++stats_.ticks;
    stats_.tick_thread = std::this_thread::get_id();
    if (!input.empty()) {
      ++stats_.consumed;
      input.pop();
    }
  }

  friend class vortex::SimObject<Node>;

private:
  void message(const Packet&) {
    ++stats_.messages;
  }

  Stats& stats_;
};

uint64_t inflight() {
  return vortex::SimChannelBase::inflight_count().load();
}

void ticks(vortex::SimPlatform& platform, unsigned count) {
  auto future = std::async(std::launch::async, [&platform, count] {
    for (unsigned i = 0; i < count; ++i) {
      platform.tick();
    }
  });
  future.get();
}

void probe() {
  auto& platform = vortex::SimPlatform::instance();
  Stats left_stats;
  Stats right_stats;
  expect(platform.initialize(), "initialize failed");
  platform.set_num_workers(2);
  auto left = Node::Create("left", left_stats);
  Node::Ptr right;
  {
    vortex::SimPlatform::DomainScope scope(platform.alloc_domain());
    right = Node::Create("right", right_stats);
  }
  platform.reset();
  ticks(platform, 1);
  expect(left_stats.ticks == 1 && right_stats.ticks == 1,
         "both domains were not ticked");
  expect(left_stats.tick_thread != right_stats.tick_thread,
         "probe did not start the internal worker");
  expect(platform.idle() && inflight() == 0, "healthy workers did not park idle");

  std::array<std::weak_ptr<Payload>, 4> pending;
  {
    auto payload = std::make_shared<Payload>();
    pending[0] = payload;
    right->control.send(payload, 3);
  }
  expect(inflight() == 0 && !platform.idle(),
         "cross-inbox work did not independently block idle");
  {
    auto payload = std::make_shared<Payload>();
    pending[1] = payload;
    left->input.send(payload, 0);
  }
  {
    auto payload = std::make_shared<Payload>();
    pending[2] = payload;
    right->input.send(payload, 3);
  }
  unsigned callbacks = 0;
  {
    auto payload = std::make_shared<Payload>();
    pending[3] = payload;
    platform.schedule([&callbacks](const Packet&) { ++callbacks; }, payload, 3, 0);
  }
  expect(inflight() == 2 && !platform.idle(), "pending packet count mismatch");
  for (const auto& payload : pending) {
    expect(!payload.expired(), "pending payload was not retained");
  }

  platform.finalize();
  expect(inflight() == 0 && platform.idle(), "cleanup did not retire all work");
  for (const auto& payload : pending) {
    expect(payload.expired(), "cleanup retained an event or inbox payload");
  }
  expect(callbacks == 0 && right_stats.messages == 0,
         "cleanup invoked an abandoned callback");
  expect(left_stats.consumed == 0 && right_stats.consumed == 0,
         "cleanup executed abandoned channel work");
  expect(left_stats.destroyed == 0 && right_stats.destroyed == 0,
         "external owners did not survive finalization");

  Stats fresh_stats;
  expect(platform.initialize(), "fresh initialize failed");
  platform.set_num_workers(1);
  auto fresh = Node::Create("fresh", fresh_stats);
  platform.reset();
  fresh->input.send(std::make_shared<Payload>(), 1);
  expect(inflight() == 1 && !platform.idle(), "fresh reservation missing");
  left.reset();
  right.reset();
  expect(left_stats.destroyed == 1 && right_stats.destroyed == 1,
         "late owner destruction did not complete");
  expect(inflight() == 1 && !platform.idle(), "late owners changed fresh accounting");
  ticks(platform, 2);
  expect(fresh_stats.consumed == 1 && inflight() == 0 && platform.idle(),
         "fresh context failed to consume and become idle");
  expect(callbacks == 0 && right_stats.messages == 0,
         "abandoned callbacks reached the new context");
  platform.finalize();
  fresh.reset();
  platform.finalize();
  expect(fresh_stats.destroyed == 1 && inflight() == 0 && platform.idle(),
         "repeated finalization was not clean");
  std::printf("PASS lifecycle internal_workers=2 discarded_payloads=4 late_owners=2 fresh_consumed=1 fresh_idle=1\n");
}

} // namespace

int main() {
  try {
    probe();
    return 0;
  } catch (const std::exception& error) {
    std::fprintf(stderr, "FAIL lifecycle: %s\n", error.what());
    return 1;
  }
}
