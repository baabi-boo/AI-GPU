#!/usr/bin/env python3
"""Retain a frozen actual-header host probe; no GPU build or qualification."""

import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/workspace/scratch/ea983fdea786/AI-GPU")
PACKET = pathlib.Path(__file__).resolve().parent
STAGE = sys.argv[1]
assert STAGE in ("before", "after")
DEST = PACKET / STAGE
DEST.mkdir(exist_ok=False)
FILES = [
    "sim/common/simobject_functional.h",
    "sw/common/linked_list.h",
    "sw/common/mempool.h",
    "sw/common/util.h",
    "sw/common/smallfunc.h",
    "sw/common/bitmanip.h",
]
ENV = {"PATH": "/usr/bin:/bin", "LC_ALL": "C"}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = {
    "scope": "actual functional SimObject header, serial host framework only",
    "not_qualified": [
        "native functional Processor execution",
        "parallel worker exception handling",
        "failed-context reuse",
        "concurrent native contexts",
        "native GPU, RTL, performance, or physical hardware",
    ],
    "stage": STAGE,
    "recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "state": "uncommitted working tree; exact local dependencies frozen and hashed",
    "sources": [],
    "commands": [],
}
for name in FILES:
    destination = DEST / "source" / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, destination)
    manifest["sources"].append({"path": name, "sha256": sha256(destination)})
for name in ("functional_cleanup_probe.cpp", "run_probe.py"):
    shutil.copyfile(PACKET / name, DEST / name)
    manifest["sources"].append({"path": name, "sha256": sha256(DEST / name)})


def run(name, argv, timeout):
    started = time.monotonic()
    result = subprocess.run(argv, cwd=DEST, env=ENV, capture_output=True, text=True, timeout=timeout)
    log = DEST / (name + ".log")
    log.write_text(result.stdout + result.stderr)
    manifest["commands"].append({
        "name": name,
        "argv": argv,
        "cwd": str(DEST),
        "environment": ENV,
        "exit_code": result.returncode,
        "duration_seconds": round(time.monotonic() - started, 6),
        "log": log.name,
        "log_sha256": sha256(log),
    })
    (DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"{name}: exit={result.returncode}")
    print(log.read_text(), end="")
    return result.returncode


run("compiler", ["/usr/bin/c++", "--version"], 5)
for mode, flags in (("release", ["-O2", "-DNDEBUG"]), ("debug", ["-O0", "-g"])):
    binary = DEST / ("functional_cleanup_" + mode)
    argv = [
        "/usr/bin/c++", "-std=c++17", "-Wall", "-Wextra", "-Wfatal-errors", "-Werror",
        *flags,
        "-I" + str(DEST / "source/sim/common"),
        "-I" + str(DEST / "source/sw/common"),
        str(DEST / "functional_cleanup_probe.cpp"), "-pthread", "-o", str(binary),
    ]
    if run(mode + "-compile", argv, 60) != 0:
        sys.exit(2)
    manifest.setdefault("binaries", []).append({"path": binary.name, "sha256": sha256(binary)})
    run(mode + "-run", [str(binary)], 10)
