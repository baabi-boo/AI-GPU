#include "simobject_functional.h"

#include <cstdio>
#include <future>
#include <stdexcept>

class Node : public vortex::SimObject<Node> {
public:
  vortex::SimChannel<int> input;
  uint32_t consumed = 0;

  Node(const vortex::SimContext& context, const char* name, bool fault)
      : vortex::SimObject<Node>(context, name)
      , input(this)
      , fault_(fault) {}

protected:
  void on_tick() {
    if (input.empty()) {
      return;
    }
    if (fault_) {
      throw std::runtime_error("fault before input pop");
    }
    input.pop();
    ++consumed;
  }

private:
  bool fault_;
  friend class vortex::SimObject<Node>;
};

int main() {
  auto& platform = vortex::SimPlatform::instance();
  platform.initialize();
  platform.set_num_workers(1);
  auto failed = Node::Create("failed", true);
  platform.reset();
  failed->input.send(1, 0);
  bool caught = false;
  auto task = std::async(std::launch::async, [&platform]() {
    platform.tick();
  });
  try {
    task.get();
  } catch (const std::runtime_error&) {
    caught = true;
  }
  auto count = vortex::SimChannelBase::inflight_count().load();
  std::printf("after_exception caught=%d inflight=%llu idle=%d queued=%u\n",
      caught, static_cast<unsigned long long>(count), platform.idle(),
      failed->input.size());
  bool valid = caught && count == 1 && !platform.idle()
      && failed->input.size() == 1;

  // Owner release follows platform finalization, as in processor teardown.
  platform.finalize();
  count = vortex::SimChannelBase::inflight_count().load();
  std::printf("after_finalize_before_owner_release inflight=%llu idle=%d\n",
      static_cast<unsigned long long>(count), platform.idle());
  valid = valid && count == 0 && platform.idle();
  failed.reset();
  count = vortex::SimChannelBase::inflight_count().load();
  std::printf("after_owner_release inflight=%llu idle=%d\n",
      static_cast<unsigned long long>(count), platform.idle());
  valid = valid && count == 0 && platform.idle();

  platform.initialize();
  platform.set_num_workers(1);
  auto fresh = Node::Create("fresh", false);
  platform.reset();
  fresh->input.send(2, 0);
  for (int i = 0; i != 4; ++i) {
    platform.tick();
  }
  count = vortex::SimChannelBase::inflight_count().load();
  std::printf("fresh_context inflight=%llu idle=%d queued=%u consumed=%u\n",
      static_cast<unsigned long long>(count), platform.idle(),
      fresh->input.size(), fresh->consumed);
  valid = valid && count == 0 && platform.idle()
      && fresh->input.empty() && fresh->consumed == 1;

  // A healthy reset starts only after the previous launch is quiescent.
  if (platform.idle()) {
    platform.reset();
    fresh->input.send(3, 7);
    for (int i = 0; i != 4; ++i) {
      platform.tick();
    }
    count = vortex::SimChannelBase::inflight_count().load();
    std::printf("healthy_reset inflight=%llu idle=%d queued=%u consumed=%u\n",
        static_cast<unsigned long long>(count), platform.idle(),
        fresh->input.size(), fresh->consumed);
    valid = valid && count == 0 && platform.idle()
        && fresh->input.empty() && fresh->consumed == 2;
  }
  platform.finalize();
  fresh.reset();
  platform.finalize();
  valid = valid && vortex::SimChannelBase::inflight_count().load() == 0
      && platform.idle();
  if (!valid) {
    std::fprintf(stderr, "FAIL: full teardown retained abandoned inflight accounting\n");
    return 1;
  }
  std::puts("PASS: functional host framework teardown and fresh-context accounting");
  return 0;
}
