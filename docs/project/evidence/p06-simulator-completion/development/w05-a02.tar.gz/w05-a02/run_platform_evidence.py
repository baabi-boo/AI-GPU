#!/usr/bin/env python3
"""Retain bounded current/pinned-parent SimObject cleanup evidence."""

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path("/workspace/scratch/ea983fdea786/AI-GPU")
EVIDENCE = Path(__file__).resolve().parent
BASE = "42809ff0c1b81384d7c9b079e4ef786be8407600"
sys.path.insert(0, str(ROOT / "ci/project"))
from baseline_process import GIB, MIB, run_bounded

KERNELS = ("timing", "functional")
GROUPS = ("queued_exception", "scheduled_reservation", "late_owner", "normal")
HEADERS = (
    "sim/common/simobject.h", "sim/common/simobject_functional.h",
    "sw/common/bitmanip.h", "sw/common/linked_list.h", "sw/common/mempool.h",
    "sw/common/ringqueue.h", "sw/common/smallfunc.h", "sw/common/util.h",
)
SOURCES = (
    "ci/project/fixtures/simulator_platform_cleanup.cpp",
    "ci/project/test_p06_simulator_platform.py",
    "ci/project/tensor_host_tools.py", "ci/project/baseline_process.py", *HEADERS,
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    return {name: digest(ROOT / name) for name in SOURCES}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main():
    before = inventory()
    write_json(EVIDENCE / "source-hashes-before.json", before)
    compiler = shutil.which("c++") or shutil.which("g++") or shutil.which("clang++")
    if compiler is None:
        raise RuntimeError("C++17 compiler is unavailable")
    environment = {
        "PATH": os.environ.get("PATH", os.defpath), "LC_ALL": "C",
        "TMPDIR": str(EVIDENCE), "UBSAN_OPTIONS": "halt_on_error=1:print_stacktrace=1",
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    records = []

    def execute(name, argv, cwd, timeout, expected_exit=0, marker=None):
        logfile = EVIDENCE / (name + ".log")
        outcome = run_bounded(
            argv, cwd, environment, logfile, timeout_seconds=timeout,
            min_free_bytes=GIB, max_log_bytes=MIB, max_rss_bytes=GIB,
            resource_paths=(cwd,),
        )
        output = logfile.read_text(encoding="utf-8", errors="replace") if logfile.exists() else ""
        correct = (
            outcome["cleanup_complete"] and outcome["process_started"]
            and outcome["exit_code"] == expected_exit
            and outcome["outcome"] == ("pass" if expected_exit == 0 else "fail")
            and (marker is None or marker in output)
            and "runtime error:" not in output
        )
        record = {"name": name, "argv": argv, "cwd": str(cwd),
                  "timeout_seconds": timeout, "expected_exit": expected_exit,
                  "expected_marker": marker, "expectation_met": correct,
                  "log_path": str(logfile), "result": outcome}
        records.append(record)
        write_json(EVIDENCE / "commands.json", records)
        print(name + ": exit=" + str(outcome["exit_code"]) + " expectation=" + str(correct), flush=True)
        if not correct:
            raise AssertionError(name + " did not meet its bounded expectation\n" + output[-4096:])
        return output

    metadata = {
        "base_revision": BASE,
        "head_revision": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "source_scope": "dirty working-tree bytes bound by source-hashes-before/after.json",
        "compiler": compiler, "compiler_realpath": str(Path(compiler).resolve()),
        "compiler_sha256": digest(Path(compiler).resolve()),
        "python": sys.executable, "python_sha256": digest(Path(sys.executable).resolve()),
        "environment": environment,
        "bounds": {"max_rss_bytes": GIB, "min_free_bytes": GIB, "max_log_bytes": MIB},
        "disk_free_bytes_at_start": shutil.disk_usage(EVIDENCE).free,
        "limitations": [
            "Actual SimObject/SimChannel host framework; no native Processor or GPU execution",
            "One internal executor worker; no parallel model-fault recovery or cross-inbox execution",
            "Host teardown follows get/join of the completed or exceptional async model worker",
            "Old finalized channels are never accessed; late-owner case only releases a shared owner",
            "Parent evidence requires built behavioral failure; compile errors/timeouts do not qualify",
        ],
    }
    write_json(EVIDENCE / "metadata.json", metadata)
    execute("compiler-version", [compiler, "--version"], EVIDENCE, 15)
    execute("unittest-current", [sys.executable, "-m", "unittest", "discover", "-s", "ci/project",
                                "-p", "test_p06_simulator_platform.py", "-v"], ROOT, 120,
            marker="Ran 4 tests")

    for variant in ("candidate", "parent"):
        tree = EVIDENCE / "sources" / variant
        for relative in SOURCES:
            destination = tree / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            if variant == "parent" and relative in HEADERS:
                data = subprocess.check_output(["git", "show", BASE + ":" + relative], cwd=ROOT)
            else:
                data = (ROOT / relative).read_bytes()
            destination.write_bytes(data)
        write_json(EVIDENCE / (variant + "-source-hashes.json"),
                   {name: digest(tree / name) for name in SOURCES})
        build = EVIDENCE / "build" / variant
        build.mkdir(parents=True, exist_ok=True)
        for kernel in KERNELS:
            binary = build / ("simulator-platform-" + kernel)
            flags = [compiler, "-std=c++17", "-O1", "-g0", "-Wall", "-Wextra", "-Werror",
                     "-fsanitize=undefined", "-fno-sanitize-recover=undefined", "-pthread"]
            if kernel == "functional":
                flags.append("-DSIMX_FUNCTIONAL")
            command = [*flags, "-I", str(tree / "sim/common"), "-I", str(tree / "sw/common"),
                       str(tree / "ci/project/fixtures/simulator_platform_cleanup.cpp"),
                       "-o", str(binary)]
            execute(variant + "-" + kernel + "-compile", command, build, 60)
            for group in GROUPS:
                expected_failure = variant == "parent" and group != "normal"
                marker = ("fresh context consumed its packet but remained non-idle" if expected_failure
                          else "PASS simulator-platform-cleanup " + group)
                execute(variant + "-" + kernel + "-" + group, [str(binary), group], build, 15,
                        expected_exit=1 if expected_failure else 0, marker=marker)
    after = inventory()
    write_json(EVIDENCE / "source-hashes-after.json", after)
    if after != before:
        raise AssertionError("Source changed during retained validation")
    for variant in ("candidate", "parent"):
        tree = EVIDENCE / "sources" / variant
        original = json.loads((EVIDENCE / (variant + "-source-hashes.json")).read_text())
        current = {name: digest(tree / name) for name in SOURCES}
        if current != original:
            raise AssertionError("Snapshot changed during retained validation: " + variant)
    write_json(EVIDENCE / "summary.json", {
        "status": "pass", "sources_unchanged": True, "unittest_tests": 4,
        "current_kernel_group_cells": 8, "candidate_snapshot_passes": 8,
        "parent_built_expected_failures": 6, "parent_normal_control_passes": 2,
        "commands": len(records), "evidence_runner_sha256": digest(Path(__file__).resolve()),
    })


if __name__ == "__main__":
    main()
