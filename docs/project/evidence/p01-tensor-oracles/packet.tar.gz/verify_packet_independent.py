#!/usr/bin/env python3
"""Independent, bounded, read-only tensor packet audit (Python stdlib only).

Usage: python3 -B verify_packet_independent.py OUTPUT_DIR --work-root WORK
       [--report AUDIT_JSON] [--require-current]

Does not import/execute the packet builder, extract files, invoke Git, or build.
Historical current-file drift is reported separately from packet integrity.
--require-current is appropriate after final inputs have been frozen.
"""
import argparse
import datetime
import fnmatch
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile

RAW_CAP = 32 * 1024 * 1024
PACKET_CAP = 8 * 1024 * 1024
INDEX_CAP = 1024 * 1024
MEMBER_CAP = 512
PRELIMINARY = (
    "softfloat-build", "configure-fedp-rv64-n2", "configure-fedp-rv64-n2-focal-bundle",
    "build-fedp-rv64-n2-preliminary", "fedp-rv64-fp16-preliminary",
    "configure-wmma-rv64-t4-preliminary", "build-wmma-rv64-t4-preliminary",
    "wmma-rv64-t4-fmt2-preliminary", "wmma-rv64-t4-fmt3-preliminary",
)
RECEIPTS = tuple(f"{group}-{rev}/report.json" for group in ("final-matrix", "governance")
                 for rev in ("20ea50d", "ca8686d")) + ("host-followup-a25ee66/report.json",) + tuple(
                     f"reports/{name}.json" for name in PRELIMINARY)
A34 = tuple("w06_a34/" + name for name in (
    "run_probe.py", "probe.cpp", "results.json", "fedp_base.cpp.txt",
    "fedp_current.cpp.txt", "unit_base.cpp.txt", "unit_current.cpp.txt",
    "compile.log", "stdout.json", "stderr.log"))
EXACT = {
    "build_evidence_packet.py", "bounded_command.py", "provision_verilator.py",
    "LICENSE", "finalize_ledger.py", "verify_packet_independent.py",
    "run_final_matrix.py", "run_governance.py", "run_host_followup.py",
    "session-state.json", "identities/source-map.json", "reports/compactnumeric-summary.json",
    "w06-a36-checker-probes.json", "drafts/agents.json", "drafts/agents.md",
    "host-followup-a25ee66/focused-host-suite.log", "reports/provision-verilator.json",
    "softfloat-command.json", *A34, *RECEIPTS,
    *(f"{group}-{rev}/runner.py" for group in ("final-matrix", "governance")
      for rev in ("20ea50d", "ca8686d")),
    *(f"governance-{rev}/matrix-support.py" for rev in ("20ea50d", "ca8686d")),
    *(f"logs/{name}.log" for name in PRELIMINARY),
    *(f"{name}.command.json" for name in PRELIMINARY if name != "softfloat-build"),
}
PATTERNS = (
    "final-matrix-20ea50d/logs/*.log", "final-matrix-ca8686d/logs/*.log",
    "governance-20ea50d/*.log", "governance-ca8686d/*.log", "identities/*.commit",
    "reports/w*.md", "reports/w*.json", "reports/w*.py", "reports/w*.patch",
)


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {"sha256": sha(data), "size_bytes": len(data)}


def valid_name(name):
    need(isinstance(name, str) and name and not name.startswith("/") and
         "\\" not in name and "\0" not in name and
         all(p not in ("", ".", "..") for p in name.split("/")), "unsafe path")


def allowed(name):
    valid_name(name)
    p = PurePosixPath(name)
    return name in EXACT or any(p.parent == PurePosixPath(q).parent and
                               fnmatch.fnmatchcase(p.name, PurePosixPath(q).name) for q in PATTERNS)


def read_regular(root, name, cap):
    valid_name(name)
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    fd = os.open(root, flags | os.O_DIRECTORY)
    try:
        for part in name.split("/")[:-1]:
            child = os.open(part, flags | os.O_DIRECTORY, dir_fd=fd)
            os.close(fd)
            fd = child
        leaf = os.open(name.split("/")[-1], flags, dir_fd=fd)
        try:
            before = os.fstat(leaf)
            need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= cap,
                 "nonregular/oversized input: " + name)
            parts, left = [], cap + 1
            while left:
                part = os.read(leaf, min(left, 1024 * 1024))
                if not part:
                    break
                parts.append(part)
                left -= len(part)
            data = b"".join(parts)
            after = os.fstat(leaf)
            keys = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
            need(all(getattr(before, k) == getattr(after, k) for k in keys) and
                 len(data) == before.st_size <= cap, "input changed during read: " + name)
            return data
        finally:
            os.close(leaf)
    finally:
        os.close(fd)


def transform(data, roots):
    data.decode("utf-8", "strict")
    need(b"\0" not in data, "binary NUL in text")
    counts = {}
    for token, prefix in roots:
        n = data.count(prefix)
        if n:
            counts[token.decode()] = n
            data = data.replace(prefix, token)
    return data, {"kind": "utf8_literal_path_substitution", "replacement_counts": counts}


def walk(value, pointer=""):
    if isinstance(value, dict):
        yield pointer, value
        for k, v in value.items():
            yield from walk(v, pointer + "/" + k.replace("~", "~0").replace("/", "~1"))
    elif isinstance(value, list):
        for i, v in enumerate(value):
            yield from walk(v, pointer + "/" + str(i))


def parse_tar(raw_tar, rows):
    """Read USTAR at fixed offsets, without extraction or tarfile parsing."""
    files, offset = {}, 0
    for row in rows:
        name = row["path"]
        size = row["published_size_bytes"]
        need(type(size) is int and 0 <= size <= RAW_CAP, "invalid member size")
        header = raw_tar[offset:offset + 512]
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = size, 0o644, 0
        info.uid = info.gid = 0
        info.uname = info.gname = ""
        info.type = tarfile.REGTYPE
        need(header == info.tobuf(format=tarfile.USTAR_FORMAT),
             "noncanonical USTAR header/order: " + name)
        start = offset + 512
        end = start + size
        data = raw_tar[start:end]
        need(len(data) == size and sha(data) == row["published_sha256"],
             "published member mismatch: " + name)
        offset = end + (-size % 512)
        need(raw_tar[end:offset] == b"\0" * (offset - end), "nonzero member padding")
        files[name] = data
    expected_size = ((offset + 1024 + 10239) // 10240) * 10240
    need(len(raw_tar) == expected_size and raw_tar[offset:] == b"\0" * (expected_size - offset),
         "noncanonical tar terminator/padding or extra members")
    return files


def audit(output, work):
    need({p.name for p in output.iterdir()} == {"index.json", "packet.tar.gz"},
         "bundle directory must contain exactly its two files")
    index_data = read_regular(output, "index.json", INDEX_CAP)
    index = json.loads(index_data)
    need((json.dumps(index, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode() == index_data,
         "noncanonical or duplicate-key JSON index")
    need(index["schema_version"] == 1 and index["phase_complete"] is False, "schema/scope mismatch")
    limits = index["limits"]
    need(type(limits["raw_bytes"]) is int and 0 < limits["raw_bytes"] <= RAW_CAP and
         type(limits["compressed_bytes"]) is int and 0 < limits["compressed_bytes"] <= PACKET_CAP,
         "invalid resource limits")
    packet = read_regular(output, "packet.tar.gz", limits["compressed_bytes"])
    need(identity(packet) == index["archive"]["compressed"], "compressed archive identity mismatch")
    need(packet[:10] == bytes.fromhex("1f8b08000000000002ff"), "nondeterministic gzip header")
    with gzip.GzipFile(fileobj=io.BytesIO(packet), mode="rb") as stream:
        raw_tar = stream.read(limits["raw_bytes"] + 1)
    need(len(raw_tar) <= limits["raw_bytes"] and identity(raw_tar) == index["archive"]["uncompressed_tar"],
         "tar identity/size mismatch")
    recompressed = io.BytesIO()
    with gzip.GzipFile(filename="", fileobj=recompressed, mode="wb", compresslevel=9, mtime=0) as stream:
        stream.write(raw_tar)
    need(recompressed.getvalue() == packet, "noncanonical gzip stream")
    rows = index["members"]
    names = [r["path"] for r in rows]
    need(len(names) == index["member_count"] <= MEMBER_CAP and names == sorted(set(names)),
         "invalid member count/order/uniqueness")
    need(EXACT <= set(names) and all(allowed(n) for n in names), "allowlist mismatch")
    need(index["allowlist"] == {"required_exact_paths": sorted(EXACT), "nonrecursive_patterns": list(PATTERNS)},
         "declared allowlist differs from independent policy")
    files = parse_tar(raw_tar, rows)
    need(sum(len(d) for d in files.values()) == index["published_total_size_bytes"] <= limits["raw_bytes"],
         "published total mismatch")
    need(all(type(r["raw_size_bytes"]) is int and 0 <= r["raw_size_bytes"] <= RAW_CAP for r in rows) and
         sum(r["raw_size_bytes"] for r in rows) == index["raw_total_size_bytes"] <= limits["raw_bytes"],
         "raw total mismatch")
    roots = [(b"<SOURCE>", str(work.parent / "AI-GPU").encode()),
             (b"<WORK>", str(work).encode()), (b"<WORKSPACE>", str(work.parent).encode())]
    need(index["path_transform"]["order"] == [t.decode() for t, _ in roots], "path transform order mismatch")
    expected_roots = [{"token": t.decode(), "root_relative_to_workspace": rel,
                       "original_absolute_prefix_sha256": sha(p)}
                      for (t, p), rel in zip(roots, ("AI-GPU", work.name, "."))]
    need(index["path_transform"]["roots"] == expected_roots, "original root identity mismatch")
    current_count, historical_count, inverse_count, drift, commits = 0, 0, 0, [], []
    raw_by_name = {}
    for row in rows:
        name, published = row["path"], files[row["path"]]
        need(row["raw_path"] == "<WORK>/" + name, "raw path mismatch")
        need(not published.startswith(b"\x7fELF"), "ELF member included: " + name)
        current = read_regular(work, name, RAW_CAP)
        expected = {"sha256": row["raw_sha256"], "size_bytes": row["raw_size_bytes"]}
        if identity(current) == expected:
            raw = current
            current_count += 1
        else:
            event = {"path": name, "captured": expected, "current": identity(current)}
            backup_name = name.replace("drafts/agents.", "drafts/agents.agent39-original.")
            if backup_name != name and (work / backup_name).is_file():
                candidate = read_regular(work, backup_name, RAW_CAP)
            else:
                candidate = b""
            if identity(candidate) == expected:
                raw = candidate
                historical_count += 1
                event["captured_raw_verification"] = "matching retained historical original"
            else:
                candidate = published
                for token, prefix in roots:
                    candidate = candidate.replace(token, prefix)
                need(identity(candidate) == expected, "raw original unavailable/unrecoverable: " + name)
                raw = candidate
                inverse_count += 1
                event["captured_raw_verification"] = "inverse path reconstruction matched captured raw SHA-256 and size"
            drift.append(event)
        raw_by_name[name] = raw
        if name.startswith("identities/") and name.endswith(".commit"):
            need(re.fullmatch(r"identities/[0-9a-f]{40}\.commit", name), "invalid commit filename")
            oid = hashlib.sha1(b"commit " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            need(oid == PurePosixPath(name).stem and raw == published and
                 row["transformation"] == {"kind": "verbatim_git_commit", "git_commit_sha1": oid},
                 "commit object identity mismatch")
            commits.append(oid)
        else:
            transformed, metadata = transform(raw, roots)
            need(transformed == published and metadata == row["transformation"],
                 "raw/published path transform mismatch: " + name)
            need(not any(prefix in published for _, prefix in roots), "unreplaced workspace path: " + name)
    derived_bindings = []
    for report_name in RECEIPTS:
        for pointer, record in walk(json.loads(files[report_name])):
            if not {"log", "log_sha256", "log_size_bytes"} <= record.keys():
                continue
            need(record["log"].startswith("<WORK>/"), "receipt log has unexpected root")
            log = record["log"][len("<WORK>/"):]
            need(log in raw_by_name and identity(raw_by_name[log]) ==
                 {"sha256": record["log_sha256"], "size_bytes": record["log_size_bytes"]},
                 "receipt log identity mismatch: " + report_name + pointer)
            derived_bindings.append({"report": report_name, "record_json_pointer": pointer,
                                     "log": log, "raw_sha256": record["log_sha256"],
                                     "raw_size_bytes": record["log_size_bytes"]})
    need(derived_bindings == index["raw_log_bindings"], "missing, additional, duplicate or changed log bindings")
    need(set(n for n in names if n.startswith("w06_a34/")) == set(A34), "A34 selection mismatch")
    for name in A34:
        files[name].decode("utf-8", "strict")
        need(b"\0" not in files[name], "binary A34 member")
    ledger = json.loads(files["drafts/agents.json"])
    state = json.loads(files["session-state.json"])
    source_map = json.loads(files["identities/source-map.json"])
    for mapping in source_map["mappings"]:
        name = "identities/" + mapping["original_commit_object"]
        need(name in raw_by_name and mapping["local_commit"] == PurePosixPath(name).stem and
             raw_by_name[name].startswith(("tree " + mapping["tree"] + "\n").encode()),
             "source-map raw commit/tree binding mismatch")
    return {
        "outcome": "pass_with_live_input_drift" if drift else "pass",
        "audit_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "packet_directory": str(output), "archive": identity(packet),
        "uncompressed_tar": identity(raw_tar), "index": identity(index_data),
        "members_verified": len(rows), "raw_total_size_bytes": index["raw_total_size_bytes"],
        "published_total_size_bytes": index["published_total_size_bytes"],
        "current_raw_members_matched": current_count, "historical_raw_members_matched": historical_count,
        "inverse_reconstructed_raw_members_matched": inverse_count, "live_input_drift": drift,
        "raw_published_transforms_verified": len(rows), "git_commit_sha1_verified": commits,
        "raw_log_bindings_complete_and_verified": len(derived_bindings),
        "a34_text_members_verified": len(A34), "elf_members": 0,
        "canonical_ustar_and_gzip_verified": True, "phase_complete": index["phase_complete"],
        "captured_ledger": {k: ledger.get(k) for k in ("snapshot_utc", "document_status", "counts", "source_snapshot")},
        "ledger_session_hash_matches_captured_session": ledger.get("source_snapshot", {}).get("session_state_sha256") == sha(raw_by_name["session-state.json"]),
        "captured_session": {"assigned_tasks": sum(len(w["agents"]) for w in state["waves"]),
                             "completed_ids_count": len(state.get("completed_agent_ids", [])),
                             **{k: state.get(k) for k in ("final_source_commit", "latest_source_commit", "prepared_remote_source", "remote_branch_moved")}},
        "captured_source_map_state": source_map.get("state"),
        "limits": "Verification capped at 8 MiB compressed, 32 MiB uncompressed, 1 MiB index, 512 members; no extraction/execution.",
        "authentication_caveat": "Unsigned index proves internal consistency and raw-file agreement, not execution or remote publication.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--work-root", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--require-current", action="store_true")
    args = parser.parse_args()
    try:
        report = audit(args.output_dir.resolve(strict=True), args.work_root.resolve(strict=True))
        if args.require_current and report["live_input_drift"]:
            report["outcome"] = "fail_current_inputs_changed"
    except (OSError, ValueError, KeyError, TypeError, EOFError, tarfile.TarError) as error:
        report = {"outcome": "fail", "error": str(error)}
    if args.report:
        args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: report[k] for k in (
        "outcome", "archive", "members_verified", "current_raw_members_matched",
        "historical_raw_members_matched", "inverse_reconstructed_raw_members_matched",
        "raw_log_bindings_complete_and_verified", "a34_text_members_verified", "error") if k in report}, sort_keys=True))
    return 1 if report["outcome"].startswith("fail") else 0


if __name__ == "__main__":
    sys.exit(main())
