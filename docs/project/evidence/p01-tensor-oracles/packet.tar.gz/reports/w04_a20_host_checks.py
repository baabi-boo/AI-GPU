import json
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path('<WORKSPACE>')
SOURCE = ROOT / 'AI-GPU'
BODY = (SOURCE / 'hw/unittest/tcu_unit/main.cpp').read_text()
GEN = ROOT / 'tensor-work/build-wmma-rv64-t4-preliminary/sw'
REPORT = ROOT / 'tensor-work/reports/w04-a20-host-results.json'

def section(start, end):
    return BODY[BODY.index(start):BODY.index(end)]

def function(start):
    begin = BODY.index(start)
    brace = BODY.index('{', begin)
    depth = 1
    end = brace + 1
    while depth:
        depth += (BODY[end] == '{') - (BODY[end] == '}')
        end += 1
    return BODY[begin:end]

program = '''
#include <algorithm>
#include <charconv>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include "VX_config.h"
#include "tensor_exact_cases.h"
'''
program += section('static_assert((VX_CFG_NUM_THREADS', '// WMMA op_type')
program += section('struct FmtInfo {', '// Convert a packed')
program += section('enum class RoundingMode', '// ---- Test value generation')
program += section('static uint32_t pack_fp', '// ---- Directed vectors')
program += section('struct DirectedVec {', '// ---- Testbench class')
program += '''
class Testbench {
  TestConfig cfg_;
  uint64_t cycle_ = 0;
  std::mt19937 rng_;
  void reset() {}
  bool check_expected(const std::vector<uint32_t>&, const std::vector<uint32_t>&,
                      const std::vector<uint32_t>&, const FmtInfo&,
                      const std::vector<uint32_t>&, uint32_t, const std::string&) {
    return true;
  }
  bool check(const std::vector<uint32_t>& a, const std::vector<uint32_t>& b,
             const std::vector<uint32_t>& c, const FmtInfo&, const std::string& name) {
    if (name.rfind("Test #", 0) == 0) {
      std::cout << "INPUT " << name;
      for (const auto* words : {&a, &b, &c}) {
        std::cout << " |";
        for (uint32_t word : *words) std::cout << " " << std::hex << word;
      }
      std::cout << std::dec << "\\n";
    }
    return true;
  }
public:
  explicit Testbench(const TestConfig& config) : cfg_(config), rng_(config.random_seed) {}
'''
program += function('    bool run_tests()') + '\n};\n'
program += section('template <typename T>\nstatic T parse_number', 'int main(int argc')
program += '''
int main(int argc, char** argv) {
  try {
    const auto config = parse_args(argc, argv);
    Testbench test(config);
    return test.run_tests() ? 0 : 1;
  } catch (const std::exception& error) {
    std::cerr << "Invalid test configuration: " << error.what() << "\\n";
    return 2;
  }
}
'''

variants = [
    ('default-tfr', [], {2, 3}),
    ('tfr-tf32', ['-DVX_CFG_TCU_TYPE_TFR', '-DVX_CFG_TCU_TF32_ENABLE'], {1, 2, 3}),
    ('tfr-fp16-disabled', ['-DVX_CFG_TCU_TYPE_TFR', '-DVX_CFG_TCU_FP16_DISABLE'], set()),
    ('dpi', ['-DVX_CFG_TCU_TYPE_DPI'], {2, 3}),
    ('dpi-tf32', ['-DVX_CFG_TCU_TYPE_DPI', '-DVX_CFG_TCU_TF32_ENABLE'], {1, 2, 3}),
    ('dpi-fp16-disabled', ['-DVX_CFG_TCU_TYPE_DPI', '-DVX_CFG_TCU_FP16_DISABLE'], set()),
    ('bhf', ['-DVX_CFG_TCU_TYPE_BHF'], {2, 3}),
    ('bhf-fp16-disabled', ['-DVX_CFG_TCU_TYPE_BHF', '-DVX_CFG_TCU_FP16_DISABLE'], {2}),
    ('dsp-tf32-enabled', ['-DVX_CFG_TCU_TYPE_DSP', '-DVX_CFG_TCU_TF32_ENABLE'], {2, 3}),
    ('dsp-fp16-disabled', ['-DVX_CFG_TCU_TYPE_DSP', '-DVX_CFG_TCU_FP16_DISABLE'], {2}),
    ('fpnew-tf32-enabled', ['-DVX_CFG_TCU_TYPE_FPNEW', '-DVX_CFG_TCU_TF32_ENABLE'], {2, 3}),
    ('fpnew-fp16-disabled', ['-DVX_CFG_TCU_TYPE_FPNEW', '-DVX_CFG_TCU_FP16_DISABLE'], set()),
]
results = []
with tempfile.TemporaryDirectory(prefix='wmma-host-check-', dir=ROOT / 'tensor-work') as temporary:
    temporary = Path(temporary)
    translation = temporary / 'production-parser-loop.cpp'
    translation.write_text(program)
    for name, flags, supported in variants:
        binary = temporary / name
        command = ['g++', '-std=c++17', '-Wall', '-Wextra', '-Werror', '-O2',
                   '-fsanitize=undefined', '-fno-sanitize-recover=undefined',
                   '-DVX_CFG_NUM_THREADS=4', '-DVX_CFG_XLEN=64', '-I', str(GEN), '-I', str(SOURCE / 'hw/unittest/common'),
                   *flags, str(translation), '-o', str(binary)]
        build = subprocess.run(command, text=True, capture_output=True, timeout=30)
        assert build.returncode == 0, (name, build.stderr)
        for fmt in range(4):
            run = subprocess.run([str(binary), f'--fmt={fmt}', '--tests=7', '--test=3', '--no-trace'],
                                 text=True, capture_output=True, timeout=5)
            accepted = fmt in supported
            assert (run.returncode == 0) == accepted, (name, fmt, run.stdout, run.stderr)
            if not accepted:
                assert 'unavailable' in run.stderr or 'does not implement' in run.stderr
                assert 'PASSED' not in run.stdout
            results.append({'kind': 'backend-format', 'backend': name, 'fmt': fmt,
                            'expected_accept': accepted, 'exit_code': run.returncode, 'pass': True})
        if name == 'default-tfr':
            for fmt in (2, 3):
                arguments = [str(binary), f'--fmt={fmt}', '--tests=18', '--seed=2468', '--no-trace']
                full = subprocess.run(arguments, text=True, capture_output=True, timeout=5)
                assert full.returncode == 0
                lines = [line for line in full.stdout.splitlines() if line.startswith('INPUT Test #')]
                assert len(lines) == 18
                for index in (0, 1, 3, 17):
                    single = subprocess.run(arguments + [f'--test={index}'], text=True,
                                            capture_output=True, timeout=5)
                    actual = [line for line in single.stdout.splitlines() if line.startswith('INPUT Test #')]
                    assert single.returncode == 0 and actual == [lines[index]], (fmt, index, actual)
                    assert 'random=1' in single.stdout
                    results.append({'kind': 'selected-input-replay', 'fmt': fmt, 'index': index,
                                    'pass': True})

enum_records = []
for backend in ('TFR', 'DPI', 'BHF', 'DSP', 'FPNEW'):
    completed = subprocess.run(['python3', str(SOURCE / 'ci/gen_config.py'),
        '--config=' + str(SOURCE / 'VX_config.toml'),
        '--cflags=-DVX_CFG_XLEN=64 -DVX_CFG_EXT_TCU_ENABLE -DVX_CFG_TCU_TYPE=' + backend],
        capture_output=True, text=True, timeout=5)
    assert completed.returncode == 0, completed.stderr
    selectors = [value for value in completed.stdout.split() if value.startswith('-DVX_CFG_TCU_TYPE_')]
    assert selectors == ['-DVX_CFG_TCU_TYPE_' + backend], (backend, selectors)
    enum_records.append({'backend': backend, 'resolved_selector': selectors[0], 'pass': True})

report = {'scope': 'Host-only extracted production parser and random-generation loop; stubbed DUT adapter is not numerical/RTL evidence',
          'checks': len(results) + len(enum_records), 'results': results, 'enum_resolution': enum_records}
REPORT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'checks': report['checks'], 'all_passed': True, 'report': str(REPORT)}))
