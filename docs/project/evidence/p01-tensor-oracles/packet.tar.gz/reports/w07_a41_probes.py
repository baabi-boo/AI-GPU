#!/usr/bin/env python3
"""Scratch-only host-wrapper failure-boundary probes; no native compilation."""
import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path('<SOURCE>')
SCRATCH = Path('<WORK>')
sys.path.insert(0, str(ROOT / 'ci/project'))
import baseline_process
import tensor_host_tools

NAMES = ('test_tensor_fp32_compare', 'test_tensor_int_reference', 'test_tensor_exact_cases')
MODULES = [importlib.import_module(name) for name in NAMES]
CLASSES = [m.TensorFp32ComparisonTests if i == 0 else
           m.TensorIntegerReferenceTests if i == 1 else m.TensorExactFixtureTests
           for i, m in enumerate(MODULES)]
FILES = ['ci/project/tensor_host_tools.py', 'ci/project/baseline_process.py',
         *[f'ci/project/{name}.py' for name in NAMES],
         'hw/unittest/common/tests/fp32_compare_test.cpp',
         'hw/unittest/common/tests/int_dot_reference_test.cpp',
         'hw/unittest/common/tests/tensor_exact_cases_test.cpp',
         'hw/unittest/common/tensor_exact_cases.h']
source_hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in FILES}
observed = {'source_sha256': source_hashes, 'probes': []}
real_tempdir = tempfile.TemporaryDirectory
real_run_bounded = baseline_process.run_bounded


def run_suite(cls):
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(cls)
    result = unittest.TestResult()
    suite.run(result)
    return result


with real_tempdir(prefix='w07-a41-no-compiler-', dir=SCRATCH) as empty_path:
    for cls, module in zip(CLASSES, MODULES):
        with mock.patch.dict(os.environ, {'PATH': empty_path}), \
             mock.patch.object(module, 'run_host_command') as run, \
             mock.patch.object(module.tempfile, 'TemporaryDirectory') as temporary:
            result = run_suite(cls)
        require = len(result.errors) == 1 and len(result.skipped) == 0 and not run.called and not temporary.called
        assert require and 'C++17 host compiler is required' in result.errors[0][1]
        observed['probes'].append({'probe': 'missing_compiler', 'class': cls.__name__,
            'outcome': 'expected_failure', 'tests_run': result.testsRun,
            'errors': len(result.errors), 'skips': len(result.skipped),
            'commands_started': run.call_count, 'temporary_dirs_created': temporary.call_count})

# The first would-be compiler command writes an artifact and exits unsuccessfully.
# Actual class setup and unittest cleanup run; only the compiler command is substituted.
for cls, module in zip(CLASSES, MODULES):
    directories = []
    command_results = []
    def create_tempdir(*args, **kwargs):
        kwargs['dir'] = SCRATCH
        temporary = real_tempdir(*args, **kwargs)
        directories.append(Path(temporary.name))
        return temporary
    def record_run(*args, **kwargs):
        result = real_run_bounded(*args, **kwargs)
        command_results.append(result)
        return result
    def failing_compile(argv, **kwargs):
        payload = "from pathlib import Path; import sys; Path('compiler-artifact').write_text('created'); print('injected compile failure'); sys.exit(7)"
        kwargs['timeout'] = 3
        return tensor_host_tools.run_host_command([sys.executable, '-c', payload], **kwargs)
    with mock.patch.object(module.shutil, 'which', return_value='/unused/compiler'), \
         mock.patch.object(module.tempfile, 'TemporaryDirectory', side_effect=create_tempdir), \
         mock.patch.object(module, 'run_host_command', side_effect=failing_compile), \
         mock.patch.object(tensor_host_tools, 'run_bounded', side_effect=record_run):
        result = run_suite(cls)
    assert len(result.errors) == 1 and not result.skipped
    assert 'Host command failed: nonzero_exit (exit 7)' in result.errors[0][1]
    assert len(directories) == 1 and not directories[0].exists()
    assert command_results[0]['cleanup_complete']
    observed['probes'].append({'probe': 'setup_command_failure_cleanup', 'class': cls.__name__,
        'outcome': 'expected_failure', 'exception': 'AssertionError',
        'reason': command_results[0]['reason'], 'exit_code': command_results[0]['exit_code'],
        'process_cleanup_complete': command_results[0]['cleanup_complete'],
        'class_temporary_dir_removed': not directories[0].exists()})

# An apparently passing command must still be rejected if process cleanup failed.
with real_tempdir(prefix='w07-a41-cleanup-gate-', dir=SCRATCH) as directory:
    def incomplete_cleanup(argv, cwd, env, log, **kwargs):
        Path(log).write_text('plausible success\n', encoding='utf-8')
        return {'outcome': 'pass', 'cleanup_complete': False, 'reason': None, 'exit_code': 0}
    try:
        with mock.patch.object(tensor_host_tools, 'run_bounded', side_effect=incomplete_cleanup):
            tensor_host_tools.run_host_command([sys.executable], cwd=directory, env={}, timeout=1)
    except AssertionError as error:
        observed['probes'].append({'probe': 'incomplete_cleanup_gate', 'outcome': 'expected_failure',
            'exception': type(error).__name__, 'diagnostic': str(error)})
    else:
        raise AssertionError('incomplete cleanup was accepted')

# Decode errors are tested after a real child has exited and monitor cleanup has completed.
for exit_code in (0, 7):
    command_results = []
    def record_run(*args, **kwargs):
        result = real_run_bounded(*args, **kwargs)
        command_results.append(result)
        return result
    with real_tempdir(prefix='w07-a41-invalid-utf8-', dir=SCRATCH) as directory:
        path = Path(directory)
        payload = "from pathlib import Path; import os; Path('artifact').write_text('created'); os.write(1, b'\\xffdiagnostic\\n'); raise SystemExit(" + str(exit_code) + ")"
        try:
            with mock.patch.object(tensor_host_tools, 'run_bounded', side_effect=record_run):
                tensor_host_tools.run_host_command([sys.executable, '-c', payload], cwd=path,
                    env={'PATH': os.defpath, 'LC_ALL': 'C', 'TMPDIR': directory}, timeout=3)
        except UnicodeDecodeError as error:
            assert command_results[0]['cleanup_complete']
            observed['probes'].append({'probe': 'invalid_utf8', 'outcome': 'expected_failure',
                'child_exit': exit_code, 'exception': type(error).__name__,
                'underlying_outcome': command_results[0]['outcome'],
                'underlying_reason': command_results[0]['reason'],
                'process_cleanup_complete': command_results[0]['cleanup_complete'],
                'log_size_bytes': command_results[0]['log_size_bytes']})
        else:
            raise AssertionError('invalid UTF-8 unexpectedly accepted')
    observed['probes'][-1]['temporary_dir_removed'] = not path.exists()
    assert not path.exists()

with real_tempdir(prefix='w07-a41-utf8-λ-', dir=SCRATCH) as directory:
    path = Path(directory)
    payload = "from pathlib import Path; import os; Path('artifact-λ').write_text('created', encoding='utf-8'); os.write(1, 'λ\\n'.encode('utf-8'))"
    output = tensor_host_tools.run_host_command([sys.executable, '-c', payload], cwd=path,
        env={'PATH': os.defpath, 'LC_ALL': 'C', 'TMPDIR': directory}, timeout=3)
    assert output == 'λ\n' and (path / 'artifact-λ').exists()
assert not path.exists()
observed['probes'].append({'probe': 'valid_utf8_and_unicode_artifact_path', 'outcome': 'pass',
    'output': output, 'temporary_dir_removed': not path.exists()})

# A failed leader with a live descendant must not leave that process running.
with real_tempdir(prefix='w07-a41-descendant-', dir=SCRATCH) as directory:
    command_results = []
    def record_run(*args, **kwargs):
        result = real_run_bounded(*args, **kwargs)
        command_results.append(result)
        return result
    pidfile = Path(directory) / 'child.pid'
    payload = "import subprocess, sys; from pathlib import Path; child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(20)']); Path('child.pid').write_text(str(child.pid)); print('leader failure', flush=True); sys.exit(7)"
    try:
        with mock.patch.object(tensor_host_tools, 'run_bounded', side_effect=record_run):
            tensor_host_tools.run_host_command([sys.executable, '-c', payload], cwd=directory,
                env={'PATH': os.defpath, 'LC_ALL': 'C', 'TMPDIR': directory}, timeout=3)
    except AssertionError as error:
        assert 'descendants_after_exit' in str(error)
        child_pid = int(pidfile.read_text())
        stat = Path('/proc') / str(child_pid) / 'stat'
        state = stat.read_text().rsplit(') ', 1)[1].split()[0] if stat.exists() else 'absent'
        if state not in ('absent', 'Z', 'X'):
            os.kill(child_pid, signal.SIGKILL)
            raise AssertionError('injected descendant remains alive')
        assert command_results[0]['cleanup_complete']
        observed['probes'].append({'probe': 'failed_leader_descendant_cleanup', 'outcome': 'expected_failure',
            'reason': command_results[0]['reason'], 'exit_code': command_results[0]['exit_code'],
            'process_cleanup_complete': command_results[0]['cleanup_complete'],
            'descendant_final_state': state})
    else:
        raise AssertionError('failed leader with descendant accepted')

end_hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in FILES}
assert end_hashes == source_hashes
observed['source_unchanged_during_probes'] = True
observed['probe_count'] = len(observed['probes'])
output = SCRATCH / 'reports/w07-a41-host-boundary-results.json'
output.write_text(json.dumps(observed, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'probe_count': len(observed['probes']), 'all_expected_outcomes_observed': True,
                  'result_path': str(output)}, indent=2))
