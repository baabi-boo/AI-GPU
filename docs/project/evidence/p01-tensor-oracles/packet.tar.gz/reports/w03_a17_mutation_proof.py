import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

ROOT = Path('<WORKSPACE>')
SOURCE = ROOT / 'AI-GPU'
REPORTS = ROOT / 'tensor-work/reports'
BASE = 'fcf2dee15fc1ae8aab95ba033ffac1340eec32fd'
HEADER = SOURCE / 'hw/unittest/common/fp32_compare.h'
TEST = SOURCE / 'hw/unittest/common/tests/fp32_compare_test.cpp'
COMPILER = shutil.which('g++')
assert COMPILER


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def original_function(relative, name):
    text = subprocess.check_output(['git', '-C', str(SOURCE), 'show', BASE + ':' + relative], text=True)
    start = text.index('static int ' + name + '(')
    opening = text.index('{', start)
    depth = 1
    end = opening + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[start:end]


prefix = ('#pragma once\n#include <cmath>\n#include <cstdlib>\n'
          '#define test_fp32 reference_fp32\n#include "' + str(HEADER)
          + '"\n#undef test_fp32\n')
adapter = '''
namespace test_fp32 {
using Comparison = reference_fp32::Comparison;
using reference_fp32::bits;
inline Comparison compare_bits(uint32_t a, uint32_t b, uint32_t tolerance) {
  const auto clean = reference_fp32::compare_bits(a, b, tolerance);
  const uint32_t am = a & 0x7fffffffu;
  const uint32_t bm = b & 0x7fffffffu;
  (void)am; (void)bm;
  MUTATION
  return clean;
}
}
'''
variants = {
    'opposite_infinity_false_pass': ('special',
        'if (am == 0x7f800000u && bm == am && a != b) return {true, 1};'),
    'finite_infinity_false_pass': ('special',
        'if ((am == 0x7f7fffffu && bm == 0x7f800000u) || '
        '(bm == 0x7f7fffffu && am == 0x7f800000u)) return {true, 1};'),
    'infinity_nan_false_pass': ('special',
        'if ((am == 0x7f800001u && bm == 0x7f800000u) || '
        '(bm == 0x7f800001u && am == 0x7f800000u)) return {true, 1};'),
    'signed_distance_abs_overflow': ('finite',
        'if (clean.ulps == 0x80000000ull) { volatile int bad = static_cast<int>(clean.ulps); '
        'const auto distance = static_cast<uint64_t>(std::abs(bad)); '
        'return {distance <= tolerance, distance}; }'),
}
headers = {name: (group, prefix + adapter.replace('MUTATION', body))
           for name, (group, body) in variants.items()}
originals = {}
for family, relative, name in (
        ('wmma', 'hw/unittest/tcu_unit/main.cpp', 'approx_equal'),
        ('fedp', 'hw/unittest/tcu_fedp/main.cpp', 'approximately_equal')):
    function = original_function(relative, name)
    originals[family] = {'path': relative, 'function_sha256': hashlib.sha256(function.encode()).hexdigest()}
    original = prefix + '''
template<class To, class From> To bit_cast(const From& value) {
  static_assert(sizeof(To) == sizeof(From));
  To result; std::memcpy(&result, &value, sizeof(result)); return result;
}
''' + function + '''
namespace test_fp32 {
using Comparison = reference_fp32::Comparison;
using reference_fp32::bits;
inline Comparison compare_bits(uint32_t a, uint32_t b, uint32_t tolerance) {
  float af, bf;
  std::memcpy(&af, &a, sizeof(af)); std::memcpy(&bf, &b, sizeof(bf));
  const int delta = FUNCTION(af, bf);
  const auto distance = static_cast<uint64_t>(std::abs(delta));
  return {distance <= tolerance, distance};
}
}
'''.replace('FUNCTION', name)
    headers['original_' + family] = ('special', original)

started = time.monotonic()
results = []
with tempfile.TemporaryDirectory(prefix='tensor-fp32-mutations-', dir=ROOT / 'tensor-work') as temporary:
    work = Path(temporary)
    for name, (group, header) in [('clean_control', ('all', HEADER.read_text())), *headers.items()]:
        directory = work / name
        directory.mkdir()
        (directory / 'fp32_compare.h').write_text(header)
        binary = directory / 'comparator'
        argv = [COMPILER, '-std=c++17', '-Wall', '-Wextra', '-Werror', '-O2', '-DNDEBUG',
                '-fsanitize=undefined', '-fno-sanitize-recover=undefined', '-I', str(directory),
                str(TEST), '-o', str(binary)]
        compiled = subprocess.run(argv, cwd=directory, capture_output=True, text=True, timeout=10)
        assert compiled.returncode == 0, compiled.stderr
        groups = ['special', 'finite', 'zero', 'representation'] if group == 'all' else [group]
        if name.startswith('original_'):
            groups.append('finite')
        for current in groups:
            result = subprocess.run([str(binary), current], cwd=directory,
                                    capture_output=True, text=True, timeout=2)
            expected_success = name == 'clean_control'
            assert (result.returncode == 0) == expected_success, (name, result.stdout, result.stderr)
            if 'overflow' in name or (name.startswith('original_') and current == 'finite'):
                assert 'cannot be represented in type' in result.stderr, result.stderr
            if name != 'clean_control' and current == 'special':
                assert 'equal=1' in result.stderr and 'expected_equal=0' in result.stderr
            results.append({'variant': name, 'group': current, 'exit_code': result.returncode,
                            'expected_detection': not expected_success, 'observed_expected_result': True,
                            'stdout': result.stdout.strip(),
                            'stderr_excerpt': result.stderr[:1200].replace(str(work), '$MUTATION_WORK')})

report = {'scope': 'Host-only comparator regression mutation proof; no native RTL/GPU execution',
          'base_revision': BASE, 'original_functions': originals,
          'current_header_sha256': sha(HEADER), 'current_test_sha256': sha(TEST),
          'compiler': subprocess.check_output([COMPILER, '--version'], text=True).splitlines()[0],
          'compiler_flags': argv[1:9], 'duration_seconds': round(time.monotonic() - started, 6),
          'clean_control_groups': 4, 'mutant_groups_detected': 8,
          'all_expected_results': True, 'results': results}
(REPORTS / 'w03-a17-mutation-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key not in ('results', 'original_functions')}, indent=2))
