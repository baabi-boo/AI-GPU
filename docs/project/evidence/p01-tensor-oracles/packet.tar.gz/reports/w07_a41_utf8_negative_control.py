#!/usr/bin/env python3
"""Compare current and scratch-fixed UTF-8 failure reporting; no compilation."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path('<SOURCE>')
SCRATCH = Path('<WORK>')
REPORTS = SCRATCH / 'reports'
sys.path.insert(0, str(ROOT / 'ci/project'))
import baseline_process
import tensor_host_tools as original
import test_tensor_exact_cases as exact

source = ROOT / 'ci/project/tensor_host_tools.py'
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
assert source_hash == '8f1172c411aa72cae1368f0a2877aa6e5d3369cfd883131dedab987b375cbdcd'
fixed_path = REPORTS / 'w07_a41_tensor_host_tools_fixed.py'
spec = importlib.util.spec_from_file_location('w07_a41_tensor_host_tools_fixed', fixed_path)
fixed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixed)
real_tempdir = tempfile.TemporaryDirectory
real_run_bounded = baseline_process.run_bounded
results = []

for label, helper, expected_exception in (
    ('original_repository_helper', original, 'UnicodeDecodeError'),
    ('scratch_fixed_helper', fixed, 'AssertionError'),
):
    directories = []
    command_results = []
    observed_files = []
    def create_tempdir(*args, **kwargs):
        kwargs['dir'] = SCRATCH
        temporary = real_tempdir(*args, **kwargs)
        directories.append(Path(temporary.name))
        return temporary
    def record_run(*args, **kwargs):
        result = real_run_bounded(*args, **kwargs)
        command_results.append(result)
        observed_files.extend(p.name for p in Path(args[1]).iterdir())
        return result
    def compiler_substitute(argv, **kwargs):
        payload = "from pathlib import Path; import os; Path('compiler-artifact').write_text('created'); os.write(1, b'\\xffcompiler diagnostic\\n'); raise SystemExit(7)"
        kwargs['timeout'] = 3
        return helper.run_host_command([sys.executable, '-c', payload], **kwargs)
    with mock.patch.object(exact.shutil, 'which', return_value='/unused/compiler'), \
         mock.patch.object(exact.tempfile, 'TemporaryDirectory', side_effect=create_tempdir), \
         mock.patch.object(exact, 'run_host_command', side_effect=compiler_substitute), \
         mock.patch.object(helper, 'run_bounded', side_effect=record_run):
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(exact.TensorExactFixtureTests)
        result = unittest.TestResult()
        suite.run(result)
    assert len(result.errors) == 1 and len(result.skipped) == 0
    traceback = result.errors[0][1]
    assert expected_exception + ':' in traceback
    assert len(command_results) == 1
    command = command_results[0]
    assert command['outcome'] == 'fail' and command['reason'] == 'nonzero_exit'
    assert command['exit_code'] == 7 and command['cleanup_complete']
    assert len(directories) == 1 and not directories[0].exists()
    assert 'dump.cpp' in observed_files and 'compiler-artifact' in observed_files
    assert any(name.startswith('host-command-') and name.endswith('.log') for name in observed_files)
    if label == 'scratch_fixed_helper':
        assert 'AssertionError: Host command failed: nonzero_exit (exit 7)' in traceback
        assert '\ufffdcompiler diagnostic' in traceback
        assert 'UnicodeDecodeError' not in traceback
    else:
        assert 'Host command failed: nonzero_exit' not in traceback
    results.append({'variant': label, 'expected_exception': expected_exception,
        'exception_observed': expected_exception, 'outcome': 'expected_failure',
        'underlying_outcome': command['outcome'], 'underlying_reason': command['reason'],
        'exit_code': command['exit_code'], 'process_cleanup_complete': command['cleanup_complete'],
        'temporary_tree_removed': not directories[0].exists(),
        'temporary_files_observed_before_cleanup': observed_files,
        'reason_preserved_in_exception': 'Host command failed: nonzero_exit (exit 7)' in traceback,
        'replacement_character_preserved_in_diagnostic': '\ufffdcompiler diagnostic' in traceback,
        'traceback': traceback})

assert hashlib.sha256(source.read_bytes()).hexdigest() == source_hash
record = {'repository_source_sha256': source_hash,
          'scratch_fixed_sha256': hashlib.sha256(fixed_path.read_bytes()).hexdigest(),
          'repository_unchanged': True, 'probes': results,
          'native_identity_from_parent': 'ca8686d',
          'native_tests_run_by_this_review': False}
result_path = REPORTS / 'w07-a41-utf8-negative-control.json'
result_path.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'all_expected_outcomes_observed': True, 'probe_count': len(results),
    'original_exception': results[0]['exception_observed'],
    'corrected_exception': results[1]['exception_observed'],
    'corrected_reason_preserved': results[1]['reason_preserved_in_exception'],
    'cleanup_complete_for_both': all(p['process_cleanup_complete'] and p['temporary_tree_removed'] for p in results),
    'result_path': str(result_path)}, indent=2))
