import json
from pathlib import Path
import shlex
import subprocess
import tempfile

ROOT = Path('<WORKSPACE>')
SOURCE = ROOT / 'AI-GPU'
WORK = ROOT / 'tensor-work'
BODY = (SOURCE / 'hw/unittest/tcu_fedp/main.cpp').read_text()
GEN = WORK / 'build-fedp-rv64-n2/sw'

def section(start, end):
    return BODY[BODY.index(start):BODY.index(end)]

program = '''
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
#include "VX_config.h"
#define NUM_REGS 2
'''
program += section('enum class RoundingMode {', 'std::ostream &operator<<')
program += section('static bool is_mx_fmt(', '#ifndef SF')
program += section('static uint64_t parse_unsigned(', 'int main(int argc')
program += '''
int main(int argc, char** argv) {
  try {
    const auto config = parse_args(argc, argv);
    std::cout << "PARSED " << config.fmt_s << " " << config.ulp << "\\n";
    return 0;
  } catch (const std::exception& error) {
    std::cerr << error.what() << "\\n";
    return 1;
  }
}
'''
all_enables = ['TF32', 'FP8', 'FP4', 'MX', 'MXFP4', 'NVFP4', 'INT8', 'INT4']
variants = []
for backend in ('TFR', 'DPI', 'BHF', 'DSP', 'FPNEW'):
    base = {2, 3, 17, 18, 19, 20} if backend == 'DSP' else {2, 3}
    all_formats = ({1, 2, 3, 4, 5, 8, 9, 10, 11, 17, 18, 19, 20}
                   if backend in ('TFR', 'DPI') else
                   {1, 2, 3, 4, 5} if backend == 'BHF' else base)
    disabled = {2, 17, 18, 19, 20} if backend == 'DSP' else {2} if backend == 'BHF' else set()
    variants.extend([(backend + '-default', backend, [], base, False),
                     (backend + '-enabled', backend, all_enables, all_formats, False),
                     (backend + '-fp16-disabled', backend, ['!FP16'], disabled, False)])
for backend in ('TFR', 'DPI'):
    for name, flags, expected in (
        ('mx-only', ['MX'], {2, 3}),
        ('fp8-only', ['FP8'], {2, 3, 4, 5}),
        ('mx-fp8', ['MX', 'FP8'], {2, 3, 4, 5, 8, 9}),
        ('mx-fp4-base', ['MX', 'FP4'], {2, 3}),
        ('mx-fp4', ['MX', 'FP4', 'MXFP4'], {2, 3, 10}),
        ('nv-fp4', ['MX', 'FP4', 'NVFP4'], {2, 3, 11}),
        ('fp4-no-parent', ['MXFP4', 'NVFP4'], {2, 3}),
    ):
        variants.append((backend + '-' + name, backend, flags, expected, False))
variants.append(('TFR-fedp-reference', 'TFR', all_enables,
                 {1, 2, 3, 4, 5, 8, 9, 10, 11, 17, 18, 19, 20}, True))
results = []
with tempfile.TemporaryDirectory(prefix='fedp-format-host-', dir=WORK) as temporary:
    temporary = Path(temporary)
    translation = temporary / 'production-parser.cpp'
    translation.write_text(program)
    for name, backend, features, supported, use_fedp in variants:
        flags = ['-DVX_CFG_XLEN=64', '-DVX_CFG_EXT_TCU_ENABLE', '-DVX_CFG_TCU_TYPE=' + backend]
        for feature in features:
            flags.append('-DVX_CFG_TCU_' + (feature[1:] + '_DISABLE' if feature.startswith('!') else feature + '_ENABLE'))
        resolved = subprocess.run(['python3', str(SOURCE / 'ci/gen_config.py'),
            '--config=' + str(SOURCE / 'VX_config.toml'), '--cflags=' + ' '.join(flags)],
            text=True, capture_output=True, timeout=5)
        assert resolved.returncode == 0, (name, resolved.stderr)
        selectors = [flag for flag in shlex.split(resolved.stdout) if flag.startswith('-DVX_CFG_TCU_TYPE_')]
        assert selectors == ['-DVX_CFG_TCU_TYPE_' + backend], (name, selectors)
        binary = temporary / name
        command = ['g++', '-std=c++17', '-Wall', '-Wextra', '-Werror', '-O1',
                   '-fsanitize=undefined', '-fno-sanitize-recover=undefined',
                   '-I', str(GEN), *flags, *selectors,
                   *(['-DUSE_FEDP'] if use_fedp else []), str(translation), '-o', str(binary)]
        build = subprocess.run(command, text=True, capture_output=True, timeout=30)
        assert build.returncode == 0, (name, build.stderr)
        for fmt in range(21):
            run = subprocess.run([str(binary), f'--fmt={fmt}', '--W=25', '--features=normals',
                                  '--sparsity=100', '--tests=1', '--no-trace'],
                                 text=True, capture_output=True, timeout=5)
            accepted = fmt in supported
            assert (run.returncode == 0) == accepted, (name, fmt, run.stdout, run.stderr)
            if accepted:
                assert run.stdout.strip() == f'PARSED {fmt} 1', (name, fmt, run.stdout)
            else:
                assert 'PARSED' not in run.stdout, (name, fmt, run.stdout)
                assert any(text in run.stderr for text in ('unavailable', 'Unsupported source', 'MX source'))
            results.append({'variant': name, 'format': fmt, 'expected_accept': accepted,
                            'exit_code': run.returncode, 'pass': True})
report = {'scope': 'Host-only extracted production parser with generated VX_config.h and resolved enum selectors; no numerical or RTL evidence',
          'variants': len(variants), 'checks': len(results), 'results': results}
path = WORK / 'reports/w05-a30-host-results.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'variants': len(variants), 'checks': len(results), 'all_passed': True, 'report': str(path)}))
