#!/usr/bin/env python3
"""Host-only isolated parser diagnostic check; never edits or builds the repo."""

import difflib
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess

ROOT = Path('<WORKSPACE>')
REPO = ROOT / 'AI-GPU'
SOURCE = REPO / 'hw/unittest/tcu_unit/main.cpp'
GEN = ROOT / 'tensor-work/final-matrix-20ea50d/builds/wmma-rv64-t8-tfr/sw/VX_config.h'
OUT = ROOT / 'tensor-work/w07-a37-diagnostic'
REPORTS = ROOT / 'tensor-work/reports'
OUT.mkdir(exist_ok=True)
(OUT / 'build').mkdir(exist_ok=True)
(OUT / 'include').mkdir(exist_ok=True)

body = SOURCE.read_text()
before_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
shutil.copyfile(GEN, OUT / 'include/VX_config.h')

old = '''    const char *formats[] = {"FP32", "TF32", "FP16", "BF16"};
    throw std::invalid_argument("--fmt=" + std::to_string(cfg.fmt_s) + " selects "
        + formats[cfg.fmt_s] + ", which is unavailable in this compiled WMMA configuration");'''
new = '''    const char *format_name = "unknown";
    switch (cfg.fmt_s) {
    case TCU_TF32_ID: format_name = "TF32"; break;
    case TCU_FP16_ID: format_name = "FP16"; break;
    case TCU_BF16_ID: format_name = "BF16"; break;
    default: break;
    }
    throw std::invalid_argument("--fmt=" + std::to_string(cfg.fmt_s) + " selects "
        + format_name + ", which is unavailable in this compiled WMMA configuration");'''
assert body.count(old) == 1
patched = body.replace(old, new)
patch = ''.join(difflib.unified_diff(
    body.splitlines(keepends=True), patched.splitlines(keepends=True),
    fromfile='a/hw/unittest/tcu_unit/main.cpp',
    tofile='b/hw/unittest/tcu_unit/main.cpp'))
(REPORTS / 'w07_a37_diagnostic.patch').write_text(patch)


def section(text, start, end):
    begin = text.index(start)
    return text[begin:text.index(end, begin)]


def extract(text):
    result = '''#include <charconv>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include "VX_config.h"
'''
    result += section(text, '// TCU format IDs', '// WMMA op_type')
    result += section(text, 'enum class RoundingMode', '// ---- Test value generation')
    result += section(text, 'template <typename T>\nstatic T parse_number', 'int main(int argc')
    result += '''int main(int argc, char **argv) {
  TestConfig cfg;
  try {
    cfg = parse_args(argc, argv);
  } catch (const std::exception &error) {
    std::cerr << "Invalid test configuration: " << error.what() << '\\n';
    return 2;
  }
  std::cout << "PARSED fmt=" << cfg.fmt_s << " tests=" << cfg.num_tests
            << " test=" << cfg.test_id << " trace=" << cfg.enable_trace << '\\n';
  return 0;
}
'''
    return result


for name, text in [('original', body), ('fixed', patched)]:
    (OUT / (name + '.cpp')).write_text(extract(text))

compiler = shutil.which('g++')
common = [compiler, '-std=c++17', '-Wall', '-Wextra', '-Wfatal-errors', '-Werror',
          '-fPIC', '-DUSE_FEDP', '-DVX_CFG_XLEN=64', '-DVX_CFG_XLEN_64',
          '-DSIMULATION', '-DSV_DPI', '-DVX_CFG_EXT_TCU_ENABLE',
          '-DVX_CFG_ISSUE_WIDTH=1', '-DVX_CFG_TCU_TYPE_TFR',
          '-DVX_CFG_NUM_THREADS=8', '-I', str(OUT / 'include')]
variants = {
    'tfr-default': [],
    'tfr-all-source-formats': ['-DVX_CFG_TCU_TF32_ENABLE'],
    'tfr-no-source-formats': ['-DVX_CFG_TCU_FP16_DISABLE'],
}
optimizations = {'O0': ['-O0', '-DNDEBUG'], 'Os': ['-Os', '-DNDEBUG'],
                 'O2': ['-O2', '-DNDEBUG'],
                 'native-order': ['-O2', '-DNDEBUG', '-Os']}
record = {
    'scope': 'Host-only extracted production parser; no native build, RTL execution, repository mutation or Git commands.',
    'assigned_revision': '20ea50d (root-provided frozen revision; not queried with Git)',
    'compiler': subprocess.run([compiler, '--version'], text=True, capture_output=True, check=True).stdout,
    'compiler_target': subprocess.run([compiler, '-dumpmachine'], text=True, capture_output=True, check=True).stdout.strip(),
    'source': str(SOURCE), 'source_sha256_before': before_hash,
    'generated_config': str(GEN),
    'generated_config_sha256': hashlib.sha256((OUT / 'include/VX_config.h').read_bytes()).hexdigest(),
    'patch': str(REPORTS / 'w07_a37_diagnostic.patch'),
    'compiles': [], 'runtime_checks': [],
}
commands = []
binaries = {}
for variant, flags in variants.items():
    for version in ('original', 'fixed'):
        for optimization, opts in optimizations.items():
            if optimization == 'O0' and version == 'fixed':
                continue
            if optimization == 'native-order' and variant != 'tfr-all-source-formats':
                continue
            key = f'{version}-{variant}-{optimization}'
            binary = OUT / 'build' / key
            command = common + flags + opts + [str(OUT / (version + '.cpp')), '-o', str(binary)]
            completed = subprocess.run(command, cwd=OUT / 'build', capture_output=True, text=True, timeout=30)
            log = OUT / (key + '.log')
            log.write_text('$ ' + shlex.join(command) + '\n' + completed.stdout + completed.stderr)
            entry = {'key': key, 'version': version, 'variant': variant,
                     'optimization': optimization, 'command': command,
                     'exit_code': completed.returncode, 'stdout': completed.stdout,
                     'stderr': completed.stderr, 'log': str(log)}
            record['compiles'].append(entry)
            commands.append(shlex.join(command))
            print(f'{key}: exit={completed.returncode}', flush=True)
            if completed.returncode == 0:
                binaries[(version, variant, optimization)] = binary

control_source = next(item for item in record['compiles']
                      if item['key'] == 'original-tfr-all-source-formats-O2')
control_command = list(control_source['command'])
position = control_command.index('-O2')
control_command[position:position] = ['-fsanitize=undefined', '-fno-sanitize-recover=undefined']
control_command[-1] += '-ubsan-control'
control = subprocess.run(control_command, cwd=OUT / 'build', capture_output=True,
                         text=True, timeout=30)
control_log = OUT / 'original-tfr-all-source-formats-O2-ubsan-control.log'
control_log.write_text('$ ' + shlex.join(control_command) + '\n' + control.stdout + control.stderr)
record['diagnostic_controls'] = [{
    'purpose': 'Check prior a20 UBSan instrumentation difference without suppressing warnings',
    'command': control_command, 'exit_code': control.returncode,
    'stdout': control.stdout, 'stderr': control.stderr, 'log': str(control_log)}]
commands.append(shlex.join(control_command))

cases = [[], ['--fmt=0'], ['--fmt=1'], ['--fmt=2'], ['--fmt=3'],
         ['--fmt=4'], ['--fmt=4294967295'], ['--fmt=4294967296'], ['--fmt=-1'],
         ['--fmt='], ['--fmt=1x'], ['--fmt=3', '--fmt=1'],
         ['--frm=RTZ'], ['--W=24'], ['--test=1', '--tests=1']]
for variant in variants:
    reference_binary = binaries[('original', variant, 'O0')]
    for optimization in ('Os', 'O2', 'native-order'):
        binary = binaries.get(('fixed', variant, optimization))
        if binary is None:
            continue
        for args in cases:
            suffix = ['--features=zeros', '--tests=1', '--no-trace']
            reference = subprocess.run([str(reference_binary), *args, *suffix],
                                       cwd=OUT / 'build', capture_output=True, text=True, timeout=5)
            fixed = subprocess.run([str(binary), *args, *suffix],
                                   cwd=OUT / 'build', capture_output=True, text=True, timeout=5)
            equivalent = (reference.returncode, reference.stdout, reference.stderr) == (
                fixed.returncode, fixed.stdout, fixed.stderr)
            record['runtime_checks'].append({
                'variant': variant, 'optimization': optimization,
                'arguments': args + suffix, 'equivalent': equivalent,
                'reference_exit_code': reference.returncode, 'fixed_exit_code': fixed.returncode,
                'reference_stdout': reference.stdout, 'fixed_stdout': fixed.stdout,
                'reference_stderr': reference.stderr, 'fixed_stderr': fixed.stderr})
            assert equivalent, (variant, optimization, args, reference, fixed)

record['source_sha256_after'] = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
record['source_unchanged'] = record['source_sha256_after'] == before_hash
record['fixed_builds_passed_without_diagnostics'] = all(
    result['exit_code'] == 0 and not result['stdout'] and not result['stderr']
    for result in record['compiles'] if result['version'] == 'fixed')
record['runtime_checks_passed'] = all(result['equivalent'] for result in record['runtime_checks'])
(OUT / 'commands.txt').write_text('\n'.join(commands) + '\n')
(REPORTS / 'w07-a37-host-results.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'compiles': len(record['compiles']),
                  'fixed_builds_passed_without_diagnostics': record['fixed_builds_passed_without_diagnostics'],
                  'runtime_checks': len(record['runtime_checks']),
                  'runtime_checks_passed': record['runtime_checks_passed'],
                  'source_unchanged': record['source_unchanged']}), flush=True)
assert record['source_unchanged']
assert record['fixed_builds_passed_without_diagnostics']
