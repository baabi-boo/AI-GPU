#!/usr/bin/env python3
"""Refresh the scratch agent ledger from real assignments and retained reports.

Run only after the parent has verified that every assignment in the prefix has
finished. Report existence alone is never treated as completion:

  python3 -B finalize_ledger.py --completed-through 48
  python3 -B finalize_ledger.py --completed-through 60

The second command is valid only after all 60 actual canonical assignments and
the final report of agent 60 exist. This tool does not create reports, infer
completion from session-state fields, run builds/Git, or modify the repository.
The packet builder handles publication path substitution separately; SHA-256
values here always describe the original raw input bytes.

Optional --summaries JSON maps IDs >= 37 to a short parent-provided result string
or an object with "result" and optionally "scope". Roles always come from the
actual canonical task. IDs 1--36 retain the existing ledger's scoped wording.
"""

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile


TARGET = 60
WAVE_SIZE = 6
WORK_ROOT = Path(__file__).resolve().parent
TASK_RE = re.compile(r"/root/w(?P<wave>\d{2})_a(?P<id>\d{2})_(?P<role>[a-z0-9]+(?:_[a-z0-9]+)*)\Z")
PRESERVED_KEYS = ("role", "scope", "result", "evidence_kind", "evidence_note")
ACRONYMS = {"ci": "CI", "cli": "CLI", "fedp": "FEDP", "wmma": "WMMA",
            "utf8": "UTF-8", "fp32": "FP32", "fp16": "FP16", "bf16": "BF16"}


class LedgerError(Exception):
    """Reject incomplete or inconsistent evidence before writing a ledger."""


def require(condition, message):
    if not condition:
        raise LedgerError(message)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def utc(timestamp=None):
    value = datetime.now(timezone.utc) if timestamp is None else datetime.fromtimestamp(timestamp, timezone.utc)
    return value.isoformat(timespec="microseconds").replace("+00:00", "Z")


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON key: {key!r}")
        result[key] = value
    return result


def parse_json(raw, path):
    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise LedgerError(f"invalid UTF-8 JSON in {path}: {error}") from error


def file_identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


class Inputs:
    def __init__(self):
        self.snapshots = {}

    def read(self, path):
        path = Path(path).absolute()
        require(not path.is_symlink(), f"symlink is not a retained raw input: {path}")
        try:
            with path.open("rb") as stream:
                before = os.fstat(stream.fileno())
                require(stat.S_ISREG(before.st_mode), f"not a regular file: {path}")
                require(before.st_size <= 4 * 1024 * 1024, f"unexpectedly large ledger input: {path}")
                raw = stream.read(4 * 1024 * 1024 + 1)
                after = os.fstat(stream.fileno())
        except OSError as error:
            raise LedgerError(f"cannot read required input {path}: {error}") from error
        require(file_identity(before) == file_identity(after) and len(raw) == before.st_size,
                f"input changed while reading: {path}")
        self.snapshots[path] = file_identity(after)
        return raw, after

    def unchanged(self):
        for path, identity in self.snapshots.items():
            try:
                current = path.stat()
            except OSError as error:
                raise LedgerError(f"input disappeared before publication: {path}") from error
            require(not path.is_symlink() and file_identity(current) == identity,
                    f"input changed before publication; rerun against a stable snapshot: {path}")


def assignments_from_state(state):
    waves = state.get("waves")
    require(isinstance(waves, list) and waves, "session state has no actual assignment waves")
    assigned, tasks = {}, set()
    for position, wave in enumerate(waves, 1):
        require(isinstance(wave, dict), "each wave must be an object")
        number, agents = wave.get("wave"), wave.get("agents")
        require(type(number) is int and number == position and 1 <= number <= 10,
                "session-state waves must be unique, ordered and contiguous from 1 through at most 10")
        require(isinstance(agents, list) and 1 <= len(agents) <= WAVE_SIZE,
                f"wave {number} must contain 1--6 actual assignments")
        require(position == len(waves) or len(agents) == WAVE_SIZE,
                f"wave {number} is incomplete before a later wave")
        for offset, value in enumerate(agents, 1):
            require(isinstance(value, str), f"wave {number} contains a non-string task")
            task = value if value.startswith("/root/") else "/root/" + value
            match = TASK_RE.fullmatch(task)
            require(match is not None, f"invalid actual canonical task: {task!r}")
            agent_id, task_wave = int(match["id"]), int(match["wave"])
            expected = (number - 1) * WAVE_SIZE + offset
            require(agent_id == expected and task_wave == number,
                    f"canonical task does not match its wave/slot: {task}")
            require(agent_id not in assigned and task not in tasks, f"duplicate assignment: {task}")
            assigned[agent_id] = task
            tasks.add(task)
    require(sorted(assigned) == list(range(1, len(assigned) + 1)), "actual assignment IDs are not contiguous")
    return assigned


def readable_role(task):
    words = TASK_RE.fullmatch(task)["role"].split("_")
    return " ".join(ACRONYMS.get(word, word.capitalize() if i == 0 else word)
                    for i, word in enumerate(words))


def plain_inline(value):
    # Preserve meaning but prevent report-local Markdown links from becoming
    # broken links when the ledger is copied beside the published packet.
    value = re.sub(r"!?\[([^\]]+)\]\([^)]*\)", r"\1", value)
    value = value.replace("**", "").replace("__", "").replace("`", "")
    return re.sub(r"\s+", " ", value).strip()


def report_excerpt(text):
    paragraphs, lines, in_code, heading = [], [], False, ""

    def flush():
        if lines:
            paragraphs.append((heading, plain_inline(" ".join(lines))))
            lines.clear()

    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(("```", "~~~")):
            flush()
            in_code = not in_code
        elif in_code:
            continue
        elif stripped.startswith("#"):
            flush()
            heading = plain_inline(stripped.lstrip("# "))
        elif not stripped or stripped.startswith("|") or re.fullmatch(r"[-*_]{3,}", stripped):
            flush()
        else:
            lines.append(re.sub(r"^[-*+]\s+", "", stripped))
    flush()
    require(bool(paragraphs), "retained report contains no substantive text")
    substantive = [(h, p) for h, p in paragraphs
                   if not re.match(r"(?i)(status|assignment|agent|wave|task)\s*:", p)]
    paragraphs = substantive or paragraphs
    candidates = [p for h, p in paragraphs if re.match(r"(?i)final disposition\s*:", p)]
    if not candidates:
        candidates = [p for h, p in paragraphs if re.match(r"(?i)verdict\s*:", p)]
    if not candidates:
        candidates = [p for h, p in paragraphs if re.match(r"(?i)(verdict|result|conclusion)\b", h)]
    value = (candidates or [p for h, p in paragraphs])[0]
    # A compact excerpt is explicitly attributed; the complete report, including
    # qualifications after the excerpt, remains the authoritative retained text.
    sentence = re.search(r"[.!?](?=\s|$)", value)
    if sentence:
        value = value[:sentence.end()]
    if len(value) > 450:
        value = value[:447].rsplit(" ", 1)[0] + "…"
    return value


def load_summaries(path, inputs):
    if path is None:
        return {}, None
    raw, info = inputs.read(path)
    parsed = parse_json(raw, path)
    require(isinstance(parsed, dict), "--summaries must contain a JSON object keyed by agent ID")
    result = {}
    for key, value in parsed.items():
        require(re.fullmatch(r"[0-9]+", key) is not None and 37 <= int(key) <= TARGET,
                f"parent summaries may override only IDs 37--60: {key!r}")
        value = {"result": value} if isinstance(value, str) else value
        require(isinstance(value, dict) and set(value) <= {"result", "scope"} and "result" in value,
                f"summary {key} needs result and optional scope only")
        require(all(isinstance(text, str) and text.strip() for text in value.values()),
                f"summary {key} contains empty or non-string text")
        result[int(key)] = value
    return result, {"path": str(Path(path).absolute()), "raw_sha256": sha256(raw),
                    "source_mtime_utc": utc(info.st_mtime)}


def prepare(args):
    inputs = Inputs()
    work = args.work_root.absolute()
    state_path = args.session_state or work / "session-state.json"
    template_path = args.template or work / "drafts" / "agents.json"
    state_raw, state_info = inputs.read(state_path)
    template_raw, _ = inputs.read(template_path)
    state, template = parse_json(state_raw, state_path), parse_json(template_raw, template_path)
    require(isinstance(state, dict) and isinstance(template, dict), "state and template must be objects")
    assigned = assignments_from_state(state)
    require(36 <= args.completed_through <= TARGET,
            "--completed-through must be 36--60; the preserved first 36 assignments are already completed")
    require(args.completed_through <= len(assigned),
            f"completion prefix {args.completed_through} exceeds {len(assigned)} actual canonical assignments")
    old_agents = template.get("agents")
    require(isinstance(old_agents, list), "template has no agents list")
    require(all(isinstance(a, dict) and type(a.get("id")) is int for a in old_agents),
            "template agents must have integer IDs")
    original = {a["id"]: a for a in old_agents}
    require(len(original) == len(old_agents), "duplicate IDs in template")
    require(all(i in original for i in range(1, 37)), "template is missing an original first-36 scoped summary")
    summaries, summary_source = load_summaries(args.summaries, inputs)
    require(all(i in assigned for i in summaries), "parent summary supplied for a task that has not been assigned")
    records, preserved = [], []
    for agent_id in range(1, TARGET + 1):
        wave, batch = (agent_id - 1) // WAVE_SIZE + 1, ((agent_id - 1) % WAVE_SIZE) // 3 + 1
        task = assigned.get(agent_id)
        if task is None:
            records.append({"id": agent_id, "wave": wave, "logical_batch": batch,
                            "canonical_task": None, "role": None, "status": "pending_not_spawned",
                            "scope": None, "result": "Not spawned at this snapshot; no result or completion is claimed.",
                            "evidence_kind": "planned_slot_only", "report_path": None,
                            "report_archive_member": None, "report_sha256": None,
                            "evidence_note": "Reserved target slot, not an actual assignment."})
            continue
        completed = agent_id <= args.completed_through
        if agent_id <= 36:
            record = copy.deepcopy(original[agent_id])
            require(record.get("canonical_task") == task, f"preserved summary/task mismatch for agent {agent_id}")
            require(all(key in record for key in PRESERVED_KEYS), f"incomplete preserved summary for agent {agent_id}")
            preserved.append({"id": agent_id, **{key: record[key] for key in PRESERVED_KEYS}})
        else:
            role = readable_role(task)
            record = {"role": role, "role_source": "actual_canonical_task_suffix",
                      "scope": f"{role} assignment; the full retained report defines its detailed scope and qualifications.",
                      "result": "Assigned; completion is outside the root-attested prefix for this snapshot.",
                      "evidence_kind": "actual_dispatch_only",
                      "evidence_note": "Actual dispatch comes from session state; report existence does not attest completion."}
        record.update({"id": agent_id, "wave": wave, "logical_batch": batch,
                       "canonical_task": task, "status": "completed" if completed else "in_progress",
                       "report_path": None, "report_archive_member": None, "report_sha256": None})
        if agent_id <= 6:
            require(record.get("evidence_kind") == "parent_summary", f"agent {agent_id} must retain parent-summary provenance")
        else:
            member = f"reports/w{wave:02d}_a{agent_id:02d}.md"
            report_path = work / member
            require(not completed or report_path.is_file(),
                    f"completed agent {agent_id} lacks its retained report: {member}")
            if report_path.exists():
                raw, _ = inputs.read(report_path)
                try:
                    report = raw.decode("utf-8")
                except UnicodeDecodeError as error:
                    raise LedgerError(f"report is not UTF-8: {member}") from error
                require(report.strip(), f"empty retained report: {member}")
                record.update({"report_path": str(report_path), "report_archive_member": member,
                               "report_sha256": sha256(raw)})
                if agent_id >= 37:
                    record["evidence_kind"] = "retained_report" if completed else "retained_report_unattested"
                    record["evidence_note"] = (
                        "Summary is attributed to the full retained report, whose qualifications remain controlling; "
                        "the ledger finalizer did not rerun its checks. Raw report SHA-256 precedes publication path substitution."
                    )
                    if completed:
                        if agent_id in summaries:
                            record.update(summaries[agent_id])
                            record["result"] = "Parent-provided summary of retained report: " + record["result"]
                            record["result_summary_source"] = "explicit_parent_summary"
                        else:
                            record["result"] = "Retained report excerpt: " + report_excerpt(report)
                            record["result_summary_source"] = "leading_verdict_or_first_substantive_paragraph"
        records.append(record)
    counts = {"actual_assignments": len(assigned), "completed_assignments": args.completed_through,
              "in_progress_assignments": len(assigned) - args.completed_through,
              "pending_unspawned_slots": TARGET - len(assigned)}
    wave_counts = [{"wave": wave, "target_slots": WAVE_SIZE,
                    "actual_assignments": sum(a["canonical_task"] is not None for a in records if a["wave"] == wave),
                    "completed_assignments": sum(a["status"] == "completed" for a in records if a["wave"] == wave),
                    "in_progress_assignments": sum(a["status"] == "in_progress" for a in records if a["wave"] == wave),
                    "pending_unspawned_slots": sum(a["status"] == "pending_not_spawned" for a in records if a["wave"] == wave)}
                   for wave in range(1, 11)]
    revision_key = next((key for key in ("latest_source_commit", "final_source_commit", "implementation_commit", "base_commit")
                         if state.get(key)), None)
    require(revision_key is not None, "session state has no recorded source revision")
    source = {"session_state_path": str(state_path.absolute()), "session_state_archive_member": "session-state.json",
              "session_state_sha256": sha256(state_raw), "session_state_mtime_utc": utc(state_info.st_mtime),
              "retained_report_root": str(work / "reports"),
              "source_revision_recorded_in_session_state": state[revision_key], "source_revision_key": revision_key,
              "recorded_source_identities": {key: state[key] for key in (
                  "base_commit", "implementation_commit", "implementation_tree", "final_source_commit", "final_source_tree",
                  "latest_source_commit", "latest_source_tree", "prepared_remote_source") if key in state},
              "recorded_test_revisions": {key: state[key].get("revision") for key in (
                  "native_final", "governance_final", "host_followup") if isinstance(state.get(key), dict)},
              "note": "Current session-state bytes and file modification time were read for this generation. "
                      "Recorded revision labels are attributed to session state; no Git identity or test was rerun."}
    ledger = {
        "schema_version": 2,
        "document_status": "complete_assignment_ledger" if args.completed_through == TARGET else "partial_assignment_ledger",
        "snapshot_utc": utc(),
        "generated_by": {"tool": "finalize_ledger.py", "tool_author_task": "/root/w09_a50_ledger_finalize_tool"},
        "target": {"agents": TARGET, "logical_waves": 10, "agents_per_logical_wave": WAVE_SIZE},
        "counts": counts,
        "status_semantics": {"completed": "Parent explicitly attests completion through the supplied prefix; agents 7+ also have retained reports.",
                             "in_progress": "Actually assigned, but completion is not attested by this generation's prefix; a retained report alone is insufficient.",
                             "pending_not_spawned": "Target slot only; absent from actual session-state assignments."},
        "completion_attestation": {"source": "Explicit parent --completed-through argument; session-state completion fields are not used.",
                                   "completed_through": args.completed_through,
                                   "report_required_from_agent": 7},
        "scheduling": {"max_concurrent_subagents": 3, "root_plus_subagent_capacity": 4,
                       "batches_per_logical_wave": 2, "max_subagents_per_batch": 3, "strict_wave_barrier": False,
                       "description": "Ten logical waves group six target slots each. Capacity is three concurrent subagents beside root. "
                                      "The two logical batches per wave group slots, not a timestamped execution trace. "
                                      "Review and handoff work can overlap across waves; there are no strict wave barriers or six-way concurrency claims."},
        "evidence_policy": [
            "Completed means an assignment finished, not that every reviewed experiment passed or that a project gate closed.",
            "Agents 1–6 retain explicit parent summaries; no original self-authored reports are claimed.",
            "Agents 1–36 retain the earlier scoped role/result wording. Their raw report hashes are refreshed from current retained bytes.",
            "Agents 37+ use actual canonical task roles and attributed report excerpts or explicit parent summaries. Consult each full report for scope and qualifications.",
            "Host, extracted-parser, stub, preliminary-native and frozen-matrix evidence remain distinct; historical failed packets remain failed.",
            "Only actual dispatches appear as assignments. Target slots and report existence cannot manufacture completion.",
            "This ledger does not establish hosted CI, vendor hw_emu, FPGA, silicon, P01 completion or P02 start.",
            "Raw SHA-256 values identify retained inputs. The packet index separately binds raw bytes to path-substituted archive members.",
        ],
        "source_snapshot": source,
        "preserved_summary_provenance": {"author_task": "/root/w07_a39_ledger_draft", "agent_ids": list(range(1, 37)),
                                         "preserved_fields": list(PRESERVED_KEYS),
                                         "scoped_summary_sha256": sha256(json_bytes(preserved)),
                                         "input_ledger_raw_sha256": sha256(template_raw)},
        "parent_summary_source": summary_source,
        "wave_counts": wave_counts,
        "parent_update_instructions": [
            "Update session-state waves only with actual canonical assignments, and retain each completed report before advancing --completed-through.",
            "After agent 60 returns its final report, let the parent run --completed-through 60 and then build the packet. Do not fabricate a self-completion or embed the final ledger's own hash in agent 60's report.",
            "If any report or session-state input changes, rerun the finalizer before rebuilding the packet; the packet builder performs publication path substitution and records both raw and published hashes.",
        ],
        "agents": records,
    }
    require(len(records) == TARGET and [a["id"] for a in records] == list(range(1, TARGET + 1)), "invalid generated IDs")
    require(sum(counts[k] for k in ("completed_assignments", "in_progress_assignments")) == counts["actual_assignments"], "invalid assigned count")
    require(counts["actual_assignments"] + counts["pending_unspawned_slots"] == TARGET, "invalid slot count")
    require(all(sum(a["wave"] == w for a in records) == WAVE_SIZE for w in range(1, 11)), "invalid six-slot wave mapping")
    for key in counts:
        require(sum(w[key] for w in wave_counts) == counts[key], f"wave/global count mismatch: {key}")
    return ledger, inputs


def markdown_cell(value):
    return plain_inline(str(value)).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("|", "\\|")


def render_markdown(ledger):
    counts, source = ledger["counts"], ledger["source_snapshot"]
    lines = ["# Agent assignment ledger", "", f"Snapshot UTC: `{ledger['snapshot_utc']}`.", "",
             f"**{counts['actual_assignments']} actual assignments; {counts['completed_assignments']} completed; "
             f"{counts['in_progress_assignments']} assigned without completion attestation; "
             f"{counts['pending_unspawned_slots']} unspawned target slots.**", "",
             "The target is 60 assignments in ten logical waves of six. The table includes unspawned target slots explicitly. "
             "Completed describes an assignment, not a passing experiment or phase closure.", "",
             "## Scheduling and evidence", "", ledger["scheduling"]["description"], "",
             "Completion comes only from the parent's explicit `--completed-through` cutoff plus retained reports for agents 7 onward. "
             "An assigned row beyond that cutoff is unconfirmed even if a report is already present. Agents 1–6 use the original parent summaries.", "",
             "The earlier scoped wording for agents 1–36 is preserved. Later brief results are attributed excerpts or parent summaries; "
             "the full reports retain all qualifications. Historical host, stub, preliminary and failed-run results are not promoted to final native passes. "
             "No hosted CI, vendor hardware, P01 closure or P02-start claim follows from this ledger.", "",
             "Full reports are named by archive member below. Obtain them from [packet.tar.gz](packet.tar.gz) and use [index.json](index.json) "
             "to map original raw hashes to published members. Report paths are archive member names, not local hyperlinks. "
             "The JSON ledger records every raw report SHA-256; path-substituted published bytes can have different hashes.", "",
             "## Counts by logical wave", "", "| Wave | Target slots | Assigned | Completed | Completion unconfirmed | Unspawned |",
             "| --- | ---: | ---: | ---: | ---: | ---: |"]
    for wave in ledger["wave_counts"]:
        lines.append(f"| {wave['wave']} | 6 | {wave['actual_assignments']} | {wave['completed_assignments']} | {wave['in_progress_assignments']} | {wave['pending_unspawned_slots']} |")
    lines += ["", "## Assignments", ""]
    for wave in range(1, 11):
        lines += [f"### Wave {wave}", "", "| ID / logical batch | Canonical task and role | Status | Scope and attributed result | Report provenance |",
                  "| --- | --- | --- | --- | --- |"]
        for record in (a for a in ledger["agents"] if a["wave"] == wave):
            task = f"`{record['canonical_task']}`; {markdown_cell(record['role'])}" if record["canonical_task"] else "Unspawned target slot"
            status = {"completed": "Completed assignment", "in_progress": "Assigned; completion unconfirmed", "pending_not_spawned": "Pending; not spawned"}[record["status"]]
            details = markdown_cell(((record["scope"] + " ") if record["scope"] else "") + record["result"])
            member = record["report_archive_member"]
            provenance = f"`{member}`; raw hash in JSON" if member else ("Explicit parent summary; original report not retained" if record["id"] <= 6 else "No retained report claimed")
            lines.append(f"| {record['id']} / {record['logical_batch']} | {task} | {status} | {details} | {provenance} |")
        lines.append("")
    lines += ["## Current source snapshot", "",
              f"- Session-state member: `{source['session_state_archive_member']}`.",
              f"- Raw session-state SHA-256: `{source['session_state_sha256']}`.",
              f"- Session-state file modification UTC: `{source['session_state_mtime_utc']}`.",
              f"- Current recorded source revision: `{source['source_revision_recorded_in_session_state']}` from `{source['source_revision_key']}`.",
              f"- Ledger generated UTC: `{ledger['snapshot_utc']}`.", "", source["note"], "",
              "Native, governance and host-follow-up revisions remain separately recorded in the JSON ledger; a later source label does not inherit an earlier test execution.", "",
              "## Parent finalization", ""]
    lines.extend("- " + instruction for instruction in ledger["parent_update_instructions"])
    lines.append("")
    result = "\n".join(lines)
    links = re.findall(r"\]\(([^)]+)\)", result)
    require(links == ["packet.tar.gz", "index.json"], "generated Markdown contains an unexpected hyperlink")
    return result.encode("utf-8")


def write_outputs(directory, payloads, inputs):
    directory.mkdir(parents=True, exist_ok=True)
    temporary = []
    try:
        for name, data in payloads.items():
            descriptor, filename = tempfile.mkstemp(prefix=f".{name}.", suffix=".tmp", dir=directory)
            temporary.append((Path(filename), directory / name))
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
        inputs.unchanged()
        for temporary_path, destination in temporary:
            os.replace(temporary_path, destination)
    finally:
        for temporary_path, _ in temporary:
            temporary_path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--completed-through", type=int, required=True, help="parent-verified completed prefix, 36--60")
    parser.add_argument("--work-root", type=Path, default=WORK_ROOT)
    parser.add_argument("--session-state", type=Path, help="default: WORK_ROOT/session-state.json")
    parser.add_argument("--template", type=Path, help="default: WORK_ROOT/drafts/agents.json; preserve its first-36 scoped summaries")
    parser.add_argument("--output-dir", type=Path, help="default: WORK_ROOT/drafts")
    parser.add_argument("--summaries", type=Path, help="optional explicit parent summaries for agents 37 onward")
    parser.add_argument("--check-only", action="store_true", help="validate inputs and generated content without writing outputs")
    args = parser.parse_args()
    try:
        ledger, inputs = prepare(args)
        payloads = {"agents.json": json_bytes(ledger), "agents.md": render_markdown(ledger)}
        inputs.unchanged()
        output = (args.output_dir or args.work_root / "drafts").absolute()
        if not args.check_only:
            write_outputs(output, payloads, inputs)
        print(json.dumps({"outcome": "validated" if args.check_only else "written", "counts": ledger["counts"],
                          "snapshot_utc": ledger["snapshot_utc"],
                          "session_state_sha256": ledger["source_snapshot"]["session_state_sha256"],
                          "output_dir": str(output),
                          "retained_report_count": sum(a["report_sha256"] is not None for a in ledger["agents"]),
                          "completed_report_count": sum(a["status"] == "completed" and a["report_sha256"] is not None for a in ledger["agents"])}))
    except (LedgerError, OSError) as error:
        print(f"ledger finalization failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
