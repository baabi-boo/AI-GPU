import json, os, sys, tempfile
from pathlib import Path
import run_final_matrix as matrix
from tensor_host_tools import run_host_command

revision='a25ee6663e37d5fe28e7a6fd40b3857083ddeecc'
source, work=matrix.SOURCE,matrix.WORK
matrix.source_guard(revision)
packet=work/'host-followup-a25ee66'
packet.mkdir()
(packet/'tmp').mkdir()
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','LC_ALL':'C','TMPDIR':str(packet/'tmp')}
report={'schema_version':1,'source_revision':revision,'source_tree':matrix.git('rev-parse','HEAD^{tree}'),
 'source_clean_before':True,'started_at':matrix.now(),'outcome':'running','runner':matrix.identity(__file__),
 'changed_file':matrix.identity(source/'ci/project/tensor_host_tools.py'),'commands':[],'phase_complete':False}
try:
 argv=[sys.executable,'-B','-m','unittest','discover','-s','ci/project','-p','test_tensor_*.py','-v']
 log=packet/'focused-host-suite.log'
 result=matrix.run_bounded(argv,source,env,log,timeout_seconds=120,min_free_bytes=15*matrix.GIB,max_log_bytes=16*matrix.MIB,max_rss_bytes=6*matrix.GIB,resource_paths=(packet,packet/'tmp'))
 report['commands'].append({'id':'focused-host-suite','argv':argv,'cwd':str(source),'log':str(log),**result})
 if result['outcome']!='pass' or not result['cleanup_complete'] or '\nRan 12 tests in ' not in log.read_text() or not log.read_text().endswith('\nOK\n'):
  raise RuntimeError('focused host suite failed')
 with tempfile.TemporaryDirectory(dir=packet/'tmp') as temporary:
  folder=Path(temporary)
  try:
   run_host_command([sys.executable,'-c','import sys; sys.stdout.buffer.write(bytes([98,97,100,32,255,10])); sys.exit(7)'],cwd=folder,env=env,timeout=5)
  except AssertionError as error:
   message=str(error)
   if 'nonzero_exit (exit 7)' not in message or '\ufffd' not in message:
    raise RuntimeError('structured failure diagnostic missing')
   report['utf8_probe']={'outcome':'pass','expected_failure_preserved':True,'exception':'AssertionError','message':message}
  else:
   raise RuntimeError('failing host command accepted')
 report['utf8_probe']['temporary_cleanup_complete']=not folder.exists()
 native=json.loads((work/'final-matrix-ca8686d/report.json').read_text())
 report['native_execution_revision']=native['source']['revision']
 report['all_native_recorded_source_files_unchanged']=all(matrix.identity(source/p)==before for p,before in native['source']['files'].items())
 if not report['all_native_recorded_source_files_unchanged']:
  raise RuntimeError('native input drift')
 matrix.source_guard(revision)
 report['source_clean_after']=True
 report['outcome']='pass'
except Exception as error:
 report['outcome']='fail';report['failure']=str(error)
finally:
 report['finished_at']=matrix.now();matrix.save(packet,report)
print(json.dumps(report,indent=2))
sys.exit(0 if report['outcome']=='pass' else 1)
