#!/usr/bin/env python3
"""Package the retained tensor evidence; never build, run Git, or modify inputs.

Build (destination must not exist):
  python3 -B build_evidence_packet.py build --output-dir packet-staging
Verify only the published bundle:
  python3 -B build_evidence_packet.py verify packet-staging
Also reproduce every transformation from the original retained files:
  python3 -B build_evidence_packet.py verify packet-staging --raw-work-root .

The allowlist is deliberately nonrecursive. A later build automatically includes
new reports/w*.{md,json,py,patch} and the current drafts/agents.{json,md} ledger.
No result, embedded raw hash, timestamp, or historical claim is reinterpreted.
Only literal absolute workspace prefixes in UTF-8 text are substituted. Original
Git commit object payloads are a byte-for-byte exception to text substitution.
The index is an unsigned integrity map, not proof of execution or publication.
"""

import argparse
import fnmatch
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile


MIB = 1024 * 1024
HARD_RAW_LIMIT = 32 * MIB
HARD_COMPRESSED_LIMIT = 8 * MIB
MAX_MEMBERS = 512
MAX_INDEX_BYTES = MIB
SCRIPT_WORK = Path(__file__).resolve().parent
PREFIX_ORDER = ("SOURCE", "WORK", "WORKSPACE")
PRELIMINARY_IDS = (
    "softfloat-build", "configure-fedp-rv64-n2",
    "configure-fedp-rv64-n2-focal-bundle", "build-fedp-rv64-n2-preliminary",
    "fedp-rv64-fp16-preliminary", "configure-wmma-rv64-t4-preliminary",
    "build-wmma-rv64-t4-preliminary", "wmma-rv64-t4-fmt2-preliminary",
    "wmma-rv64-t4-fmt3-preliminary",
)
RECEIPTS = tuple(
    f"{category}-{revision}/report.json"
    for category in ("final-matrix", "governance")
    for revision in ("20ea50d", "ca8686d")
) + ("host-followup-a25ee66/report.json",) + tuple(
    f"reports/{name}.json" for name in PRELIMINARY_IDS
)
EXACT = tuple(sorted({
    "build_evidence_packet.py", "bounded_command.py", "provision_verilator.py",
    "LICENSE", "finalize_ledger.py", "verify_packet_independent.py",
    "run_final_matrix.py", "run_governance.py", "run_host_followup.py",
    "session-state.json", "identities/source-map.json",
    "reports/compactnumeric-summary.json", "w06-a36-checker-probes.json",
    "w06_a34/run_probe.py", "w06_a34/probe.cpp", "w06_a34/results.json",
    "w06_a34/fedp_base.cpp.txt", "w06_a34/fedp_current.cpp.txt",
    "w06_a34/unit_base.cpp.txt", "w06_a34/unit_current.cpp.txt",
    "w06_a34/compile.log", "w06_a34/stdout.json", "w06_a34/stderr.log",
    "drafts/agents.json", "drafts/agents.md",
    "host-followup-a25ee66/focused-host-suite.log",
    "reports/provision-verilator.json", "softfloat-command.json",
    *RECEIPTS,
    *(f"{category}-{revision}/runner.py"
      for category in ("final-matrix", "governance")
      for revision in ("20ea50d", "ca8686d")),
    *(f"governance-{revision}/matrix-support.py" for revision in ("20ea50d", "ca8686d")),
    *(f"logs/{name}.log" for name in PRELIMINARY_IDS),
    *(f"{name}.command.json" for name in PRELIMINARY_IDS if name != "softfloat-build"),
}))
PATTERNS = (
    "final-matrix-20ea50d/logs/*.log", "final-matrix-ca8686d/logs/*.log",
    "governance-20ea50d/*.log", "governance-ca8686d/*.log",
    "identities/*.commit", "reports/w*.md", "reports/w*.json",
    "reports/w*.py", "reports/w*.patch",
)


class PacketError(Exception):
    """Fail closed without leaving a partial output bundle."""


def require(condition, message):
    if not condition:
        raise PacketError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {"sha256": digest(data), "size_bytes": len(data)}


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def relative_name(name):
    parts = PurePosixPath(name).parts
    require(bool(parts) and not name.startswith("/") and "\\" not in name
            and all(part not in ("", ".", "..") for part in name.split("/"))
            and "\x00" not in name, f"unsafe member path: {name!r}")
    return parts


def approved(name):
    relative_name(name)
    if name in EXACT:
        return True
    path = PurePosixPath(name)
    return any(str(path.parent) == str(PurePosixPath(pattern).parent)
               and fnmatch.fnmatchcase(path.name, PurePosixPath(pattern).name)
               for pattern in PATTERNS)


def safe_read(root, name, limit):
    """Bound reads and reject links, special files, and changes during a read."""
    parts = relative_name(name)
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    directory = os.open(root, flags | os.O_DIRECTORY)
    try:
        for part in parts[:-1]:
            child = os.open(part, flags | os.O_DIRECTORY, dir_fd=directory)
            os.close(directory)
            directory = child
        descriptor = os.open(parts[-1], flags, dir_fd=directory)
        try:
            before = os.fstat(descriptor)
            require(stat.S_ISREG(before.st_mode), f"not a regular file: {name}")
            require(before.st_size <= limit, f"raw byte limit exceeded by: {name}")
            chunks, remaining = [], limit + 1
            while remaining:
                chunk = os.read(descriptor, min(MIB, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
            data = b"".join(chunks)
            after = os.fstat(descriptor)
            fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
            require(all(getattr(before, field) == getattr(after, field) for field in fields)
                    and len(data) == before.st_size, f"input changed during read: {name}")
            require(len(data) <= limit, f"raw byte limit exceeded by: {name}")
            return data
        finally:
            os.close(descriptor)
    finally:
        os.close(directory)


def select_inputs(work):
    names = set(EXACT)
    for pattern in PATTERNS:
        parent, glob = PurePosixPath(pattern).parent, PurePosixPath(pattern).name
        folder = work / str(parent)
        require(folder.is_dir() and not folder.is_symlink(), f"missing or linked input directory: {parent}")
        matches = [str(parent / entry.name) for entry in folder.iterdir()
                   if fnmatch.fnmatchcase(entry.name, glob)]
        if not str(parent).startswith("reports"):
            require(bool(matches), f"required pattern has no files: {pattern}")
        names.update(matches)
    require(len(names) <= MAX_MEMBERS, "member count limit exceeded")
    require(all(approved(name) for name in names), "input outside the allowlist")
    return sorted(names)


def path_roots(work, source=None, workspace=None):
    work = Path(work).resolve(strict=True)
    workspace = Path(workspace).resolve(strict=True) if workspace else work.parent
    source = Path(source).resolve(strict=True) if source else (workspace / "AI-GPU").resolve(strict=True)
    require(work.is_dir() and workspace.is_dir() and source.is_dir(), "roots must be existing directories")
    require(work != source and work != workspace and source != workspace, "path roots must be distinct")
    require(work.is_relative_to(workspace) and source.is_relative_to(workspace),
            "source and work roots must be inside the workspace root")
    require(not work.is_relative_to(source) and not source.is_relative_to(work),
            "source and work roots must not overlap")
    return {"SOURCE": source, "WORK": work, "WORKSPACE": workspace}


def transform(name, raw, roots):
    if name.startswith("identities/") and name.endswith(".commit"):
        require(bool(re.fullmatch(r"[0-9a-f]{40}\.commit", PurePosixPath(name).name)),
                f"commit filename must contain its complete object id: {name}")
        oid = hashlib.sha1(b"commit " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()
        require(PurePosixPath(name).stem == oid, f"commit object id mismatch: {name}")
        return raw, {"kind": "verbatim_git_commit", "git_commit_sha1": oid}
    try:
        raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        raise PacketError(f"selected text is not UTF-8: {name}") from error
    require(b"\0" not in raw, f"selected text contains binary NUL bytes: {name}")
    published, counts = raw, {}
    # More specific roots precede WORKSPACE; preserve every other original byte.
    for token in PREFIX_ORDER:
        prefix = str(roots[token]).encode("utf-8")
        count = published.count(prefix)
        if count:
            counts[f"<{token}>"] = count
            published = published.replace(prefix, f"<{token}>".encode("ascii"))
    require(all(str(path).encode("utf-8") not in published for path in roots.values()),
            f"workspace path remains in published text: {name}")
    return published, {"kind": "utf8_literal_path_substitution", "replacement_counts": counts}


class BoundedBuffer(io.BytesIO):
    def __init__(self, limit, label):
        super().__init__()
        self.limit, self.label = limit, label

    def write(self, data):
        require(self.tell() + len(data) <= self.limit, f"{self.label} byte limit would be exceeded")
        return super().write(data)


def make_tar(files, limit):
    buffer = BoundedBuffer(limit, "uncompressed tar")
    with tarfile.open(mode="w", fileobj=buffer, format=tarfile.USTAR_FORMAT) as archive:
        for name, data in sorted(files.items()):
            relative_name(name)
            info = tarfile.TarInfo(name)
            info.type = tarfile.REGTYPE
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(data))
    return buffer.getvalue()


def compress_tar(raw_tar, limit):
    buffer = BoundedBuffer(limit, "compressed archive")
    with gzip.GzipFile(filename="", mode="wb", fileobj=buffer, compresslevel=9, mtime=0) as stream:
        stream.write(raw_tar)
    return buffer.getvalue()


def walk_json(value, pointer=""):
    if isinstance(value, dict):
        yield pointer, value
        for key, child in value.items():
            yield from walk_json(child, pointer + "/" + key.replace("~", "~0").replace("/", "~1"))
    elif isinstance(value, list):
        for number, child in enumerate(value):
            yield from walk_json(child, pointer + "/" + str(number))


def bind_raw_logs(files, roots):
    bindings = []
    for name in RECEIPTS:
        report = json.loads(files[name])
        for pointer, record in walk_json(report):
            if not all(key in record for key in ("log", "log_sha256", "log_size_bytes")):
                continue
            path = Path(record["log"])
            require(path.is_absolute() and path.is_relative_to(roots["WORK"]),
                    f"receipt log outside work root: {name}{pointer}")
            log = path.relative_to(roots["WORK"]).as_posix()
            require(log in files, f"receipt log is not packaged: {log}")
            require(record["log_sha256"] == digest(files[log])
                    and record["log_size_bytes"] == len(files[log]),
                    f"raw receipt/log identity mismatch: {name}{pointer}")
            bindings.append({"report": name, "record_json_pointer": pointer, "log": log,
                             "raw_sha256": record["log_sha256"],
                             "raw_size_bytes": record["log_size_bytes"]})
    return bindings


def verify_bytes(packet, index):
    require(index["schema_version"] == 1, "unsupported index schema")
    limits = index["limits"]
    require(0 < limits["raw_bytes"] <= HARD_RAW_LIMIT
            and 0 < limits["compressed_bytes"] <= HARD_COMPRESSED_LIMIT, "unsafe index limits")
    require(len(packet) <= limits["compressed_bytes"], "compressed archive exceeds limit")
    require(identity(packet) == index["archive"]["compressed"], "archive identity mismatch")
    require(packet[:10] == b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff",
            "gzip metadata is not deterministic")
    with gzip.GzipFile(fileobj=io.BytesIO(packet), mode="rb") as stream:
        raw_tar = stream.read(limits["raw_bytes"] + 1)
    require(len(raw_tar) <= limits["raw_bytes"], "uncompressed tar exceeds limit")
    require(identity(raw_tar) == index["archive"]["uncompressed_tar"], "tar identity mismatch")
    entries = index["members"]
    names = [entry["path"] for entry in entries]
    require(names == sorted(set(names)) and len(names) <= MAX_MEMBERS, "index paths are not unique and sorted")
    require(set(EXACT).issubset(names) and all(approved(name) for name in names), "index differs from allowlist")
    require(len(names) == index["member_count"], "member count mismatch")
    by_name = {entry["path"]: entry for entry in entries}
    files = {}
    with tarfile.open(mode="r:", fileobj=io.BytesIO(raw_tar)) as archive:
        for member in archive:
            name = member.name
            require(name in by_name and name not in files, f"unexpected or duplicate tar member: {name}")
            require(member.type == tarfile.REGTYPE and not member.linkname and not member.pax_headers,
                    f"nonregular tar member: {name}")
            require((member.uid, member.gid, member.mtime, member.mode, member.uname, member.gname)
                    == (0, 0, 0, 0o644, "", ""), f"nondeterministic tar metadata: {name}")
            entry = by_name[name]
            is_commit = name.startswith("identities/") and name.endswith(".commit")
            expected_kind = "verbatim_git_commit" if is_commit else "utf8_literal_path_substitution"
            require(entry["transformation"]["kind"] == expected_kind,
                    f"unexpected transformation type: {name}")
            require(0 <= entry["raw_size_bytes"] <= limits["raw_bytes"]
                    and 0 <= entry["published_size_bytes"] <= limits["raw_bytes"],
                    f"invalid member byte limits: {name}")
            require(member.size == entry["published_size_bytes"], f"member size mismatch: {name}")
            stream = archive.extractfile(member)
            require(stream is not None, f"unreadable member: {name}")
            data = stream.read(limits["raw_bytes"] + 1)
            require(len(data) == entry["published_size_bytes"]
                    and digest(data) == entry["published_sha256"], f"published identity mismatch: {name}")
            if entry["transformation"]["kind"] == "verbatim_git_commit":
                require(len(data) == entry["raw_size_bytes"] and digest(data) == entry["raw_sha256"],
                        f"raw commit was transformed: {name}")
                _, transformation = transform(name, data, {})
                require(transformation == entry["transformation"], f"commit identity metadata mismatch: {name}")
            else:
                data.decode("utf-8", errors="strict")
            files[name] = data
    require(sorted(files) == names, "tar members differ from index")
    require(make_tar(files, limits["raw_bytes"]) == raw_tar, "tar is not the canonical regular-file archive")
    require(sum(entry["raw_size_bytes"] for entry in entries) == index["raw_total_size_bytes"]
            <= limits["raw_bytes"], "raw total mismatch or overflow")
    require(sum(map(len, files.values())) == index["published_total_size_bytes"]
            <= limits["raw_bytes"], "published total mismatch or overflow")
    for binding in index["raw_log_bindings"]:
        record = json.loads(files[binding["report"]])
        for part in binding["record_json_pointer"].split("/")[1:]:
            part = part.replace("~1", "/").replace("~0", "~")
            record = record[int(part)] if isinstance(record, list) else record[part]
        entry = by_name[binding["log"]]
        require(record["log"] == "<WORK>/" + binding["log"], "published log path binding mismatch")
        require(record["log_sha256"] == binding["raw_sha256"] == entry["raw_sha256"]
                and record["log_size_bytes"] == binding["raw_size_bytes"] == entry["raw_size_bytes"],
                "embedded raw log hash or size was rewritten")
    return files


def make_bundle(roots, raw_limit, compressed_limit):
    work = roots["WORK"]
    names = select_inputs(work)
    raw_files, files, entries = {}, {}, []
    raw_total = published_total = 0
    for name in names:
        raw = safe_read(work, name, raw_limit - raw_total)
        published, transformation = transform(name, raw, roots)
        raw_total += len(raw)
        published_total += len(published)
        require(published_total <= raw_limit, "published member bytes exceed limit")
        raw_files[name], files[name] = raw, published
        entries.append({"path": name, "raw_path": "<WORK>/" + name,
                        "raw_sha256": digest(raw), "raw_size_bytes": len(raw),
                        "published_sha256": digest(published), "published_size_bytes": len(published),
                        "transformation": transformation})
    require(select_inputs(work) == names, "input selection changed during snapshot; retry with a fresh output")
    bindings = bind_raw_logs(raw_files, roots)
    raw_tar = make_tar(files, raw_limit)
    packet = compress_tar(raw_tar, compressed_limit)
    index = {
        "schema_version": 1,
        "scope": "Supplemental local tensor evidence snapshot; no vendor or phase-gate qualification is inferred.",
        "phase_complete": False,
        "integrity_caveat": "Unsigned integrity metadata; this packaging step neither executes workloads nor verifies branch publication.",
        "allowlist": {"required_exact_paths": list(EXACT), "nonrecursive_patterns": list(PATTERNS)},
        "exclusions": ["build trees", "binaries", "tool installations", "toolchain archives and checkouts",
                       "temporary files", "unlisted diagnostic scratch trees", "unlisted draft documents"],
        "limits": {"raw_bytes": raw_limit, "compressed_bytes": compressed_limit,
                   "max_members": MAX_MEMBERS, "index_bytes": MAX_INDEX_BYTES,
                   "enforcement": "Source and published byte totals and the complete uncompressed tar are separately capped; compressed writes are bounded before output publication."},
        "path_transform": {
            "algorithm": "Ordered, literal UTF-8 byte replacement; all other bytes, including line endings and embedded raw hashes, are retained.",
            "order": [f"<{token}>" for token in PREFIX_ORDER],
            "roots": [{"token": f"<{token}>",
                       "root_relative_to_workspace": "." if token == "WORKSPACE" else roots[token].relative_to(roots["WORKSPACE"]).as_posix(),
                       "original_absolute_prefix_sha256": digest(str(roots[token]).encode("utf-8"))}
                      for token in PREFIX_ORDER],
            "commit_exception": "identities/*.commit are exact original Git commit object payload bytes and receive no substitutions.",
            "hash_semantics": "Hashes and sizes inside reports and agent notes continue to describe raw originals. Use member published_sha256 and published_size_bytes to verify distributed files.",
        },
        "member_count": len(entries), "raw_total_size_bytes": raw_total,
        "published_total_size_bytes": published_total, "members": entries,
        "raw_log_bindings": bindings,
        "archive": {"path": "packet.tar.gz", "compressed": identity(packet),
                    "uncompressed_tar": identity(raw_tar), "format": "USTAR, sorted regular files only",
                    "uid": 0, "gid": 0, "mtime": 0, "mode": "0644",
                    "gzip": {"mtime": 0, "filename": "", "compression_level": 9}},
        "snapshot_policy": "No wall-clock packaging timestamp is added. Identical selected inputs and roots produce identical outputs. Rebuild after all desired reports and the final ledger are available.",
    }
    require(all(str(path).encode("utf-8") not in json_bytes(index) for path in roots.values()),
            "workspace path leaked into index")
    verify_bytes(packet, index)
    index_data = json_bytes(index)
    require(len(index_data) <= MAX_INDEX_BYTES, "index byte limit exceeded")
    return packet, index_data, index


def build(args):
    require(0 < args.max_raw_bytes <= HARD_RAW_LIMIT, "raw limit may only be lowered")
    require(0 < args.max_compressed_bytes <= HARD_COMPRESSED_LIMIT, "compressed limit may only be lowered")
    roots = path_roots(args.work_root, args.source_root, args.workspace_root)
    output = Path(args.output_dir) if args.output_dir else roots["WORK"] / "packet-staging"
    require(not os.path.lexists(output), "output directory must be fresh and must not exist")
    require(output.parent.is_dir(), "output parent directory must already exist")
    output = output.parent.resolve(strict=True) / output.name
    require(not output.is_relative_to(roots["SOURCE"]), "output must be scratch, outside the source checkout")
    packet, index_data, index = make_bundle(roots, args.max_raw_bytes, args.max_compressed_bytes)
    # Publish only the two complete, already-validated files. No intermediate disk
    # artifacts are created, and no existing destination is removed or replaced.
    output.mkdir(mode=0o755)
    created = []
    try:
        for name, data in (("packet.tar.gz", packet), ("index.json", index_data)):
            destination = output / name
            with destination.open("xb") as stream:
                created.append(destination)
                stream.write(data)
    except BaseException:
        for destination in created:
            destination.unlink()
        output.rmdir()
        raise
    return {"outcome": "pass", "mode": "build", "output_dir": str(output),
            "members": index["member_count"], "raw_bytes": index["raw_total_size_bytes"],
            "published_bytes": index["published_total_size_bytes"],
            "compressed_bytes": len(packet), "packet_sha256": digest(packet),
            "raw_log_bindings_verified": len(index["raw_log_bindings"])}


def verify(args):
    output = Path(args.output_dir).resolve(strict=True)
    require(sorted(path.name for path in output.iterdir()) == ["index.json", "packet.tar.gz"],
            "output directory must contain exactly index.json and packet.tar.gz")
    index_data = safe_read(output, "index.json", MAX_INDEX_BYTES)
    index = json.loads(index_data)
    require(json_bytes(index) == index_data, "index is not canonical JSON")
    packet = safe_read(output, "packet.tar.gz", HARD_COMPRESSED_LIMIT)
    files = verify_bytes(packet, index)
    raw_verified = False
    if args.raw_work_root:
        roots = path_roots(args.raw_work_root, args.source_root, args.workspace_root)
        for mapping in index["path_transform"]["roots"]:
            token = mapping["token"][1:-1]
            require(digest(str(roots[token]).encode("utf-8")) == mapping["original_absolute_prefix_sha256"],
                    f"original root identity differs: {mapping['token']}")
        for entry in index["members"]:
            name = entry["path"]
            raw = safe_read(roots["WORK"], name, index["limits"]["raw_bytes"])
            require(digest(raw) == entry["raw_sha256"] and len(raw) == entry["raw_size_bytes"],
                    f"raw member identity mismatch: {name}")
            published, transformation = transform(name, raw, roots)
            require(published == files[name] and transformation == entry["transformation"],
                    f"raw/published transformation mismatch: {name}")
        raw_verified = True
    return {"outcome": "pass", "mode": "verify", "members": len(files),
            "packet_sha256": digest(packet), "raw_members_verified": raw_verified,
            "raw_log_bindings_verified": len(index["raw_log_bindings"])}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    builder = commands.add_parser("build", help="write a fresh deterministic packet snapshot")
    builder.add_argument("--work-root", type=Path, default=SCRIPT_WORK)
    builder.add_argument("--output-dir", type=Path)
    builder.add_argument("--max-raw-bytes", type=int, default=HARD_RAW_LIMIT)
    builder.add_argument("--max-compressed-bytes", type=int, default=HARD_COMPRESSED_LIMIT)
    verifier = commands.add_parser("verify", help="verify every archive member without extracting files")
    verifier.add_argument("output_dir", type=Path)
    verifier.add_argument("--raw-work-root", type=Path)
    for command in (builder, verifier):
        command.add_argument("--source-root", type=Path)
        command.add_argument("--workspace-root", type=Path)
    args = parser.parse_args()
    try:
        result = build(args) if args.command == "build" else verify(args)
    except (PacketError, OSError, ValueError, KeyError, TypeError, tarfile.TarError, EOFError) as error:
        print(json.dumps({"outcome": "fail", "error": str(error)}), file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
