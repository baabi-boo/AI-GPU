import json, os, re, sys
from pathlib import Path
import run_final_matrix as matrix

source, work = matrix.SOURCE, matrix.WORK
revision = matrix.EXPECTED
packet = work / ('governance-' + revision[:7])
if packet.exists():
    raise SystemExit('output must be fresh')
matrix.source_guard(revision)
packet.mkdir()
(packet / 'tmp').mkdir()
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'LC_ALL': 'C', 'TMPDIR': str(packet / 'tmp')}
paths = matrix.git('ls-files', 'ci/project/*.py').splitlines()
report = {'schema_version': 1, 'source_revision': revision, 'source_tree': matrix.git('rev-parse','HEAD^{tree}'),
          'source_clean_before': True, 'started_at': matrix.now(), 'outcome': 'running',
          'source_hashes': {p: matrix.identity(source / p) for p in paths},
          'runner': matrix.identity(__file__), 'commands': [], 'phase_complete': False}
steps = [
    ('full-tooling-suite', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'ci/project', '-p', 'test_*.py']),
    ('check-project', [sys.executable, '-B', 'ci/project/check_project.py']),
    ('check-baseline-packets', [sys.executable, '-B', 'ci/project/check_baseline_packets.py']),
    ('governance-preflight', [sys.executable, '-B', 'ci/project/preflight.py', '--tier', 'governance', '--json']),
    ('change-impact', [sys.executable, '-B', 'ci/change_impact.py', 'classify', '--base', 'fcf2dee15fc1ae8aab95ba033ffac1340eec32fd', '--head', revision, '--format', 'json']),
    ('diff-check', ['git', 'diff', '--check', 'fcf2dee15fc1ae8aab95ba033ffac1340eec32fd', revision]),
]
try:
    for name, argv in steps:
        matrix.source_guard(revision)
        log = packet / (name + '.log')
        result = matrix.run_bounded(argv, source, env, log, timeout_seconds=600,
            min_free_bytes=15*matrix.GIB, max_log_bytes=16*matrix.MIB,
            max_rss_bytes=6*matrix.GIB, resource_paths=(packet,packet/'tmp'))
        entry = {'id':name,'argv':argv,'cwd':str(source),'log':str(log),**result}
        report['commands'].append(entry)
        matrix.save(packet,report)
        print(json.dumps({'id':name,'outcome':result['outcome'],'duration_seconds':result['duration_seconds'],'peak_rss_bytes':result['peak_rss_bytes']}),flush=True)
        matrix.source_guard(revision)
        if result['outcome'] != 'pass' or not result['cleanup_complete']:
            raise RuntimeError(name + ' failed')
        if name == 'full-tooling-suite':
            text = log.read_text()
            match = re.search(r'Ran (\d+) tests in ([\d.]+)s\n\nOK\n\Z',text)
            if not match:
                raise RuntimeError('suite result does not show unqualified OK')
            report['suite']={'tests':int(match[1]),'unittest_seconds':float(match[2]),'failures':0,'errors':0,'skips':0}
    report['source_hashes_unchanged'] = all(matrix.identity(source/p)==before for p,before in report['source_hashes'].items())
    if not report['source_hashes_unchanged']:
        raise RuntimeError('source hash drift')
    matrix.source_guard(revision)
    report['source_clean_after'] = True
    report['outcome']='pass'
except Exception as error:
    report['outcome']='fail'
    report['failure']=str(error)
finally:
    report['finished_at']=matrix.now()
    matrix.save(packet,report)
print(json.dumps({k:report[k] for k in ('outcome','suite','failure') if k in report}),flush=True)
sys.exit(0 if report['outcome']=='pass' else 1)
