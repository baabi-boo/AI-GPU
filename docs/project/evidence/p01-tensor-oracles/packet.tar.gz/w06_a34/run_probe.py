#!/usr/bin/env python3
"""Bounded host-only extraction of operand generation and selected-case loops."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path('<SOURCE>')
OUT = Path(__file__).resolve().parent
BASE = 'fcf2dee'
OUT.mkdir(parents=True, exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True)

def balanced(text, start):
    opening = text.index('{', start)
    level = 0
    for pos in range(opening, len(text)):
        level += (text[pos] == '{') - (text[pos] == '}')
        if level == 0:
            return text[start:pos + 1]
    raise AssertionError('unclosed body')

def block(text, marker):
    return balanced(text, text.index(marker))

sources = {}
metadata = {
    'scope': 'host-only extracted operand generation; no Verilator or DUT execution',
    'base': git('rev-parse', BASE).strip(),
    'head_at_snapshot': git('rev-parse', 'HEAD').strip(),
    'status_at_snapshot': git('status', '--short').splitlines(),
    'source_sha256': {},
}
for name in ('unit', 'fedp'):
    path = f'hw/unittest/tcu_{name}/main.cpp'
    for rev in ('base', 'current'):
        text = git('show', f'{BASE}:{path}') if rev == 'base' else (ROOT / path).read_text()
        sources[name, rev] = text
        filename = f'{name}_{rev}.cpp.txt'
        (OUT / filename).write_text(text)
        metadata['source_sha256'][filename] = hashlib.sha256(text.encode()).hexdigest()

header = r'''
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <bitmanip.h>
enum class RoundingMode { RNE, RTZ, RDN, RUP, RMM };
constexpr uint32_t TCU_FP32_ID=0, TCU_TF32_ID=1, TCU_FP16_ID=2, TCU_BF16_ID=3;
template<class To, class From> To bit_cast(From src) {
  static_assert(sizeof(To)==sizeof(From)); To dst; std::memcpy(&dst,&src,sizeof(dst)); return dst;
}
// These discarded float values only feed diagnostics in the source loop; all
// source raw-bit generation, RNG draws, masking and selection stay verbatim.
float cvt_custom_to_f32(uint32_t, int, int, int, void*) { return 0.0f; }
struct Record {
  uint32_t id, c, mask;
  std::string feature;
  std::vector<uint32_t> a,b;
  std::vector<uint8_t> sa,sb,la,lb;
  bool operator==(const Record& other) const {
    return id==other.id && c==other.c && mask==other.mask && feature==other.feature
      && a==other.a && b==other.b && sa==other.sa && sb==other.sb && la==other.la && lb==other.lb;
  }
};
struct Result { std::vector<Record> rows; uint32_t counter=0; };
constexpr int log2_floor(int n) { return n<=1 ? 0 : 1+log2_floor(n/2); }
'''

def unit_namespace(rev):
    text = sources['unit', rev]
    config = block(text, 'struct TestConfig') + ';'
    helpers = '\n'.join([block(text, 'struct FmtInfo')+';', block(text, 'static FmtInfo get_fmt_info'),
                          block(text, 'static uint32_t pack_fp('), block(text, 'static uint32_t gen_fp_value')])
    loop = block(text, 'for (uint32_t test_id = 0; test_id < cfg_.num_tests; test_id++)')
    begin = loop.index('std::ostringstream label;')
    end = loop.index('tests_done++;', begin)
    loop = loop[:begin] + 'out.rows.push_back(Record{test_id, 0, 0, feat, rs1, rs2});\n' \
        + 'out.rows.back().la.clear(); for (auto c : rs3) { out.rows.back().sa.push_back(c); out.rows.back().sa.push_back(c>>8); out.rows.back().sa.push_back(c>>16); out.rows.back().sa.push_back(c>>24); }\n' \
        + loop[end:]
    return f'''namespace unit_{rev} {{
{config}
{helpers}
template<int VX_CFG_NUM_THREADS> struct Generator {{
  TestConfig cfg_; std::mt19937 rng_;
  constexpr static int TCU_LG=log2_floor(VX_CFG_NUM_THREADS);
  constexpr static int TCU_EN=TCU_LG/2, TCU_EM=TCU_LG-TCU_EN;
  constexpr static int TCU_TC_M=1<<TCU_EM, TCU_TC_N=1<<TCU_EN;
  constexpr static int TCU_TC_K=VX_CFG_NUM_THREADS/std::max(TCU_TC_M,TCU_TC_N);
  Generator(TestConfig cfg):cfg_(cfg),rng_(cfg.random_seed) {{}}
  Result run() {{ Result out; const auto fi=get_fmt_info(cfg_.fmt_s); uint32_t tests_done=0;
    {loop}
    out.counter=tests_done; return out;
  }}
}};
}}
'''

def fedp_namespace(rev):
    text = sources['fedp', rev]
    config = block(text, 'struct TestConfig') + ';'
    helpers = '\n'.join(block(text, name) for name in (
        'void init_default_fp_format', 'static int float_fmt_width', 'static bool is_mx_fmt',
        'static int int_fmt_width', 'static int int_fmt_sign', 'static inline uint32_t pack_fp_bits'))
    generators = '\n'.join(block(text, name) for name in (
        'int32_t generate_int_value', 'uint8_t generate_scale', 'uint32_t generate_fp_value'))
    methods = []
    for mode, name in [('integer', 'bool test_integers()'), ('float', 'bool test_floating_points(')]:
        method = block(text, name)
        prefix = method[method.index('{')+1:method.index('// Pack into VX_CFG_XLEN words')]
        if mode == 'float':
            prefix = prefix.replace('return false;', 'return out;').replace('return true;', 'return out;')
            capture = 'out.rows.push_back(Record{uint32_t(test_id), c_value_hex, current_vld_mask, feature, a_value_hex, b_value_hex, {sf_slot_a,sf_slot_a+SF}, {sf_slot_b,sf_slot_b+SF}, sf_lane_a,sf_lane_b});'
        else:
            capture = 'out.rows.push_back(Record{uint32_t(test_id), uint32_t(c_value), current_vld_mask, "integer", a_values, b_values});'
        if rev == 'current':
            tail = '++tests_done_;\n' + block(method, 'if (config_.test_id >= 0) {')
        else:
            tail = ''
        methods.append(f'''Result {mode}_run() {{
          Result out; tests_done_=0; const auto& features_to_test=config_.test_features;
          {prefix}
          {capture}
          {tail}
          }}
          out.counter=tests_done_; return out;
        }}''')
    return f'''namespace fedp_{rev} {{
{config}
{helpers}
template<int NUM_REGS,int SF> struct Generator {{
  TestConfig config_; std::mt19937 rng_; uint32_t tests_done_=0;
  Generator(TestConfig cfg):config_(cfg),rng_(cfg.random_seed) {{}}
  {generators}
  {''.join(methods)}
}};
}}
'''

driver = r'''
uint64_t unit_configs=0, unit_replays=0, unit_old_mismatch=0;
uint64_t fedp_configs=0, fedp_replays=0, fedp_old_int_overexecution=0, fedp_old_float_match=0;
uint64_t failures=0;
uint32_t witness_unit_full_c=0,witness_unit_old_c=0;
std::vector<std::vector<std::string>> feature_lists={
  {"infinities","nans","subnormals","normals","zeros"},
  {"zeros","normals"}, {"nans","subnormals","zeros"}
};
void require(bool value) { if(!value) ++failures; }
template<int THREADS> void unit_matrix() {
 for(auto fmt:{1u,2u,3u}) for(auto seed:{0u,12345u,0xffffffffu})
 for(auto n:{1u,2u,5u,7u,17u}) for(const auto& features:feature_lists) {
  unit_current::TestConfig cfg; cfg.fmt_s=fmt; cfg.random_seed=seed; cfg.num_tests=n; cfg.features=features;
  unit_base::TestConfig old; old.fmt_s=fmt; old.random_seed=seed; old.num_tests=n; old.features=features;
  auto full=unit_current::Generator<THREADS>(cfg).run();
  auto oldfull=unit_base::Generator<THREADS>(old).run();
  ++unit_configs; require(full.rows.size()==n && full.counter==n); require(full.rows==oldfull.rows);
  for(uint32_t i=0;i<n;++i) {
   cfg.test_id=i; old.test_id=i;
   auto replay=unit_current::Generator<THREADS>(cfg).run();
   auto oldreplay=unit_base::Generator<THREADS>(old).run();
   ++unit_replays;
   require(replay.rows.size()==1 && replay.counter==1 && replay.rows[0]==full.rows[i]);
   bool equal=oldreplay.rows.size()==1 && oldreplay.rows[0]==oldfull.rows[i];
   if(i==0) require(equal); else { require(!equal); unit_old_mismatch+=!equal; }
   if(THREADS==4 && fmt==2 && seed==12345 && n==17 && features==feature_lists[0] && i==1) {
     std::memcpy(&witness_unit_full_c,oldfull.rows[i].sa.data(),4);
     std::memcpy(&witness_unit_old_c,oldreplay.rows[0].sa.data(),4);
   }
  }
 }
}
template<int REGS,int SCALES> void fedp_matrix() {
 for(auto fmt:{1u,2u,3u,4u,5u,8u,9u,10u,11u,17u,18u,19u,20u})
 for(auto seed:{0u,12345u}) for(auto n:{1u,2u,5u,7u,17u}) for(auto sparse:{0,37,100}) {
  bool integer=fmt>=16;
  for(int feature_case=0;feature_case<(integer?1:3);++feature_case)
  for(int fixed=0;fixed<(fedp_current::is_mx_fmt(fmt)?2:1);++fixed) {
   const auto& features=feature_lists[feature_case];
   fedp_current::TestConfig cfg; cfg.fmt_s=fmt; cfg.random_seed=seed; cfg.num_tests=n;
   cfg.test_features=features; cfg.sparsity=sparse; if(fixed) {cfg.sf_a=127;cfg.sf_b=48;}
   fedp_current::init_default_fp_format(fmt,&cfg.exp_bits,&cfg.sig_bits);
   fedp_base::TestConfig old; old.fmt_s=fmt; old.random_seed=seed; old.num_tests=n;
   old.test_features=features; old.sparsity=sparse; if(fixed) {old.sf_a=127;old.sf_b=48;}
   fedp_base::init_default_fp_format(fmt,&old.exp_bits,&old.sig_bits);
   auto run=[&]() { auto g=fedp_current::Generator<REGS,SCALES>(cfg); return integer?g.integer_run():g.float_run(); };
   auto oldrun=[&]() { auto g=fedp_base::Generator<REGS,SCALES>(old); return integer?g.integer_run():g.float_run(); };
   auto full=run(); auto oldfull=oldrun(); ++fedp_configs;
   require(full.rows.size()==n && full.counter==n); require(oldfull.rows.size()==n);
   if(integer) require(full.rows==oldfull.rows);
   else { for(uint32_t i=0;i<n;++i) { auto a=full.rows[i],b=oldfull.rows[i]; a.c=b.c=0; require(a==b); } }
   for(uint32_t i=0;i<n;++i) {
    cfg.test_id=i; old.test_id=i; auto replay=run(); auto oldreplay=oldrun(); ++fedp_replays;
    require(replay.rows.size()==1 && replay.counter==1 && replay.rows[0]==full.rows[i]);
    if(integer) {
      require(oldreplay.rows==oldfull.rows);
      if(n>1) { ++fedp_old_int_overexecution; require(oldreplay.rows.size()>1); }
    } else {
      require(oldreplay.rows.size()==1 && oldreplay.rows[0]==oldfull.rows[i]);
      ++fedp_old_float_match;
    }
   }
  }
 }
}
int main() {
  std::ostringstream diagnostics; auto oldbuf=std::cout.rdbuf(diagnostics.rdbuf());
  unit_matrix<4>(); unit_matrix<8>(); unit_matrix<32>();
  fedp_matrix<1,1>(); fedp_matrix<2,2>(); fedp_matrix<4,4>();
  std::cout.rdbuf(oldbuf);
  std::cout << "{\"unit_configs\":"<<unit_configs<<",\"unit_replays\":"<<unit_replays
    <<",\"unit_old_mismatch\":"<<unit_old_mismatch<<",\"fedp_configs\":"<<fedp_configs
    <<",\"fedp_replays\":"<<fedp_replays<<",\"fedp_old_int_overexecution\":"<<fedp_old_int_overexecution
    <<",\"fedp_old_float_match\":"<<fedp_old_float_match<<",\"failures\":"<<failures
    <<",\"unit_witness_full_c0\":"<<witness_unit_full_c<<",\"unit_witness_old_selected_c0\":"<<witness_unit_old_c
    <<"}\n";
  return failures ? 1 : 0;
}
'''

cpp = header + ''.join(unit_namespace(rev) for rev in ('base','current')) \
    + ''.join(fedp_namespace(rev) for rev in ('base','current')) + driver
(OUT/'probe.cpp').write_text(cpp)
metadata['probe_sha256'] = hashlib.sha256(cpp.encode()).hexdigest()
metadata['compiler'] = subprocess.check_output(['g++','--version'], text=True).splitlines()[0]
command = ['g++','-std=c++17','-O1','-g0','-fsanitize=undefined','-fno-sanitize-recover=all',
           '-I'+str(ROOT/'sw/common'),str(OUT/'probe.cpp'),'-o',str(OUT/'probe')]
metadata['compile_command'] = command
started=time.monotonic()
compile_result=subprocess.run(command,capture_output=True,text=True,timeout=45)
(OUT/'compile.log').write_text(compile_result.stdout+compile_result.stderr)
metadata['compile_exit']=compile_result.returncode
if compile_result.returncode == 0:
    run_result=subprocess.run([str(OUT/'probe')],capture_output=True,text=True,timeout=45)
    (OUT/'stdout.json').write_text(run_result.stdout)
    (OUT/'stderr.log').write_text(run_result.stderr)
    metadata['run_exit']=run_result.returncode
    if run_result.returncode==0: metadata['results']=json.loads(run_result.stdout)
metadata['elapsed_seconds']=round(time.monotonic()-started,3)
metadata['source_sha256_after']={
    f'{name}_current.cpp.txt':hashlib.sha256((ROOT/f'hw/unittest/tcu_{name}/main.cpp').read_bytes()).hexdigest()
    for name in ('unit','fedp')}
(OUT/'results.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
if compile_result.returncode: print(compile_result.stderr[:3000])
