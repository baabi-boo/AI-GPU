
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <bitmanip.h>
enum class RoundingMode { RNE, RTZ, RDN, RUP, RMM };
constexpr uint32_t TCU_FP32_ID=0, TCU_TF32_ID=1, TCU_FP16_ID=2, TCU_BF16_ID=3;
template<class To, class From> To bit_cast(From src) {
  static_assert(sizeof(To)==sizeof(From)); To dst; std::memcpy(&dst,&src,sizeof(dst)); return dst;
}
// These discarded float values only feed diagnostics in the source loop; all
// source raw-bit generation, RNG draws, masking and selection stay verbatim.
float cvt_custom_to_f32(uint32_t, int, int, int, void*) { return 0.0f; }
struct Record {
  uint32_t id, c, mask;
  std::string feature;
  std::vector<uint32_t> a,b;
  std::vector<uint8_t> sa,sb,la,lb;
  bool operator==(const Record& other) const {
    return id==other.id && c==other.c && mask==other.mask && feature==other.feature
      && a==other.a && b==other.b && sa==other.sa && sb==other.sb && la==other.la && lb==other.lb;
  }
};
struct Result { std::vector<Record> rows; uint32_t counter=0; };
constexpr int log2_floor(int n) { return n<=1 ? 0 : 1+log2_floor(n/2); }
namespace unit_base {
struct TestConfig {
    uint64_t    max_cycles  = 2000;
    bool        enable_trace = true;
    uint64_t    trace_start = 0;
    uint64_t    trace_end   = ~0ULL;
    unsigned    random_seed = 12345;
    uint32_t    fmt_s       = TCU_FP16_ID; // source format (A, B)
    RoundingMode frm        = RoundingMode::RNE;
    uint32_t    num_tests   = 1000;
    int         ulp         = 1;
    int         window      = 25;   // TFR accumulator window (FEDP model)
    int32_t     test_id     = -1;
    bool        directed_only = false;
    std::vector<std::string> features = {"infinities","nans","subnormals","normals","zeros"};
};
struct FmtInfo {
    uint32_t id;
    int exp_bits;
    int sig_bits;
    int width_bits; // 16, 19 (tf32), or 32
    // a 32-bit register packs this many elements, element e in bits [e*width +: width]
    int per_word() const { return 32 / width_bits; }
};
static FmtInfo get_fmt_info(uint32_t fmt_id) {
    switch (fmt_id) {
    case TCU_FP32_ID: return {TCU_FP32_ID, 8, 23, 32};
    case TCU_FP16_ID: return {TCU_FP16_ID, 5, 10, 16};
    case TCU_BF16_ID: return {TCU_BF16_ID, 8,  7, 16};
    case TCU_TF32_ID: return {TCU_TF32_ID, 8, 10, 19};
    default:
        std::cerr << "Unsupported format id: " << fmt_id << "\n";
        std::abort();
    }
}
static uint32_t pack_fp(uint32_t sign, uint32_t exp, uint32_t frac,
                        uint32_t eb, uint32_t sb) {
    return (sign << (eb + sb)) | (exp << sb) | frac;
}
static uint32_t gen_fp_value(const std::string &feat, uint32_t eb, uint32_t sb,
                              uint32_t test_id, std::mt19937 &rng) {
    uint32_t all_exp = (eb == 32) ? 0xFFFFFFFFu : ((1u << eb) - 1u);
    uint32_t max_frac = (sb == 32) ? 0xFFFFFFFFu : ((1u << sb) - 1u);
    std::uniform_int_distribution<uint32_t> sign_d(0, 1);
    std::uniform_int_distribution<uint32_t> exp_d(1, (all_exp > 0) ? all_exp - 1 : 0);
    std::uniform_int_distribution<uint32_t> frac_d(0, max_frac);
    std::uniform_int_distribution<uint32_t> frac_nz_d(1, std::max(max_frac, 1u));

    if (feat == "zeros") {
        return pack_fp((test_id & 1) ? 1 : 0, 0, 0, eb, sb);
    } else if (feat == "normals") {
        uint32_t s = sign_d(rng);
        uint32_t e = exp_d(rng);
        uint32_t f = frac_d(rng);
        return pack_fp(s, e, f, eb, sb);
    } else if (feat == "subnormals") {
        if (sb == 0) return pack_fp(0, 0, 0, eb, sb);
        return pack_fp(sign_d(rng), 0, frac_nz_d(rng), eb, sb);
    } else if (feat == "infinities") {
        return pack_fp((test_id & 1), all_exp, 0, eb, sb);
    } else if (feat == "nans") {
        if (sb == 0) return pack_fp(sign_d(rng), all_exp, 0, eb, sb);
        uint32_t qbit = 1u << (sb - 1);
        uint32_t payload = frac_d(rng) & (qbit - 1);
        if (!payload) payload = 1;
        return pack_fp(sign_d(rng), all_exp, qbit | payload, eb, sb);
    }
    std::cerr << "Unknown feature: " << feat << "\n";
    std::abort();
}
template<int VX_CFG_NUM_THREADS> struct Generator {
  TestConfig cfg_; std::mt19937 rng_;
  constexpr static int TCU_LG=log2_floor(VX_CFG_NUM_THREADS);
  constexpr static int TCU_EN=TCU_LG/2, TCU_EM=TCU_LG-TCU_EN;
  constexpr static int TCU_TC_M=1<<TCU_EM, TCU_TC_N=1<<TCU_EN;
  constexpr static int TCU_TC_K=VX_CFG_NUM_THREADS/std::max(TCU_TC_M,TCU_TC_N);
  Generator(TestConfig cfg):cfg_(cfg),rng_(cfg.random_seed) {}
  Result run() { Result out; const auto fi=get_fmt_info(cfg_.fmt_s); uint32_t tests_done=0;
    for (uint32_t test_id = 0; test_id < cfg_.num_tests; test_id++) {
            if (cfg_.test_id >= 0 && (int)test_id != cfg_.test_id)
                continue;

            // Select feature to test
            size_t feat_idx = test_id % cfg_.features.size();
            const std::string &feat = cfg_.features[feat_idx];

            // A carries the feature, B and C are normals; each register lane
            // packs per_word() source elements.
            const int epw = fi.per_word();
            std::vector<uint32_t> rs1(VX_CFG_NUM_THREADS, 0), rs2(VX_CFG_NUM_THREADS, 0), rs3(VX_CFG_NUM_THREADS);
            for (int t = 0; t < TCU_TC_M * TCU_TC_K; t++) {
                for (int e = 0; e < epw; e++) {
                    uint32_t elem_id = (test_id * VX_CFG_NUM_THREADS + t) * epw + e;
                    rs1[t] |= gen_fp_value(feat, fi.exp_bits, fi.sig_bits, elem_id, rng_) << (e * fi.width_bits);
                }
            }
            for (int t = 0; t < TCU_TC_N * TCU_TC_K; t++) {
                for (int e = 0; e < epw; e++) {
                    uint32_t elem_id = (test_id * VX_CFG_NUM_THREADS + t) * epw + e;
                    rs2[t] |= gen_fp_value("normals", fi.exp_bits, fi.sig_bits, elem_id, rng_) << (e * fi.width_bits);
                }
            }
            for (int t = 0; t < VX_CFG_NUM_THREADS; t++) {
                rs3[t] = gen_fp_value("normals", 8, 23, test_id * VX_CFG_NUM_THREADS + t + 1, rng_);
            }

            out.rows.push_back(Record{test_id, 0, 0, feat, rs1, rs2});
out.rows.back().la.clear(); for (auto c : rs3) { out.rows.back().sa.push_back(c); out.rows.back().sa.push_back(c>>8); out.rows.back().sa.push_back(c>>16); out.rows.back().sa.push_back(c>>24); }
tests_done++;
        }
    out.counter=tests_done; return out;
  }
};
}
namespace unit_current {
struct TestConfig {
    uint64_t    max_cycles  = 2000;
    bool        enable_trace = true;
    uint64_t    trace_start = 0;
    uint64_t    trace_end   = ~0ULL;
    unsigned    random_seed = 12345;
    uint32_t    fmt_s       = TCU_FP16_ID; // source format (A, B)
    RoundingMode frm        = RoundingMode::RNE;
    uint32_t    num_tests   = 1000;
    int         ulp         = 1;
    int         window      = 25;   // TFR accumulator window (FEDP model)
    int32_t     test_id     = -1;
    bool        directed_only = false;
    std::vector<std::string> features = {"infinities","nans","subnormals","normals","zeros"};
};
struct FmtInfo {
    uint32_t id;
    int exp_bits;
    int sig_bits;
    int width_bits; // 16, 19 (tf32), or 32
    // a 32-bit register packs this many elements, element e in bits [e*width +: width]
    int per_word() const { return 32 / width_bits; }
};
static FmtInfo get_fmt_info(uint32_t fmt_id) {
    switch (fmt_id) {
    case TCU_FP32_ID: return {TCU_FP32_ID, 8, 23, 32};
    case TCU_FP16_ID: return {TCU_FP16_ID, 5, 10, 16};
    case TCU_BF16_ID: return {TCU_BF16_ID, 8,  7, 16};
    case TCU_TF32_ID: return {TCU_TF32_ID, 8, 10, 19};
    default:
        std::cerr << "Unsupported format id: " << fmt_id << "\n";
        std::abort();
    }
}
static uint32_t pack_fp(uint32_t sign, uint32_t exp, uint32_t frac,
                        uint32_t eb, uint32_t sb) {
    return (sign << (eb + sb)) | (exp << sb) | frac;
}
static uint32_t gen_fp_value(const std::string &feat, uint32_t eb, uint32_t sb,
                              uint32_t test_id, std::mt19937 &rng) {
    uint32_t all_exp = (eb == 32) ? 0xFFFFFFFFu : ((1u << eb) - 1u);
    uint32_t max_frac = (sb == 32) ? 0xFFFFFFFFu : ((1u << sb) - 1u);
    std::uniform_int_distribution<uint32_t> sign_d(0, 1);
    std::uniform_int_distribution<uint32_t> exp_d(1, (all_exp > 0) ? all_exp - 1 : 0);
    std::uniform_int_distribution<uint32_t> frac_d(0, max_frac);
    std::uniform_int_distribution<uint32_t> frac_nz_d(1, std::max(max_frac, 1u));

    if (feat == "zeros") {
        return pack_fp((test_id & 1) ? 1 : 0, 0, 0, eb, sb);
    } else if (feat == "normals") {
        uint32_t s = sign_d(rng);
        uint32_t e = exp_d(rng);
        uint32_t f = frac_d(rng);
        return pack_fp(s, e, f, eb, sb);
    } else if (feat == "subnormals") {
        if (sb == 0) return pack_fp(0, 0, 0, eb, sb);
        return pack_fp(sign_d(rng), 0, frac_nz_d(rng), eb, sb);
    } else if (feat == "infinities") {
        return pack_fp((test_id & 1), all_exp, 0, eb, sb);
    } else if (feat == "nans") {
        if (sb == 0) return pack_fp(sign_d(rng), all_exp, 0, eb, sb);
        uint32_t qbit = 1u << (sb - 1);
        uint32_t payload = frac_d(rng) & (qbit - 1);
        if (!payload) payload = 1;
        return pack_fp(sign_d(rng), all_exp, qbit | payload, eb, sb);
    }
    std::cerr << "Unknown feature: " << feat << "\n";
    std::abort();
}
template<int VX_CFG_NUM_THREADS> struct Generator {
  TestConfig cfg_; std::mt19937 rng_;
  constexpr static int TCU_LG=log2_floor(VX_CFG_NUM_THREADS);
  constexpr static int TCU_EN=TCU_LG/2, TCU_EM=TCU_LG-TCU_EN;
  constexpr static int TCU_TC_M=1<<TCU_EM, TCU_TC_N=1<<TCU_EN;
  constexpr static int TCU_TC_K=VX_CFG_NUM_THREADS/std::max(TCU_TC_M,TCU_TC_N);
  Generator(TestConfig cfg):cfg_(cfg),rng_(cfg.random_seed) {}
  Result run() { Result out; const auto fi=get_fmt_info(cfg_.fmt_s); uint32_t tests_done=0;
    for (uint32_t test_id = 0; test_id < cfg_.num_tests; test_id++) {
            // Select feature to test
            size_t feat_idx = test_id % cfg_.features.size();
            const std::string &feat = cfg_.features[feat_idx];

            // A carries the feature, B and C are normals; each register lane
            // packs per_word() source elements.
            const int epw = fi.per_word();
            std::vector<uint32_t> rs1(VX_CFG_NUM_THREADS, 0), rs2(VX_CFG_NUM_THREADS, 0), rs3(VX_CFG_NUM_THREADS);
            for (int t = 0; t < TCU_TC_M * TCU_TC_K; t++) {
                for (int e = 0; e < epw; e++) {
                    uint32_t elem_id = (test_id * VX_CFG_NUM_THREADS + t) * epw + e;
                    rs1[t] |= gen_fp_value(feat, fi.exp_bits, fi.sig_bits, elem_id, rng_) << (e * fi.width_bits);
                }
            }
            for (int t = 0; t < TCU_TC_N * TCU_TC_K; t++) {
                for (int e = 0; e < epw; e++) {
                    uint32_t elem_id = (test_id * VX_CFG_NUM_THREADS + t) * epw + e;
                    rs2[t] |= gen_fp_value("normals", fi.exp_bits, fi.sig_bits, elem_id, rng_) << (e * fi.width_bits);
                }
            }
            for (int t = 0; t < VX_CFG_NUM_THREADS; t++) {
                rs3[t] = gen_fp_value("normals", 8, 23, test_id * VX_CFG_NUM_THREADS + t + 1, rng_);
            }

            // Reproduce the full run's random stream before selecting a case.
            if (cfg_.test_id >= 0 && test_id != static_cast<uint32_t>(cfg_.test_id)) {
                continue;
            }

            out.rows.push_back(Record{test_id, 0, 0, feat, rs1, rs2});
out.rows.back().la.clear(); for (auto c : rs3) { out.rows.back().sa.push_back(c); out.rows.back().sa.push_back(c>>8); out.rows.back().sa.push_back(c>>16); out.rows.back().sa.push_back(c>>24); }
tests_done++;
            if (cfg_.test_id >= 0) {
                break;
            }
        }
    out.counter=tests_done; return out;
  }
};
}
namespace fedp_base {
struct TestConfig {
  uint64_t max_cycles = 1000;
  bool enable_tracing = true;
  bool fused = true;
  uint64_t trace_start = 0;
  uint64_t trace_end = -1ull;
  unsigned int random_seed = 12345;
  uint32_t fmt_s = 0; // Source format
  uint32_t fmt_d = 0; // Destination format (always 0 for float32)
  std::vector<std::string> test_features = {
      "infinities",
      "nans",
      "subnormals",
      "normals",
      "zeros"};
  int exp_bits = 0; // Exponent bits
  int sig_bits = 0; // Significand bits
  RoundingMode frm = RoundingMode::RNE; // Rounding mode
  int W = 53; // Accumulator window width
  bool renorm = false; // renormalize product
  uint32_t num_tests = 100000; // Number of tests per feature
  int ulp = 1; // float precision error bits
  int sparsity = 0; // % of zero inputs
  int32_t test_id = -1; // Specific test ID to run (for debugging)
  int sf_a = -1, sf_b = -1; // fixed block scales (debugging), random when negative
};
void init_default_fp_format(uint32_t fmt, int *exp_bits, int *sig_bits) {
  switch (fmt) {
    case 0: // fp32
      *exp_bits = 8;
      *sig_bits = 23;
      break;
    case 1: // tf32
      *exp_bits = 8;
      *sig_bits = 10;
      break;
    case 2: // fp16
      *exp_bits = 5;
      *sig_bits = 10;
      break;
    case 3: // bf16
      *exp_bits = 8;
      *sig_bits = 7;
      break;
    case 4: // fp8 (E4M3)
      *exp_bits = 4;
      *sig_bits = 3;
      break;
    case 5: // bf8 (E5M2)
      *exp_bits = 5;
      *sig_bits = 2;
      break;
    case 8: // mxfp8 (E4M3, E8M0 block scale)
      *exp_bits = 4;
      *sig_bits = 3;
      break;
    case 9: // mxbf8 (E5M2, E8M0 block scale)
      *exp_bits = 5;
      *sig_bits = 2;
      break;
    case 10: // mxfp4 (E2M1, E8M0 block scale)
    case 11: // nvfp4 (E2M1, E4M3 block scale)
      *exp_bits = 2;
      *sig_bits = 1;
      break;
    default:
      break;
  }
}
static int float_fmt_width(int exp_bits, int sig_bits) {
  int element_bits = 1 + exp_bits + sig_bits;
  if (element_bits <= 4) return 4; // fp4 packs eight to a register
  return 8 * ((element_bits + 7) / 8);
}
static bool is_mx_fmt(uint32_t fmt) { return (fmt & 0x18) == 0x8; }
static int int_fmt_width(int fmt) {
  switch (fmt) {
  case 16: return 32; // int32
  case 17: return 8;  // int8
  case 18: return 8;  // uint8
  case 19: return 4;  // int4
  case 20: return 4;  // uint4
  default:
    std::cerr << "Unsupported integer format: " << fmt << std::endl;
    std::abort();
  }
}
static int int_fmt_sign(int fmt) {
  switch (fmt) {
  case 16: return true;  // int32
  case 17: return true;  // int8
  case 18: return false; // uint8
  case 19: return true;  // int4
  case 20: return false; // uint4
  default:
    std::cerr << "Unsupported integer format: " << fmt << std::endl;
    std::abort();
  }
}
static inline uint32_t pack_fp_bits(uint32_t sign, uint32_t exp, uint32_t frac, uint32_t exp_bits, uint32_t sig_bits) {
  const uint32_t S = 1u;
  const uint32_t W = S + exp_bits + sig_bits;
  assert(W <= 32);
  const uint32_t sign_mask = 1u;
  const uint32_t exp_mask  = (exp_bits == 32 ? 0xFFFFFFFFu : ((1u << exp_bits) - 1u));
  const uint32_t frac_mask = (sig_bits == 32 ? 0xFFFFFFFFu : ((1u << sig_bits) - 1u));

  sign &= sign_mask;
  exp  &= exp_mask;
  frac &= frac_mask;

  const uint32_t sign_shift = exp_bits + sig_bits;
  const uint32_t exp_shift  = sig_bits;

  return (sign << sign_shift) | (exp << exp_shift) | frac;
}
template<int NUM_REGS,int SF> struct Generator {
  TestConfig config_; std::mt19937 rng_; uint32_t tests_done_=0;
  Generator(TestConfig cfg):config_(cfg),rng_(cfg.random_seed) {}
  int32_t generate_int_value(bool is_signed, int element_bits, int test_id) {
    uint32_t mask = (element_bits < 32) ? ((1u << element_bits) - 1u) : 0xFFFFFFFFu;
    std::uniform_int_distribution<uint32_t> int_dist(0, mask);

    int32_t value;
    if (test_id == -1) {
      value = int_dist(rng_);
    } else {
      switch (test_id % 4) {
      case 0: // zero
        value = 0;
        break;
      case 1: // min
        if (is_signed) {
          value = (element_bits < 32) ? (1u << (element_bits - 1)) : 0x80000000u;
        } else {
          value = 0;
        }
        break;
      case 2: // max
        if (is_signed) {
          value = (element_bits < 32) ? ((1u << (element_bits - 1)) - 1u) : 0x7FFFFFFFu;
        } else {
          value = mask;
        }
        break;
      default: // random
        value = int_dist(rng_);
        break;
      }
    }

    if (is_signed) {
      value = vortex::sext<int32_t>(value, element_bits);
    }
    return value;
  }
uint8_t generate_scale(uint32_t fmt) {
    std::uniform_int_distribution<int> coin(0, 1);
    if (fmt == 11) {
      std::uniform_int_distribution<int> any(0, 0x7f);
      std::uniform_int_distribution<int> near(0x30, 0x48);
      return uint8_t(coin(rng_) ? near(rng_) : any(rng_));
    }
    std::uniform_int_distribution<int> any(0, 255);
    std::uniform_int_distribution<int> near(127 - 8, 127 + 8);
    return uint8_t(coin(rng_) ? near(rng_) : any(rng_));
  }
uint32_t generate_fp_value(const std::string &feature, uint32_t exp_bits, uint32_t sig_bits, uint32_t test_id) {
    const uint32_t all_exp = (exp_bits == 32 ? 0xFFFFFFFFu : ((1u << exp_bits) - 1u));
    const uint32_t max_frac = (sig_bits == 32 ? 0xFFFFFFFFu : ((1u << sig_bits) - 1u));

    std::uniform_int_distribution<uint32_t> bit_dist(0, 0xFFFFFFFFu);
    std::uniform_int_distribution<uint32_t> sign_dist(0, 1);
    std::uniform_int_distribution<uint32_t> exp_norm_dist(1, (all_exp > 0 ? all_exp - 1 : 0)); // [1, all_ones-1]
    std::uniform_int_distribution<uint32_t> frac_dist(0, (max_frac > 0 ? max_frac : 0));
    std::uniform_int_distribution<uint32_t> frac_nz_dist(1, (max_frac > 0 ? max_frac : 1)); // nonzero frac

    auto deterministic_sign = [&](uint32_t salt) -> uint32_t {
      // Mix test_id with salt for reproducible sign selection
      return ((test_id ^ (salt * 0x9E3779B9u)) >> 31) & 1u;
    };

    if (feature == "zeros") {
      // +0 and -0; alternate by test_id for coverage
      uint32_t s = (test_id & 1u) ? 1u : 0u;
      return pack_fp_bits(s, 0u, 0u, exp_bits, sig_bits);

    } else if (feature == "normals") {
      if (exp_bits < 2) {
        // No normal numbers exist; fall back to zero
        return pack_fp_bits(0u, 0u, 0u, exp_bits, sig_bits);
      }
      // Spread some directed cases using test_id to hit edges:
      const uint32_t which = test_id % 5u;
      uint32_t s = (which == 0) ? deterministic_sign(1) : sign_dist(rng_);
      uint32_t e, f;
      switch (which) {
      case 0: // random normal
        e = exp_norm_dist(rng_);
        f = frac_dist(rng_);
        break;
      case 1: // smallest normal: exp=1, frac varies
        e = 1u;
        f = frac_dist(rng_);
        break;
      case 2: // largest finite: exp=all_ones-1, frac=all_ones
        e = (all_exp > 0 ? all_exp - 1 : 0);
        f = max_frac;
        break;
      case 3: // near one: exponent=bias, small fraction
        e = (exp_bits ? ((1u << (exp_bits - 1)) - 1u) : 0u);
        f = (sig_bits ? (frac_dist(rng_) & ((1u << (sig_bits > 4 ? 4 : sig_bits)) - 1u)) : 0u);
        break;
      default: // dense random but still normal
        e = exp_norm_dist(rng_);
        f = frac_dist(rng_);
        break;
      }
      return pack_fp_bits(s, e, f, exp_bits, sig_bits);

    } else if (feature == "subnormals") {
      // exp = 0, frac != 0
      if (sig_bits == 0) {
        // No fraction field -> subnormals don't exist; return zero
        return pack_fp_bits(0u, 0u, 0u, exp_bits, sig_bits);
      }
      uint32_t s = sign_dist(rng_);
      // Bias test_id to sometimes hit smallest and largest subnormals
      const uint32_t which = test_id % 3u;
      uint32_t f;
      if (which == 0)
        f = 1u; // smallest subnormal (lsb)
      else if (which == 1)
        f = max_frac; // largest subnormal
      else
        f = frac_nz_dist(rng_);
      return pack_fp_bits(s, 0u, f, exp_bits, sig_bits);

    } else if (feature == "infinities") {
      // exp = all ones, frac = 0
      uint32_t s = deterministic_sign(2);
      uint32_t e = all_exp;
      uint32_t f = 0u;
      return pack_fp_bits(s, e, f, exp_bits, sig_bits);

    } else if (feature == "nans") {
      // exp = all ones, frac != 0. Prefer quiet NaNs by setting MSB of fraction.
      if (sig_bits == 0) {
        // If there is no fraction field, you can't encode a NaN distinct from Inf; return Inf pattern.
        uint32_t s = deterministic_sign(3);
        return pack_fp_bits(s, all_exp, 0u, exp_bits, sig_bits);
      }
      uint32_t s = sign_dist(rng_);
      uint32_t e = all_exp;
      uint32_t quiet_bit = 1u << (sig_bits - 1); // top frac bit
      uint32_t payload = frac_dist(rng_) & (quiet_bit - 1u);
      if (payload == 0u)
        payload = 1u;                   // ensure nonzero payload
      uint32_t f = quiet_bit | payload; // make it a qNaN
      return pack_fp_bits(s, e, f, exp_bits, sig_bits);

    } else {
      std::cout << "Unknown feature: " << feature << std::endl;
      std::abort();
    }
  }
  Result integer_run() {
          Result out; tests_done_=0; const auto& features_to_test=config_.test_features;
          
    std::cout << "Testing integer format" << std::endl;

    // Calculate how many elements we can fit in NUM_REGS VX_CFG_XLEN words
    bool is_signed = int_fmt_sign(config_.fmt_s);
    int element_bits = int_fmt_width(config_.fmt_s);
    int elements_per_word = 32 / element_bits;
    int total_elements = NUM_REGS * elements_per_word;

    // Determine bits per element in vld_mask depending on element packing size
    int vld_bits_per_elem = 32 / elements_per_word / 4;
    uint32_t elem_vld_mask = (1 << vld_bits_per_elem) - 1;

    std::cout << "  elements_per_word=" << elements_per_word << ", total_elements=" << total_elements << std::endl;

    std::uniform_int_distribution<int> sparsity_dist(0, 99);

    for (int test_id = 0; test_id < config_.num_tests; test_id++) {
      std::vector<uint32_t> a_values(total_elements), b_values(total_elements);

      bool a_enable = (test_id % 3) == 0;
      bool b_enable = (test_id % 3) == 1;
      bool c_enable = (test_id % 3) == 2;
      uint32_t current_vld_mask = 0;

      for (int i = 0; i < total_elements; i++) {
        bool is_sparse = (config_.sparsity > 0) && (sparsity_dist(rng_) < config_.sparsity);

        if (is_sparse) {
          a_values[i] = 0;
        } else {
          a_values[i] = generate_int_value(is_signed, element_bits, (a_enable && i == 0) ? test_id : -1);
          current_vld_mask |= (elem_vld_mask << (i * vld_bits_per_elem));
        }
        b_values[i] = generate_int_value(is_signed, element_bits, (b_enable && i == 0) ? test_id : -1);
      }

      int32_t c_value = generate_int_value(true, 32, c_enable ? test_id : -1);

      
          out.rows.push_back(Record{uint32_t(test_id), uint32_t(c_value), current_vld_mask, "integer", a_values, b_values});
          
          }
          out.counter=tests_done_; return out;
        }Result float_run() {
          Result out; tests_done_=0; const auto& features_to_test=config_.test_features;
          
    if (features_to_test.empty()) return out;

    // Calculate how many elements we can fit in NUM_REGS VX_CFG_XLEN words
    int element_bits = float_fmt_width(config_.exp_bits, config_.sig_bits);
    int elements_per_word = 32 / element_bits;
    int total_elements = NUM_REGS * elements_per_word;

    // Determine bits per element in vld_mask depending on element packing size
    int vld_bits_per_elem = 32 / elements_per_word / 4;
    uint32_t elem_vld_mask = (1 << vld_bits_per_elem) - 1;

    const uint32_t NT = config_.num_tests;
    const uint32_t NF = features_to_test.size();
    const uint32_t tests_per_feature = (NT + NF - 1) / NF;

  #ifdef USE_FEDP
    TfrFedp fedp(config_.exp_bits, config_.sig_bits, (int)config_.frm, config_.W, config_.renorm);
  #endif

    uint32_t skipped = 0;
    std::uniform_int_distribution<int> sparsity_dist(0, 99);

    for (int test_id = 0; test_id < NT; test_id++) {
      // select feature to test
      int feature_id = test_id / tests_per_feature;
      if (feature_id >= NF) break; // prevent overflow if division rounding goes out of bounds
      std::string feature = features_to_test[feature_id];

      std::vector<float> a_values_float(total_elements), b_values_float(total_elements);
      std::vector<uint32_t> a_value_hex(total_elements), b_value_hex(total_elements);

      bool a_enable = (test_id % 3) == 0;
      bool b_enable = (test_id % 3) == 1;
      bool c_enable = (test_id % 3) == 2;
      uint32_t current_vld_mask = 0;

      for (int i = 0; i < total_elements; i++) {
        bool is_sparse = (config_.sparsity > 0) && (sparsity_dist(rng_) < config_.sparsity);

        if (is_sparse) {
          a_value_hex[i] = pack_fp_bits(0u, 0u, 0u, config_.exp_bits, config_.sig_bits);
          a_values_float[i] = 0.0f;
        } else {
          a_value_hex[i] = generate_fp_value((a_enable && (i & 0x1) == 0) ? feature : "normals", config_.exp_bits, config_.sig_bits, test_id);
          a_values_float[i] = cvt_custom_to_f32(a_value_hex[i], config_.exp_bits, config_.sig_bits, (int)config_.frm, nullptr);
          current_vld_mask |= (elem_vld_mask << (i * vld_bits_per_elem));
        }

        b_value_hex[i] = generate_fp_value((b_enable && (i & 0x1) == 0) ? feature : "normals", config_.exp_bits, config_.sig_bits, test_id);
        b_values_float[i] = cvt_custom_to_f32(b_value_hex[i], config_.exp_bits, config_.sig_bits, (int)config_.frm, nullptr);
      }

      float c_value_float = generate_fp_value(c_enable ? feature : "normals", 8, 23, test_id);

      uint32_t c_value_hex;
      std::memcpy(&c_value_hex, &c_value_float, sizeof(float));

      // Block scales, one per scale slot; lane l (two per register) takes
      // slot l * SF / lanes, as the datapath maps them.
      const bool mx = is_mx_fmt(config_.fmt_s);
      const int lanes = 2 * NUM_REGS;
      uint8_t sf_slot_a[SF] = {}, sf_slot_b[SF] = {};
      std::vector<uint8_t> sf_lane_a(lanes), sf_lane_b(lanes);
      if (mx) {
        for (int k = 0; k < SF; ++k) {
          sf_slot_a[k] = generate_scale(config_.fmt_s);
          sf_slot_b[k] = generate_scale(config_.fmt_s);
          if (config_.sf_a >= 0) sf_slot_a[k] = uint8_t(config_.sf_a);
          if (config_.sf_b >= 0) sf_slot_b[k] = uint8_t(config_.sf_b);
        }
        for (int l = 0; l < lanes; ++l) {
          sf_lane_a[l] = sf_slot_a[(l * SF) / lanes];
          sf_lane_b[l] = sf_slot_b[(l * SF) / lanes];
        }
      }
      // skip if not in selected test id
      if (config_.test_id >= 0 && test_id != config_.test_id)
        continue;

      if (config_.test_id >= 0 || (test_id % tests_per_feature) == 0) {
        std::cout << "Testing floating-point feature: " << feature << std::endl;
      }

      
          out.rows.push_back(Record{uint32_t(test_id), c_value_hex, current_vld_mask, feature, a_value_hex, b_value_hex, {sf_slot_a,sf_slot_a+SF}, {sf_slot_b,sf_slot_b+SF}, sf_lane_a,sf_lane_b});
          
          }
          out.counter=tests_done_; return out;
        }
};
}
namespace fedp_current {
struct TestConfig {
  uint64_t max_cycles = 1000;
  bool enable_tracing = true;
  bool fused = true;
  uint64_t trace_start = 0;
  uint64_t trace_end = -1ull;
  unsigned int random_seed = 12345;
  uint32_t fmt_s = 0; // Source format
  uint32_t fmt_d = 0; // Destination format (always 0 for float32)
  std::vector<std::string> test_features = {
      "infinities",
      "nans",
      "subnormals",
      "normals",
      "zeros"};
  int exp_bits = 0; // Exponent bits
  int sig_bits = 0; // Significand bits
  RoundingMode frm = RoundingMode::RNE; // Rounding mode
  int W = 53; // Accumulator window width
  bool renorm = false; // renormalize product
  uint32_t num_tests = 100000; // Number of tests per feature
  int ulp = 1; // float precision error bits
  int sparsity = 0; // % of zero inputs
  int32_t test_id = -1; // Specific test ID to run (for debugging)
  int sf_a = -1, sf_b = -1; // fixed block scales (debugging), random when negative
};
void init_default_fp_format(uint32_t fmt, int *exp_bits, int *sig_bits) {
  switch (fmt) {
    case 0: // fp32
      *exp_bits = 8;
      *sig_bits = 23;
      break;
    case 1: // tf32
      *exp_bits = 8;
      *sig_bits = 10;
      break;
    case 2: // fp16
      *exp_bits = 5;
      *sig_bits = 10;
      break;
    case 3: // bf16
      *exp_bits = 8;
      *sig_bits = 7;
      break;
    case 4: // fp8 (E4M3)
      *exp_bits = 4;
      *sig_bits = 3;
      break;
    case 5: // bf8 (E5M2)
      *exp_bits = 5;
      *sig_bits = 2;
      break;
    case 8: // mxfp8 (E4M3, E8M0 block scale)
      *exp_bits = 4;
      *sig_bits = 3;
      break;
    case 9: // mxbf8 (E5M2, E8M0 block scale)
      *exp_bits = 5;
      *sig_bits = 2;
      break;
    case 10: // mxfp4 (E2M1, E8M0 block scale)
    case 11: // nvfp4 (E2M1, E4M3 block scale)
      *exp_bits = 2;
      *sig_bits = 1;
      break;
    default:
      break;
  }
}
static int float_fmt_width(int exp_bits, int sig_bits) {
  int element_bits = 1 + exp_bits + sig_bits;
  if (element_bits <= 4) return 4; // fp4 packs eight to a register
  return 8 * ((element_bits + 7) / 8);
}
static bool is_mx_fmt(uint32_t fmt) { return (fmt & 0x18) == 0x8; }
static int int_fmt_width(int fmt) {
  switch (fmt) {
  case 16: return 32; // int32
  case 17: return 8;  // int8
  case 18: return 8;  // uint8
  case 19: return 4;  // int4
  case 20: return 4;  // uint4
  default:
    std::cerr << "Unsupported integer format: " << fmt << std::endl;
    std::abort();
  }
}
static int int_fmt_sign(int fmt) {
  switch (fmt) {
  case 16: return true;  // int32
  case 17: return true;  // int8
  case 18: return false; // uint8
  case 19: return true;  // int4
  case 20: return false; // uint4
  default:
    std::cerr << "Unsupported integer format: " << fmt << std::endl;
    std::abort();
  }
}
static inline uint32_t pack_fp_bits(uint32_t sign, uint32_t exp, uint32_t frac, uint32_t exp_bits, uint32_t sig_bits) {
  const uint32_t S = 1u;
  const uint32_t W = S + exp_bits + sig_bits;
  assert(W <= 32);
  const uint32_t sign_mask = 1u;
  const uint32_t exp_mask  = (exp_bits == 32 ? 0xFFFFFFFFu : ((1u << exp_bits) - 1u));
  const uint32_t frac_mask = (sig_bits == 32 ? 0xFFFFFFFFu : ((1u << sig_bits) - 1u));

  sign &= sign_mask;
  exp  &= exp_mask;
  frac &= frac_mask;

  const uint32_t sign_shift = exp_bits + sig_bits;
  const uint32_t exp_shift  = sig_bits;

  return (sign << sign_shift) | (exp << exp_shift) | frac;
}
template<int NUM_REGS,int SF> struct Generator {
  TestConfig config_; std::mt19937 rng_; uint32_t tests_done_=0;
  Generator(TestConfig cfg):config_(cfg),rng_(cfg.random_seed) {}
  int32_t generate_int_value(bool is_signed, int element_bits, int test_id) {
    uint32_t mask = (element_bits < 32) ? ((1u << element_bits) - 1u) : 0xFFFFFFFFu;
    std::uniform_int_distribution<uint32_t> int_dist(0, mask);

    int32_t value;
    if (test_id == -1) {
      value = int_dist(rng_);
    } else {
      switch (test_id % 4) {
      case 0: // zero
        value = 0;
        break;
      case 1: // min
        if (is_signed) {
          value = (element_bits < 32) ? (1u << (element_bits - 1)) : 0x80000000u;
        } else {
          value = 0;
        }
        break;
      case 2: // max
        if (is_signed) {
          value = (element_bits < 32) ? ((1u << (element_bits - 1)) - 1u) : 0x7FFFFFFFu;
        } else {
          value = mask;
        }
        break;
      default: // random
        value = int_dist(rng_);
        break;
      }
    }

    if (is_signed) {
      value = vortex::sext<int32_t>(value, element_bits);
    }
    return value;
  }
uint8_t generate_scale(uint32_t fmt) {
    std::uniform_int_distribution<int> coin(0, 1);
    if (fmt == 11) {
      std::uniform_int_distribution<int> any(0, 0x7f);
      std::uniform_int_distribution<int> near(0x30, 0x48);
      return uint8_t(coin(rng_) ? near(rng_) : any(rng_));
    }
    std::uniform_int_distribution<int> any(0, 255);
    std::uniform_int_distribution<int> near(127 - 8, 127 + 8);
    return uint8_t(coin(rng_) ? near(rng_) : any(rng_));
  }
uint32_t generate_fp_value(const std::string &feature, uint32_t exp_bits, uint32_t sig_bits, uint32_t test_id) {
    const uint32_t all_exp = (exp_bits == 32 ? 0xFFFFFFFFu : ((1u << exp_bits) - 1u));
    const uint32_t max_frac = (sig_bits == 32 ? 0xFFFFFFFFu : ((1u << sig_bits) - 1u));

    std::uniform_int_distribution<uint32_t> bit_dist(0, 0xFFFFFFFFu);
    std::uniform_int_distribution<uint32_t> sign_dist(0, 1);
    std::uniform_int_distribution<uint32_t> exp_norm_dist(1, (all_exp > 0 ? all_exp - 1 : 0)); // [1, all_ones-1]
    std::uniform_int_distribution<uint32_t> frac_dist(0, (max_frac > 0 ? max_frac : 0));
    std::uniform_int_distribution<uint32_t> frac_nz_dist(1, (max_frac > 0 ? max_frac : 1)); // nonzero frac

    auto deterministic_sign = [&](uint32_t salt) -> uint32_t {
      // Mix test_id with salt for reproducible sign selection
      return ((test_id ^ (salt * 0x9E3779B9u)) >> 31) & 1u;
    };

    if (feature == "zeros") {
      // +0 and -0; alternate by test_id for coverage
      uint32_t s = (test_id & 1u) ? 1u : 0u;
      return pack_fp_bits(s, 0u, 0u, exp_bits, sig_bits);

    } else if (feature == "normals") {
      if (exp_bits < 2) {
        // No normal numbers exist; fall back to zero
        return pack_fp_bits(0u, 0u, 0u, exp_bits, sig_bits);
      }
      // Spread some directed cases using test_id to hit edges:
      const uint32_t which = test_id % 5u;
      uint32_t s = (which == 0) ? deterministic_sign(1) : sign_dist(rng_);
      uint32_t e, f;
      switch (which) {
      case 0: // random normal
        e = exp_norm_dist(rng_);
        f = frac_dist(rng_);
        break;
      case 1: // smallest normal: exp=1, frac varies
        e = 1u;
        f = frac_dist(rng_);
        break;
      case 2: // largest finite: exp=all_ones-1, frac=all_ones
        e = (all_exp > 0 ? all_exp - 1 : 0);
        f = max_frac;
        break;
      case 3: // near one: exponent=bias, small fraction
        e = (exp_bits ? ((1u << (exp_bits - 1)) - 1u) : 0u);
        f = (sig_bits ? (frac_dist(rng_) & ((1u << (sig_bits > 4 ? 4 : sig_bits)) - 1u)) : 0u);
        break;
      default: // dense random but still normal
        e = exp_norm_dist(rng_);
        f = frac_dist(rng_);
        break;
      }
      return pack_fp_bits(s, e, f, exp_bits, sig_bits);

    } else if (feature == "subnormals") {
      // exp = 0, frac != 0
      if (sig_bits == 0) {
        // No fraction field -> subnormals don't exist; return zero
        return pack_fp_bits(0u, 0u, 0u, exp_bits, sig_bits);
      }
      uint32_t s = sign_dist(rng_);
      // Bias test_id to sometimes hit smallest and largest subnormals
      const uint32_t which = test_id % 3u;
      uint32_t f;
      if (which == 0)
        f = 1u; // smallest subnormal (lsb)
      else if (which == 1)
        f = max_frac; // largest subnormal
      else
        f = frac_nz_dist(rng_);
      return pack_fp_bits(s, 0u, f, exp_bits, sig_bits);

    } else if (feature == "infinities") {
      // exp = all ones, frac = 0
      uint32_t s = deterministic_sign(2);
      uint32_t e = all_exp;
      uint32_t f = 0u;
      return pack_fp_bits(s, e, f, exp_bits, sig_bits);

    } else if (feature == "nans") {
      // exp = all ones, frac != 0. Prefer quiet NaNs by setting MSB of fraction.
      if (sig_bits == 0) {
        // If there is no fraction field, you can't encode a NaN distinct from Inf; return Inf pattern.
        uint32_t s = deterministic_sign(3);
        return pack_fp_bits(s, all_exp, 0u, exp_bits, sig_bits);
      }
      uint32_t s = sign_dist(rng_);
      uint32_t e = all_exp;
      uint32_t quiet_bit = 1u << (sig_bits - 1); // top frac bit
      uint32_t payload = frac_dist(rng_) & (quiet_bit - 1u);
      if (payload == 0u)
        payload = 1u;                   // ensure nonzero payload
      uint32_t f = quiet_bit | payload; // make it a qNaN
      return pack_fp_bits(s, e, f, exp_bits, sig_bits);

    } else {
      std::cout << "Unknown feature: " << feature << std::endl;
      std::abort();
    }
  }
  Result integer_run() {
          Result out; tests_done_=0; const auto& features_to_test=config_.test_features;
          
    std::cout << "Testing integer format" << std::endl;

    // Calculate how many elements we can fit in NUM_REGS VX_CFG_XLEN words
    bool is_signed = int_fmt_sign(config_.fmt_s);
    int element_bits = int_fmt_width(config_.fmt_s);
    int elements_per_word = 32 / element_bits;
    int total_elements = NUM_REGS * elements_per_word;

    // Determine bits per element in vld_mask depending on element packing size
    int vld_bits_per_elem = 32 / elements_per_word / 4;
    uint32_t elem_vld_mask = (1 << vld_bits_per_elem) - 1;

    std::cout << "  elements_per_word=" << elements_per_word << ", total_elements=" << total_elements << std::endl;

    std::uniform_int_distribution<int> sparsity_dist(0, 99);

    for (int test_id = 0; test_id < config_.num_tests; test_id++) {
      std::vector<uint32_t> a_values(total_elements), b_values(total_elements);

      bool a_enable = (test_id % 3) == 0;
      bool b_enable = (test_id % 3) == 1;
      bool c_enable = (test_id % 3) == 2;
      uint32_t current_vld_mask = 0;

      for (int i = 0; i < total_elements; i++) {
        bool is_sparse = (config_.sparsity > 0) && (sparsity_dist(rng_) < config_.sparsity);

        if (is_sparse) {
          a_values[i] = 0;
        } else {
          a_values[i] = generate_int_value(is_signed, element_bits, (a_enable && i == 0) ? test_id : -1);
          current_vld_mask |= (elem_vld_mask << (i * vld_bits_per_elem));
        }
        b_values[i] = generate_int_value(is_signed, element_bits, (b_enable && i == 0) ? test_id : -1);
      }

      int32_t c_value = generate_int_value(true, 32, c_enable ? test_id : -1);

      if (config_.test_id >= 0 && test_id != config_.test_id) {
        continue;
      }

      
          out.rows.push_back(Record{uint32_t(test_id), uint32_t(c_value), current_vld_mask, "integer", a_values, b_values});
          ++tests_done_;
if (config_.test_id >= 0) {
        break;
      }
          }
          out.counter=tests_done_; return out;
        }Result float_run() {
          Result out; tests_done_=0; const auto& features_to_test=config_.test_features;
          
    if (features_to_test.empty()) {
      return out;
    }

    // Calculate how many elements we can fit in NUM_REGS VX_CFG_XLEN words
    int element_bits = float_fmt_width(config_.exp_bits, config_.sig_bits);
    int elements_per_word = 32 / element_bits;
    int total_elements = NUM_REGS * elements_per_word;

    // Determine bits per element in vld_mask depending on element packing size
    int vld_bits_per_elem = 32 / elements_per_word / 4;
    uint32_t elem_vld_mask = (1 << vld_bits_per_elem) - 1;

    const uint32_t NT = config_.num_tests;
    const uint32_t NF = features_to_test.size();
    const uint32_t tests_per_feature = NT / NF + (NT % NF != 0);

  #ifdef USE_FEDP
    TfrFedp fedp(config_.exp_bits, config_.sig_bits, (int)config_.frm, config_.W, config_.renorm);
  #endif

    std::uniform_int_distribution<int> sparsity_dist(0, 99);

    for (int test_id = 0; test_id < NT; test_id++) {
      // select feature to test
      int feature_id = test_id / tests_per_feature;
      if (feature_id >= NF) break; // prevent overflow if division rounding goes out of bounds
      std::string feature = features_to_test[feature_id];

      std::vector<float> a_values_float(total_elements), b_values_float(total_elements);
      std::vector<uint32_t> a_value_hex(total_elements), b_value_hex(total_elements);

      bool a_enable = (test_id % 3) == 0;
      bool b_enable = (test_id % 3) == 1;
      bool c_enable = (test_id % 3) == 2;
      uint32_t current_vld_mask = 0;

      for (int i = 0; i < total_elements; i++) {
        bool is_sparse = (config_.sparsity > 0) && (sparsity_dist(rng_) < config_.sparsity);

        if (is_sparse) {
          a_value_hex[i] = pack_fp_bits(0u, 0u, 0u, config_.exp_bits, config_.sig_bits);
          a_values_float[i] = 0.0f;
        } else {
          a_value_hex[i] = generate_fp_value((a_enable && (i & 0x1) == 0) ? feature : "normals", config_.exp_bits, config_.sig_bits, test_id);
          a_values_float[i] = cvt_custom_to_f32(a_value_hex[i], config_.exp_bits, config_.sig_bits, (int)config_.frm, nullptr);
          current_vld_mask |= (elem_vld_mask << (i * vld_bits_per_elem));
        }

        b_value_hex[i] = generate_fp_value((b_enable && (i & 0x1) == 0) ? feature : "normals", config_.exp_bits, config_.sig_bits, test_id);
        b_values_float[i] = cvt_custom_to_f32(b_value_hex[i], config_.exp_bits, config_.sig_bits, (int)config_.frm, nullptr);
      }

      uint32_t c_value_hex = generate_fp_value(c_enable ? feature : "normals", 8, 23, test_id);
      float c_value_float = bit_cast<float>(c_value_hex);

      // Block scales, one per scale slot; lane l (two per register) takes
      // slot l * SF / lanes, as the datapath maps them.
      const bool mx = is_mx_fmt(config_.fmt_s);
      const int lanes = 2 * NUM_REGS;
      uint8_t sf_slot_a[SF] = {}, sf_slot_b[SF] = {};
      std::vector<uint8_t> sf_lane_a(lanes), sf_lane_b(lanes);
      if (mx) {
        for (int k = 0; k < SF; ++k) {
          sf_slot_a[k] = generate_scale(config_.fmt_s);
          sf_slot_b[k] = generate_scale(config_.fmt_s);
          if (config_.sf_a >= 0) sf_slot_a[k] = uint8_t(config_.sf_a);
          if (config_.sf_b >= 0) sf_slot_b[k] = uint8_t(config_.sf_b);
        }
        for (int l = 0; l < lanes; ++l) {
          sf_lane_a[l] = sf_slot_a[(l * SF) / lanes];
          sf_lane_b[l] = sf_slot_b[(l * SF) / lanes];
        }
      }
      // skip if not in selected test id
      if (config_.test_id >= 0 && test_id != config_.test_id)
        continue;

      if (config_.test_id >= 0 || (test_id % tests_per_feature) == 0) {
        std::cout << "Testing floating-point feature: " << feature << std::endl;
      }

      
          out.rows.push_back(Record{uint32_t(test_id), c_value_hex, current_vld_mask, feature, a_value_hex, b_value_hex, {sf_slot_a,sf_slot_a+SF}, {sf_slot_b,sf_slot_b+SF}, sf_lane_a,sf_lane_b});
          ++tests_done_;
if (config_.test_id >= 0) {
        break;
      }
          }
          out.counter=tests_done_; return out;
        }
};
}

uint64_t unit_configs=0, unit_replays=0, unit_old_mismatch=0;
uint64_t fedp_configs=0, fedp_replays=0, fedp_old_int_overexecution=0, fedp_old_float_match=0;
uint64_t failures=0;
uint32_t witness_unit_full_c=0,witness_unit_old_c=0;
std::vector<std::vector<std::string>> feature_lists={
  {"infinities","nans","subnormals","normals","zeros"},
  {"zeros","normals"}, {"nans","subnormals","zeros"}
};
void require(bool value) { if(!value) ++failures; }
template<int THREADS> void unit_matrix() {
 for(auto fmt:{1u,2u,3u}) for(auto seed:{0u,12345u,0xffffffffu})
 for(auto n:{1u,2u,5u,7u,17u}) for(const auto& features:feature_lists) {
  unit_current::TestConfig cfg; cfg.fmt_s=fmt; cfg.random_seed=seed; cfg.num_tests=n; cfg.features=features;
  unit_base::TestConfig old; old.fmt_s=fmt; old.random_seed=seed; old.num_tests=n; old.features=features;
  auto full=unit_current::Generator<THREADS>(cfg).run();
  auto oldfull=unit_base::Generator<THREADS>(old).run();
  ++unit_configs; require(full.rows.size()==n && full.counter==n); require(full.rows==oldfull.rows);
  for(uint32_t i=0;i<n;++i) {
   cfg.test_id=i; old.test_id=i;
   auto replay=unit_current::Generator<THREADS>(cfg).run();
   auto oldreplay=unit_base::Generator<THREADS>(old).run();
   ++unit_replays;
   require(replay.rows.size()==1 && replay.counter==1 && replay.rows[0]==full.rows[i]);
   bool equal=oldreplay.rows.size()==1 && oldreplay.rows[0]==oldfull.rows[i];
   if(i==0) require(equal); else { require(!equal); unit_old_mismatch+=!equal; }
   if(THREADS==4 && fmt==2 && seed==12345 && n==17 && features==feature_lists[0] && i==1) {
     std::memcpy(&witness_unit_full_c,oldfull.rows[i].sa.data(),4);
     std::memcpy(&witness_unit_old_c,oldreplay.rows[0].sa.data(),4);
   }
  }
 }
}
template<int REGS,int SCALES> void fedp_matrix() {
 for(auto fmt:{1u,2u,3u,4u,5u,8u,9u,10u,11u,17u,18u,19u,20u})
 for(auto seed:{0u,12345u}) for(auto n:{1u,2u,5u,7u,17u}) for(auto sparse:{0,37,100}) {
  bool integer=fmt>=16;
  for(int feature_case=0;feature_case<(integer?1:3);++feature_case)
  for(int fixed=0;fixed<(fedp_current::is_mx_fmt(fmt)?2:1);++fixed) {
   const auto& features=feature_lists[feature_case];
   fedp_current::TestConfig cfg; cfg.fmt_s=fmt; cfg.random_seed=seed; cfg.num_tests=n;
   cfg.test_features=features; cfg.sparsity=sparse; if(fixed) {cfg.sf_a=127;cfg.sf_b=48;}
   fedp_current::init_default_fp_format(fmt,&cfg.exp_bits,&cfg.sig_bits);
   fedp_base::TestConfig old; old.fmt_s=fmt; old.random_seed=seed; old.num_tests=n;
   old.test_features=features; old.sparsity=sparse; if(fixed) {old.sf_a=127;old.sf_b=48;}
   fedp_base::init_default_fp_format(fmt,&old.exp_bits,&old.sig_bits);
   auto run=[&]() { auto g=fedp_current::Generator<REGS,SCALES>(cfg); return integer?g.integer_run():g.float_run(); };
   auto oldrun=[&]() { auto g=fedp_base::Generator<REGS,SCALES>(old); return integer?g.integer_run():g.float_run(); };
   auto full=run(); auto oldfull=oldrun(); ++fedp_configs;
   require(full.rows.size()==n && full.counter==n); require(oldfull.rows.size()==n);
   if(integer) require(full.rows==oldfull.rows);
   else { for(uint32_t i=0;i<n;++i) { auto a=full.rows[i],b=oldfull.rows[i]; a.c=b.c=0; require(a==b); } }
   for(uint32_t i=0;i<n;++i) {
    cfg.test_id=i; old.test_id=i; auto replay=run(); auto oldreplay=oldrun(); ++fedp_replays;
    require(replay.rows.size()==1 && replay.counter==1 && replay.rows[0]==full.rows[i]);
    if(integer) {
      require(oldreplay.rows==oldfull.rows);
      if(n>1) { ++fedp_old_int_overexecution; require(oldreplay.rows.size()>1); }
    } else {
      require(oldreplay.rows.size()==1 && oldreplay.rows[0]==oldfull.rows[i]);
      ++fedp_old_float_match;
    }
   }
  }
 }
}
int main() {
  std::ostringstream diagnostics; auto oldbuf=std::cout.rdbuf(diagnostics.rdbuf());
  unit_matrix<4>(); unit_matrix<8>(); unit_matrix<32>();
  fedp_matrix<1,1>(); fedp_matrix<2,2>(); fedp_matrix<4,4>();
  std::cout.rdbuf(oldbuf);
  std::cout << "{\"unit_configs\":"<<unit_configs<<",\"unit_replays\":"<<unit_replays
    <<",\"unit_old_mismatch\":"<<unit_old_mismatch<<",\"fedp_configs\":"<<fedp_configs
    <<",\"fedp_replays\":"<<fedp_replays<<",\"fedp_old_int_overexecution\":"<<fedp_old_int_overexecution
    <<",\"fedp_old_float_match\":"<<fedp_old_float_match<<",\"failures\":"<<failures
    <<",\"unit_witness_full_c0\":"<<witness_unit_full_c<<",\"unit_witness_old_selected_c0\":"<<witness_unit_old_c
    <<"}\n";
  return failures ? 1 : 0;
}
